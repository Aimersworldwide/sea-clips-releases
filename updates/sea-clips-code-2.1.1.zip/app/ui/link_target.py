"""
=====================================================================
  UI / LINK TARGET            (Google Sheet se "aaj ka target")
  Kaam:
    * Har ghante dekho: kisi campaign ki channel sheet 7 din purani ho
      to channel dobara padho, nayi videos Pending mein (line mein nahi).
    * "Aaj ka target" (maslan Political 300): Pending ka sab se purana
      link line mein, us ki zyada se zyada achhi clips; video khatam ho
      to link Used mein (clips ki ginti ke saath), phir agla. Target
      poora hote hi campaign ki video ruk jati hai (campaign_caps).
  Network ka har kaam alag thread par: app kabhi nahi atakti.
=====================================================================
"""
from __future__ import annotations

import json
import threading
from datetime import datetime

from PySide6.QtCore import QObject, QTimer, Signal

from app.campaign import link_sheets as ls
from app.core.logging_setup import get_logger
from app.core.paths import app_data_dir
from app.queue import caps
from app.queue.store import QueueItem

log = get_logger("link_target")
STATE = "link_targets.json"
MAX_PER_MIN = 8            # had: video ke har minute ki itni clips (tool sirf achhe moments leta hai)
USED_SHARE = 0.5           # (18 Nov, user) adhoori video: aadhi ya zyada clips ban gayin to Used, warna Pending
RETRY_TIMES = 3            # download na ho to itni dafa koshish (beech mein doosre links), phir agle din
RETRY_GAP = 10 * 60        # fail ke baad itne second tak doosre links
PREPARE_AHEAD = 2          # (20 Nov) sheet ke itne agle links pehle se tayyar (download + transcript)


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _load() -> dict:
    try:
        d = json.loads((app_data_dir() / STATE).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(d: dict) -> None:
    p = app_data_dir() / STATE
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, indent=1), encoding="utf-8")
    tmp.replace(p)


def _set_cap(campaign: str, limit: int | None, since: str = "") -> None:
    p = app_data_dir() / caps.CAPS_FILE
    d = caps.load_caps()
    if limit:
        d[campaign] = {"limit": int(limit), "since": since}
    else:
        d.pop(campaign, None)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, indent=1), encoding="utf-8")
    tmp.replace(p)


class LinkTarget(QObject):
    status = Signal(str)
    _done = Signal(object, object)            # (callback, result) thread se wapas UI par

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.text = ""
        self._busy = False
        self._done.connect(lambda cb, res: cb(res))
        self._upcoming: list[dict] = []           # (20 Nov) sheet ke agle links: line inhein pehle se tayyar karti hai
        q = ctx.queue
        q.extra_sources = self.upcoming
        q.itemFinished.connect(lambda item_id, summary: self._item_end(item_id, True))
        q.itemFailed.connect(lambda item_id, *a: self._item_end(item_id, False, a[1] if len(a) > 1 else ""))
        q.clipDone.connect(self._clip_done)
        q.lineChanged.connect(self._line_changed)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.tick)
        self._timer.start(60 * 60 * 1000)           # har ghante: 7 din wali channel jaanch
        QTimer.singleShot(45000, self.tick)
        self.refresh()

    # ------------------------------------------------------------ helpers
    def _device(self) -> str:
        return (getattr(self.ctx.settings, "device_code", "A") or "A").strip().upper()

    def _sheets(self):
        from app.drive.sheets import SheetsClient
        return SheetsClient(self.ctx.drive.client)

    def _bg(self, work, done) -> None:
        def run():
            try:
                res = work()
            except Exception as exc:  # noqa: BLE001 - kabhi app na gire
                log.exception("Link sheet work failed")
                res = exc
            self._done.emit(done, res)
        threading.Thread(target=run, daemon=True, name="link-sheet").start()

    def upcoming(self) -> list[dict]:
        """Line ke liye: sheet ke agle links (sirf chalte target ke)."""
        active = {c for c, t in _load().items() if t.get("active")}
        return [u for u in self._upcoming if u.get("campaign_name") in active]

    def target(self, campaign: str) -> dict:
        return _load().get(campaign, {})

    def progress(self, campaign: str) -> tuple[int, int]:
        t = self.target(campaign)
        if not t.get("goal"):
            return 0, 0
        try:
            made = caps.cap_status(self.ctx.db, campaign) or (0, int(t["goal"]))
            return made[0], int(t["goal"])
        except Exception:  # noqa: BLE001
            return 0, int(t["goal"])

    def refresh(self, text: str = "") -> None:
        if text:
            self.text = text
        else:
            active = [(c, t) for c, t in _load().items() if t.get("active")]
            if active:
                c, t = active[0]
                made, goal = self.progress(c)
                self.text = f"{c}: {made} of {goal} today"
            else:
                self.text = ""
        self.status.emit(self.text)

    # ------------------------------------------------------------ weekly channel check
    def shutdown(self) -> None:
        """App band: ghante wala timer aur baqi kaam ruk jayein."""
        self._closed = True
        self._timer.stop()

    def tick(self) -> None:
        if getattr(self, "_closed", False) or self._busy or not self.ctx.drive.auth.connected:
            return
        # (20 Nov) team: channel sirf malik ka tool (A) padhta hai; doosra tool (B) sirf links uthata hai,
        # warna dono ek hi link do dafa sheet mein daal dete
        dev = self._device()
        tidy = [s for s in ls.load_sources() if s.get("sheet_id") and not s.get(f"tidied_{dev}")]
        if tidy:
            self._tidy(tidy[0])
            return
        due = [s for s in ls.load_sources() if s.get("channel") and ls.scan_due(s)] if dev == "A" else []
        if not due:
            self.kick()
            return
        self.scan(due[0]["campaign"])

    def _tidy(self, s: dict) -> None:
        """(20 Nov) Ek dafa har sheet par: jin links ke clips is tool mein pehle ban chuke, wo Used mein."""
        campaign, dev, db = s["campaign"], self._device(), self.ctx.db
        keep = {ls.video_id(it.source) for it in self.ctx.queue.store.items(0) if it.is_open}
        self._busy = True

        def work():
            return ls.move_made_before(s, self._sheets(), db, dev, keep)

        def done(res):
            self._busy = False
            if isinstance(res, Exception):
                log.warning("Link sheet %s: made-before check failed: %s", campaign, res)
                QTimer.singleShot(10 * 60 * 1000, self.tick)       # baad mein dobara
                return
            ls.update_source(campaign, **{f"tidied_{dev}": _now()})
            if res:
                self.refresh(f"{campaign}: {res} links already clipped moved to Used")
            QTimer.singleShot(2000, self.tick)
        self._bg(work, done)

    def scan(self, campaign: str, done_cb=None) -> None:
        s = ls.source_for(campaign)
        if not s or self._busy:
            return
        self._busy = True
        self.refresh(f"Reading {campaign} channel...")
        db = self.ctx.db
        folder = self._campaign_folder(campaign)

        def work():
            from app.campaign.channel_scan import scan
            return ls.refresh(s, self._sheets(), scan, db, folder, self._device())

        def done(res):
            self._busy = False
            if isinstance(res, Exception):
                self.refresh(f"Channel check failed: {str(res)[:80]}")
            else:
                self.refresh(f"{campaign}: {res} new links in the sheet")
                QTimer.singleShot(3000, self.refresh)
            if done_cb:
                done_cb(res)
            self.kick()
        self._bg(work, done)

    def _campaign_folder(self, campaign: str) -> str:
        """Sheet campaign ke Drive folder mein (jahan Clip Pool hai)."""
        pool = (self.ctx.settings.drive_folders or {}).get(campaign, "")
        if not pool or pool == "none":
            return ""
        try:
            from app.drive.client import API
            r = self.ctx.drive.client._call("GET", f"{API}/files/{pool}",
                                            {"fields": "parents", "supportsAllDrives": "true"})
            return (r.get("parents") or [""])[0]
        except Exception:  # noqa: BLE001
            return ""

    # ------------------------------------------------------------ daily target
    def start(self, campaign: str, goal: int) -> None:
        d = _load()
        since = _now()
        d[campaign] = {"goal": int(goal), "since": since, "active": True, "item": 0, "link": "",
                       "fails": {}, "planned": 0, "made": 0}
        _save(d)
        _set_cap(campaign, int(goal), since)
        log.info("Target: %s %d clips from the sheet", campaign, goal)
        self.refresh()
        self.kick()

    def stop(self, campaign: str) -> None:
        d = _load()
        t = d.get(campaign)
        if t:
            t["active"] = False
            _save(d)
        _set_cap(campaign, None)
        self.refresh()

    def kick(self) -> None:
        """Har chalte target ke liye line mein ek video (sheet ka agla link) ho."""
        if self._busy or getattr(self, "_closed", False):
            return
        for campaign, t in _load().items():
            if not t.get("active"):
                continue
            made, goal = self.progress(campaign)
            if made >= goal:
                self._finish(campaign)
                continue
            item = self.ctx.queue.store.get(int(t.get("item") or 0)) if t.get("item") else None
            if item is not None and item.is_open:
                continue
            self._add_next(campaign)
            return

    def _add_next(self, campaign: str) -> None:
        s = ls.source_for(campaign)
        if not s or not s.get("sheet_id"):
            self.refresh(f"{campaign}: no link sheet yet (Settings, Channel sheets)")
            return
        cid = self.ctx.db.find_campaign(campaign)
        if not cid:
            return
        self._busy = True
        st = _load().get(campaign, {})
        now = datetime.now().timestamp()
        skip = {vid for vid, f in (st.get("fails") or {}).items()
                if int(f.get("n", 0)) >= RETRY_TIMES or now - float(f.get("at", 0)) < RETRY_GAP}
        skip |= set(st.get("cancelled") or [])

        dev = self._device()

        def work():
            # (20 Nov) pehla khula link apne naam (H column); doosra tool usi waqt le gaya ho to agla
            sheets = self._sheets()
            for _ in range(5):
                got = ls.next_links(s, sheets, skip, 1 + PREPARE_AHEAD, dev)
                if not got or ls.claim(s, sheets, got[0][1][0], dev):
                    return got
                skip.add(ls.video_id(got[0][1][0]))
            return []

        def done(res):
            self._busy = False
            if isinstance(res, Exception):
                self.refresh(f"Sheet not reachable: {str(res)[:80]}")
                QTimer.singleShot(5 * 60 * 1000, self.kick)
                return
            if not res:
                self._upcoming = []
                self.refresh(f"{campaign}: no pending links left in the sheet")
                return
            (_, row), later = res[0], res[1:]
            row = (row + [""] * 7)[:7]
            prof = self.ctx.db.get_campaign(cid)
            lo, hi = prof.length_range(self.ctx.settings)
            self._upcoming = [dict(source=r[0], campaign_id=cid, campaign_name=prof.name, profile=prof.to_dict(),
                                   min_len=lo, max_len=hi) for _, r in later]
            try:
                minutes = float(row[3] or 0)
            except ValueError:
                minutes = 0.0
            count = int(min(500, max(30, minutes * MAX_PER_MIN))) if minutes else 200
            item_id = self.ctx.queue.add(QueueItem(source=row[0], title=row[1], campaign_id=cid,
                                                   campaign_name=prof.name, profile=prof.to_dict(),
                                                   clip_count=count, min_len=lo, max_len=hi, preview=False,
                                                   duration=minutes * 60))
            d = _load()
            if campaign in d:
                d[campaign].update(item=item_id, link=row[0], planned=0, made=0, count=count)
                _save(d)
            log.info("Target %s: added %s (%s)", campaign, row[0], row[1][:60])
            self.refresh()
        self._bg(work, done)

    # ------------------------------------------------------------ video ka anjaam -> sheet
    def _clip_done(self, done: int, total: int, info: dict) -> None:
        cur = self.ctx.queue.current
        if cur is None:
            return
        d = _load()
        for t in d.values():
            if t.get("item") == cur.id:
                t["planned"] = max(int(t.get("planned") or 0), int(total or 0) + int(cur.made or 0) - int(done or 0))
                t["made"] = int(cur.made or 0)
                _save(d)
                return

    def _share(self, t: dict, made: int) -> float:
        """Video ka kitna hissa istemal hua: bani clips / is video ki kul banne wali clips (pata na ho to had)."""
        planned = int(t.get("planned") or 0) or int(t.get("count") or 0)
        return made / planned if planned > 0 else 0.0

    def _line_changed(self) -> None:
        """Target wali video line se haath se hata di gayi (cancel): aadhi se zyada bani to Used, warna Pending."""
        d = _load()
        for campaign, t in d.items():
            if t.get("item") and self.ctx.queue.store.get(int(t["item"])) is None:
                made = int(t.get("made") or 0)
                self._settle(campaign, t, made, done=False, note="Cancelled")
                return

    def _settle(self, campaign: str, t: dict, made: int, done: bool, note: str = "") -> None:
        link, s = t.get("link", ""), ls.source_for(campaign)
        d = _load()
        if campaign in d:
            d[campaign].update(item=0, link="", planned=0, made=0)
            if note == "Cancelled":                    # aap ne hataya: aaj ke target mein ye link dobara nahi
                d[campaign].setdefault("cancelled", []).append(ls.video_id(link))
            _save(d)
        if not (s and link):
            self.kick()
            return
        share = 1.0 if done else self._share(t, made)
        sheets = self._sheets()
        if done or share >= USED_SHARE:
            msg = "" if done else f"{note}: {made} clips ({share:.0%} of the video)"
            self._bg(lambda: ls.mark_used(s, sheets, link, made, msg), lambda r: self.kick())
        else:
            log.info("Target %s: %s stays Pending (%d clips, %.0f%%)", campaign, link, made, share * 100)
            dev = self._device()                         # (20 Nov) link wapas khula: doosra tool bhi le sake
            self._bg(lambda: ls.release(s, sheets, link, dev), lambda r: self.kick())

    def _item_end(self, item_id: int, ok: bool, why: str = "") -> None:
        d = _load()
        for campaign, t in d.items():
            if t.get("item") != item_id:
                continue
            item = self.ctx.queue.store.get(item_id)
            made = int(item.made) if item else int(t.get("made") or 0)
            reached = self.progress(campaign)[0] >= int(t.get("goal") or 0)
            status = item.status if item else ("done" if ok else "failed")
            if status in ("paused", "waiting", "stopped") and not reached:
                return                                   # aap ne roka / laptop band: video line mein, link Pending
            if status in ("paused", "waiting", "stopped"):
                keep = dict(t, made=made)
                t["item"] = 0                            # pehle hisaab se hatao (warna line badalna 'cancel' samjha jaye)
                _save(d)
                try:
                    self.ctx.queue.remove(item_id)        # target poora: adhoori video line se hat jaye
                except Exception:  # noqa: BLE001
                    pass
                self._settle(campaign, keep, made, done=False, note="Stopped at the daily target")
                self.refresh()
                return
            if status == "failed" or not ok:
                vid = ls.video_id(t.get("link", ""))
                fails = t.setdefault("fails", {})
                f = fails.setdefault(vid, {"n": 0, "at": 0})
                f["n"], f["at"] = int(f["n"]) + 1, datetime.now().timestamp()
                link, s = t.get("link", ""), ls.source_for(campaign)
                t.update(item=0, link="", planned=0, made=0)
                _save(d)
                try:
                    self.ctx.queue.remove(item_id)        # dobara koshish naye item se (purana fail line mein na rahe)
                except Exception:  # noqa: BLE001
                    pass
                if s and link:
                    sheets = self._sheets()
                    note = f"try {f['n']} of {RETRY_TIMES}" + (f": {why[:60]}" if why else "")
                    self._bg(lambda: ls.mark_failed(s, sheets, link, note), lambda r: self.kick())
                QTimer.singleShot(RETRY_GAP * 1000 + 2000, self.kick)    # baad mein yahi link dobara
                self.refresh()
                return
            self._settle(campaign, t, made, done=True)
            self.refresh()
            return

    def _finish(self, campaign: str) -> None:
        d = _load()
        if campaign in d and d[campaign].get("active"):
            d[campaign]["active"] = False
            _save(d)
            _set_cap(campaign, None)
            made, goal = self.progress(campaign)
            log.info("Target %s reached", campaign)
            self.refresh(f"{campaign}: today's target of {goal} reached")
