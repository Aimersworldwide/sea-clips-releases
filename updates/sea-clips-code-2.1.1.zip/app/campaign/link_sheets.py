"""
=====================================================================
  CAMPAIGN / LINK SHEETS
  Kaam: har campaign ka YouTube channel aur us ki Google Sheet.
    * refresh: channel padh kar nayi lambi videos Pending mein (jo link
      Pending ya Used mein pehle se ho, dobara nahi). Pehli dafa pichle
      4 saal, phir har 7 din.
    * next_link: Pending ka sab se purana link (aaj download fail hua ho
      to agla).
    * mark_used: link Pending se Used mein (tareekh + kitni clips bani).
    * claim / release (20 Nov): do tools (A aur B) ek hi sheet se kaam
      karte hain. Jo tool link uthaye wo Pending ke H column mein likh
      deta hai "In use: Tool A ..."; doosra tool aisa link chhor deta
      hai. 12 ghante purana claim (laptop band / crash) khatam samjha
      jata hai, taake link zaya na ho.
  Sources: app data folder mein link_sources.json.
=====================================================================
"""
from __future__ import annotations

import json
import re
from datetime import date, datetime, timedelta
from pathlib import Path

from app.core.logging_setup import get_logger
from app.core.paths import app_data_dir
from app.drive.sheets import PENDING, USED

log = get_logger("link_sheets")
FILE = "link_sources.json"
SCAN_DAYS = 7
FAIL_NOTE = "Download failed"
CLAIM_COL = "H"                 # Pending ka 8wan column
CLAIM_PREFIX = "In use: Tool "
CLAIM_HOURS = 12                # is se purana claim khatam (us tool ne chhor diya)
CLAIM_SETTLE_S = 3.0            # likhne ke baad itna ruk kar dobara parho (do tools ek saath likhen to)


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def video_id(link: str) -> str:
    m = re.search(r"(?:youtu\.be/|[?&]v=|/shorts/|/live/|/embed/)([A-Za-z0-9_-]{11})", link or "")
    return m.group(1) if m else ""


def load_sources() -> list[dict]:
    try:
        d = json.loads((app_data_dir() / FILE).read_text(encoding="utf-8"))
        return [s for s in d if isinstance(s, dict) and s.get("campaign")] if isinstance(d, list) else []
    except (OSError, ValueError):
        return []


def save_sources(sources: list[dict]) -> None:
    p = app_data_dir() / FILE
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(sources, indent=1, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)


def source_for(campaign: str) -> dict | None:
    return next((s for s in load_sources() if s.get("campaign") == campaign), None)


def update_source(campaign: str, **values) -> dict:
    sources = load_sources()
    s = next((x for x in sources if x.get("campaign") == campaign), None)
    if s is None:
        s = {"campaign": campaign, "channel": "", "years": 4, "min_seconds": 240}
        sources.append(s)
    s.update(values)
    save_sources(sources)
    return s


def scan_due(s: dict) -> bool:
    if not s.get("sheet_id") or not s.get("last_scan"):
        return True
    try:
        return datetime.now() - datetime.fromisoformat(s["last_scan"]) >= timedelta(days=SCAN_DAYS)
    except ValueError:
        return True


def made_before(db, vid: str) -> int:
    if not vid:
        return 0
    with db._conn() as c:
        return int(c.execute("SELECT COUNT(*) FROM clips WHERE source_path LIKE ?", (f"%[{vid}]%",)).fetchone()[0])


def refresh(s: dict, sheets, scan_fn, db, folder_id: str = "", device: str = "A") -> int:
    """Sheet na ho to banao; channel ki nayi videos Pending mein (purani upar). Returns kitni nayi judin."""
    camp = s["campaign"]
    if not s.get("sheet_id") or not sheets.exists(s["sheet_id"]):
        made = sheets.create(f"SEA CLIPS · {camp} Links", folder_id)
        s = update_source(camp, sheet_id=made["id"], sheet_url=made["url"], pending_gid=made["pending_gid"],
                          used_gid=made["used_gid"])
        log.info("Link sheet made for %s: %s", camp, made["url"])
    known = {video_id(r[0]) for tab in (PENDING, USED) for r in sheets.rows(s["sheet_id"], tab) if r}
    vids = scan_fn(s["channel"], float(s.get("years", 4)), int(s.get("min_seconds", 240)))
    new = [v for v in vids if v["id"] not in known]
    new.sort(key=lambda v: v.get("uploaded") or "0000")          # purani pehle (upar), nayi neeche
    today = date.today().isoformat()
    rows, used = [], []
    for v in new:
        n = made_before(db, v["id"])
        if n:                       # (20 Nov) is video ke clips pehle ban chuke: seedha Used, dobara nahi
            used.append([v["link"], v["title"], v["uploaded"], v["minutes"], v["channel"],
                         _now()[:16].replace("T", " "), n, f"Made before (Tool {device}): {n} clips"])
        else:
            rows.append([v["link"], v["title"], v["uploaded"], v["minutes"], v["channel"], today, ""])
    sheets.append(s["sheet_id"], PENDING, rows)
    sheets.append(s["sheet_id"], USED, used)
    update_source(camp, last_scan=_now(), last_added=len(rows))
    log.info("Link sheet %s: %d new links", camp, len(rows))
    return len(rows)


def pending_rows(s: dict, sheets) -> list[tuple[int, list[str]]]:
    """[(sheet row index, row)] Pending ke, sheet ki tarteeb mein (row 1 = pehla link)."""
    return [(k + 1, r) for k, r in enumerate(sheets.rows(s["sheet_id"], PENDING)) if r and video_id(r[0])]


def claim_of(row: list[str]) -> tuple[str, datetime | None]:
    """Row ka claim: (tool code, kab) ya ("", None)."""
    cell = (row + [""] * 8)[7].strip()
    if not cell.startswith(CLAIM_PREFIX):
        return "", None
    rest = cell[len(CLAIM_PREFIX):].split(" since ", 1)
    code = rest[0].strip().upper()
    try:
        when = datetime.fromisoformat(rest[1].strip()) if len(rest) > 1 else None
    except ValueError:
        when = None
    return code, when


def taken_by_other(row: list[str], device: str) -> bool:
    """Doosre tool ne ye link utha rakha hai (aur claim taza hai)?"""
    code, when = claim_of(row)
    if not code or code == (device or "A").upper():
        return False
    return when is None or datetime.now() - when < timedelta(hours=CLAIM_HOURS)


def next_link(s: dict, sheets, skip: set | None = None, device: str = "A") -> tuple[int, list[str]] | None:
    """Pending mein sab se purana (upar wala) link; jo abhi na lena ho (skip: chal raha / abhi abhi fail,
    ya doosre tool ka) wo chhor kar."""
    got = next_links(s, sheets, skip, 1, device)
    return got[0] if got else None


def next_links(s: dict, sheets, skip: set | None = None, n: int = 3,
               device: str = "A") -> list[tuple[int, list[str]]]:
    """(20 Nov) next_link jaisa, magar pehle n links: pehla line mein jata hai, baqi pehle se tayyar hote hain."""
    out = []
    for idx, r in pending_rows(s, sheets):
        if skip and video_id(r[0]) in skip:
            continue
        if taken_by_other(r, device):
            continue
        out.append((idx, r))
        if len(out) >= n:
            break
    return out


def _find(s: dict, sheets, link: str) -> tuple[int, list[str]] | None:
    vid = video_id(link)
    return next(((i, r) for i, r in pending_rows(s, sheets) if video_id(r[0]) == vid), None)


def mark_used(s: dict, sheets, link: str, clips: int, note: str = "") -> bool:
    got = _find(s, sheets, link)
    if got is None:
        return False
    idx, r = got
    r = (r + [""] * 7)[:7]
    sheets.append(s["sheet_id"], USED, [[r[0], r[1], r[2], r[3], r[4], _now()[:16].replace("T", " "),
                                         int(clips), note]])
    sheets.delete_row(s["sheet_id"], int(s.get("pending_gid", 0)), idx)
    return True


def mark_failed(s: dict, sheets, link: str, why: str = "") -> None:
    got = _find(s, sheets, link)
    if got is not None:
        sheets.set_cell(s["sheet_id"], PENDING, f"G{got[0] + 1}",
                        f"{FAIL_NOTE} {date.today().isoformat()}" + (f": {why[:80]}" if why else ""))


def claim(s: dict, sheets, link: str, device: str = "A", settle: float | None = None) -> bool:
    """Link apne naam: H column mein "In use: Tool A since ...". Phir thora ruk kar dobara parho: agar
    doosre tool ne usi waqt likh diya ho to jo aakhir mein likha gaya wohi jeeta, haarne wala chhor de.
    False = link ab hamara nahi (doosre ka, ya Pending mein hi nahi)."""
    import time
    device = (device or "A").upper()
    got = _find(s, sheets, link)
    if got is None or taken_by_other(got[1], device):
        return False
    sheets.set_cell(s["sheet_id"], PENDING, f"{CLAIM_COL}{got[0] + 1}", f"{CLAIM_PREFIX}{device} since {_now()}")
    time.sleep(CLAIM_SETTLE_S if settle is None else settle)
    again = _find(s, sheets, link)
    return again is not None and claim_of(again[1])[0] == device


def release(s: dict, sheets, link: str, device: str = "A") -> None:
    """Link wapas khula (sirf apna claim mitao, doosre ka kabhi nahi)."""
    got = _find(s, sheets, link)
    if got is not None and claim_of(got[1])[0] == (device or "A").upper():
        sheets.set_cell(s["sheet_id"], PENDING, f"{CLAIM_COL}{got[0] + 1}", "")


def move_made_before(s: dict, sheets, db, device: str = "A", keep: set | None = None) -> int:
    """(20 Nov) Ek dafa: Pending ke jin links ki video se is tool mein clips pehle ban chuke, wo Used mein
    (doosra tool unhein dobara na banaye). Chhorta hai: jo abhi kisi tool ke paas hain (In use) aur jo is
    tool ki line mein hain (keep: video ids). Sheet ek dafa parhi, ek dafa likhi, ek dafa rows hatin.
    Returns kitne links gaye."""
    keep = keep or set()
    moved, idxs = [], []
    stamp = _now()[:16].replace("T", " ")
    for idx, r in pending_rows(s, sheets):
        vid = video_id(r[0])
        if vid in keep or claim_of(r)[0]:
            continue
        n = made_before(db, vid)
        if n:
            r = (r + [""] * 7)[:7]
            moved.append([r[0], r[1], r[2], r[3], r[4], stamp, n, f"Made before (Tool {device}): {n} clips"])
            idxs.append(idx)
    if moved:
        sheets.append(s["sheet_id"], USED, moved)
        sheets.delete_rows(s["sheet_id"], int(s.get("pending_gid", 0)), idxs)
        log.info("Link sheet %s: %d links with clips made before moved to Used", s.get("campaign"), len(moved))
    return len(moved)
