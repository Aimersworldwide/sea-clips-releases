"""
=====================================================================
  UI / PAGES / DRIVE CARD          (Settings: Google Drive)
  Kaam: ek dafa ka setup. 1) Google Cloud ki "Desktop app" key file
  chuno, 2) Connect (browser mein apne Drive account se login),
  3) har campaign ka Clip Pool folder check / chuno.
=====================================================================
"""
from __future__ import annotations

import threading
import webbrowser
from pathlib import Path

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtWidgets import (QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout,
                               QLabel, QSpinBox, QVBoxLayout)

from app.drive import client as dc
from app.ui import theme as T
from app.ui.pages.common import info, warn
from app.ui.widgets import Card, field_label, ghost_button, section


class _Relay(QObject):
    done = Signal(object, object)       # (result, error)


def _run(fn, cb) -> None:
    relay = _Relay()
    relay.done.connect(lambda r, e: (cb(r, e), relay.deleteLater()))

    def work():
        try:
            relay.done.emit(fn(), None)
        except Exception as exc:  # noqa: BLE001
            relay.done.emit(None, exc)
    threading.Thread(target=work, daemon=True).start()
    _run._keep = relay                   # zinda rakho jab tak jawab na aaye


class DriveCard(Card):
    def __init__(self, ctx, parent=None):
        super().__init__(parent=parent)
        self.ctx = ctx
        self.body.addWidget(section("GOOGLE DRIVE · CLIP POOL"))
        hint = QLabel("New clips go to each campaign's \"Clip Pool\" folder on your Drive, 50 at a time (or all "
                      "of them when a video ends), and are deleted from this laptop only after Drive has a "
                      "checked copy. Turn it on or off with the Drive upload switch in Studio.")
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{T.FAINT};")
        self.body.addWidget(hint)
        self.state = QLabel()
        self.state.setWordWrap(True)
        self.body.addWidget(self.state)
        row = QHBoxLayout()
        self.key_btn = ghost_button("1.  Choose key file")
        self.key_btn.clicked.connect(self._choose_key)
        self.con_btn = ghost_button("2.  Connect Drive")
        self.con_btn.clicked.connect(self._connect)
        self.fold_btn = ghost_button("3.  Campaign folders")
        self.fold_btn.clicked.connect(self._folders)
        self.dis_btn = ghost_button("Disconnect", danger=True)
        self.dis_btn.clicked.connect(self._disconnect)
        self.team_btn = ghost_button("Import Team Setup")        # (20 Nov) malik ka diya hua setup, ek dafa
        self.team_btn.setToolTip("Adds the team's campaigns, link sheets, Clip Pool folders and key file "
                                 "from a SEA CLIPS Team Setup file (.seaclips).")
        self.team_btn.clicked.connect(self._import_team)
        for b in (self.key_btn, self.con_btn, self.fold_btn, self.dis_btn, self.team_btn):
            row.addWidget(b)
        row.addStretch(1)
        self.body.addLayout(row)
        brow = QHBoxLayout()
        brow.addWidget(field_label("Upload when this many new clips are ready"))
        self.batch = QSpinBox()
        self.batch.setRange(1, 500)
        self.batch.setValue(int(ctx.settings.drive_batch))
        self.batch.valueChanged.connect(self._batch_changed)
        brow.addWidget(self.batch)
        brow.addStretch(1)
        self.body.addLayout(brow)
        self.refresh()

    @property
    def drive(self):
        return self.ctx.drive

    def refresh(self) -> None:
        a = self.drive.auth
        if a.connected:
            self.state.setText(f"<b>Connected:</b> {a.email or 'Google account'}")
        elif dc.has_client():
            self.state.setText("Key file added. Now press <b>Connect Drive</b> and sign in with the Drive "
                               "account that has the Clip Pool folders.")
        else:
            self.state.setText("Not connected. First choose the Google Cloud key file (OAuth client, type "
                               "<b>Desktop app</b>).")
        self.con_btn.setEnabled(dc.has_client() and not a.connected)
        self.fold_btn.setEnabled(a.connected)
        self.dis_btn.setEnabled(a.connected)

    def _batch_changed(self, v: int) -> None:
        self.ctx.settings.drive_batch = int(v)
        self.ctx.save_settings()
        self.drive.refresh()

    def _choose_key(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Google Cloud key file", str(Path.home() / "Downloads"),
                                              "Key file (*.json)")
        if not path:
            return
        try:
            dc.save_client(Path(path))
        except dc.DriveError as exc:
            warn(self, str(exc))
            return
        self.refresh()
        info(self, "Key file added. Now press Connect Drive.")

    def _import_team(self) -> None:
        from app.campaign import team_setup as ts
        path, _ = QFileDialog.getOpenFileName(self, "SEA CLIPS Team Setup file", str(Path.home() / "Downloads"),
                                              "Team Setup (*.seaclips)")
        if not path:
            return
        try:
            done = ts.apply(ts.read(Path(path)), self.ctx.db, self.ctx.settings)
        except Exception as exc:  # noqa: BLE001 - kharab file: kuch na badle, saaf batao
            warn(self, f"The Team Setup was not added.\n\n{exc}")
            return
        self.ctx.save_settings()
        self.ctx.campaignsChanged.emit()
        self.drive.refresh()
        self.refresh()
        step = ("" if self.drive.auth.connected else
                "\n\nLast step: press 2. Connect Drive and sign in with the team Google account.")
        info(self, "Team Setup added:\n\n" + "\n".join(f"• {x}" for x in done) + step)

    def _connect(self) -> None:
        self.con_btn.setEnabled(False)
        self.state.setText("Your browser is open: sign in with the Drive account and allow access. "
                           "Waiting up to 5 minutes...")

        def done(email, err):
            if err:
                warn(self, f"Drive was not connected.\n\n{err}")
            else:
                self.drive.connected(email)
                info(self, f"Google Drive connected: {email}\n\nOnly clips made from now on are uploaded. "
                           "Press 3. Campaign folders to check each campaign's Clip Pool.")
            self.refresh()
        _run(lambda: self.drive.auth.sign_in(webbrowser.open), done)

    def _disconnect(self) -> None:
        self.drive.auth.disconnect()
        self.drive.set_enabled(False)
        self.refresh()

    def _folders(self) -> None:
        self.fold_btn.setEnabled(False)

        def done(pools, err):
            self.fold_btn.setEnabled(True)
            if err:
                warn(self, f"Could not read Drive folders.\n\n{err}")
                return
            FolderDialog(self.ctx, pools, self).exec()
        _run(self.drive.client.clip_pools, done)


class FolderDialog(QDialog):
    """Har campaign ke saamne Drive ka Clip Pool (naam se khud mila, ya haath se chuno)."""

    def __init__(self, ctx, pools: list[dict], parent=None):
        super().__init__(parent)
        from app.drive.sync import match_folder
        self.ctx = ctx
        self.setWindowTitle("Campaign folders on Drive")
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)
        note = QLabel(f"{len(pools)} Clip Pool folder(s) found on Drive. Each campaign's clips go to the "
                      "Clip Pool chosen here.")
        note.setWordWrap(True)
        lay.addWidget(note)
        form = QFormLayout()
        self.boxes: dict[str, QComboBox] = {}
        chosen = dict(ctx.settings.drive_folders or {})
        for name in sorted(ctx.db.campaign_names(include_hidden=False).values(), key=str.lower):
            box = QComboBox()
            box.addItem("Not set (clips stay on the laptop)", "none")
            for p in pools:
                box.addItem(f"{p['campaign'] or '?'} / Clip Pool", p["id"])
            cur = match_folder(name, pools, chosen)
            box.setCurrentIndex(max(0, box.findData(cur)))
            form.addRow(name, box)
            self.boxes[name] = box
        lay.addLayout(form)
        row = QHBoxLayout()                     # apne buttons: text hamesha saaf nazar aaye
        row.addStretch(1)
        cancel = ghost_button("Cancel")
        cancel.clicked.connect(self.reject)
        from PySide6.QtWidgets import QPushButton
        save = QPushButton("Save")
        save.setProperty("role", "gold")
        save.setCursor(Qt.PointingHandCursor)
        save.clicked.connect(self._save)
        row.addWidget(cancel)
        row.addWidget(save)
        lay.addLayout(row)

    def _save(self) -> None:
        self.ctx.settings.drive_folders = {n: b.currentData() for n, b in self.boxes.items()}
        self.ctx.save_settings()
        self.accept()


class ChannelCard(Card):
    """(18 Nov) Campaign ka YouTube channel: us ki sab lambi videos ek Google Sheet (Pending / Used) mein,
    har 7 din nayi khud. Line mein kuch nahi jata; Studio ka "Today from sheet" wahan se uthata hai."""

    def __init__(self, ctx, parent=None):
        super().__init__(parent=parent)
        from PySide6.QtWidgets import QLineEdit
        self.ctx = ctx
        self.body.addWidget(section("CHANNEL SHEETS"))
        hint = QLabel("Give a campaign its YouTube channel. The tool puts every long video (4 min and up, last "
                      "4 years, no Shorts or Lives) in a Google Sheet next to the campaign's Clip Pool, with a "
                      "Pending and a Used tab, and adds new uploads every 7 days. Studio's \"Today from sheet\" "
                      "takes the oldest Pending link first and moves it to Used when done.")
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{T.FAINT};")
        self.body.addWidget(hint)
        row = QHBoxLayout()
        self.camp = QComboBox()
        self.camp.setMinimumWidth(200)
        self.url = QLineEdit()
        self.url.setPlaceholderText("https://youtube.com/@channel")
        self.go = ghost_button("Save and read channel")
        self.go.clicked.connect(self._save)
        row.addWidget(self.camp)
        row.addWidget(self.url, 1)
        row.addWidget(self.go)
        self.body.addLayout(row)
        self.list = QLabel()
        self.list.setWordWrap(True)
        self.list.setOpenExternalLinks(True)
        self.list.setTextFormat(Qt.RichText)
        self.body.addWidget(self.list)
        self.camp.currentIndexChanged.connect(self._picked)
        links = getattr(ctx, "links", None)
        if links is not None:
            links.status.connect(lambda _t: self.refresh())
        self.refresh()

    def refresh(self) -> None:
        from app.campaign.link_sheets import load_sources
        keep = self.camp.currentData()
        self.camp.blockSignals(True)
        self.camp.clear()
        for name in sorted(self.ctx.db.campaign_names(include_hidden=False).values(), key=str.lower):
            self.camp.addItem(name, name)
        self.camp.setCurrentIndex(max(0, self.camp.findData(keep)))
        self.camp.blockSignals(False)
        lines = []
        for s in load_sources():
            when = (s.get("last_scan") or "")[:16].replace("T", " ") or "not read yet"
            sheet = f" · <a href='{s['sheet_url']}' style='color:#E8C46A'>Open sheet</a>" if s.get("sheet_url") else ""
            lines.append(f"<b>{s['campaign']}</b> · {s.get('channel', '')} · last read {when}{sheet}")
        links = getattr(self.ctx, "links", None)
        if links is not None and links.text:
            lines.append(f"<span style='color:{T.FAINT}'>{links.text}</span>")
        self.list.setText("<br>".join(lines) or "No channel yet.")
        self._picked()

    def _picked(self, *_):
        from app.campaign.link_sheets import source_for
        s = source_for(self.camp.currentData() or "")
        self.url.setText(s.get("channel", "") if s else "")

    def _save(self) -> None:
        from app.campaign.link_sheets import update_source
        camp, url = self.camp.currentData() or "", self.url.text().strip()
        if not camp or "youtube.com/" not in url:
            warn(self, "Choose a campaign and paste the channel link (https://youtube.com/@...).")
            return
        if not self.ctx.drive.auth.connected:
            warn(self, "Connect Google Drive first (the sheet is made in that Drive).")
            return
        update_source(camp, channel=url.split("?")[0], last_scan="")
        self.refresh()
        info(self, f"Reading the channel for {camp}. A big channel takes a few minutes; the sheet link "
                   "shows here when it is ready.")
        self.ctx.links.scan(camp, lambda res: self.refresh())
