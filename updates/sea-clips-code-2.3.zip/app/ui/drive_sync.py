"""
=====================================================================
  UI / DRIVE SYNC
  Kaam: Studio ke "Drive upload" switch ke peeche ka kaam. Switch on ho
  to: 50 nayi clips jama hon to ek saath upload; video khatam ho to
  jitni bani hon sab ek saath; har clip Drive par check hone ke baad
  laptop se delete. Upload alag thread par: clips bante rehte hain.
=====================================================================
"""
from __future__ import annotations

import threading

from PySide6.QtCore import QObject, QTimer, Signal

from app.core.logging_setup import get_logger
from app.drive import client as dc
from app.drive import sync

log = get_logger("drive.ui")


class DriveSync(QObject):
    status = Signal(str)
    _done = Signal(object)

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.auth = dc.DriveAuth()
        self.client = dc.DriveClient(self.auth)
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.text = ""             # chhota (Studio ke dabbe mein)
        self.detail = ""           # poori baat (tooltip)
        self._no_folder: set[str] = set()   # (19 Nov) jin campaigns ka Drive folder nahi: ginti mein nahi
        self._retries = 0                   # (19 Nov) error ke baad 1 minute wali dobara koshish (5 tak)
        self._done.connect(self._finished)
        q = ctx.queue
        q.clipDone.connect(lambda *a: self.kick("clip"))
        q.itemFinished.connect(lambda *a: self.kick("video_end"))
        q.itemFailed.connect(lambda *a: self.kick("video_end"))
        self._timer = QTimer(self)
        self._timer.timeout.connect(lambda: self.kick("timer"))
        self._timer.start(10 * 60 * 1000)          # har 10 minute: ruki hui / fail upload dobara
        QTimer.singleShot(20000, lambda: self.kick("timer"))
        self.refresh()

    # ------------------------------------------------------------ state
    @property
    def enabled(self) -> bool:
        return bool(self.ctx.settings.drive_upload)

    @property
    def busy(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def _goes(self, clips: list) -> list:
        """Sirf wo clips jo Drive par ja sakti hain (jis campaign ka folder nahi ya "none", wo laptop par rehti hain)."""
        chosen = dict(self.ctx.settings.drive_folders or {})
        return [c for c in clips if c.campaign not in self._no_folder and chosen.get(c.campaign) != "none"]

    def waiting(self) -> int:
        return len(self._goes(sync.pending(self.ctx.db, self.ctx.settings.drive_since)))

    def refresh(self, text: str = "", detail: str = "") -> None:
        if text:
            self.text, self.detail = text, detail or text
        elif not self.auth.connected:
            self.text, self.detail = "Not connected", "Connect Google Drive in Settings first."
        elif not self.enabled:
            n = self.waiting()
            self.text = f"Off · {n} kept" if n else "Off"
            self.detail = (f"{n} new clip(s) are kept on the laptop; they go to Drive when you turn this on."
                           if n else "Clips stay on the laptop.")
        elif not self.busy:
            n, b = self.waiting(), self.ctx.settings.drive_batch
            self.text = f"On · {n}/{b}"
            self.detail = (f"{n} new clip(s) ready. They go to Drive together at {b}, or when the video ends."
                           + (f" {self.detail}" if self.detail.startswith("Last") else ""))
        self.status.emit(self.text)

    def set_enabled(self, on: bool) -> None:
        s = self.ctx.settings
        s.drive_upload = bool(on)
        self.ctx.save_settings()
        if not on and self.busy:
            self._stop.set()                       # chalti clip poori, phir ruk jao
        self.refresh()
        if on:
            self.kick("toggle")

    def connected(self, email: str) -> None:
        s = self.ctx.settings
        if not s.drive_since:
            from datetime import datetime
            s.drive_since = datetime.now().isoformat(timespec="seconds")   # sirf is ke baad wali clips
        self.ctx.save_settings()
        self.refresh()

    # ------------------------------------------------------------ work
    def kick(self, reason: str) -> None:
        if not self.enabled or not self.auth.connected or self.busy:
            self.refresh() if not self.busy else None
            return
        clips = sync.pending(self.ctx.db, self.ctx.settings.drive_since)
        undel = sync.undeleted(self.ctx.db)
        full = len(self._goes(clips)) >= self.ctx.settings.drive_batch
        line_busy = bool(self.ctx.queue.running)
        if reason == "clip" and not full:
            self.refresh()
            return
        if reason in ("toggle", "timer", "retry") and line_busy and not full and not undel:
            self.refresh()                         # video chal rahi: 50 ya video ke khatam hone ka intezar
            return
        if not self._goes(clips) and not undel:
            self.refresh()
            return
        self._stop = threading.Event()
        chosen = dict(self.ctx.settings.drive_folders or {})
        db = self.ctx.db

        def prog(i: int, n: int, label: str) -> None:
            if n:
                self.text = f"Uploading {min(i + 1, n)}/{n}"
                self.status.emit(self.text)

        def run() -> None:
            try:
                res = sync.upload_batch(db, self.client, clips, chosen, self._stop, prog)
            except Exception as exc:  # noqa: BLE001 - upload kabhi app nahi girata
                log.exception("Drive batch crashed")
                res = exc
            self._done.emit(res)

        self.text = f"Uploading 1/{len(clips)}" if clips else "Cleaning up"
        self.status.emit(self.text)
        log.info("Drive: batch of %d (%s)", len(clips), reason)
        self._thread = threading.Thread(target=run, name="drive-upload", daemon=True)
        self._thread.start()

    def _finished(self, res) -> None:
        self._thread = None
        if not isinstance(res, Exception):
            self._no_folder = set(res.no_folder)
        failed = isinstance(res, Exception) or bool(res.failed)
        if failed and self.enabled and self._retries < 30:
            self._retries += 1                     # (2.3) internet ka jhatka: har 20 s dobara (~10 min tak)
            QTimer.singleShot(20 * 1000, lambda: self.kick("retry"))
        elif not failed:
            self._retries = 0
        if isinstance(res, Exception):
            self.refresh("Upload error", f"Last batch stopped: {res}")
        else:
            bits = [f"{res.uploaded} uploaded to Drive and deleted from the laptop"]
            if res.failed:
                bits.append(f"{len(res.failed)} will retry ({res.failed[0][:120]})")
            if res.no_folder:
                bits.append("no Clip Pool folder for " + ", ".join(res.no_folder) + " (Settings, Campaign folders)")
            short = f"Sent {res.uploaded}" + (f" · {len(res.failed)} retry in 1 min" if res.failed else "") \
                + (" · no folder" if res.no_folder else "")
            self.refresh(short, "Last batch: " + "; ".join(bits) + ".")
        try:
            self.ctx.clipsChanged.emit()
        except Exception:  # noqa: BLE001
            pass
        # 50 se zyada jama ho gayi hon (upload ke dauran bani) to foran agla batch
        if self.enabled and not isinstance(res, Exception) and not res.stopped \
                and self.waiting() >= self.ctx.settings.drive_batch:
            QTimer.singleShot(2000, lambda: self.kick("clip"))

    def shutdown(self) -> None:
        self._stop.set()
