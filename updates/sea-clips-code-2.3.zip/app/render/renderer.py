"""
=====================================================================
  RENDER / RENDERER  (one clip = one ffmpeg run)
  Kaam: ek clip = ek ffmpeg run (framing, captions, encoding).
  Steps inside one filtergraph:
    1. keep segments   (trim + 15 ms audio fades + concat)
    2. framing          per camera shot (stack top/bottom, face crop,
                        blur fit) -> 1080x1920 or 1920x1080
    3. colour look      (subtle)
    4. light sharpen    (cas 0.35, faces stay natural)
    5. captions         (libass, our fonts)
    6. audio            (beep/mute -> one volume change towards -14 LUFS)
  Encoding (same on every laptop, so quality is identical):
    x264 high profile, CRF 16, preset slow, aq-mode 3 (no colour
    banding in dark backgrounds), slightly sharper edges (deblock -1),
    BT.709, AAC 320k 48 kHz, +faststart for instant playback.

  ROMAN URDU KHULASA
    * Ek clip = ek ffmpeg run. Kaatna, frame karna, rang, captions,
      aawaz, sab ek hi dafa.
    * YouTube HQ (on/off): clip 1440x2560 mein banta hai taake YouTube
      behtar compression (VP9) de. Sirf YouTube pe faida.
    * GPU Fast encoding (on/off, sirf GPU wale laptop pe): NVENC se
      2 se 3 guna tez, quality thori kam. Fail ho to khud x264 pe.
    * GPU decode: GPU wale laptop pe video GPU se parhi jati hai
      (quality pe koi asar nahi). Fail ho to khud CPU pe.
=====================================================================
"""
from __future__ import annotations

import os
import shutil
import threading
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Callable

from app.captions.builder import build_ass
from app.captions.fonts import font_dir_for
from app.captions.styles import cover_version, get_style, with_accent, with_palette
from app.core.logging_setup import get_logger
from app.edit.looks import look_filter
from app.media.ffmpeg_tools import Cancelled, escape_filter_path, run_ffmpeg
from app.media.probe import SourceInfo
from app.render.audio import censor_filters, limiter_correction_db, loudness_filter, measure_loudness
from app.edit.motion import punch_times, zoom_filter
from app.render.logo import brand_overlay_graph, source_logo_graph, ticker_blur_graph
from app.render.framing import FIT_LIFT, OUTPUTS, fit_bottom, FramePlan, face_heights, framing_filter, piece_filter
from app.render.timeline import Segment, total_duration
from app.transcribe.models import Word

log = get_logger("render")

BAR_HEIGHT = 12      # px, progress bar (re-edit variant)

# ---------------------------------------------------------------------
#  Quality presets (x264). "high" har asli clip ke liye.
# ---------------------------------------------------------------------
QUALITY = {
    # name: (preset, crf)
    # (21 Nov, 2.3) medium/13: VMAF 97.77 vs 97.71 (slow/14) aur captions wali clip par 98.13 vs 98.08,
    # encoding ~30-36% tez, file ~15-18% badi. Quality kam nahi (user ki shart).
    "high": ("medium", 13),
    "balanced": ("medium", 18),
    "draft": ("veryfast", 22),   # only used by tests / previews
}
X264_PARAMS = "aq-mode=3:deblock=-1,-1"     # andhere background mein patti nahi, text ke kinare saaf

# ---------------------------------------------------------------------
#  YouTube HQ: final size (sirf jab option on ho)
# ---------------------------------------------------------------------
HQ_OUTPUTS = {"9:16": (1440, 2560), "16:9": (2560, 1440)}



# (18 Nov, user) viral reference clips jaisi aawaz (reference -9.7 LUFS). Aawaz pehle -14 par aati hai, phir
# halka compressor (dheemi / tez barabar), pakka gain, aur limiter (kabhi phatti nahi).
# Test samples ke liye ye teen cheezen environment se badli ja sakti hain (default wahi jo tool mein hai):
#   AIMERS_LOUD_GAIN (dB), AIMERS_LOUD_TONE (pehle lagne wala filter), AIMERS_LOUD_MUSIC (music level)
LOUD_GAIN = float(os.environ.get("AIMERS_LOUD_GAIN", "4.8"))     # (19 Nov, user) 4.8 dB = reference ka 60% (~-14 LUFS, YouTube ka level)
LOUD_TONE = os.environ.get("AIMERS_LOUD_TONE", "highshelf=f=4000:g=-4").strip(",")   # aawaz narm, reference jaisi
LOUD_CHAIN = ("," + (LOUD_TONE + "," if LOUD_TONE else "")
              + "acompressor=threshold=-20dB:ratio=2:attack=8:release=160:makeup=1,"
              f"volume={LOUD_GAIN:.2f}dB,alimiter=limit=0.85:attack=2:release=50:level=0")

# (18 Nov) music aawaz ke peeche: halki, bolte waqt kaafi dabi, do lafzon ke beech na uthe (release 1 s)
DUCK = "threshold=0.02:ratio=8:attack=15:release=900:knee=4"
# (18 Nov, user) reference jaisa: music poore clip mein saath chalta hai (aawaz se ~10 dB neeche), bolte waqt
# sirf thoda sa dabta hai
LOUD_DUCK = "threshold=0.05:ratio=2:attack=30:release=800"
LOUD_MUSIC = float(os.environ.get("AIMERS_LOUD_MUSIC", "0.25"))   # (19 Nov) music aawaz ka ~22%, reference jitna


def music_bed(src: str, key: str, vol: float, duration: float, out: str, duck: str = DUCK) -> list[str]:
    """Filters for the background music: level, fade in / out, ducked under the voice (key)."""
    vol = max(0.02, min(0.6, float(vol)))
    return [f"[{src}]aformat=sample_rates=48000:channel_layouts=stereo,volume={vol:.3f},"
            f"afade=t=in:d=0.8,afade=t=out:st={max(0.0, duration - 1.5):.3f}:d=1.5[{out}_m]",
            f"[{out}_m][{key}]sidechaincompress={duck}[{out}]"]

def final_size(ratio: str, hq: bool) -> tuple[int, int]:
    """Clip ka aakhri size: normal 1080p, YouTube HQ on ho to 1440p."""
    return HQ_OUTPUTS[ratio] if hq else OUTPUTS[ratio]


# ---------------------------------------------------------------------
#  NVENC (GPU Fast encoding): best quality settings, zyada bitrate
# ---------------------------------------------------------------------
def video_codec_args(quality: str, gpu: bool, fps: float, height: int) -> list[str]:
    """Encoder ke arguments. gpu=True: NVENC; warna x264 (default, best quality)."""
    level = "5.1" if height > 1920 or (height > 1080 and fps > 30.5) else "4.2"
    gop = str(max(1, int(round(fps))))          # har 1 second keyframe (platforms ke liye behtar)
    if gpu:
        return ["-c:v", "h264_nvenc", "-preset", "p7", "-tune", "hq", "-rc", "vbr", "-cq", "15",
                "-b:v", "0", "-maxrate", "40M", "-bufsize", "80M", "-spatial-aq", "1", "-temporal-aq", "1",
                "-profile:v", "high", "-level:v", level, "-pix_fmt", "yuv420p", "-g", gop, "-bf", "3"]
    preset, crf = QUALITY.get(quality, QUALITY["high"])
    return ["-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-x264-params", X264_PARAMS,
            "-profile:v", "high", "-level:v", level, "-pix_fmt", "yuv420p", "-g", gop, "-bf", "3"]


@dataclass
class RenderJob:
    source: SourceInfo
    segments: list[Segment]           # source time
    words: list[Word]                 # clip time
    masked: set[int]                  # indexes into `words` shown masked
    censor: list[tuple[float, float]] # clip-time intervals to beep/mute
    out_path: Path
    ratio: str = "9:16"
    frame: FramePlan | None = None
    pieces: list | None = None        # layout pieces (source time); None -> `frame` for the whole clip
    caption_y: float | None = None    # caption block centre (0..1); None -> style default
    platform: str = ""                # tiktok: captions TikTok ke buttons / username / post caption se door
    bar: str = ""                     # progress bar: "" | top | bottom (caption accent colour)
    threads: int = 0                  # encoder threads (0 = ffmpeg decides); set when clips run in parallel
    logo_box: object = None           # app.render.logo.LogoBox of the channel logo in the source
    logo_mode: str = "keep"           # keep | blur | replace
    brand: object = None              # campaign logo (config.OverlaySpec) or None
    zoom: str = ""                    # "" | punch | push (Phase 3)
    hook: str = ""                    # hook title text ("" = none)
    sfx: str = ""                     # sound effects family ("" = off): soft | punchy | clean
    captions: bool = True
    caption_style: str = "yellow_pop"
    accent: str = ""                  # bolte lafz ka rang is clip ke liye ("" = style ka apna)
    palette: str = ""                 # rangeen captions ki palette (styles.PALETTES), "" = style ka apna
    hook_box: bool = True             # hook dabbe pe (True) ya sirf outline text (False)
    hook_color: str = ""              # hook dabbe ka rang
    hook_seconds: float = 0.0         # hook kitni der (0 = aam HOOK_SECONDS); Super lamba
    hook_force: bool = False          # Super: saaf jagah na mile tab bhi zaroor dikhe
    cover_subs: bool = False          # source mein subtitles hain: captions ke peeche gehra box
    caption_pos: str = ""             # "" | high | low  (style ki apni jagah se thoda upar / neeche)
    caption_mode: str = ""            # "" | word  (1-2 lafz ek waqt)
    caption_size: float = 1.0         # captions ka size (0.92 .. 1.08)
    name_card: str = ""               # shuru mein naam patti ("Ben Shapiro  |  Oct 2026"), "" = nahi
    entrance: str = ""
    look: str = ""
    sharpen: bool = True
    loudness: bool = True
    censor_mode: str = "beep"
    quality: str = "high"
    temp_dir: Path | None = None
    hq: bool = False                  # YouTube HQ: 1440x2560 output
    gpu_encode: bool = False          # GPU Fast encoding (NVENC); fails -> x264
    gpu_decode: bool = False          # GPU se video parhna; fails -> CPU
    title_card: str = ""              # safed title card ka title ("" = poori screen video)
    title_emoji: str = ""             # title ke aakhir ka emoji (assets/emoji/<naam>.png)
    channel_name: str = ""            # title card ke upar channel ka naam ("" = nahi)
    card_offset: int = -1             # title card: 9:16 frame se kahan se kaatna (px), -1 = beech se
    disclosure: str = ""              # neeche gehri patti mein lafz ba lafz disclosure ("" = nahi); title card ki jagah
    disclosure_top: bool = False      # patti upar (jab video ka apna purana disclosure upar likha ho)
    disclosure_cover: float = 0.0     # purana disclosure dhakne ke liye patti kam az kam itni unchi (frame ka hissa)
    disclosure_place: str = "bottom"  # below_video (video ke neeche, app ke buttons se upar) | top | bottom
    disclosure_region: tuple[float, float] | None = None   # khaali jagah (y0, y1) jo pehle naap li (frame ka hissa)
    blur_bands: tuple = ()            # news ki chalti patti(yan) (y0, y1) source frame mein: blur
    background: str = "blur"          # poori video beech mein ho to peechha: blur | black
    comp_inputs: list = field(default_factory=list)   # sawal jawab upar neeche: saathi shots (start, lambai)
    level_voices: bool = False        # dheemi aur oonchi aawazein barabar (speech leveler)
    classic: str = ""                 # (17 Nov) Classic: square video beech mein, patti ka rang black | white ("" = nahi)
    classic_title: str = ""           # Classic: upar wali patti ka title
    classic_key: str = ""             # (18 Nov) title ka ahem lafz (rangeen)
    classic_caption: str = "classic_caps"   # Classic captions ka andaaz (classic_caps / classic_ref, baari baari)
    classic_super: str = ""           # (19 Nov, Diamonds) Classic ki neeche wali patti mein campaign ka Super
    loud: bool = False                # (18 Nov) reference jaisi oonchi aawaz (~-10 LUFS, dabi hui)
    music: str = ""                   # background music file ("" = nahi)
    music_offset: float = 0.0         # gaane mein kahan se shuru (sec)
    music_volume: float = 0.20        # music ki oonchai (aawaz ke neeche, bolte waqt aur dheemi)
    fit_zoom: float = 1.0             # poori video (fit) kitni bari: kaali pattiyan chhoti (campaign "fit_bars")


def _segment_graph(segments: list[Segment], clip_start: float, video: bool = True,
                   vlabels: list[str] | None = None, srcs: list[tuple[str, str, float]] | None = None,
                   select: bool = False) -> str:
    """
    Trim each kept piece (times relative to the input seek point) and
    join them. Outputs [vcat] (when video) and [acat].
    Every audio piece gets 15 ms fades so joins never click.
    srcs: har tukre ka (video input, audio input, input ka shuru); cold
    open ka tukra apne alag input se aata hai (memory kam).
    select (20 Nov): ek input ke lagataar tukron ki video ek hi select se. Har tukre ki alag trim mein
    ffmpeg baad wale tukron ke saare frames memory mein rakhta hai (60fps 1080p, 30 s = ~6 GB); select
    mein ek hi dhaara, koi jama nahi. Aawaz pehle jaisi (har tukre par fade).
    """
    if video and select and not vlabels and len(segments) > 1:
        aud = _segment_graph(segments, clip_start, video=False, srcs=srcs)
        groups: list[tuple[str, float, list[tuple[float, float]]]] = []
        for i, seg in enumerate(segments):
            vsrc, _asrc, base = srcs[i] if srcs else ("0:v", "0:a", clip_start)
            a, b = seg.start - base, seg.end - base
            if groups and groups[-1][0] == vsrc and a >= groups[-1][2][-1][1] - 1e-6:
                groups[-1][2].append((a, b))
            else:
                groups.append((vsrc, base, [(a, b)]))
        parts, labels = [], []
        for k, (vsrc, _base, spans) in enumerate(groups):
            cond = "+".join(f"gte(t,{a:.3f})*lt(t,{b:.3f})" for a, b in spans)
            parts.append(f"[{vsrc}]select='{cond}',setpts=N/(FRAME_RATE*TB)[vg{k}]")
            labels.append(f"[vg{k}]")
        if len(labels) == 1:
            parts.append(f"{labels[0]}null[vcat]")
        else:
            parts.append(f"{''.join(labels)}concat=n={len(labels)}:v=1:a=0[vcat]")
        return ";".join(parts) + ";" + aud
    parts, labels = [], []
    for i, seg in enumerate(segments):
        vsrc, asrc, base = srcs[i] if srcs else ("0:v", "0:a", clip_start)
        a, b = seg.start - base, seg.end - base
        d = b - a
        fade = min(0.015, d / 4)
        if video:
            src = vlabels[i] if vlabels else vsrc
            parts.append(f"[{src}]trim=start={a:.3f}:end={b:.3f},setpts=PTS-STARTPTS[v{i}]")
        parts.append(
            f"[{asrc}]atrim=start={a:.3f}:end={b:.3f},asetpts=PTS-STARTPTS,"
            f"afade=t=in:d={fade:.3f},afade=t=out:st={max(0.0, d - fade):.3f}:d={fade:.3f}[a{i}]"
        )
        labels.append(f"[v{i}][a{i}]" if video else f"[a{i}]")
    n = len(segments)
    if n == 1:
        parts.append(("[v0]null[vcat];" if video else "") + "[a0]anull[acat]")
    elif video:
        parts.append(f"{''.join(labels)}concat=n={n}:v=1:a=1[vcat][acat]")
    else:
        parts.append(f"{''.join(labels)}concat=n={n}:v=0:a=1[acat]")
    return ";".join(parts)


def video_pieces(segments: list[Segment], pieces: list) -> list[tuple[float, float, object]]:
    """Cut the kept segments at shot changes: [(start, end, piece)] in source time.
    The first and last piece are stretched so no picture is ever dropped."""
    lo, hi = min(s.start for s in segments), max(s.end for s in segments)
    out = []
    for seg in segments:
        for k, p in enumerate(pieces):
            p_start = min(p.start, lo) if k == 0 else p.start
            p_end = max(p.end, hi) if k == len(pieces) - 1 else p.end
            a, b = max(seg.start, p_start), min(seg.end, p_end)
            if b - a > 0.001:
                out.append((a, b, p))
    return out


def _still_trim(a: float, b: float, piece, clip_start: float) -> str:
    """
    Trim [a, b] (source time). Show graphic ki slide in / out animation
    wale hisse (piece.still_until / still_from) ki jagah saaf frame
    rokta hai (tpad clone), lambai bilkul wohi rehti hai.
    """
    hold_in = max(0.0, min(b, getattr(piece, "still_until", 0.0) or 0.0) - a)
    still_from = getattr(piece, "still_from", 0.0) or 0.0
    hold_out = max(0.0, b - max(a, still_from)) if still_from else 0.0
    if hold_in + hold_out > (b - a) - 0.2:          # trim ka zyada tar hissa animation: jaisa hai waisa
        hold_in = hold_out = 0.0
    hold_in = 0.0 if hold_in < 0.02 else hold_in
    hold_out = 0.0 if hold_out < 0.02 else hold_out
    f = f"trim=start={a + hold_in - clip_start:.3f}:end={b - hold_out - clip_start:.3f},setpts=PTS-STARTPTS"
    if hold_in or hold_out:
        f += (",tpad=" + ":".join(x for x in (
            f"start_mode=clone:start_duration={hold_in:.3f}" if hold_in else "",
            f"stop_mode=clone:stop_duration={hold_out:.3f}" if hold_out else "") if x))
    return f


def piece_trims(segments: list[Segment], pieces: list) -> list[tuple[float, float, object, int]]:
    """video_pieces jaisa, saath mein tukre ka number (kaun sa input)."""
    lo, hi = min(s.start for s in segments), max(s.end for s in segments)
    out = []
    for i, seg in enumerate(segments):
        for k, p in enumerate(pieces):
            p_start = min(p.start, lo) if k == 0 else p.start
            p_end = max(p.end, hi) if k == len(pieces) - 1 else p.end
            a, b = max(seg.start, p_start), min(seg.end, p_end)
            if b - a > 0.001:
                out.append((a, b, p, i))
    return out


_GPU_SLOT = threading.Semaphore(1)     # (18 Nov) GPU decoder ek waqt mein ek clip (4 GB GTX 1050 Ti)
_GPU_FAILS: dict[str, int] = {}         # video -> GPU kitni dafa fail hua (is process mein)
GPU_FAIL_LIMIT = 2
GPU_DECODE_SKIP = ("av1",)          # (18 Nov) in codecs ka GPU decode is laptop par hota hi nahi


def _framed_video_graph(job: RenderJob, clip_start: float, vlabels: list[str] | None = None,
                        srcs: list[tuple[str, str, float]] | None = None) -> str:
    """Video trims, each framed for its own shot, joined -> [vframed]."""
    parts, labels = [], []
    job.comp_inputs = []
    comp_uses: dict[int, tuple] = {}
    for i, (a, b, piece, k) in enumerate(piece_trims(job.segments, job.pieces)):
        vsrc, _, base = srcs[k] if srcs else ("0:v", "0:a", clip_start)
        src = vlabels[i] if vlabels else vsrc
        parts.append(f"[{src}]{_still_trim(a, b, piece, base)}[pv{i}]")
        comp = ""
        if piece.mode == "qa" and getattr(piece, "comp", ()) and job.ratio == "9:16" and not getattr(job, "classic", ""):
            comp = f"pc{i}"
            comp_uses.setdefault(id(piece), (piece, []))[1].append((i, a, b))
        if getattr(job, "classic", "") and job.ratio == "9:16":
            from app.render.framing import classic_filter
            parts.append(classic_filter(job.source, piece, f"pv{i}", f"pf{i}", t0=a, bg=job.classic))
        else:
            parts.append(piece_filter(job.source, job.ratio, piece, f"pv{i}", f"pf{i}", f"p{i}", t0=a,
                                      bg=job.background, comp_label=comp, fit_zoom=getattr(job, "fit_zoom", 1.0)))
        labels.append(f"[pf{i}]")
    parts = _companion_graph(job, comp_uses) + parts
    if len(labels) == 1:
        parts.append(f"{labels[0]}null[vframed]")
    else:
        parts.append(f"{''.join(labels)}concat=n={len(labels)}:v=1:a=0[vframed]")
    return ";".join(parts)


# ---------------------------------------------------------------------
#  Sawal jawab: saathi zoom (doosra hissa) ke tukre
#  Kaam: piece ka doosra zoom (piece.comps) USI lamhe se: apna input usi
#  waqt par, logo / ticker wahi chhupao jo asal video mein, apne chehre par
#  crop (aadhe ka size). Live hissa aur saathi bilkul ek hi waqt ke frames.
#  Purane (kisi aur waqt wale) saathi ke liye hifazat: kam pade to thora
#  ahista (COMP_SLOW tak), phir aakhri frame; kabhi loop nahi.
# ---------------------------------------------------------------------
STILL_ZOOM = 0.08            # ruki tasveer poori lambai mein itna (8%) qareeb aati hai
COMP_SLOW = 1.35             # sunne wala shot itna ahista chal sakta hai (nazar nahi aata)


def _companion_graph(job: RenderJob, comp_uses: dict) -> list[str]:
    from app.render.framing import OUTPUTS, ZOOM_SHARPEN, rate_expr, slot_crop
    out: list[str] = []
    fps = job.source.fps if job.source.fps > 0 else 30
    dur = job.source.duration or 0.0
    sw, sh = job.source.display_size
    out_w, out_h = OUTPUTS["9:16"]
    slot_h = out_h // 2
    for piece, uses in comp_uses.values():
        need = max(b for _, _, b in uses) - piece.start + 0.05      # piece mein saathi kitni der chahiye
        chain = list(getattr(piece, "comps", ()) or ()) or [piece.comp]
        segs = []
        for c in chain:
            cs, ce = float(c[0]), float(c[1])
            still = len(c) >= 9 and c[8] == "still"
            if dur and not still:
                ce = min(ce, dur - 0.15)                           # video ke bilkul aakhir se aage seek nahi
            if dur and still:
                cs = min(cs, dur - 0.5)
            if ce - cs >= 0.2:
                segs.append((cs, ce, c))
        if not segs:
            segs = [(float(piece.comp[0]), float(piece.comp[0]) + 0.5, piece.comp)]
        total = sum(ce - cs for cs, ce, _ in segs)
        slow = min(COMP_SLOW, max(1.0, need / total)) if total > 0 else 1.0
        hold = max(0.0, need - total * slow)
        tag0 = f"cq{len(job.comp_inputs)}"
        labels = []
        for cs, ce, c in segs:
            j = len(job.comp_inputs)
            span = ce - cs
            still = len(c) >= 9 and c[8] == "still"
            job.comp_inputs.append((cs, 0.4 if still else span + 0.1))
            cur, tag = f"@COMP{j}:v", f"cq{j}"
            if job.logo_box is not None and job.logo_mode in ("blur", "replace"):
                from app.render.logo import source_logo_graph
                out.append(source_logo_graph(job.logo_box, sw, sh, "blur", cur, f"{tag}lg", tag=f"{tag}l"))
                cur = f"{tag}lg"
            if job.blur_bands:
                from app.render.logo import ticker_blur_graph
                out.append(ticker_blur_graph(cur, f"{tag}tk", job.blur_bands, sw, sh, tag=f"{tag}t"))
                cur = f"{tag}tk"
            x0, x1 = (c[5], c[6]) if len(c) >= 7 else (-1.0, -1.0)
            cc = slot_crop(job.source, c[2], c[3], c[4], out_w, slot_h, x0, x1, c[7] if len(c) >= 8 else 1.0)
            sharp = ",unsharp=5:5:0.55:5:5:0.0" if slot_h / cc[1] > ZOOM_SHARPEN else ""
            if still:
                # ruki hui tasveer (munh kabhi nahi hilta) + halka slow zoom, poori lambai tak
                nfr = max(1, int(round(span * fps)))
                out.append(f"[{cur}]trim=end_frame=1,setpts=PTS-STARTPTS,"
                           f"crop={cc[0]}:{cc[1]}:{cc[2]}:{cc[3]},scale={out_w * 2}:{slot_h * 2}:flags=lanczos,"
                           f"zoompan=z='min(1+{STILL_ZOOM / max(1, nfr):.6f}*on,{1 + STILL_ZOOM:.3f})':"
                           f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={nfr}:s={out_w}x{slot_h}:fps={rate_expr(fps)},"
                           f"setsar=1,format=yuv420p[{tag}z]")
            else:
                out.append(f"[{cur}]trim=end={span:.3f},setpts=PTS-STARTPTS,"
                           f"crop={cc[0]}:{cc[1]}:{cc[2]}:{cc[3]},scale={out_w}:{slot_h}:flags=lanczos{sharp},"
                           f"setsar=1,fps={rate_expr(fps)},format=yuv420p[{tag}z]")
            labels.append(f"[{tag}z]")
        chain_label = labels[0] if len(labels) == 1 else None
        if chain_label is None:
            out.append(f"{''.join(labels)}concat=n={len(labels)}:v=1:a=0[{tag0}cat]")
            chain_label = f"[{tag0}cat]"
        post = []
        if slow > 1.001:
            post.append(f"setpts={slow:.4f}*PTS,fps={rate_expr(fps)}")
        if hold > 0.01:
            post.append(f"tpad=stop_mode=clone:stop_duration={hold + 0.1:.3f}")
        tail = ",".join(post) if post else "null"
        out.append(f"{chain_label}{tail}"
                   + (f",split={len(uses)}" + "".join(f"[{tag0}s{n}]" for n in range(len(uses)))
                      if len(uses) > 1 else f"[{tag0}s0]"))
        for n, (i, a, b) in enumerate(uses):
            off = max(0.0, a - piece.start)
            out.append(f"[{tag0}s{n}]trim=start={off:.3f}:end={off + (b - a):.3f},setpts=PTS-STARTPTS[pc{i}]")
    return out


# Har bolne wale ki aawaz barabar: ~2 s ki khidki mein dheemi aawaz (door ka mic) upar, oonchi
# neeche; khamoshi / shor ko nahi uthata (max 12 dB). Loudness baad mein -14 LUFS par.
VOICE_LEVELER = "dynaudnorm=f=150:g=15:p=0.85:m=4:r=0.5:s=8"


def _audio_graph(job: RenderJob, duration: float, in_label: str) -> tuple[str, str]:
    """Censoring (beep/mute). Returns (graph, out_label)."""
    mute, tone = censor_filters(job.censor, job.censor_mode, duration)
    parts = []
    level = f",{VOICE_LEVELER}" if getattr(job, "level_voices", False) else ""
    if mute:
        parts.append(f"[{in_label}]{mute},aformat=sample_rates=48000:channel_layouts=stereo{level}[voice]")
    else:
        parts.append(f"[{in_label}]aformat=sample_rates=48000:channel_layouts=stereo{level}[voice]")
    if tone:
        parts.append(f"{tone}[tone]")
        parts.append("[voice][tone]amix=inputs=2:normalize=0:duration=first[aclean]")
    else:
        parts.append("[voice]anull[aclean]")
    return ";".join(parts), "aclean"


HIGH_FPS = 40                # (20 Nov) is se zyada fps ki video ke tukre select se (memory)
STREAM_HOOK_Y = {"round": 0.105, "stack": 0.42}    # (20 Nov) stream layouts ka hook (title) kahan
HOOK_BANDS = (0.33, 0.12, 0.385, 0.80)   # hook title heights to try, in order (9:16); 0.80 sirf aakhri chara


FIT_CAPTION_Y = 0.80       # under a full 16:9 picture shown on a blurred background
STACK_CAPTION_Y = 0.50     # on the divider of the stacked layout


CARD_VIDEO_H = 1350          # title card mein video ki unchai (9:16 frame ke beech se kati hui, 4:5)
CARD_TOP = (390, 440)        # video ka upar wala kinara: channel naam ke bina / sath


DISCLOSURE_GAP = 0.05             # captions disclosure ki patti se itna upar (frame ka hissa)


CAPTION_HALF = 0.032             # ek line caption ki aadhi unchai (frame ka hissa)
MID_CAPTION_LIFT = 0.14          # patti beech mein ho to captions us se itna upar (news headline patti ke upar)
UI_SAFE = 0.80                    # TikTok / Reels / Shorts: neeche ka 20% app ke caption aur buttons ke neeche


FIT_CAP_GAP = 0.045               # video ke neeche kinare se caption ka beech (frame ka hissa)
CAPTION_ROOM = 0.09               # video ke neeche itni jagah captions ki, phir disclosure


def _fit_bottom_of(job: RenderJob) -> float | None:
    """Poori landscape video (fit) 9:16 mein: us ka neecha kinara (frame ka hissa)."""
    if job.source is None or job.ratio != "9:16":
        return None
    sw, sh = job.source.display_size
    if sw <= sh:
        return None
    out_w, out_h = OUTPUTS[job.ratio]
    fg_h = min(out_h, out_w * sh / sw * max(1.0, getattr(job, "fit_zoom", 1.0)))
    return ((out_h - fg_h) / 2 - int(FIT_LIFT * out_h) + fg_h) / out_h


def _fit_video_bottom(job: RenderJob) -> float | None:
    """Har shot mein poori video / dabba beech mein ho to sab se neecha kinara (frame ka hissa), warna None."""
    if job.source is None or job.ratio != "9:16":
        return None
    if job.pieces:
        bottoms = [fit_bottom(job.source, p, getattr(job, "fit_zoom", 1.0)) for p in job.pieces]
        return None if any(b is None for b in bottoms) else max(bottoms)
    if (job.frame or FramePlan()).mode != "fit_blur":
        return None
    return _fit_bottom_of(job)


def fit_caption_y(job: RenderJob) -> float:
    """Poori video beech mein: captions video ke foran neeche (disclosure un ke neeche)."""
    bottom = _fit_video_bottom(job) or _fit_bottom_of(job)
    return round(bottom + FIT_CAP_GAP, 3) if bottom is not None else FIT_CAPTION_Y


def disclosure_layout(job: RenderJob) -> tuple[int, int, float]:
    """Disclosure patti: (upar wali lakeer, unchai) OUTPUTS frame pe px, aur text kitni jagah mein samaye
    (frame ka hissa, 0 = apna size). (0, 0, 0) = disclosure nahi. Patti video ke UPAR lagti hai."""
    if not job.disclosure.strip():
        return 0, 0, 0.0
    from app.captions.builder import disclosure_band
    out_w, out_h = OUTPUTS[job.ratio]
    if job.disclosure_top or job.disclosure_place == "top":
        return 0, int(disclosure_band(job.disclosure, out_w, out_h, job.disclosure_cover)[2]), job.disclosure_cover
    if job.disclosure_place == "bottom" or job.disclosure_cover > 0:
        band = int(disclosure_band(job.disclosure, out_w, out_h, job.disclosure_cover)[2])
        return out_h - band, band, job.disclosure_cover
    # video ke neeche (app ke buttons se upar)
    if job.disclosure_region is not None:
        y0, y1 = job.disclosure_region
        band = int(disclosure_band(job.disclosure, out_w, out_h, y1 - y0)[2])
        return int(round(y0 * out_h / 2)) * 2, band, y1 - y0
    band = int(disclosure_band(job.disclosure, out_w, out_h)[2])
    limit = int(UI_SAFE * out_h)
    bottom = _fit_video_bottom(job)
    if bottom is None:
        return (limit - band) // 2 * 2, band, 0.0
    # poori video beech mein: video, phir captions, phir disclosure (jagah kam ho to text chhota)
    y = int((bottom + CAPTION_ROOM) * out_h) // 2 * 2
    if y + band <= limit:
        return y, band, 0.0
    room = (limit - y) / out_h
    band = int(disclosure_band(job.disclosure, out_w, out_h, room)[2])
    if y + band > limit:
        return (limit - band) // 2 * 2, band, room
    return y, band, room


def disclosure_box(job: RenderJob) -> tuple[int, int]:
    """Disclosure patti (upar wali lakeer, unchai) OUTPUTS frame pe px. (0, 0) = disclosure nahi."""
    y, band, _cover = disclosure_layout(job)
    return y, band


def disclosure_height(job: RenderJob) -> int:
    """Disclosure patti ki unchai (OUTPUTS frame pe, px), 0 = disclosure nahi."""
    return disclosure_box(job)[1]


def disclosure_top_px(job: RenderJob) -> int:
    """Upar wali patti ki unchai (OUTPUTS px); 0 jab patti upar nahi."""
    y, band = disclosure_box(job)
    return band if band and y == 0 else 0


def disclosure_span(job: RenderJob) -> tuple[float, float] | None:
    """Patti (y0, y1) frame ke hisse mein, ya None."""
    y, band = disclosure_box(job)
    if not band:
        return None
    h = OUTPUTS[job.ratio][1]
    return y / h, (y + band) / h


def caption_limit(job: RenderJob) -> float | None:
    """Captions ka sab se neecha markaz (frame ka hissa) jab patti neeche ho; patti upar ho to None."""
    span = disclosure_span(job)
    if span is None or span[0] <= 0.001:
        return None
    return round(span[0] - DISCLOSURE_GAP, 3)


def caption_clear(job: RenderJob, y: float) -> float:
    """Caption ki unchai jo disclosure patti ke upar na aaye: takraye to patti ke upar khisak jaye."""
    span = disclosure_span(job)
    if span is None or span[0] <= 0.001:
        return y
    s0, s1 = span
    bottom = _fit_video_bottom(job)
    if bottom is not None and bottom <= y and y + CAPTION_HALF <= s0:
        return y                                           # video aur disclosure ke beech: theek
    if s1 >= 0.995:
        return min(y, round(s0 - DISCLOSURE_GAP, 3))       # patti bilkul neeche: captions us se upar
    if s0 - DISCLOSURE_GAP < y < s1 + DISCLOSURE_GAP:
        # beech mein patti (video ke neeche): captions video ke beech, us ki neeche wali headline patti se upar
        return round(s0 - MID_CAPTION_LIFT, 3)
    return y


def zoom_focus(job: RenderJob) -> tuple[float, float]:
    """Zoom ka markaz: main speaker ka chehra (output frame mein), clip ke zyada tar hisse ka."""
    if not job.pieces or job.ratio != "9:16":
        return (0.5, 0.4)
    from app.render.framing import QA_FACE_LINE
    weights: dict[float, float] = {}
    for p in job.pieces:
        span = max(0.01, p.end - p.start)
        if p.mode == "qa":
            main_top = p.live_top if getattr(p, "main_live", False) else not p.live_top
            y = (0.0 if main_top else 0.5) + QA_FACE_LINE * 0.5
        else:
            ys = face_heights(job.source, job.ratio, p)
            y = ys[0] if ys else 0.4
        y = round(min(0.9, max(0.1, y)), 2)
        weights[y] = weights.get(y, 0.0) + span
    return (0.5, max(weights, key=weights.get))


def card_geometry(job: RenderJob) -> tuple[int, int] | None:
    """(video top, crop offset) at 1080x1920, ya None jab title card nahi."""
    if not job.title_card or job.ratio != "9:16":
        return None
    out_w, out_h = OUTPUTS[job.ratio]
    off = job.card_offset if job.card_offset >= 0 else (out_h - CARD_VIDEO_H) // 2
    return CARD_TOP[1 if job.channel_name else 0], min(off, out_h - CARD_VIDEO_H)


# ---------------------------------------------------------------------
#  TikTok ki safe jagah (30 Oct): neeche takreeban 25% par username aur
#  post caption, daayen buttons (builder pehle se 150 px door rakhta hai),
#  upar "Following / For You". Captions ka beech is pattee ke andar.
# ---------------------------------------------------------------------
TIKTOK_CAP_Y = (0.14, 0.68)


def platform_y(job: RenderJob, y: float | None) -> float | None:
    """Platform ki safe jagah mein caption ki unchai (sirf TikTok par; baaqi waisa hi)."""
    if y is None or getattr(job, "platform", "") != "tiktok" or job.ratio != "9:16":
        return y
    return round(min(TIKTOK_CAP_Y[1], max(TIKTOK_CAP_Y[0], y)), 3)


def caption_heights(job: RenderJob):
    """Function clip time -> caption height for the shot on screen then (None = style default)."""
    if not job.pieces:
        return None
    spans, clock = [], 0.0
    for a, b, piece in video_pieces(job.segments, job.pieces):
        y = {"fit_blur": fit_caption_y(job), "stack": STACK_CAPTION_Y, "qa": STACK_CAPTION_Y,
             "panels": (fit_caption_y(job) if getattr(piece, "fit", False)
                        else STACK_CAPTION_Y if getattr(piece, "box_b", ()) else None)}.get(piece.mode)
        spans.append((clock, clock + (b - a), y))
        clock += b - a

    card = card_geometry(job)
    shift = (card[0] - card[1]) / OUTPUTS[job.ratio][1] if card else 0.0
    def clamp(y):
        return y if y is None else platform_y(job, caption_clear(job, y))

    def y_at(t: float):
        for a, b, y in spans:
            if a <= t + 0.05 < b:
                return None if y is None else clamp(y + shift)
        y = spans[-1][2] if spans else None
        return None if y is None else clamp(y + shift)
    return y_at


# ---------------------------------------------------------------------
#  Caption ka andaaz (edit matrix): jagah, lafz ek waqt mein, size
#  Kaam: ek hi style ke kai roop. Jagah sirf 9:16 pe aur safe zone ke
#  andar (0.56 .. 0.70), taake Shorts / TikTok ke buttons ke neeche na
#  jaye aur chehre pe na aaye.
# ---------------------------------------------------------------------
CAP_SHIFT = {"high": -0.07, "low": 0.06}
SAFE_Y = (0.56, 0.70)


def caption_variant(style, pos: str = "", mode: str = "", size: float = 1.0):
    if pos in CAP_SHIFT:
        style = replace(style, y_pct=round(min(SAFE_Y[1], max(SAFE_Y[0], style.y_pct + CAP_SHIFT[pos])), 3))
    if mode == "word":
        style = replace(style, max_words=2, max_lines=1)
    elif mode == "reveal" and style.highlight != "dim":
        style = replace(style, reveal=True)          # lafz bolte hi ek ek kar ke aate hain
    if size and abs(size - 1.0) > 0.001:
        style = replace(style, size=max(30, round(style.size * min(1.12, max(0.88, size)))))
    return style


HOOK_HALF = 0.045                        # half height of a hook pill (share of the frame)


def hook_position(job: RenderJob, caption_y: float, faces: bool = True) -> float | None:
    """
    A height for the hook title that keeps clear of faces (their whole
    head, hair included) and of the captions; None = no clean place.
    """
    from app.captions.builder import HOOK_SECONDS
    seconds = job.hook_seconds or HOOK_SECONDS
    plan = job.frame or FramePlan()
    if not job.pieces and plan.mode == "stream" and job.ratio == "9:16":
        # (20 Nov) stream: round = game ke upar wali dhundli patti; stack = chehre aur game ki beech wali lakeer
        y = STREAM_HOOK_Y.get(plan.layout, STREAM_HOOK_Y["round"])
        top = disclosure_top_px(job) / OUTPUTS[job.ratio][1]
        return round(y + top, 3) if y < 0.3 else y          # upar ad patti ho to headline us ke neeche
    spans: list[tuple[float, float]] = []          # (top, bottom) areas to keep clear
    if not faces:
        pass                                       # Super: chehron se bachna mumkin na ho to bhi dikhe
    elif job.pieces:
        clock = 0.0
        for a, b, piece in video_pieces(job.segments, job.pieces):
            if clock < seconds:
                fw = getattr(piece, "face_w", 0.0) if piece.mode == "crop" else 0.0
                sw, sh = job.source.display_size
                head = 1.25 * fw * sw / sh if fw else 0.10     # face height in the output frame
                for y in face_heights(job.source, job.ratio, piece):
                    spans.append((y - 0.75 * head, y + 0.55 * head))
                if piece.mode == "panels":
                    # show ke dabbe (tweet / document) ka likha hua: hook us ke upar nahi
                    if getattr(piece, "fit", False):
                        spans.append((0.18, 0.86))
                    elif getattr(piece, "box_b", ()):
                        spans.append((0.47, 0.98))
            clock += b - a
    else:
        spans.append((0.20, 0.50))
    caps = [caption_y]
    y_at = caption_heights(job)
    if y_at is not None:
        caps += [y for y in (y_at(t / 4) for t in range(11)) if y is not None]
    spans += [(c - 0.06, c + 0.06) for c in caps]
    if job.name_card and not job.disclosure_top:
        spans.append((0.03, 0.11))                   # naam patti upar baayen: hook us pe nahi
    dspan = disclosure_span(job)
    if dspan:
        spans.append((dspan[0] - 0.03, dspan[1] + 0.03))               # disclosure patti: hook us pe nahi
    bands = HOOK_BANDS if job.ratio == "9:16" else (0.12, 0.85)
    if getattr(job, "platform", "") == "tiktok":
        bands = tuple(b for b in bands if TIKTOK_CAP_Y[0] <= b <= TIKTOK_CAP_Y[1])   # TikTok ke buttons / likhai se door
    for y in bands:                       # first clean band wins
        top, bottom = y - HOOK_HALF, y + HOOK_HALF
        if all(bottom < s0 or top > s1 for s0, s1 in spans):
            return y
    return None


def _clip_style(job: RenderJob):
    """Clip ka caption style: palette ho to wo (rangeen), warna bolte lafz ka accent rang."""
    st = get_style(job.caption_style)
    return with_palette(st, job.palette) if job.palette else with_accent(st, job.accent)


def render_clip(job: RenderJob,
                on_progress: Callable[[float], None] | None = None,
                cancel_event: threading.Event | None = None) -> Path:
    temp = job.temp_dir or job.out_path.parent
    temp.mkdir(parents=True, exist_ok=True)
    out_w, out_h = OUTPUTS[job.ratio]                 # framing, zoom: hamesha 1080p pe
    fin_w, fin_h = final_size(job.ratio, job.hq)      # captions, bar, logo: aakhri size pe
    segs = job.segments
    # Cold open: pehla tukra clip mein baad ka hissa hai. Use apna alag
    # input milta hai, warna ffmpeg beech ke saare frames memory mein
    # rakhta (har second ~90 MB). Baaki clip ek hi input se.
    teaser = len(segs) > 1 and segs[0].start > segs[1].start + 0.001     # pehla tukra baad ka (ulti tarteeb)
    body = segs[1:] if teaser else segs
    clip_start = min(seg.start for seg in body)
    clip_end = max(seg.end for seg in body)
    duration = total_duration(segs)
    span = clip_end - clip_start
    input_args = ["-ss", f"{clip_start:.3f}", "-t", f"{span + 0.05:.3f}", "-i", str(job.source.path)]
    teaser_args = (["-ss", f"{segs[0].start:.3f}", "-t", f"{segs[0].end - segs[0].start + 0.05:.3f}",
                    "-i", str(job.source.path)] if teaser else [])

    def srcs_for(t_index: int) -> list[tuple[str, str, float]]:
        out = [("0:v", "0:a", clip_start)] * len(segs)
        if teaser:
            out[0] = (f"{t_index}:v", f"{t_index}:a", segs[0].start)
        return out

    srcs = srcs_for(1)                                  # main render: input 1 = cold open
    many_frames = bool(job.source is not None and (job.source.fps or 0) > HIGH_FPS)   # 60fps: select (memory)
    seg_graph = _segment_graph(segs, clip_start, video=not job.pieces, srcs=srcs, select=many_frames)
    audio_graph, a_label = _audio_graph(job, duration, "acat")

    # --- loudness pass 1 (audio only, fast) --------------------------
    measured = None
    correction = 0.0
    if job.loudness:
        try:
            audio_only = f"{_segment_graph(segs, clip_start, video=False, srcs=srcs_for(1))};{audio_graph}"
            measured = measure_loudness(input_args + teaser_args, audio_only, a_label, cancel_event=cancel_event)
            if measured:
                correction = limiter_correction_db(input_args + teaser_args, audio_only, a_label, measured,
                                                   cancel_event)
        except Cancelled:
            raise
        except Exception as exc:   # never fail a clip because of loudness
            log.warning("Loudness measure failed: %s", exc)

    # --- video chain ---------------------------------------------------
    plan = job.frame or FramePlan()
    # --- logos ------------------------------------------------------
    brand_path = Path(job.brand.path) if job.brand is not None and getattr(job.brand, "enabled", False) \
        and job.brand.path and Path(job.brand.path).is_file() else None
    hide = job.logo_box is not None and job.logo_mode in ("blur", "replace")
    replace_logo = hide and job.logo_mode == "replace" and brand_path is not None
    corner_brand = brand_path is not None and not replace_logo
    extra_inputs: list[str] = []
    first_extra = 1 + (1 if teaser else 0)              # brand input ka number
    if brand_path is not None:
        fps_in = job.source.fps if job.source.fps > 0 else 30
        extra_inputs = ["-loop", "1", "-framerate", f"{fps_in:.3f}", "-i", str(brand_path)]
    pre: list[str] = []
    # har video input (asal + cold open) jis pe logo chhupana hai
    src_inputs = [0, 1] if teaser else [0]
    brand_need = (len(src_inputs) if replace_logo else 0) + (1 if corner_brand else 0)
    if brand_path is not None and brand_need > 1:
        names = [f"br{i}" for i in range(brand_need)]
        pre.append(f"[{first_extra}:v]split={brand_need}" + "".join(f"[{x}]" for x in names))
        brand_labels = names
    else:
        brand_labels = [f"{first_extra}:v"] if brand_path is not None else []
    vlabels = None
    if hide or job.blur_bands:
        sw, sh = job.source.display_size
        if job.pieces:
            owners = [k for *_, k in piece_trims(segs, job.pieces)]
        else:
            owners = list(range(len(segs)))
        vlabels = [""] * len(owners)
        for n, inp in enumerate(src_inputs):
            mine = [i for i, k in enumerate(owners) if (k == 0 and teaser) == (inp == 1)]
            if not mine:
                continue
            cur = f"{inp}:v"
            if hide:
                nxt = f"lgo{inp}" if job.blur_bands else f"srcv{inp}"
                pre.append(source_logo_graph(job.logo_box, sw, sh, job.logo_mode, cur, nxt,
                                             brand_label=brand_labels[n] if replace_logo else "", tag=f"lg{inp}"))
                cur = nxt
            if job.blur_bands:
                # news ki chalti patti: doosri (unrelated) khabrein clip mein na parhi jayein
                pre.append(ticker_blur_graph(cur, f"srcv{inp}", job.blur_bands, sw, sh, tag=f"tk{inp}"))
            outs = [f"sv{i}" for i in mine]
            pre.append(f"[srcv{inp}]split={len(outs)}" + "".join(f"[{v}]" for v in outs) if len(outs) > 1
                       else f"[srcv{inp}]null[{outs[0]}]")
            for i in mine:
                vlabels[i] = f"sv{i}"
        if not job.pieces:
            seg_graph = _segment_graph(segs, clip_start, video=True, vlabels=vlabels, srcs=srcs, select=many_frames)
    classic = bool(getattr(job, "classic", "")) and job.ratio == "9:16"
    if job.pieces:
        chain = pre + [seg_graph, _framed_video_graph(job, clip_start, vlabels, srcs=srcs)]
    elif classic:
        from types import SimpleNamespace
        from app.render.framing import classic_filter
        chain = pre + [seg_graph, classic_filter(job.source, SimpleNamespace(mode="crop", x_center=plan.x_center,
                                                                             x_path=(), start=clip_start),
                                                 "vcat", "vframed", bg=job.classic)]
    else:
        chain = pre + [seg_graph, framing_filter(job.source, job.ratio,
                                                 replace(plan, bg=job.background, zoom=getattr(job, "fit_zoom", 1.0)),
                                                 "vcat", "vframed")]
    post = []
    cuts: list[float] = []                       # clip times of camera cuts / reaction shots
    if job.pieces:
        clock, last = 0.0, None
        for a, b, piece in video_pieces(job.segments, job.pieces):
            if last is not None and piece is not last:
                cuts.append(round(clock, 3))
            clock += b - a
            last = piece
    punches: list[float] = []
    if job.zoom:
        punches = punch_times(job.words, cuts, duration) if job.zoom == "punch" else []
        zf = zoom_filter(job.zoom, punches, duration, out_w, out_h, focus=zoom_focus(job))
        if zf:
            post.append(zf)
    hook_shown = False
    emoji_inputs: list[str] = []
    look = look_filter(job.look)
    if look:
        post.append(look)
    if job.sharpen:
        post.append("cas=strength=0.35")
    card = card_geometry(job)
    disc_y, disc = disclosure_box(job)
    if card:
        # title card: 9:16 frame ka beech (4:5) safed pas-e-manzar pe, upar title
        c_top, c_off = card
        post.append(f"crop={out_w}:{CARD_VIDEO_H}:0:{c_off},pad={out_w}:{out_h}:0:{c_top}:color=white")
    if disc:
        # disclosure: neeche saada gehri patti (video mein pehle se likha disclosure chhup jaata hai)
        from app.captions.builder import DISCLOSURE_BG
        post.append(f"drawbox=x=0:y={disc_y}:w={out_w}:h={disc}:color={DISCLOSURE_BG}@1:t=fill")
    if (fin_w, fin_h) != (out_w, out_h):
        # YouTube HQ: captions se pehle bara karo, taake text 1440p pe tez aur saaf bane
        post.append(f"scale={fin_w}:{fin_h}:flags=lanczos,setsar=1")
    card_events = None
    emoji_png = None
    if card:
        from app.captions.builder import Frame, title_card_events
        from app.core.paths import resource
        png = resource("assets", "emoji", f"{job.title_emoji}.png") if job.title_emoji else None
        emoji_png = png if png is not None and Path(png).is_file() else None
        card_events = title_card_events(job.title_card, Frame(fin_w, fin_h), card[0] * fin_h / out_h,
                                        header=job.channel_name, emoji=emoji_png is not None)
        if card_events[1] is None:
            emoji_png = None
    if disc:
        from app.captions.builder import Frame, disclosure_events
        lines = disclosure_events(job.disclosure, Frame(fin_w, fin_h), cover=disclosure_layout(job)[2],
                                  top=disc_y * fin_h / out_h, band=disc * fin_h / out_h)
        card_events = ((card_events[0] if card_events else []) + lines, card_events[1] if card_events else None)
    if classic and job.classic_title:
        from app.captions.builder import Frame, classic_title_events
        from app.render.framing import CLASSIC_TOP
        tl = classic_title_events(job.classic_title, Frame(fin_w, fin_h), job.classic, CLASSIC_TOP * fin_h / out_h,
                                  key=job.classic_key)
        if getattr(job, "classic_super", ""):
            from app.captions.builder import classic_super_events
            from app.render.framing import CLASSIC_SQ
            tl += classic_super_events(job.classic_super, Frame(fin_w, fin_h), job.classic,
                                       (CLASSIC_TOP + CLASSIC_SQ) * fin_h / out_h, fin_h)
        card_events = ((card_events[0] if card_events else []) + tl, card_events[1] if card_events else None)
    if (job.captions and job.words) or card or disc or (job.hook and job.hook_force) or (classic and job.classic_title):
        ass_path = temp / (job.out_path.stem.replace(" ", "_")[:40] + ".ass")
        # (31 Oct) pehle se 9:16 video (jaise campaign ke ads): us ki apni patti (CBS / news headline) captions
        # ki jagah ke foran upar hoti hai; "high" captions ko us patti ke upar le jata tha (lafz par lafz)
        pos = "" if (job.caption_pos == "high" and job.source is not None and job.source.is_vertical) else job.caption_pos
        style = caption_variant(_clip_style(job), pos, job.caption_mode, job.caption_size)
        if classic:
            from app.captions.styles import STYLES as _ST
            style = _ST.get(job.classic_caption) or _ST["classic_caps"]   # Classic: video ke andar wale captions
        if job.cover_subs and _fit_video_bottom(job) is None and not classic:    # captions video ke neeche hon to dabba nahi
            style = cover_version(style)
        if classic:
            pass
        elif job.caption_y is not None:
            style = replace(style, y_pct=job.caption_y)
        elif not job.pieces and (job.frame or FramePlan()).mode == "fit_blur" and _fit_bottom_of(job) is not None:
            style = replace(style, y_pct=fit_caption_y(job))          # poori video beech mein: captions neeche
        if card:
            style = replace(style, y_pct=round(style.y_pct + (card[0] - card[1]) / out_h, 3),
                            size=max(30, round(style.size * 0.88)))
        if disc:
            style = replace(style, y_pct=caption_clear(job, style.y_pct))
        if not classic:
            style = replace(style, y_pct=platform_y(job, style.y_pct))       # TikTok: buttons / username se door
        hook_y = hook_position(job, style.y_pct) if (job.hook and not card) else None
        hook_box = job.hook_box
        if hook_y is None and job.hook and job.hook_force:
            hook_box = False             # (15 Nov) chehre se bachne ki jagah nahi: dabba nahi, sirf kinare wala text
            # Super zaroori hai: chehre ke upar bhi chale, magar captions / disclosure se door
            # pehle sab se upar (sar ke upar, TikTok ki upar wali likhai se neeche), phir koi bhi saaf patti
            top = 0.13 if job.ratio == "9:16" else 0.12
            caps = [style.y_pct] + [y for y in ((caption_heights(job) or (lambda t: None))(t / 4) for t in range(11))
                                    if y is not None]
            hook_y = top if all(abs(c - top) > 0.10 for c in caps) else (
                hook_position(job, style.y_pct, faces=False) or top)
        hook_shown = hook_y is not None
        build_ass(job.words if job.captions else [], style, fin_w, fin_h, job.masked, ass_path,
                  entrance=None if classic else (job.entrance or None), hook=job.hook if hook_y is not None else "", hook_y=hook_y,
                  y_at=None if classic else caption_heights(job), hook_box=hook_box, hook_color=job.hook_color,
                  hook_seconds=job.hook_seconds, hook_big=(job.frame or FramePlan()).mode == "stream" and job.hook_force,
                  name_card="" if (card or job.disclosure_top) else job.name_card,
                  name_card_right=corner_brand and getattr(job.brand, "position", "") == "top_left",
                  title_card=card_events)
        fonts_dir = font_dir_for(style.font)
        post.append(f"subtitles=filename={escape_filter_path(ass_path)}:fontsdir={escape_filter_path(fonts_dir)}")
    if job.bar in ("top", "bottom"):
        # Thin progress bar that fills from left to right over the clip.
        colour = _clip_style(job).highlight_color.lstrip("#")
        bar_h = (BAR_HEIGHT if job.ratio == "9:16" else BAR_HEIGHT - 2) * fin_w // out_w
        y = 0 if job.bar == "top" else fin_h - bar_h
        fps_bar = job.source.fps if job.source.fps > 0 else 30
        chain.append(f"[vframed]{','.join(post)}[vpost]")
        chain.append(f"color=c=0x{colour}@0.92:s={fin_w}x{bar_h}:r={fps_bar:.3f}:d={duration + 0.5:.3f}[bar]")
        chain.append(f"[vpost][bar]overlay=x='-w+w*t/{max(duration, 0.1):.3f}':y={y}:shortest=1:eof_action=pass,"
                     f"format=yuv420p[vout]")
    elif emoji_png is not None:
        # title ke aakhir ka rangeen emoji (libass rangeen emoji nahi banata): tasveer upar lagao
        ex, ey, es = card_events[1]
        e_in = first_extra + (1 if extra_inputs else 0)
        emoji_inputs = ["-loop", "1", "-framerate", f"{job.source.fps if job.source.fps > 0 else 30:.3f}",
                        "-i", str(emoji_png)]
        chain.append(f"[vframed]{','.join(post)}[vcard]")
        chain.append(f"[{e_in}:v]scale={round(es)}:{round(es)}:flags=lanczos,format=rgba[emo]")
        chain.append(f"[vcard][emo]overlay=x={ex:.0f}:y={ey:.0f}:shortest=1:format=auto,format=yuv420p[vout]")
    else:
        post.append("format=yuv420p")
        chain.append(f"[vframed]{','.join(post)}[vout]")

    if corner_brand:
        chain[-1] = chain[-1].replace("[vout]", "[vbase]")
        pos = getattr(job.brand, "position", "top_right")
        chain.append(brand_overlay_graph("vbase", brand_labels[-1], "vlogo", fin_w, fin_h, pos,
                                         float(getattr(job.brand, "size_pct", 14.0)),
                                         float(getattr(job.brand, "opacity", 0.9)),
                                         bottom_offset=int((out_h - disc_y) * fin_h / out_h) if disc and disc_y > out_h / 2 else 0,
                                         top_offset=int(disc * fin_h / out_h) if disc and disc_y == 0 else 0))
        chain.append("[vlogo]format=yuv420p[vout]")

    # (16 Nov) Ek waqt par ek hi frame: saathi shot / overlays alag waqt ke frame la kar
    # 60 fps video mein frame do dafa (lagbhag same waqt) likhwa dete the. Asal fps par
    # barabar frames: tasveer wahi, harkat smooth, faltu frames aur waqt bachta hai.
    from app.render.framing import rate_expr
    chain[-1] = chain[-1].replace("[vout]", "[vcfr]")
    chain.append(f"[vcfr]fps={rate_expr(job.source.fps)}[vout]")

    # --- audio chain -------------------------------------------------
    chain.append(audio_graph)
    sfx_inputs: list[str] = []
    if job.sfx:
        from app.edit.sfx import plan_sounds, write_track
        events = plan_sounds(job.sfx, 0.15 if hook_shown else None, cuts, punches, duration)
        if events:
            track = write_track(events, duration, temp / (job.out_path.stem.replace(" ", "_")[:40] + "_sfx.wav"))
            sfx_inputs = ["-i", str(track)]
    music_inputs: list[str] = []
    music_path = Path(job.music) if getattr(job, "music", "") else None
    if music_path is not None and music_path.is_file():
        music_inputs = ["-stream_loop", "-1", "-ss", f"{max(0.0, job.music_offset):.3f}", "-i", str(music_path)]
    if sfx_inputs or music_inputs:
        k = first_extra + (1 if extra_inputs else 0) + (1 if emoji_inputs else 0)
        chain.append(f"[{a_label}]{loudness_filter(measured, correction)},aresample=48000[avoice]")
        mix, n = "[avoice]", 1
        if sfx_inputs:
            chain.append(f"[{k}:a]aformat=sample_rates=48000:channel_layouts=stereo[asfx]")
            mix, n = mix + "[asfx]", n + 1
        if music_inputs:
            # (17 Nov) music aawaz ke neeche: halki, shuru mein aahista aaye, aakhir mein aahista jaye, aur jab
            # koi bole to khud aur dheemi (aawaz hi chabi hai, lafz kabhi na dabein)
            km = k + (1 if sfx_inputs else 0)
            chain.append("[avoice]asplit=2[avoice0][akey]")
            mix = mix.replace("[avoice]", "[avoice0]")
            vol = max(0.02, min(0.6, float(getattr(job, "music_volume", 0.2) or 0.2)))
            if job.loud:
                chain += music_bed(f"{km}:a", "akey", LOUD_MUSIC, duration, "aduck", LOUD_DUCK)
            else:
                chain += music_bed(f"{km}:a", "akey", vol, duration, "aduck")
            mix, n = mix + "[aduck]", n + 1
        chain.append(f"{mix}amix=inputs={n}:normalize=0:duration=first,"
                     f"alimiter=limit=0.97:level=0{LOUD_CHAIN if job.loud else ''},aresample=48000[aout]")
    else:
        chain.append(f"[{a_label}]{loudness_filter(measured, correction)}"
                     f"{LOUD_CHAIN if job.loud else ''},aresample=48000[aout]")

    # --- encoding: pehle GPU (agar on), fail ho to x264 -------------
    fps = job.source.fps if job.source.fps > 0 else 30
    tmp_out = job.out_path.with_name(job.out_path.stem + ".part.mp4")
    job.out_path.parent.mkdir(parents=True, exist_ok=True)

    # sawal jawab upar neeche: saathi shots ke inputs sab se aakhir mein (baaki inputs ke number wahi)
    comp_list = list(getattr(job, "comp_inputs", []) or [])
    comp_base = 1 + (1 if teaser_args else 0) + (1 if extra_inputs else 0) + (1 if emoji_inputs else 0) \
        + (1 if sfx_inputs else 0) + (1 if music_inputs else 0)
    comp_args: list[str] = []
    graph = ";".join(chain)
    for j, (c_start, c_len) in enumerate(comp_list):
        comp_args += ["-ss", f"{c_start:.3f}", "-t", f"{c_len:.3f}", "-an", "-i", str(job.source.path)]
        graph = graph.replace(f"[@COMP{j}:v]", f"[{comp_base + j}:v]")

    def ffmpeg_args(gpu_enc: bool, gpu_dec: bool) -> list[str]:
        decode = ["-hwaccel", "cuda"] if gpu_dec else []
        return [
            *decode, *input_args,
            *((decode + teaser_args) if teaser_args else []),
            *extra_inputs,
            *emoji_inputs,
            *sfx_inputs,
            *music_inputs,
            *comp_args,
            "-filter_complex", graph,
            "-map", "[vout]", "-map", "[aout]",
            *(["-threads", str(job.threads)] if job.threads else []),
            *video_codec_args(job.quality, gpu_enc, fps, fin_h),
            "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
            "-c:a", "aac", "-b:a", "320k", "-ar", "48000", "-ac", "2",
            "-movflags", "+faststart",
            "-t", f"{duration:.3f}",
            str(tmp_out),
        ]

    # (18 Nov) GPU decode: ek waqt mein sirf ek clip GPU par (baaki CPU par, intezaar nahi). Is video mein
    # GPU GPU_FAIL_LIMIT dafa fail ho chuka ho to aage ke clips seedha CPU par. Tasveer dono par ek jaisi.
    src_key = str(job.source.path)
    # (18 Nov) laptop ka GPU AV1 decode nahi karta (har dafa fail, phir CPU par dobara = waqt zaya): seedha CPU
    no_gpu_codec = str(getattr(job.source, "video_codec", "") or "").lower() in GPU_DECODE_SKIP
    use_dec = bool(job.gpu_decode) and not no_gpu_codec and _GPU_FAILS.get(src_key, 0) < GPU_FAIL_LIMIT
    got_slot = use_dec and _GPU_SLOT.acquire(blocking=False)
    use_dec = bool(got_slot)
    attempts = [(job.gpu_encode, use_dec)]
    if job.gpu_encode or use_dec:
        attempts.append((False, False))            # GPU ka koi masla: CPU pe dobara, wahi quality
    try:
        for k, (g_enc, g_dec) in enumerate(attempts):
            try:
                run_ffmpeg(ffmpeg_args(g_enc, g_dec), duration=duration, on_progress=on_progress,
                           cancel_event=cancel_event)
                break
            except Cancelled:
                tmp_out.unlink(missing_ok=True)
                raise
            except BaseException as exc:
                tmp_out.unlink(missing_ok=True)      # never leave half files behind
                if k == len(attempts) - 1:
                    raise
                if g_dec:
                    _GPU_FAILS[src_key] = _GPU_FAILS.get(src_key, 0) + 1
                    if got_slot:                     # CPU wale dobara render ke dauran GPU doosre clip ko mile
                        _GPU_SLOT.release()
                        got_slot = False
                log.warning("GPU render failed (%s); rendering this clip on the CPU (GPU fails in this video: %d)",
                            exc, _GPU_FAILS.get(src_key, 0))
    finally:
        if got_slot:
            _GPU_SLOT.release()
    if job.out_path.exists():
        job.out_path.unlink()
    shutil.move(str(tmp_out), str(job.out_path))
    return job.out_path
