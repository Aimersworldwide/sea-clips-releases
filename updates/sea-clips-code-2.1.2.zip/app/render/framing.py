"""
=====================================================================
  RENDER / FRAMING
  Kaam: 16:9 se 9:16 framing ke ffmpeg filters (crop, stack, boxes, blur).
  Builds the ffmpeg filter that turns the source frame into the
  output frame (9:16 or 16:9).
    crop      - fill the frame with a crop of the source. `x_center`
                (0..1) says where the speaker is (Phase 2 fills this
                from face tracking; Phase 1 uses the centre).
    fit_blur  - whole picture centred, blurred copy behind it.
                Used when a crop would cut important content, and for
                vertical sources going to 16:9 (and the reverse).
  Quality rules: Lanczos scaling, crop never more than 2x the source,
  deband on blurred backgrounds (they band easily).
=====================================================================
"""
from __future__ import annotations

from dataclasses import dataclass

from app.media.probe import SourceInfo

OUTPUTS = {"9:16": (1080, 1920), "16:9": (1920, 1080)}


@dataclass
class FramePlan:
    mode: str = "crop"          # crop | fit_blur
    x_center: float = 0.5       # 0..1 position of the subject in the source
    y_center: float = 0.5
    x_expr: str = ""            # optional ffmpeg expression of the x centre over time t (calm camera moves)
    band: float = 1.0           # use only the picture above this height (burned-in text below it)
    bg: str = "blur"            # fit_blur ka peechha: blur (tasveer ki dhundli copy) | black (saada kaala)
    zoom: float = 1.0           # fit_blur: poori video se itna bara (kaali pattiyan chhoti), sides x_center ke gird katti
    vzoom: float = 1.0          # khari ad (dabbe mein video): poori tasveer itni bari, sides barabar katti
    vtop: float = 0.0           # vzoom: source ka itna upar wala hissa kata (0..1)
    cam: tuple = ()             # (20 Nov) stream: streamer ke camera ka dabba (x, y, w, h) frame ka hissa
    face: tuple = ()            # stream: chehre ka markaz aur chaurai (cx, cy, w)
    layout: str = ""            # stream: round (gol chehra game ke kone par) | stack (chehra upar, game neeche)


VZOOM = 1.2                    # khari ad ka zoom: sides har taraf ~8% katti ("thora sa", user 31 Oct)
VIDEO_BOTTOM_MAX = 0.64        # zoom ke baad andar wali video ka neecha kinara is se upar (neeche captions, TikTok safe)


def vertical_zoom(band: tuple[float, float], z: float = VZOOM) -> tuple[float, float, float]:
    """Khari ad ki andar wali video (upar, neeche) se: (zoom, source ka kata upar wala hissa, video ka naya neecha
    kinara). Upar ka logo dabba zyada katta hai, video kabhi nahi katti."""
    top, bottom = band
    t = bottom - VIDEO_BOTTOM_MAX / z
    t = max(0.0, min(t, 1.0 - 1.0 / z, top))
    return z, round(t, 4), round((bottom - t) * z, 4)


ZOOM_SHARPEN = 2.05            # is se zyada zoom par halki sharpening (sirf "screen bharo" mein hota hai)
FIT_LIFT = 0.04                 # 9:16 mein poori video thori upar: neeche captions + disclosure ki jagah


# ---------------------------------------------------------------------
#  Kaali pattiyan aadhi (campaign switch "fit_bars": full | half)
#  Kaam: 9:16 mein beech wali poori video (fit) ko itna bara karo ke
#  upar / neeche ki kaali jagah pehle se aadhi reh jaye. Sides chehre
#  (x_center) ke gird katti hain; logo kate to bhi theek (campaign ki marzi).
# ---------------------------------------------------------------------
def fit_zoom_for(info: SourceInfo, bars: str) -> float:
    if bars != "half":
        return 1.0
    out_w, out_h = OUTPUTS["9:16"]
    sw, sh = info.display_size
    if sw <= sh:
        return 1.0
    fh = out_w * sh / sw
    return round(min(out_h / fh, (out_h + fh) / (2 * fh)), 4)


def _fit_scaled(info: SourceInfo, out_w: int, out_h: int, zoom: float, xc: float, in_label: str, tag: str) -> str:
    """[in] -> zoom ki hui (sides kati) fit tasveer, label [tag] (pad se pehle)."""
    sw, sh = info.display_size
    fw = _even(out_w * zoom)
    fh = _even(fw * sh / sw)
    xc = max(0.0, min(1.0, xc))
    return (f"[{in_label}]scale={fw}:{fh}:flags=lanczos,"
            f"crop={out_w}:{fh}:'max(0,min(iw-{out_w},iw*{xc:.4f}-{out_w}/2))':0[{tag}]")


def path_expr(keys, t0: float) -> str:
    """Piecewise linear x centre over local time t from ((source time, x), ...)."""
    pts = [(max(0.0, t - t0), x) for t, x in keys]
    expr = f"{pts[-1][1]:.4f}"
    for (ta, xa), (tb, xb) in reversed(list(zip(pts, pts[1:]))):
        if tb - ta < 1e-3:
            continue
        seg = f"{xa:.4f}+({xb - xa:.4f})*(t-{ta:.3f})/{tb - ta:.3f}"
        expr = f"if(lt(t,{tb:.3f}),{seg},{expr})"
    return f"if(lt(t,{pts[0][0]:.3f}),{pts[0][1]:.4f},{expr})"


def choose_mode(info: SourceInfo, ratio: str, requested: str = "auto") -> str:
    """Pick a safe default mode for this source/output pair."""
    if requested in ("crop", "fit_blur"):
        return requested
    src_w, src_h = info.display_size
    out_w, out_h = OUTPUTS[ratio]
    src_vertical = src_h > src_w
    out_vertical = out_h > out_w
    if src_vertical != out_vertical:
        # vertical -> landscape always fit; landscape -> vertical crop is normal
        return "fit_blur" if src_vertical else "crop"
    return "crop"


def framing_filter(info: SourceInfo, ratio: str, plan: FramePlan, in_label: str, out_label: str) -> str:
    """Return a filtergraph fragment: [in_label] ... [out_label]"""
    out_w, out_h = OUTPUTS[ratio]
    if plan.mode == "stream" and plan.cam and out_h > out_w:
        return stream_filter(info, plan, in_label, out_label, fps=info.fps or 30)
    if plan.mode == "fit_blur":
        lift = int(FIT_LIFT * out_h) if out_h > out_w else 0
        if plan.zoom > 1.001 and out_h > out_w and info.display_size[0] > info.display_size[1]:
            z = _fit_scaled(info, out_w, out_h, plan.zoom, plan.x_center, in_label, "fz_fg")
            if plan.bg in ("black", "white"):
                return (f"{z};[fz_fg]pad={out_w}:{out_h}:(ow-iw)/2:max(0\\,(oh-ih)/2-{lift}):color={plan.bg},"
                        f"setsar=1[{out_label}]")
            return (f"[{in_label}]split=2[fb_a][fz_in];"
                    f"[fb_a]scale={out_w}:{out_h}:force_original_aspect_ratio=increase:flags=bicubic,"
                    f"crop={out_w}:{out_h},gblur=sigma=48,eq=brightness=-0.07:saturation=0.85,deband[fb_bg];"
                    + z.replace(f"[{in_label}]", "[fz_in]", 1) +
                    f";[fb_bg][fz_fg]overlay=(W-w)/2:max(0\\,(H-h)/2-{lift}),setsar=1[{out_label}]")
        if plan.bg in ("black", "white"):
            return (f"[{in_label}]scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:flags=lanczos,"
                    f"pad={out_w}:{out_h}:(ow-iw)/2:max(0\\,(oh-ih)/2-{lift}):color={plan.bg},setsar=1[{out_label}]")
        return (
            f"[{in_label}]split=2[fb_a][fb_b];"
            f"[fb_a]scale={out_w}:{out_h}:force_original_aspect_ratio=increase:flags=bicubic,"
            f"crop={out_w}:{out_h},gblur=sigma=48,eq=brightness=-0.07:saturation=0.85,deband[fb_bg];"
            f"[fb_b]scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:flags=lanczos[fb_fg];"
            f"[fb_bg][fb_fg]overlay=(W-w)/2:max(0\\,(H-h)/2-{lift}),setsar=1[{out_label}]"
        )

    if plan.vzoom > 1.001 and out_h > out_w:
        # (31 Oct) khari ad: andar wali video bari, upar ka logo dabba kam, sides thori katti
        z = plan.vzoom
        return (f"[{in_label}]crop=w='iw/{z:.4f}':h='ih/{z:.4f}':x='(iw-iw/{z:.4f})/2':"
                f"y='min(ih-ih/{z:.4f},ih*{max(0.0, plan.vtop):.4f})',"
                f"scale={out_w}:{out_h}:flags=lanczos,setsar=1[{out_label}]")

    # crop: take the biggest window of the output shape, centred on the subject
    target_ar = out_w / out_h
    xc = max(0.0, min(1.0, plan.x_center))
    yc = max(0.0, min(1.0, plan.y_center))
    band = max(0.5, min(1.0, plan.band))
    usable = "ih" if band >= 1.0 else f"ih*{band:.4f}"
    crop_w = f"min(iw,{usable}*{target_ar:.6f})"
    crop_h = f"min({usable},iw/{target_ar:.6f})"
    xcen = f"({plan.x_expr})" if plan.x_expr else f"{xc:.4f}"
    x = f"max(0,min(iw-{crop_w},iw*{xcen}-{crop_w}/2))"
    y = f"max(0,min({usable}-{crop_h},ih*{yc:.4f}-{crop_h}/2))"
    # 2 guna se zyada zoom (sirf "screen bharo" campaign): halki sharpening, tasveer kam dhundli
    src_h = max(1, info.display_size[1] if hasattr(info, "display_size") else out_h)
    sharp = ",unsharp=5:5:0.55:5:5:0.0" if out_h / (src_h * band) > ZOOM_SHARPEN else ""
    return (
        f"[{in_label}]crop=w='{crop_w}':h='{crop_h}':x='{x}':y='{y}',"
        f"scale={out_w}:{out_h}:flags=lanczos{sharp},setsar=1[{out_label}]"
    )


# ---------------------------------------------------------------------
#  Stacked layout (side by side source -> top / bottom)
# ---------------------------------------------------------------------
STACK_DIVIDER = 6        # px, thin dark line between the two halves
FACE_LINE = 0.40         # face centre sits at 40 % of its half (headroom)


def _even(v: float) -> int:
    return max(2, int(v) // 2 * 2)


def panel_crop(pw: int, ph: int, slot_w: int, slot_h: int, face: tuple[float, float]) -> tuple[int, int, int, int]:
    """
    Biggest window of the slot's shape inside a pw x ph side (= least
    zoom), placed so the face sits near FACE_LINE. Returns w, h, x, y.
    """
    ar = slot_w / slot_h
    if pw / ph < ar:
        cw, ch = _even(pw), _even(pw / ar)
    else:
        cw, ch = _even(ph * ar), _even(ph)
    fx, fy = face
    x = min(max(0, fx * pw - cw / 2), pw - cw)
    y = min(max(0, fy * ph - FACE_LINE * ch), ph - ch)
    return cw, ch, int(x), int(y)


def _banded(info: SourceInfo, band: float, *faces):
    """Source size and face positions when only the part above `band` is used."""
    sw, sh = info.display_size
    band = max(0.5, min(1.0, band))
    if band >= 1.0:
        return (sw, sh, *faces)
    return (sw, _even(sh * band), *((fx, min(1.0, fy / band)) for fx, fy in faces))


def stack_filter(info: SourceInfo, seam: float, top_face: tuple[float, float],
                 bottom_face: tuple[float, float], in_label: str, out_label: str, tag: str = "st",
                 swap: bool = False, band: float = 1.0) -> str:
    """Left side of the source on top, right side below (swap: the other way), 1080 x 1920."""
    out_w, out_h = OUTPUTS["9:16"]
    slot_h = out_h // 2
    sw, sh, top_face, bottom_face = _banded(info, band, top_face, bottom_face)
    sx = int(round(seam * sw))
    trim = max(2, int(sw * 0.004))           # stay clear of the join line in the source
    lw, rx = sx - trim, sx + trim
    rw = sw - rx
    lc = panel_crop(lw, sh, out_w, slot_h, top_face)
    rc = panel_crop(rw, sh, out_w, slot_h, bottom_face)
    return (
        f"[{in_label}]split=2[{tag}a][{tag}b];"
        f"[{tag}a]crop={lc[0]}:{lc[1]}:{lc[2]}:{lc[3]},scale={out_w}:{slot_h}:flags=lanczos,setsar=1[{tag}t];"
        f"[{tag}b]crop={rc[0]}:{rc[1]}:{rx + rc[2]}:{rc[3]},scale={out_w}:{slot_h}:flags=lanczos,setsar=1[{tag}u];"
        f"{f'[{tag}u][{tag}t]' if swap else f'[{tag}t][{tag}u]'}vstack=inputs=2,"
        f"drawbox=x=0:y={slot_h - STACK_DIVIDER // 2}:w=iw:h={STACK_DIVIDER}:color=black@0.85:t=fill,"
        f"setsar=1[{out_label}]"
    )


# ---------------------------------------------------------------------
#  Sawal jawab upar neeche (qa): do alag shots aik saath
#  Kaam: har aadhe (1080 x 960) ke liye us shakhs ke gird crop: chehra
#  aadhe ki chaurai ka ~QA_FACE, chehra upar se ~1/3 par (sar kabhi na
#  kate). Zoom kabhi QA_MAX_UP se zyada nahi. Upar = sawal karne wala,
#  neeche = main speaker.
# ---------------------------------------------------------------------
QA_FACE = 0.24
QA_MAX_UP = 3.6
QA_FACE_LINE = 0.36


def slot_crop(info: SourceInfo, cx: float, cy: float, fw: float, slot_w: int, slot_h: int,
              x0: float = -1.0, x1: float = -1.0, floor: float = 1.0) -> tuple[int, int, int, int]:
    """Source mein crop (w, h, x, y) jo aik aadhe (slot) mein us chehre ko poora dikhaye (kabhi aadha nahi):
    chehra hilne ke poore daire (x0..x1) samet, sar se thodi tak andar."""
    sw, sh = info.display_size
    ar = slot_w / slot_h
    min_h = slot_h / QA_MAX_UP
    want_w = (fw * sw / QA_FACE) if fw > 0 else sh * 0.75 * ar
    if x0 >= 0 and x1 > x0:
        want_w = max(want_w, (x1 - x0) * sw * 1.25)          # hilne ka poora daira + gunjaish
    fh = fw * sw * 1.2                                         # chehre ki unchai (px)
    if fh > 0:
        want_w = max(want_w, fh * 2.2 * ar)                    # sar aur thodi ke liye kam az kam itni unchai
    ch = max(min_h, min(float(sh), want_w / ar))
    cw = ch * ar
    if cw > sw:
        cw, ch = float(sw), sw / ar
    cw, ch = _even(cw), _even(ch)
    lo_x, hi_x = (x0 * sw, x1 * sw) if (x0 >= 0 and x1 > x0) else (cx * sw - fw * sw * 0.7, cx * sw + fw * sw * 0.7)
    x = (lo_x + hi_x) / 2 - cw / 2
    x = min(max(x, hi_x + fw * sw * 0.15 - cw), lo_x - fw * sw * 0.15)   # chehra poora andar (dono taraf thori jagah)
    x = min(max(0.0, x), sw - cw)
    top = cy * sh - 0.95 * fh                                  # baalon ki choti
    y = cy * sh - QA_FACE_LINE * ch
    y = min(y, top - 0.04 * ch) if fh > 0 else y               # sar kabhi na kate
    y = min(max(0.0, y), sh - ch)
    if floor < 0.999:
        # source ki likhai (naam ki patti / banner) neeche: crop ka neeche wala kinara us se upar
        lim = floor * sh
        if y + ch > lim:
            if ch > lim and lim >= min_h and (fh <= 0 or cy * sh + 0.6 * fh < lim):
                # poori unchai na samaye: thora aur zoom (QA_MAX_UP tak); chehra phir bhi poora
                nch = _even(lim)
                ncw = _even(nch * ar)
                x = min(max(0.0, x + (cw - ncw) / 2), sw - ncw)
                cw, ch = ncw, nch
            y = max(0.0, lim - ch)
    return cw, ch, int(x), int(y)


def rate_expr(fps: float) -> str:
    """fps ko pakki kasar mein (59.94 -> 60000/1001): sab hisse bilkul ek hi waqt par frame den."""
    from fractions import Fraction
    fps = fps if fps and fps > 0 else 30
    for ntsc in (24000, 30000, 48000, 60000, 120000):          # 23.976, 29.97, 59.94 ... asal kasar
        if abs(fps - ntsc / 1001) < 0.01:
            return f"{ntsc}/1001"
    r = Fraction(fps).limit_denominator(1001)
    return f"{r.numerator}/{r.denominator}"


def qa_filter(info: SourceInfo, piece, live_label: str, comp_label: str, out_label: str, tag: str) -> str:
    out_w, out_h = OUTPUTS["9:16"]
    slot_h = out_h // 2
    lc = slot_crop(info, piece.x_center, piece.face_y, piece.face_w, out_w, slot_h,
                   getattr(piece, "face_x0", -1.0), getattr(piece, "face_x1", -1.0),
                   getattr(piece, "text_top", 1.0))
    sh = info.display_size[1]
    sharp_l = ",unsharp=5:5:0.55:5:5:0.0" if slot_h / lc[1] > ZOOM_SHARPEN else ""
    rate = rate_expr(getattr(info, "fps", 0) or 0)
    # (16 Nov) dono hisse ek hi frame waqt par: warna vstack har hisse ke frame par naya frame banata (do guna)
    live = (f"[{live_label}]fps={rate},crop={lc[0]}:{lc[1]}:{lc[2]}:{lc[3]},scale={out_w}:{slot_h}:flags=lanczos"
            f"{sharp_l},setsar=1[{tag}l]")
    comp = f"[{comp_label}]fps={rate},setsar=1[{tag}c]"       # saathi pehle hi apne chehre par crop (renderer)
    order = f"[{tag}l][{tag}c]" if piece.live_top else f"[{tag}c][{tag}l]"
    _ = sh
    return (f"{live};{comp};{order}vstack=inputs=2,"
            f"drawbox=x=0:y={slot_h - STACK_DIVIDER // 2}:w=iw:h={STACK_DIVIDER}:color=black@0.85:t=fill,"
            f"setsar=1[{out_label}]")


# ---------------------------------------------------------------------
#  Panels layout (show graphic: speaker box + discussed box on a flat background)
# ---------------------------------------------------------------------
PANEL_INSET = 0.02       # stay inside the box border lines (share of the box size)


def _box_px(info: SourceInfo, box: tuple) -> tuple[int, int, int, int]:
    """x, y, w, h in source pixels, a little inside the box so its border never shows."""
    sw, sh = info.display_size
    x0, y0, x1, y1 = box
    dx, dy = (x1 - x0) * PANEL_INSET, (y1 - y0) * PANEL_INSET
    x, y = _even((x0 + dx) * sw), _even((y0 + dy) * sh)
    w = min(_even((x1 - x0 - 2 * dx) * sw), _even(sw - x))
    h = min(_even((y1 - y0 - 2 * dy) * sh), _even(sh - y))
    return x, y, w, h


def panels_crops(info: SourceInfo, piece) -> tuple:
    """(speaker crop w, h, x, y in source pixels, slot height) for a panels piece."""
    out_w, out_h = OUTPUTS["9:16"]
    slot_h = out_h // 2 if piece.box_b else out_h
    bx, by, bw, bh = _box_px(info, piece.box_a)
    cw, ch, cx, cy = panel_crop(bw, bh, out_w, slot_h, piece.top)
    return cw, ch, bx + cx, by + cy, slot_h


def fit_bottom(info: SourceInfo, piece, zoom: float = 1.0) -> float | None:
    """9:16 mein poori dikhti video / dabba (fit_blur, panels fit) ka neecha kinara (frame ka hissa), warna None."""
    out_w, out_h = OUTPUTS["9:16"]
    lift = int(FIT_LIFT * out_h)
    if piece.mode == "fit_blur":
        sw, sh = info.display_size
        if sw <= sh:
            return None
        fh = min(out_h, out_w * sh / sw * max(1.0, zoom))
    elif piece.mode == "panels" and getattr(piece, "fit", False):
        _, _, bw, bh = _box_px(info, piece.box_a)
        fh = min(out_h - 60, (out_w - 60) * bh / max(1, bw))
    else:
        return None
    return (max(0.0, (out_h - fh) / 2 - lift) + fh) / out_h


def panels_filter(info: SourceInfo, piece, in_label: str, out_label: str, tag: str = "pn", bg: str = "blur") -> str:
    """Speaker's box fills the top half; the other box is shown whole below (on a blur of itself)."""
    out_w, out_h = OUTPUTS["9:16"]
    if getattr(piece, "fit", False):
        bx, by, bw, bh = _box_px(info, piece.box_a)
        lift = int(FIT_LIFT * out_h)
        if bg in ("black", "white"):
            return (f"[{in_label}]crop={bw}:{bh}:{bx}:{by},scale={out_w - 60}:{out_h - 60}:"
                    f"force_original_aspect_ratio=decrease:flags=lanczos,"
                    f"pad={out_w}:{out_h}:(ow-iw)/2:max(0\\,(oh-ih)/2-{lift}):color={bg},setsar=1[{out_label}]")
        return (
            f"[{in_label}]crop={bw}:{bh}:{bx}:{by},split=2[{tag}a][{tag}b];"
            f"[{tag}a]scale={out_w}:{out_h}:force_original_aspect_ratio=increase:flags=bicubic,"
            f"crop={out_w}:{out_h},gblur=sigma=48,eq=brightness=-0.10:saturation=0.85,deband[{tag}g];"
            f"[{tag}b]scale={out_w - 60}:{out_h - 60}:force_original_aspect_ratio=decrease:flags=lanczos,"
            f"setsar=1[{tag}f];"
            f"[{tag}g][{tag}f]overlay=(W-w)/2:max(0\\,(H-h)/2-{lift}),setsar=1[{out_label}]"
        )
    cw, ch, cx, cy, slot_h = panels_crops(info, piece)
    if not piece.box_b:
        return (f"[{in_label}]crop={cw}:{ch}:{cx}:{cy},scale={out_w}:{out_h}:flags=lanczos,"
                f"setsar=1[{out_label}]")
    ox, oy, ow, oh = _box_px(info, piece.box_b)
    return (
        f"[{in_label}]split=3[{tag}a][{tag}b][{tag}c];"
        f"[{tag}a]crop={cw}:{ch}:{cx}:{cy},scale={out_w}:{slot_h}:flags=lanczos,setsar=1[{tag}t];"
        f"[{tag}b]crop={ow}:{oh}:{ox}:{oy},scale={out_w}:{slot_h}:force_original_aspect_ratio=increase:flags=bicubic,"
        f"crop={out_w}:{slot_h},gblur=sigma=40,eq=brightness=-0.10:saturation=0.85,deband[{tag}g];"
        f"[{tag}c]crop={ow}:{oh}:{ox}:{oy},scale={out_w - 60}:{slot_h - 60}:force_original_aspect_ratio=decrease:"
        f"flags=lanczos,setsar=1[{tag}f];"
        f"[{tag}g][{tag}f]overlay=(W-w)/2:(H-h)/2[{tag}u];"
        f"[{tag}t][{tag}u]vstack=inputs=2,"
        f"drawbox=x=0:y={slot_h - STACK_DIVIDER // 2}:w=iw:h={STACK_DIVIDER}:color=black@0.85:t=fill,"
        f"setsar=1[{out_label}]"
    )


def piece_filter(info: SourceInfo, ratio: str, piece, in_label: str, out_label: str, tag: str,
                 t0: float | None = None, bg: str = "blur", comp_label: str = "", fit_zoom: float = 1.0) -> str:
    """Framing for one layout piece (see app.render.layout.Piece). t0 = source time at local t = 0."""
    if piece.mode == "qa" and ratio == "9:16" and comp_label and getattr(piece, "comp", ()):
        return qa_filter(info, piece, in_label, comp_label, out_label, tag)
    if piece.mode == "panels" and ratio == "9:16":
        return panels_filter(info, piece, in_label, out_label, tag, bg=bg)
    if piece.mode == "stack":
        return stack_filter(info, piece.seam, piece.top, piece.bottom, in_label, out_label, tag,
                            swap=getattr(piece, "swap", False), band=getattr(piece, "band", 1.0))
    path = getattr(piece, "x_path", ())
    expr = path_expr(path, t0 if t0 is not None else piece.start) if path else ""
    plan = (FramePlan(mode="fit_blur", bg=bg, zoom=fit_zoom, x_center=getattr(piece, "x_center", 0.5))
            if piece.mode == "fit_blur"
            else FramePlan(mode="crop", x_center=piece.x_center, x_expr=expr,
                           band=getattr(piece, "band", 1.0)))
    frag = framing_filter(info, ratio, plan, in_label, out_label)
    return frag.replace("[fb_", f"[{tag}fb_").replace("[fz_", f"[{tag}fz_")       # unique labels per piece


# ---------------------------------------------------------------------
#  Classic (17 Nov): 16:9 source ka square hissa (bolne wale par, wahi
#  pur-sukoon camera jo baaki tool mein), 9:16 frame ke bilkul beech,
#  upar neeche saada kaali ya safed patti (upar title, video mein captions).
# ---------------------------------------------------------------------
CLASSIC_SQ = 1080              # square video ka size (9:16 pe poori chaurai)
CLASSIC_TOP = (1920 - CLASSIC_SQ) // 2     # 420: reference jaisa, bilkul beech
CLASSIC_EDGE = 0.011           # source ke kinare ki patli kaali lakeer kat jaye (upar neeche ~0.5%)


CLASSIC_STEP = 0.1             # camera har itne second baad naapa jata hai
CLASSIC_DEAD = 0.03            # itni chhoti harkat (source ki chaurai ka hissa) par camera nahi hilta
CLASSIC_CUT = 0.15             # shot badle aur itna faasla ho to seedha cut (warna aahista)
CLASSIC_GLIDE = (1.0, 2.2)     # camera ki ek harkat kam az kam / zyada se zyada itne second
CLASSIC_SETTLE = 0.6           # bolne wala itni der nayi jagah rahe tab camera chale (chhoti hil-jul par nahi)


def classic_camera(pieces: list, half: float = 0.28125) -> list:
    """(17 Nov, user: "jhatke nahi, smooth") Classic ka camera poore clip mein ek: tukron ki alag alag jagah
    se ek hamwar raasta. Halki harkat par nahi hilta, hile to aahista shuru, aahista ruke (1 se 2.2 s),
    sirf asal shot badalne par bara faasla ho to seedha cut. `half` = square ki aadhi chaurai (source ka hissa)."""
    from dataclasses import replace as _rep
    if not pieces:
        return pieces
    t0, t1 = pieces[0].start, pieces[-1].end
    lo, hi = half, 1.0 - half

    def clamp(x: float) -> float:
        return min(hi, max(lo, x)) if lo < hi else 0.5

    def raw(t: float) -> float:
        p = next((q for q in pieces if q.start - 1e-6 <= t < q.end), pieces[-1])
        path = getattr(p, "x_path", ()) or ()
        if not path:
            return getattr(p, "x_center", 0.5)
        if t <= path[0][0]:
            return path[0][1]
        for (ta, xa), (tb, xb) in zip(path, path[1:]):
            if ta <= t <= tb:
                return xa + (xb - xa) * ((t - ta) / (tb - ta) if tb - ta > 1e-6 else 1.0)
        return path[-1][1]

    bounds = [q.start for q in pieces[1:]]
    n = max(1, int(round((t1 - t0) / CLASSIC_STEP)))
    times = [t0 + i * (t1 - t0) / n for i in range(n + 1)]
    tg = [clamp(raw(t)) for t in times]
    # target ko thora thehrao: jagah tab badle jab woh CLASSIC_SETTLE tak wahan rahe (hil-jul nahi)
    w = max(1, int(CLASSIC_SETTLE / CLASSIC_STEP))
    settled = []
    for i in range(len(tg)):
        win = sorted(tg[i:i + w + 1])
        settled.append(win[len(win) // 2])
    keys = [(times[0], settled[0])]
    pos, glide = settled[0], None              # glide = (shuru waqt, kahan se, kahan tak, kitni der)
    for i in range(1, len(times)):
        t, want = times[i], settled[i]
        if glide is not None:
            gs, ga, gb, gd = glide
            u = min(1.0, (t - gs) / gd)
            pos = ga + (gb - ga) * u * u * (3 - 2 * u)
            if u >= 1.0:
                glide = None
        cut = next((b for b in bounds if times[i - 1] < b <= t + 1e-6), None)
        goal = glide[2] if glide is not None else pos
        if cut is not None and abs(want - pos) > CLASSIC_CUT:
            keys += [(cut - 0.002, pos), (cut, want)]      # naya shot: seedha nayi jagah (cut ke saath)
            pos, glide = want, None
        elif abs(want - goal) > CLASSIC_DEAD:
            d = min(CLASSIC_GLIDE[1], max(CLASSIC_GLIDE[0], abs(want - pos) * 12))
            glide = (t, pos, want, d)
        keys.append((t, pos))
    # seedhi line wale beech ke points nikaal do (ffmpeg ka hisaab chhota)
    slim = [keys[0]]
    for k in range(1, len(keys) - 1):
        (ta, xa), (tb, xb), (tc, xc) = slim[-1], keys[k], keys[k + 1]
        if tc - ta > 1e-6 and abs(xa + (xc - xa) * (tb - ta) / (tc - ta) - xb) > 0.0015:
            slim.append(keys[k])
    slim.append(keys[-1])
    out = []
    for p in pieces:
        mine = tuple(k for k in slim if p.start - 0.35 <= k[0] <= p.end + 0.35) or ((p.start, clamp(raw(p.start))),)
        out.append(_rep(p, x_path=mine, x_center=mine[0][1]))
    return out


def classic_filter(info: SourceInfo, piece, in_label: str, out_label: str, t0: float | None = None,
                   bg: str = "black") -> str:
    """[in] -> 1080x1920: square crop (piece ka x / x_path) beech mein, upar neeche `bg` rang."""
    out_w, out_h = OUTPUTS["9:16"]
    path = getattr(piece, "x_path", ()) if piece is not None else ()
    xc = getattr(piece, "x_center", 0.5) if piece is not None else 0.5
    expr = path_expr(path, t0 if t0 is not None else getattr(piece, "start", 0.0)) if path else ""
    xcen = f"({expr})" if expr else f"{max(0.0, min(1.0, xc)):.4f}"
    side = f"min(iw,ih*{1 - CLASSIC_EDGE:.4f})"
    x = f"max(0,min(iw-{side},iw*{xcen}-{side}/2))"
    y = f"(ih-{side})/2"
    colour = "white" if bg == "white" else "black"
    return (f"[{in_label}]crop=w='{side}':h='{side}':x='{x}':y='{y}',"
            f"scale={CLASSIC_SQ}:{CLASSIC_SQ}:flags=lanczos,"
            f"pad={out_w}:{out_h}:0:{CLASSIC_TOP}:color={colour},setsar=1[{out_label}]")


def face_heights(info: SourceInfo, ratio: str, piece) -> list[float]:
    """Where faces end up in the output frame (0..1 from the top) for one layout piece."""
    if piece.mode == "stack" and ratio == "9:16":
        out_w, out_h = OUTPUTS["9:16"]
        slot_h = out_h // 2
        band = getattr(piece, "band", 1.0)
        sw, sh, top, bottom = _banded(info, band, piece.top, piece.bottom)
        sx = int(round(piece.seam * sw))
        trim = max(2, int(sw * 0.004))
        crops = []
        for face, pw in ((top, sx - trim), (bottom, sw - sx - trim)):
            crops.append(panel_crop(pw, sh, out_w, slot_h, face))
        swap = getattr(piece, "swap", False)

        def out_y(side: int, fy: float) -> float | None:
            _, ch, _, cy = crops[side]
            rel = (fy * sh - cy) / ch
            if not 0.0 <= rel <= 1.0:
                return None                       # cropped away: not on screen
            slot = side if not swap else 1 - side
            return slot * 0.5 + rel * 0.5
        scale = 1.0 / max(0.5, min(1.0, band))
        ys = [out_y(0, top[1]), out_y(1, bottom[1])]
        ys += [out_y(side, fy * scale) for side, fy in getattr(piece, "others", ())]
        return [y for y in ys if y is not None] or [0.25, 0.75]
    if piece.mode == "qa" and ratio == "9:16":
        return [QA_FACE_LINE * 0.5, 0.5 + QA_FACE_LINE * 0.5]
    if piece.mode == "panels" and ratio == "9:16" and getattr(piece, "fit", False):
        return [0.5]
    if piece.mode == "panels" and ratio == "9:16":
        _, ch, _, cy, slot_h = panels_crops(info, piece)
        _, sh = info.display_size
        rel = (piece.face_y * sh - cy) / ch
        return [min(1.0, max(0.0, rel)) * slot_h / OUTPUTS["9:16"][1]]
    if piece.mode == "crop":
        return [min(1.0, getattr(piece, "face_y", 0.35) / max(0.5, min(1.0, getattr(piece, "band", 1.0))))]
    return [0.5]


# ---------------------------------------------------------------------
#  Title card ke liye video ka hissa: chehre ke hisaab se (sar kabhi na kate)
#  Kaam: 9:16 frame se 4:5 hissa (1350 px unchai) kaatna hai. Har shot mein
#  sar ki choti (baal samet) dhoondo aur us ke upar jagah chhod ke kaato.
#  Jagah na bane (do log upar neeche, ya sar bilkul upar) to None: us clip
#  pe title card nahi lagta, video poori screen pe banti hai (quality same).
# ---------------------------------------------------------------------
CARD_H = 1350            # title card mein video ki unchai (px, 1080 x 1920 pe)
CARD_DEFAULT_OFF = 285   # beech wala hissa (jab sar ki fikar na ho)
CARD_HEAD_GAP = 60       # baal aur safed hisse ke beech kam az kam itni jagah (px)
HAIR_ABOVE = 0.85        # chehre ke beech se baalon ki choti (naapa ~0.70, gunjaish ke sath)


def head_tops(info: SourceInfo, piece) -> list[float] | None:
    """Har chehre ke sar ki choti (px, 1920 frame mein). None = is shot pe title card nahi ho sakta."""
    _, out_h = OUTPUTS["9:16"]
    sw, sh = info.display_size
    if piece.mode in ("stack", "qa"):
        return None                                   # do log upar neeche: beech se katne pe kisi ka sar / thodi kategi
    if piece.mode == "fit_blur" or (piece.mode == "panels" and getattr(piece, "fit", False)):
        return []                                     # koi chehra nahi (tweet / poori tasveer)
    if piece.mode == "panels":
        _, ch, _, cy, slot_h = panels_crops(info, piece)
        rel = (piece.face_y * sh - cy) / ch
        face_h = max(0.18, min(0.6, getattr(piece, "face_w", 0.0) * sw / ch)) if getattr(piece, "face_w", 0.0) \
            else 0.32                                 # chehre ka size pata nahi: ehtiyat se bara maano
        return [(rel - HAIR_ABOVE * face_h) * slot_h]
    if piece.mode == "crop":
        band = max(0.5, min(1.0, getattr(piece, "band", 1.0)))
        crop_h = min(sh * band, sw / (9 / 16))
        cy = getattr(piece, "face_y", 0.35) * sh / crop_h
        fw = getattr(piece, "face_w", 0.0)
        face_h = fw * sw * 1.15 / crop_h if fw else 0.25      # YuNet dabba chaurai se thora lamba
        return [(cy - HAIR_ABOVE * face_h) * out_h]
    return None


def card_crop_offset(info: SourceInfo, pieces) -> int | None:
    """Title card ke liye 9:16 frame mein se kaatne ki upar wali lakeer (px), ya None (title card nahi)."""
    if not pieces:
        return None
    tops: list[float] = []
    for piece in pieces:
        found = head_tops(info, piece)
        if found is None:
            return None
        tops += found
    off = CARD_DEFAULT_OFF
    if tops:
        off = min(off, int(min(tops) - CARD_HEAD_GAP))
    if off < 0:
        return None                                   # sar frame ke bilkul upar: jagah nahi, title card nahi
    return off


# ---------------------------------------------------------------------
#  Stream (20 Nov, GTA 6): streamer ka camera + game, 9:16 mein
#  round: game beech mein (4:5), peeche usi ki dhundli copy, chehra gol
#         (safed kinara) game ke neeche wale kone par
#  stack: chehra upar (42%), game neeche, beech mein patli kaali lakeer
#  Gol mask ek hi baar banta hai aur dohraya jata hai (render par bojh nahi).
# ---------------------------------------------------------------------
STREAM_GAME_TOP = 285          # round: game ka upar wala kinara (px, 1920 mein)
STREAM_GAME_H = 1350           # round: game 1080x1350 (4:5)
STREAM_CIRCLE = 440            # round: gol chehre ka qutr (px)
STREAM_RING = 10               # round: safed kinara (px)
STREAM_CIRCLE_X = 44           # round: gol chehre ka baayan kinara
STREAM_CIRCLE_Y = 1290         # round: gol chehre ka upar wala kinara (game ke neeche wale kone par charha hua)
STREAM_TOP_H = 806             # stack: upar chehre ka hissa (42%)
STREAM_SEAM = 6                # stack: beech ki lakeer
STREAM_TOP_TRIM = 0.10         # game ka upar wala itna hissa nahi (chat, alerts; thora zoom)
STREAM_FACE_SPAN = 2.5         # gol: chehre ki chaurai ka itna guna hissa (sar, kandhe)


def _game_window(info: SourceInfo, plan: FramePlan, aspect: float) -> tuple[int, int, int, int]:
    """Game ka hissa (x, y, w, h px): poori unchai, beech se; camera se takraye to thora us se door."""
    sw, sh = info.display_size
    top_cut = STREAM_TOP_TRIM * sh if plan.cam else 0.0      # upar ke kone: chat / alerts (streamer ke overlay)
    gh = sh - top_cut
    gw = min(sw, _even(gh * aspect))
    if gw >= sw:
        gw = sw
        gh = min(sh, _even(gw / aspect))
    x = (sw - gw) / 2
    if plan.cam:
        cx0, cx1 = plan.cam[0] * sw, (plan.cam[0] + plan.cam[2]) * sw
        shift_max = 0.09 * sw
        if cx0 < x + gw and cx1 > x:                       # camera game ke hisse mein aa raha hai
            left_gap, right_gap = cx0 - x, (x + gw) - cx1
            if cx0 > sw / 2:                               # camera daayen: game baayen sarko
                x -= min(shift_max, (x + gw) - cx0)
            elif cx1 < sw / 2:
                x += min(shift_max, cx1 - x)
            del left_gap, right_gap
    x = max(0, min(sw - gw, x))
    return _even(x), _even(top_cut + (sh - top_cut - gh) / 2), _even(gw), _even(gh)


def _cam_window(info: SourceInfo, plan: FramePlan, aspect: float, span: float = 0.0) -> tuple[int, int, int, int]:
    """Camera dabbe ke andar ka hissa (x, y, w, h px) is shakal ka, chehra beech mein (span: chehre ka guna)."""
    sw, sh = info.display_size
    bx, by, bw, bh = plan.cam[0] * sw, plan.cam[1] * sh, plan.cam[2] * sw, plan.cam[3] * sh
    inset = max(2.0, 0.022 * bw)                           # dabbe ki apni lakeer (border) na aaye
    bx, by, bw, bh = bx + inset, by + inset, bw - 2 * inset, bh - 2 * inset
    fx, fy, fs = (plan.face[0] * sw, plan.face[1] * sh, plan.face[2] * sw) if plan.face else \
        (bx + bw / 2, by + bh / 2, bw / 3)
    if span:
        w = min(bw, bh * aspect, fs * span)
    else:
        w = min(bw, bh * aspect)
    h = w / aspect
    x = max(bx, min(bx + bw - w, fx - w / 2))
    y = max(by, min(by + bh - h, fy - 0.46 * h))           # sar ke upar thori jagah
    return _even(x), _even(y), max(2, _even(w)), max(2, _even(h))


def stream_filter(info: SourceInfo, plan: FramePlan, in_label: str, out_label: str, fps: float = 30) -> str:
    out_w, out_h = 1080, 1920
    fps = fps if fps and fps > 0 else 30
    if plan.layout == "stack":
        gh = out_h - STREAM_TOP_H - STREAM_SEAM
        cx, cy, cw, ch = _cam_window(info, plan, out_w / STREAM_TOP_H)
        gx, gy, gw, gh_src = _game_window(info, plan, out_w / gh)
        return (f"[{in_label}]split=2[st_c][st_g];"
                f"[st_c]crop={cw}:{ch}:{cx}:{cy},scale={out_w}:{STREAM_TOP_H}:flags=lanczos,setsar=1[st_top];"
                f"[st_g]crop={gw}:{gh_src}:{gx}:{gy},scale={out_w}:{gh}:flags=lanczos,setsar=1[st_bot];"
                f"[st_top]pad={out_w}:{STREAM_TOP_H + STREAM_SEAM}:0:0:color=black[st_top2];"
                f"[st_top2][st_bot]vstack=inputs=2,setsar=1[{out_label}]")
    # round
    d, ring = STREAM_CIRCLE, STREAM_CIRCLE + 2 * STREAM_RING
    gx, gy, gw, gh_src = _game_window(info, plan, out_w / STREAM_GAME_H)
    fx, fy, fw, fh = _cam_window(info, plan, 1.0, span=STREAM_FACE_SPAN)
    r, rr = d / 2 - 0.5, ring / 2 - 0.5

    def disk(size: int, rad: float, tag: str) -> str:
        # sirf EK frame: alphamerge / overlay aakhri frame khud dohrate hain. (Hamesha chalne wala mask cold
        # open wale clips mein memory mein jama hota tha aur ffmpeg mar jata tha.)
        return (f"color=c=black:s={size}x{size}:r={fps:.3f}:d={1.0 / fps:.5f},format=gray,"
                f"geq=lum='clip(255*({rad:.1f}-hypot(X-{rad:.1f},Y-{rad:.1f})),0,255)'[{tag}]")
    return (f"{disk(d, r, 'sr_m')};{disk(ring, rr, 'sr_rm')};"
            f"[{in_label}]split=3[sr_b][sr_g][sr_f];"
            f"[sr_b]crop={gw}:{gh_src}:{gx}:{gy},scale={out_w}:{out_h}:force_original_aspect_ratio=increase:"
            f"flags=bicubic,crop={out_w}:{out_h},gblur=sigma=40,eq=brightness=-0.12:saturation=0.9[sr_bg];"
            f"[sr_g]crop={gw}:{gh_src}:{gx}:{gy},scale={out_w}:{STREAM_GAME_H}:flags=lanczos,setsar=1[sr_game];"
            f"[sr_f]crop={fw}:{fh}:{fx}:{fy},scale={d}:{d}:flags=lanczos,format=yuva420p[sr_f0];"
            f"[sr_f0][sr_m]alphamerge[sr_face];"
            f"color=c=white:s={ring}x{ring}:r={fps:.3f}:d={1.0 / fps:.5f},format=yuva420p[sr_w0];"
            f"[sr_w0][sr_rm]alphamerge[sr_ring];"
            f"[sr_bg][sr_game]overlay=0:{STREAM_GAME_TOP}[sr_1];"
            f"[sr_1][sr_ring]overlay={STREAM_CIRCLE_X - STREAM_RING}:{STREAM_CIRCLE_Y - STREAM_RING}[sr_2];"
            f"[sr_2][sr_face]overlay={STREAM_CIRCLE_X}:{STREAM_CIRCLE_Y},setsar=1,format=yuv420p[{out_label}]")
