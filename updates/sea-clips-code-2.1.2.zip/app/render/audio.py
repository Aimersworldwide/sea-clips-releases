"""
=====================================================================
  RENDER / AUDIO
  Kaam: awaaz: beep / mute, loudness barabar.
  * Beep or mute banned words (original voice otherwise untouched)
  * Loudness: measure the clip, apply ONE volume change to -14 LUFS
    (the online standard; YouTube never turns quiet videos up). Only if
    sudden peaks would cross the ceiling, a transparent look-ahead
    limiter catches those milliseconds. No compressor, no auto-level.
  * 15 ms fades at every join so cuts never click
=====================================================================
"""
from __future__ import annotations

import json
import re
import threading

from app.media.ffmpeg_tools import run_ffmpeg

TARGET_I = -14.0
TARGET_TP = -1.5
TARGET_LRA = 11.0
BEEP_HZ = 1000
BEEP_LEVEL = 0.22     # gentle, not ear-piercing


def _between_expr(intervals: list[tuple[float, float]]) -> str:
    return "+".join(f"between(t,{a:.3f},{b:.3f})" for a, b in intervals) or "0"


def censor_filters(intervals: list[tuple[float, float]], mode: str, duration: float) -> tuple[str, str]:
    """
    Return (filter for the voice, extra source label or '').
    intervals are on the CLIP timeline.
    mode: beep -> mute + tone ; mute -> silence ; anything else -> none
    """
    if not intervals or mode not in ("beep", "mute"):
        return "", ""
    expr = _between_expr(intervals)
    mute = f"volume=volume=0:enable='{expr}'"
    if mode == "mute":
        return mute, ""
    tone = (f"aevalsrc=exprs='{BEEP_LEVEL}*sin(2*PI*{BEEP_HZ}*t)*gt({expr},0)':"
            f"s=48000:d={duration:.3f}:c=stereo")
    return mute, tone


def measure_loudness(audio_args: list[str], filter_complex: str, out_label: str,
                     cancel_event: threading.Event | None = None) -> dict | None:
    """Measure integrated loudness + true peak of the final clip audio."""
    graph = (f"{filter_complex};[{out_label}]loudnorm=I={TARGET_I}:TP={TARGET_TP}:LRA={TARGET_LRA}"
             f":print_format=json[ln]")
    stderr = run_ffmpeg([*audio_args, "-filter_complex", graph, "-map", "[ln]", "-f", "null", "-"],
                        cancel_event=cancel_event)
    match = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", stderr, re.S)
    if not match:
        return None
    data = json.loads(match.group(0))
    try:
        if float(data["input_i"]) < -70:      # silence: nothing to normalise
            return None
        float(data["input_tp"])
    except (KeyError, ValueError):
        return None
    return data


MAX_BOOST_DB = 20.0          # never lift a very quiet recording more than this (noise floor)
LIMIT_DBFS = -3.0            # sample-peak ceiling; leaves room for AAC overshoot (true peak <= -1 dBTP)


def loudness_gain_db(measured: dict | None) -> float:
    """Gain that brings the clip to TARGET_I (boost capped at MAX_BOOST_DB)."""
    if not measured:
        return 0.0
    return round(min(TARGET_I - float(measured["input_i"]), MAX_BOOST_DB), 2)


def needs_limiter(measured: dict | None) -> bool:
    """Only when the gain would push the loudest peaks past the ceiling."""
    if not measured:
        return False
    return float(measured["input_tp"]) + loudness_gain_db(measured) > TARGET_TP


def loudness_filter(measured: dict | None, correction_db: float = 0.0) -> str:
    """
    One plain volume change to -14 LUFS (YouTube turns loud videos down but
    never turns quiet ones up, so quiet clips must be lifted here). If a few
    sudden peaks (a shout, a clap) would go over the ceiling, a transparent
    look-ahead limiter catches only those milliseconds; everything else is
    untouched. No compressor, no auto-levelling.
    """
    gain = min(loudness_gain_db(measured) + correction_db, MAX_BOOST_DB) if measured else 0.0
    gain = round(gain, 2)
    if abs(gain) < 0.05:
        return "anull"
    chain = f"volume={gain}dB"
    if needs_limiter(measured):
        chain += (f",alimiter=limit={10 ** (LIMIT_DBFS / 20):.4f}:attack=5:release=50"
                  f":level=disabled:latency=enabled")
    return chain


def limiter_correction_db(audio_args: list[str], filter_complex: str, out_label: str,
                          measured: dict, cancel_event: threading.Event | None = None) -> float:
    """
    The limiter takes a little loudness away with the peaks. Measure once
    more WITH the limiter and return the dB still missing to TARGET_I
    (0 if no limiter is needed or the measure fails).
    """
    if not needs_limiter(measured):
        return 0.0
    graph = f"{filter_complex};[{out_label}]{loudness_filter(measured)}[lim]"
    after = measure_loudness(audio_args, graph, "lim", cancel_event)
    if not after:
        return 0.0
    return round(max(0.0, TARGET_I - float(after["input_i"])), 2)
