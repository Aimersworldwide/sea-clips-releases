"""
=====================================================================
  RENDER / TIMELINE
  Kaam: clip ke tukre: khamoshi aur kaate gaye lafz nikalna.
  A clip is a list of "keep" segments from the source. Silence
  removal and the banned-word "cut" mode both work by removing small
  pieces, so every word time must be moved to the new timeline.
  Silence levels (research: keep it natural, never breathless):
    off     : nothing removed
    light   : gaps > 0.45 s shortened to 0.22 s   (default, tight magar qudrati)
    medium  : gaps > 0.35 s -> 0.18 s, "um/uh" removed
    strong  : gaps > 0.28 s -> 0.14 s, "um/uh" removed
  Clip finder clips ki lambai silence kaatne KE BAAD ginta hai, is liye
  khamoshi kabhi "lambai poori karne" ke liye chhori nahi jaati.
  Never cut inside a word; 60 ms padding kept around speech.
=====================================================================
"""
from __future__ import annotations

from dataclasses import dataclass

from app.transcribe.models import Word

SILENCE_RULES = {
    "off": None,
    "light": (0.45, 0.22, False),
    "medium": (0.35, 0.18, True),
    "strong": (0.28, 0.14, True),
}
FILLERS = {"um", "uh", "erm", "uhh", "umm", "hmm"}
PAD = 0.06
MIN_SEGMENT = 0.25


@dataclass
class Segment:
    start: float   # source seconds
    end: float

    @property
    def duration(self) -> float:
        return self.end - self.start


def build_segments(
    words: list[Word],
    clip_start: float,
    clip_end: float,
    silence_level: str = "light",
    cut_word_indexes: set[int] | None = None,
    quiet: list[tuple[float, float]] | None = None,
) -> list[Segment]:
    """Return the source pieces to keep for one clip.
    quiet: awaaz se mili khamoshi (source seconds); lafzon ke beech na
    dikhne wali khamoshi bhi isi tarah chhoti hoti hai."""
    rule = SILENCE_RULES.get(silence_level)
    cut = set(cut_word_indexes or [])
    remove: list[tuple[float, float]] = []

    if rule:
        threshold, keep_gap, drop_fillers = rule
        half = max(PAD, keep_gap / 2)
        for a, b in quiet or []:
            if b > clip_start and a < clip_end and b - a > threshold:
                remove.append((a + half, b - half))
        for a, b in zip(words, words[1:]):
            gap = b.start - a.end
            if gap > threshold:
                # Keep `keep_gap` seconds of the pause: half after the
                # last word, half before the next (always >= PAD).
                half = max(PAD, keep_gap / 2)
                remove.append((a.end + half, b.start - half))
        if drop_fillers:
            for i, w in enumerate(words):
                if w.clean in FILLERS:
                    cut.add(i)

    # Lagataar kaate gaye lafz (poora jumla) ek saath: beech ki khamoshi bhi jaati hai
    run: list[int] = []
    for i in sorted(cut) + [None]:
        if i is not None and run and i == run[-1] + 1:
            run.append(i)
            continue
        if run:
            remove.append((words[run[0]].start - 0.02, words[run[-1]].end + 0.02))
        run = [i] if i is not None else []

    # Merge removals and turn them into keep segments.
    remove = sorted((max(clip_start, a), min(clip_end, b)) for a, b in remove if b - a > 0.05)
    merged: list[tuple[float, float]] = []
    for a, b in remove:
        if merged and a <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], b))
        else:
            merged.append((a, b))

    # A piece that holds a spoken word is ALWAYS kept, however short
    # ("No." after a long pause). Only empty slivers are dropped.
    spoken = [((w.start + w.end) / 2) for i, w in enumerate(words) if i not in cut]

    def has_word(a: float, b: float) -> bool:
        return any(a <= mid < b for mid in spoken)

    keep, cursor = [], clip_start
    for a, b in merged:
        if a - cursor >= MIN_SEGMENT or (a > cursor and has_word(cursor, a)):
            keep.append(Segment(cursor, a))
        cursor = max(cursor, b)
    if clip_end - cursor >= MIN_SEGMENT or (clip_end > cursor and has_word(cursor, clip_end)) or not keep:
        keep.append(Segment(cursor, clip_end))
    return keep


def gap_savings(words: list[Word], silence_level: str) -> list[float]:
    """
    Har lafz ke baad ki khamoshi mein se kitna kat ta hai (seconds),
    prefix sum ke saath: savings[k] = lafz 0..k-1 ke baad ki kul bachat.
    window ki asal lambai = (end - start) - (savings[last] - savings[first]).
    """
    rule = SILENCE_RULES.get(silence_level)
    out = [0.0]
    for a, b in zip(words, words[1:]):
        cut = 0.0
        if rule:
            threshold, keep_gap, _ = rule
            gap = b.start - a.end
            if gap > threshold:
                cut = gap - 2 * max(PAD, keep_gap / 2)
        out.append(out[-1] + max(0.0, cut))
    return out


def total_duration(segments: list[Segment]) -> float:
    return sum(s.duration for s in segments)


def remap_words(words: list[Word], segments: list[Segment]) -> list[tuple[int, Word]]:
    """
    Move words onto the clip timeline (0 = clip start). Words that fall
    in removed pieces are dropped. Returns (original_index, new_word).
    """
    out: list[tuple[int, Word]] = []
    # jis lafz ka beech kata hua hissa ho (lafz ke andar ki khamoshi kati), wo us tukre mein jahan
    # us ka zyada hissa bacha hai
    home: dict[int, int] = {}
    for i, w in enumerate(words):
        mid = (w.start + w.end) / 2
        if any(seg.start <= mid < seg.end for seg in segments):
            continue
        best = max(range(len(segments)), default=-1,
                   key=lambda k: min(w.end, segments[k].end) - max(w.start, segments[k].start))
        if best >= 0 and min(w.end, segments[best].end) - max(w.start, segments[best].start) > 0.05:
            home[i] = best
    offset = 0.0
    for k_seg, seg in enumerate(segments):
        for i, w in enumerate(words):
            mid = (w.start + w.end) / 2
            if seg.start <= mid < seg.end or home.get(i) == k_seg:
                ns = max(0.0, min(w.start, seg.end) - seg.start) + offset
                ne = max(ns + 0.05, min(w.end, seg.end) - seg.start + offset)
                out.append((i, Word(w.text, round(ns, 3), round(ne, 3), w.prob, w.speaker, w.doubt)))
        offset += seg.duration
    out.sort(key=lambda p: p[1].start)
    return out


def remap_time(t: float, segments: list[Segment]) -> float | None:
    """Source time -> clip time (None if inside a removed piece)."""
    offset = 0.0
    for seg in segments:
        if seg.start <= t <= seg.end:
            return offset + (t - seg.start)
        offset += seg.duration
    return None
