"""
=====================================================================
  RENDER / PHOTO FINDER   (main person ki mazeed photos, khud)
  Kaam: user 2 se 5 photos deta hai. Tool YouTube se us shakhs ki 2 ya 3
  videos (interview, show) ke shuru ke kuch minute leta hai, un mein se
  wahi chehre chunta hai jo user ki photos se PAKKA milte hain, aur har
  pose (saamne, baayen, daayen, upar / neeche dekhte hue) ki achhi
  photos rakhta hai. Is se side pose, kam roshni aur doosre angles mein
  bhi pehchan behtar hoti hai.
    * user ki photos hamesha asal reference rehti hain
    * sirf saaf, bare chehre (120 px+) aur bohot pakka mel (0.60+)
    * ek jaise frames nahi (kam az kam 3 second ka farq)
    * internet na ho / YouTube na mile: kuch nahi badalta
  Campaign ki apni video bhi isi tarah use ho sakti hai (harvest()).
=====================================================================
"""
from __future__ import annotations

import subprocess
from pathlib import Path

from app.core.logging_setup import get_logger
from app.render.person import DETECT_MODEL, PersonMatcher

log = get_logger("photo_finder")

SURE = 0.60               # itna mel ho to hi photo rakho (pehchan 0.42 pe hoti hai, yahan bohot sakht)
MIN_FACE = 120            # px
MIN_SCORE = 0.90          # YuNet face score
PER_POSE = 4              # har pose ki itni photos
MAX_PHOTOS = 15
MIN_GAP = 3.0             # do photos ke beech kam az kam itne second
SCAN_FPS = 0.5
SCAN_W = 1280


# ---------------------------------------------------------------------
#  Chehre ka pose: saamne / baayen / daayen / upar / neeche
#  YuNet ke 5 nuqte: aankhen, naak, munh ke kone
# ---------------------------------------------------------------------
def pose_of(raw) -> str:
    rex, rey, lex, ley, nx, ny = (float(raw[k]) for k in (4, 5, 6, 7, 8, 9))
    eye_mid_x, eye_mid_y = (rex + lex) / 2, (rey + ley) / 2
    eye_dist = max(1.0, abs(lex - rex))
    yaw = (nx - eye_mid_x) / eye_dist
    mouth_y = (float(raw[11]) + float(raw[13])) / 2
    pitch = (ny - eye_mid_y) / max(1.0, mouth_y - eye_mid_y)
    if yaw < -0.18:
        return "left"
    if yaw > 0.18:
        return "right"
    if pitch < 0.45:
        return "up"
    if pitch > 0.75:
        return "down"
    return "front"


# ---------------------------------------------------------------------
#  Ek video se pakke mel wale chehre nikaalo
# ---------------------------------------------------------------------
def harvest(video: Path, matcher: PersonMatcher, out_dir: Path, tag: str, start: float = 0.0,
            seconds: float = 300.0, max_photos: int = MAX_PHOTOS, cancel_event=None, on_log=None) -> list[Path]:
    import cv2
    import numpy as np

    from app.media.ffmpeg_tools import ffmpeg_bin
    from app.media.probe import probe
    info = probe(video)
    sw, sh = info.display_size
    w = min(SCAN_W, sw)
    h = max(2, int(round(w * sh / sw / 2)) * 2)
    det = cv2.FaceDetectorYN.create(str(DETECT_MODEL), "", (w, h), 0.6, 0.3, 50)
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "error", "-ss", f"{start:.2f}", "-t",
           f"{seconds:.2f}", "-i", str(video), "-an", "-vf", f"fps={SCAN_FPS},scale={w}:{h}:flags=area",
           "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    found: list[tuple[float, str, float, object]] = []          # (sim, pose, t, crop)
    k = 0
    seen = {"faces": 0, "big": 0, "best": -1.0}
    try:
        while True:
            if cancel_event is not None and cancel_event.is_set():
                break
            buf = proc.stdout.read(w * h * 3)
            if len(buf) < w * h * 3:
                break
            frame = np.frombuffer(buf, np.uint8).reshape(h, w, 3)
            t = start + k / SCAN_FPS
            k += 1
            _, faces = det.detect(frame)
            if faces is None:
                continue
            for f in faces:
                seen["faces"] += 1
                if min(f[2], f[3]) < MIN_FACE or f[-1] < MIN_SCORE:
                    continue
                seen["big"] += 1
                feat = matcher._feature(frame, f)
                sim = max(float(np.dot(feat, r)) for r in matcher.refs)
                seen["best"] = max(seen["best"], sim)
                if sim < SURE:
                    continue
                x, y, fw, fh = (float(v) for v in f[:4])
                cx, cy, side = x + fw / 2, y + fh / 2, max(fw, fh) * 1.9
                x0, y0 = int(max(0, cx - side / 2)), int(max(0, cy - side / 2))
                x1, y1 = int(min(w, cx + side / 2)), int(min(h, cy + side / 2))
                found.append((sim, pose_of(f), t, frame[y0:y1, x0:x1].copy()))
    finally:
        proc.kill()
        proc.wait()
    # har pose se behtareen, aapas mein waqt ka farq
    chosen: list[tuple[float, str, float, object]] = []
    for pose in ("front", "left", "right", "up", "down"):
        same = sorted((c for c in found if c[1] == pose), key=lambda c: -c[0])
        took = 0
        for c in same:
            if took >= PER_POSE or len(chosen) >= max_photos:
                break
            if any(abs(c[2] - o[2]) < MIN_GAP for o in chosen):
                continue
            chosen.append(c)
            took += 1
    out_dir.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []
    for sim, pose, t, crop in chosen:
        path = out_dir / f"{tag}_{int(t):05d}_{pose}.jpg"
        ok, enc = cv2.imencode(".jpg", crop, [cv2.IMWRITE_JPEG_QUALITY, 95])
        if ok:
            enc.tofile(str(path))
            saved.append(path)
    # sirf wo rakho jo khud bhi achhi reference photo hain (ek saaf chehra)
    good = [p for p, c in zip(saved, matcher_checks(saved)) if c]
    for p in saved:
        if p not in good:
            p.unlink(missing_ok=True)
    msg = (f"Photo finder: {k} frames ({w}x{h}), {seen['faces']} faces, {seen['big']} big and sharp, "
           f"best match {seen['best']:.2f}, {len(found)} matched, kept {len(good)} "
           f"({', '.join(sorted({c[1] for c in chosen})) or 'none'})")
    log.info("%s in %s", msg, video.name)
    if on_log:
        on_log(msg)
    return good


def matcher_checks(paths: list[Path]) -> list[bool]:
    if not paths:
        return []
    from app.render.person import PersonMatcher as _PM
    m = _PM.__new__(_PM)                 # sirf photo check (agree check ke baghair)
    import cv2
    import threading
    from app.render.person import RECOG_MODEL
    m._lock = threading.Lock()
    m._recog = cv2.FaceRecognizerSF.create(str(RECOG_MODEL), "")
    return [m._photo_feature(str(p))[1] is not None for p in paths]


class _QuietLog:
    """yt-dlp ki baatein sirf log file mein (console pe laal ERROR nahi)."""
    def debug(self, msg):
        pass

    def info(self, msg):
        pass

    def warning(self, msg):
        log.info("yt-dlp: %s", str(msg)[:200])

    def error(self, msg):
        log.info("yt-dlp: %s", str(msg)[:200])


# ---------------------------------------------------------------------
#  YouTube se: naam se 2-3 videos, har ek ke shuru ke 4 minute
# ---------------------------------------------------------------------
def find_online(name: str, photos: list[str], out_dir: Path, max_videos: int = 3, cancel_event=None,
                on_log=None) -> list[Path]:
    say = on_log or (lambda m: None)
    matcher = PersonMatcher(photos)
    if not matcher.usable or not name.strip():
        return []
    try:
        import yt_dlp  # type: ignore
    except ImportError:
        return []
    import tempfile

    from app.core.paths import temp_dir
    temp_dir().mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix="photo_finder_", dir=str(temp_dir())))   # har talaash ka apna folder
    query = f"ytsearch8:{name} interview"
    try:
        with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "extract_flat": True, "logger": _QuietLog(),
                               "socket_timeout": 15}) as ydl:
            res = ydl.extract_info(query, download=False) or {}
    except Exception as exc:  # noqa: BLE001 - internet nahi
        say(f"Photo search: YouTube not reachable ({str(exc)[:80]})")
        return []
    ids = [e.get("id") for e in res.get("entries") or []
           if isinstance(e, dict) and e.get("id") and 120 <= (e.get("duration") or 0) <= 4 * 3600]
    saved: list[Path] = []
    used = 0
    for vid in ids[:max_videos * 2]:
        if used >= max_videos or len(saved) >= MAX_PHOTOS or (cancel_event is not None and cancel_event.is_set()):
            break
        url = f"https://www.youtube.com/watch?v={vid}"
        target = tmp / f"{vid}.mp4"
        try:
            # yt-dlp se sirf stream ka pata (720p, sirf video), phir apna ffmpeg 4 minute ka hissa
            # utaarta hai. (yt-dlp ka "hissa download" kai laptops pe 360p pe chala jaata hai.)
            opts = {"quiet": True, "no_warnings": True, "logger": _QuietLog(), "socket_timeout": 20,
                    "format": "bestvideo[height<=720][height>=480][ext=mp4]/bestvideo[height<=720][height>=480]"
                              "/best[height<=720][height>=480]"}
            from app.media.download import _deno_options
            opts.update(_deno_options())
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False) or {}
            fmt = (info.get("requested_formats") or [info])[0]
            stream = fmt.get("url") or ""
            if not stream:
                raise RuntimeError("no stream address")
            headers = fmt.get("http_headers") or info.get("http_headers") or {}
            head = "".join(f"{k}: {v}\r\n" for k, v in headers.items())
            from app.media.ffmpeg_tools import ffmpeg_bin as _ff
            cmd = [_ff(), "-hide_banner", "-nostdin", "-loglevel", "error", "-y",
                   *(["-headers", head] if head else []), "-ss", "30", "-t", "150", "-i", stream,
                   "-an", "-c", "copy", str(target)]
            subprocess.run(cmd, capture_output=True, timeout=300,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            say(f"Photo search: video {vid} at {fmt.get('height') or '?'}p")
        except Exception as exc:  # noqa: BLE001
            log.info("photo video %s skipped: %s", vid, exc)
            say(f"Photo search: video {vid} skipped ({str(exc)[:120]})")
            target.unlink(missing_ok=True)
            continue
        if not target.exists():
            got_files = sorted(p.name for p in tmp.iterdir())
            say(f"Photo search: video {vid} not saved as expected ({', '.join(got_files)[:120] or 'nothing'})")
            for p in tmp.iterdir():
                p.unlink(missing_ok=True)
            continue
        try:
            got = harvest(target, matcher, out_dir, tag=f"web_{vid}", seconds=150,
                          max_photos=MAX_PHOTOS - len(saved), cancel_event=cancel_event, on_log=say)
        except Exception as exc:  # noqa: BLE001 - ek kharab video baaki talaash nahi rokti
            log.info("photo video %s not read: %s", vid, exc)
            say(f"Photo search: video {vid} could not be read ({type(exc).__name__}: {str(exc)[:150]})")
            got = []
        finally:
            target.unlink(missing_ok=True)
        saved += got
        used += 1 if got else 0
        say(f"Photo search: {len(got)} more photos of {name} from one video")
    try:
        tmp.rmdir()                                    # khali apna folder (sirf apna banaya hua)
    except OSError:
        pass
    return saved
