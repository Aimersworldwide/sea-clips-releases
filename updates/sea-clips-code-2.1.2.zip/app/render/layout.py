"""
=====================================================================
  RENDER / LAYOUT  (where the people are, shot by shot)
  Kaam: har shot mein kaun kahan hai, aur framing kaise ho.
  Looks at the clip's source range (3 frames per second, small size)
  and decides, for every camera shot, how to fill the 9:16 frame:

    stack     the source is already two pictures side by side
              (host left, guest right). Each side goes into its own
              half: left side on TOP, right side BELOW. Nobody is cut
              in half, and each side is zoomed only as much as needed
              to fill its half (about 1.1x).
              Two people of the same size sitting side by side in one
              wide shot are stacked the same way.
    crop      one camera shot. The crop follows the main face (the
              biggest, most present face, so bystanders are not
              chosen). Full source height is kept, so this is the
              least zoom a 9:16 crop can have. The position is fixed
              per shot (no shaky movement).
    panels    the source is a designed show graphic: the speaker in a
              small picture box (and often a second box with the tweet
              or video he talks about) on a flat coloured background.
              The speaker's box fills the TOP half, the other box is
              shown whole in the BOTTOM half; the flat background is
              never shown. Speaker box only: it fills the whole frame.
    fit_blur  no face found: the whole picture is shown on a blurred
              copy, so nothing important is cut.

  Face finding uses YuNet (OpenCV, small offline model in
  assets/models). It runs on the CPU, so both laptops get exactly the
  same framing. If anything fails, the clip falls back to the old
  centre framing; a clip is never lost because of this step.
=====================================================================
"""
from __future__ import annotations

import subprocess
import threading
from collections import OrderedDict
from dataclasses import dataclass, field, replace
from pathlib import Path
from statistics import median

from app.core.logging_setup import get_logger
from app.core.paths import resource
from app.media.ffmpeg_tools import Cancelled, ffmpeg_bin
from app.media.probe import SourceInfo
from app.render.subs import mid_text, text_spans, text_top

log = get_logger("layout")

MODEL = resource("assets", "models", "face_detection_yunet_2023mar.onnx")
SAMPLE_FPS = 3
SAMPLE_W = 640
DUO_SCORE = 0.80                 # clear face: detector confidence (weaker = back or side of a head)
MIN_PART = 0.5                   # shortest framing part kept when text splits a piece
SEAM_RANGE = (0.40, 0.60)        # where a side by side split can be
SEAM_COVERAGE = 0.55             # measured: split 0.68 to 0.9, normal shots below 0.35
SEAM_SHARP = 3.0                 # measured: split 4.6 to 6.3 (a natural edge is soft, about 1 to 2)
SEAM_EDGE = 18                   # grey level step that counts as an edge
CUT_DISTANCE = 0.45              # histogram distance that means a new camera shot
MIN_SHOT = 0.7                   # seconds; shorter shots join a neighbour
THUMB_CUT = 32.0                 # average grey change of a 64x36 picture that also means a cut
# same studio, same colours, new camera (close-up <-> wide): measured cut 33 to 47 / 0.19,
# inside one shot at most about 6 / 0.03
SOFT_CUT_MOVE = 24.0
SOFT_CUT_DISTANCE = 0.10
FACE_SCORE = 0.6


# ---------------------------------------------------------------------
#  Data
# ---------------------------------------------------------------------
@dataclass
class Face:
    cx: float     # centre, 0..1 of the frame
    cy: float
    w: float
    h: float
    score: float
    who: float = -1.0       # similarity to the campaign's main person (-1 = no main person / cannot tell)

    @property
    def mine(self) -> bool:
        """This face is the campaign's main person."""
        from app.render.person import MATCH
        return self.who >= MATCH

    @property
    def area(self) -> float:
        return self.w * self.h


@dataclass
class Sample:
    t: float                          # source seconds
    seam: float | None                # 0..1 x of a side by side split, if any
    faces: list[Face] = field(default_factory=list)
    hist: object = None               # small grey histogram (cut detection)
    thumb: object = None              # tiny grey picture (cut detection)
    gray: object = None               # small grey picture (seam re-check), dropped after planning
    text: float | None = None         # top of burned-in text at the bottom (0..1), None = none
    panels: list = field(default_factory=list)   # picture boxes on a flat background (x0, y0, x1, y1), 0..1
    mid: tuple | None = None          # (14 Nov) beech mein likhi line (left, right) 0..1: andar wali video ke captions


@dataclass
class Piece:
    """One camera shot of the clip and how to frame it (source times)."""
    start: float
    end: float
    mode: str = "crop"                # stack | panels | crop | fit_blur
    seam: float = 0.5
    x_center: float = 0.5             # crop: subject x (0..1 of the frame)
    top: tuple[float, float] = (0.5, 0.35)     # stack: face (x, y) inside the left side
    bottom: tuple[float, float] = (0.5, 0.35)  # stack: face (x, y) inside the right side
    swap: bool = False                # stack: right side on top (a re-edit variant)
    face_y: float = 0.35              # crop: main face height (0..1), used to keep titles off faces
    others: tuple = ()                # stack: other steady faces, ((side, cy), ...) side 0 = left, 1 = right
    x_path: tuple = ()                # crop: ((source time, x centre), ...) calm camera moves; () = still
    face_w: float = 0.0               # crop: main face width (tells a close-up from a wide shot)
    band: float = 1.0                 # crop / stack: frame only above this height (burned-in text below)
    reaction: bool = False            # crop: a short look at a listener while someone else talks
    locked: bool = False              # stack: the main person is on top; re-edits must not swap it
    box_a: tuple = ()                 # panels: the speaker's picture box (x0, y0, x1, y1), 0..1 of the frame
    box_b: tuple = ()                 # panels: the other picture box (shown whole below), () = none
    fit: bool = False                 # panels: no face, the box is shown whole (a tweet, a document)
    still_until: float = 0.0          # panels: source ki slide-in animation is waqt (source sec) tak: saaf frame roko
    still_from: float = 0.0           # panels: is waqt se slide-out animation: pichla saaf frame roko (0 = nahi)
    live_top: bool = False            # qa: jo is waqt bol raha (live) upar (sawal karne wala) ya neeche (main)
    live_talks: bool = False          # qa: jo camera par hai wohi bol raha hai (honth hil rahe)
    face_x0: float = -1.0             # qa: chehre ka baayan kinara (hilne samet), -1 = pata nahi
    face_x1: float = -1.0             # qa: daayan kinara
    main_live: bool = False           # qa: is waqt camera main speaker par (live wohi hai)
    comp: tuple = ()                  # qa: doosra hissa (source start, end, x, y, face_w): saath chalta shot
    comps: tuple = ()                 # qa: saathi shots ki zanjeer (har aik comp jaisa), ek ke baad ek, koi dobara nahi
    act: float = -1.0                 # shot mein dikhne wale shakhs ke honthon ki harkat (-1 = naapi nahi)
    same_person: bool = False         # qa: doosra zoom usi shakhs ka (akela tha): close up hamesha neeche
    text_top: float = 1.0             # qa: source ka likha hua (naam ki patti, "follow us") is unchai se neeche: crop upar rahe
    listen_key: tuple = ()            # sunne wala shot: (shot start, shot end, chehra number) - ginti ke liye
    listen_need: tuple = ()           # qa: is hisse ko sunne wale chahiyen (kitne second, beech ka waqt); har clip naye


# ---------------------------------------------------------------------
#  Frame sampling + per frame measurements
# ---------------------------------------------------------------------
def _frames(path: Path, start: float, end: float, size: tuple[int, int], cancel_event=None):
    import numpy as np
    w, h = size
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "error",
           "-ss", f"{start:.3f}", "-t", f"{max(0.1, end - start):.3f}", "-i", str(path),
           "-an", "-vf", f"fps={SAMPLE_FPS},scale={w}:{h}:flags=area", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=flags)
    frame_bytes = w * h * 3
    k = 0
    try:
        while True:
            if cancel_event is not None and cancel_event.is_set():
                raise Cancelled()
            buf = proc.stdout.read(frame_bytes)
            if len(buf) < frame_bytes:
                break
            yield start + k / SAMPLE_FPS, np.frombuffer(buf, np.uint8).reshape(h, w, 3)
            k += 1
    finally:
        proc.kill()
        proc.wait()


def find_seam(gray) -> tuple[float, float]:
    """
    (x 0..1, coverage) of the strongest full height vertical edge near the
    middle. A real split is a sharp one-pixel step; a natural edge (a
    shoulder, a door frame) is soft over several pixels, so its coverage
    is reported as 0 unless the step is SEAM_SHARP times stronger than
    3 pixels to either side.
    """
    import numpy as np
    w = gray.shape[1]
    lo, hi = int(w * SEAM_RANGE[0]), int(w * SEAM_RANGE[1])
    step = np.abs(np.diff(gray[:, lo - 3:hi + 4].astype(np.int16), axis=1))
    coverage = (step > SEAM_EDGE).mean(axis=0)
    inner = coverage[3:-3]
    k = int(inner.argmax()) + 3
    sharp = coverage[k] / max(1e-3, max(coverage[k - 3], coverage[k + 3]))
    cov = float(coverage[k]) if sharp >= SEAM_SHARP else 0.0
    return (lo - 3 + k + 1) / w, cov


def seam_coverage_at(gray, x: float) -> float:
    """Coverage of a vertical step exactly at x (used once a real split is known)."""
    import numpy as np
    w = gray.shape[1]
    c = int(round(x * w)) - 1
    if c < 1 or c >= w - 1:
        return 0.0
    step = np.abs(gray[:, c + 1].astype(np.int16) - gray[:, c].astype(np.int16))
    return float((step > SEAM_EDGE).mean())


# ---------------------------------------------------------------------
#  Picture boxes on a flat background (designed show graphics)
# ---------------------------------------------------------------------
PANEL_BG_DIST = 30          # Lab colour distance that still counts as the background colour
PANEL_RING = 0.6            # share of the frame edge that must be that one colour
PANEL_BG_SHARE = 0.25       # the background covers at least this much of the frame
PANEL_MIN = 0.04            # a box covers at least this much of the frame
PANEL_FILL = 0.75           # a box is solid picture, not scattered bits


def _split_columns(isbg, x0: int, y0: int, x1: int, y1: int, min_gap: int) -> list[tuple[int, int, int, int]]:
    """Two boxes that almost touch are split where a column is mostly background."""
    cols = isbg[y0:y1, x0:x1].mean(axis=0)
    parts, start = [], None
    for i, v in enumerate(cols):
        if v < 0.6:
            start = i if start is None else start
        elif start is not None:
            parts.append((start, i))
            start = None
    if start is not None:
        parts.append((start, len(cols)))
    joined: list[tuple[int, int]] = []
    for a, b in parts:
        if joined and a - joined[-1][1] < min_gap:
            joined[-1] = (joined[-1][0], b)
        else:
            joined.append((a, b))
    return [(x0 + a, y0, x0 + b, y1) for a, b in joined]


def find_panels(frame) -> list[tuple[float, float, float, float]]:
    """
    Picture boxes (x0, y0, x1, y1 as 0..1) when the frame is a show
    graphic: one flat colour around the edges and covering a good part of
    the frame, with solid rectangular pictures on top. [] for a normal
    camera picture (its edges are never one flat colour).
    """
    import cv2
    import numpy as np
    h, w = frame.shape[:2]
    lab = cv2.cvtColor(cv2.GaussianBlur(frame, (5, 5), 0), cv2.COLOR_BGR2LAB).astype(np.int16)
    m = max(2, int(0.03 * min(h, w)))
    ring = np.concatenate([lab[:m].reshape(-1, 3), lab[-m:].reshape(-1, 3),
                           lab[:, :m].reshape(-1, 3), lab[:, -m:].reshape(-1, 3)])
    bg = np.median(ring, axis=0)
    if (np.abs(ring - bg).sum(axis=1) < PANEL_BG_DIST).mean() < PANEL_RING:
        return []
    isbg = np.abs(lab - bg).sum(axis=2) < PANEL_BG_DIST
    if isbg.mean() < PANEL_BG_SHARE:
        return []
    fg = (~isbg).astype(np.uint8)
    fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, _, stats, _ = cv2.connectedComponentsWithStats(fg)
    out = []
    for i in range(1, n):
        x, y, bw, bh, _ = (int(v) for v in stats[i])
        if bw * bh < PANEL_MIN * w * h:
            continue
        # boxes joined by a thin frame line are split first, then each part must be solid picture
        for bx0, by0, bx1, by1 in _split_columns(isbg, x, y, x + bw, y + bh, max(2, w // 200)):
            rows = np.where(fg[by0:by1, bx0:bx1].mean(axis=1) > 0.5)[0]
            if not len(rows):
                continue
            by0, by1 = by0 + int(rows[0]), by0 + int(rows[-1]) + 1
            if (bx1 - bx0) * (by1 - by0) < PANEL_MIN * w * h:
                continue
            if fg[by0:by1, bx0:bx1].mean() < PANEL_FILL:
                continue
            out.append((round(bx0 / w, 4), round(by0 / h, 4), round(bx1 / w, 4), round(by1 / h, 4)))
    return out


def _inside(box: tuple, x: float, y: float) -> bool:
    return bool(box) and box[0] <= x <= box[2] and box[1] <= y <= box[3]


def _iou(a: tuple, b: tuple) -> float:
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union > 0 else 0.0


def _steady_box(boxes: list[tuple], near: tuple) -> tuple:
    """Median of the boxes that are the same box as `near` (same place across frames)."""
    same = [b for b in boxes if _iou(b, near) > 0.6]
    if not same:
        return ()
    return tuple(round(median(b[k] for b in same), 4) for k in range(4))


class FaceFinder:
    def __init__(self, size: tuple[int, int]):
        import cv2
        self.w, self.h = size
        self.det = cv2.FaceDetectorYN.create(str(MODEL), "", size, FACE_SCORE, 0.3, 50)

    def __call__(self, frame, matcher=None) -> list[Face]:
        _, found = self.det.detect(frame)
        if found is None:
            return []
        return [Face(float((f[0] + f[2] / 2) / self.w), float((f[1] + f[3] / 2) / self.h),
                     float(f[2] / self.w), float(f[3] / self.h), float(f[-1]),
                     matcher.similarity(frame, f) if matcher is not None else -1.0) for f in found]


# ---------------------------------------------------------------------
#  Samples ki yaad-dasht (speed): ek moment ke saare cuts aur edits ek
#  hi source hissa dekhte hain. Har sample ek pakki ghari (1/3 second ka
#  grid) pe liya jaata hai, is liye jo second ek dafa naap liya wo
#  dobara nahi parha jaata. Framing ka hisaab bilkul wohi rehta hai.
# ---------------------------------------------------------------------
_SAMPLES: "OrderedDict" = OrderedDict()   # (source key, grid index) -> Sample, sab se purana pehle
_SAMPLES_LOCK = threading.Lock()
_SAMPLES_MAX = 4000                  # ~22 minute video (~250 MB); is se zyada ho to purane bhool jao


def _measure_frame(t: float, frame, faces, matcher) -> Sample:
    import cv2
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    x, cov = find_seam(gray)
    hist = cv2.calcHist([gray], [0], None, [32], [0, 256])
    cv2.normalize(hist, hist)
    thumb = cv2.resize(gray, (64, 36), interpolation=cv2.INTER_AREA)
    small = cv2.resize(gray, (320, max(2, int(gray.shape[0] * 320 / gray.shape[1]))), interpolation=cv2.INTER_AREA)
    try:
        panels = find_panels(frame)
    except Exception:   # noqa: BLE001 - box finding is an extra, never a reason to lose framing
        panels = []
    return Sample(t, x if cov >= SEAM_COVERAGE else None, faces(frame, matcher), hist, thumb, small,
                  text_top(gray), panels, mid_text(gray))


def clear_sample_cache() -> None:
    with _SAMPLES_LOCK:
        _SAMPLES.clear()


def measure(path: Path, start: float, end: float, info: SourceInfo, cancel_event=None,
            matcher=None) -> list[Sample]:
    import math
    sw, sh = info.display_size
    w = SAMPLE_W
    h = max(2, int(round(w * sh / sw / 2)) * 2)
    first = math.ceil(start * SAMPLE_FPS - 1e-6)
    last = max(first, math.ceil(end * SAMPLE_FPS - 1e-6) - 1)
    ckey = (str(path), getattr(matcher, "key", "") if matcher is not None else "", w, h)
    with _SAMPLES_LOCK:
        missing = [i for i in range(first, last + 1) if (ckey, i) not in _SAMPLES]
    # gayab grid points ko lagataar hisson mein parho
    runs: list[list[int]] = []
    for i in missing:
        if runs and i == runs[-1][-1] + 1:
            runs[-1].append(i)
        else:
            runs.append([i])
    if runs:
        faces = FaceFinder((w, h))
        for run in runs:
            got: dict[int, Sample] = {}
            a = run[0] / SAMPLE_FPS
            for k, (_, frame) in enumerate(_frames(path, a, (run[-1] + 1) / SAMPLE_FPS, (w, h), cancel_event)):
                idx = run[0] + k
                if idx > run[-1]:
                    break
                got[idx] = _measure_frame(idx / SAMPLE_FPS, frame, faces, matcher)
            with _SAMPLES_LOCK:
                for i, smp in got.items():
                    _SAMPLES[(ckey, i)] = smp
    with _SAMPLES_LOCK:
        base = []
        for i in range(first, last + 1):
            smp = _SAMPLES.get((ckey, i))
            if smp is not None:
                _SAMPLES.move_to_end((ckey, i))
                base.append(smp)
        while len(_SAMPLES) > max(_SAMPLES_MAX, len(base)):
            _SAMPLES.popitem(last=False)
    # har clip ki apni copy (seam ka relax isi clip ke frames pe, jaise pehle)
    out = [Sample(b.t, b.seam, list(b.faces), b.hist, b.thumb, b.gray, b.text, list(b.panels), b.mid) for b in base]
    relax_seams(out)
    for smp in out:
        smp.gray = None
    return out


# ---------------------------------------------------------------------
#  Samples -> shots -> pieces
# ---------------------------------------------------------------------
def _hist_distance(a, b) -> float:
    import cv2
    return float(cv2.compareHist(a, b, cv2.HISTCMP_BHATTACHARYYA))


def _thumb_change(a, b) -> float:
    import numpy as np
    if a is None or b is None:
        return 0.0
    return float(np.abs(a.astype(np.int16) - b.astype(np.int16)).mean())


SEAM_RELAXED = 0.40              # coverage enough once the split position is known


def relax_seams(samples: list[Sample]) -> None:
    """
    When strict detection found a real split (30 %+ of frames, same x),
    frames at that same x with a weaker step also count as split: a
    close-up on one side can soften the join for a few seconds.
    """
    strict = [s.seam for s in samples if s.seam is not None]
    if len(strict) < 0.3 * len(samples) or not strict:
        return
    x0 = median(strict)
    if sum(abs(x - x0) < 0.01 for x in strict) < 0.8 * len(strict):
        return
    for s in samples:
        if s.seam is None and s.gray is not None and seam_coverage_at(s.gray, x0) >= SEAM_RELAXED:
            s.seam = x0


def _faces_differ(a: Sample, b: Sample) -> bool:
    """Different people or framing on the two pictures (a handheld close-up that moves is not a cut)."""
    if len(a.faces) != len(b.faces):
        return True
    if not a.faces:
        return True
    fa, fb = max(a.faces, key=lambda f: f.area), max(b.faces, key=lambda f: f.area)
    return abs(fa.cx - fb.cx) > 0.12 or not 0.75 < fa.w / max(fb.w, 1e-6) < 1.33


def split_shots(samples: list[Sample]) -> list[list[Sample]]:
    """Group samples into camera shots (cut = picture jump or split on/off)."""
    if not samples:
        return []
    # split on/off decided by the majority of 5 neighbouring frames, so one
    # frame that misses the seam never cuts a split shot into pieces
    flags = [s.seam is not None for s in samples]
    split = [sum(flags[max(0, i - 2):i + 3]) * 2 > len(flags[max(0, i - 2):i + 3]) for i in range(len(flags))]
    shots = [[samples[0]]]
    for i, (prev, cur) in enumerate(zip(samples, samples[1:])):
        cut = split[i] != split[i + 1]
        if not cut and prev.hist is not None and cur.hist is not None:
            dist = _hist_distance(prev.hist, cur.hist)
            # a new camera angle on the same place keeps similar colours but moves everything
            moved = _thumb_change(prev.thumb, cur.thumb)
            cut = dist > CUT_DISTANCE or (moved > THUMB_CUT and dist > CUT_DISTANCE / 2) \
                or (moved > SOFT_CUT_MOVE and dist > SOFT_CUT_DISTANCE and _faces_differ(prev, cur))
        if cut:
            shots.append([cur])
        else:
            shots[-1].append(cur)
    # very short shots (a flash, a detection blip) join the previous shot
    min_n = max(1, int(round(MIN_SHOT * SAMPLE_FPS)))
    merged: list[list[Sample]] = []
    for shot in shots:
        if merged and len(shot) < min_n:
            merged[-1].extend(shot)
        else:
            merged.append(shot)
    if len(merged) > 1 and len(merged[0]) < min_n:
        merged[1] = merged[0] + merged[1]
        merged.pop(0)
    return merged


def _groups(faces: list[Face]) -> list[tuple[float, list[Face]]]:
    """
    One group per person, best first: (weight, faces). A face joins a
    group only if it is close to that group's centre (scaled by face
    size), biggest faces first, so a crowd never chains into one group.
    """
    groups: list[list[Face]] = []
    centres: list[tuple[float, float, float]] = []
    for f in sorted(faces, key=lambda f: -f.area):
        for k, (gx, gy, gw) in enumerate(centres):
            if abs(f.cx - gx) < 0.6 * gw and abs(f.cy - gy) < 0.8 * gw * 16 / 9:
                groups[k].append(f)
                n = len(groups[k])
                centres[k] = (gx + (f.cx - gx) / n, gy + (f.cy - gy) / n, gw)
                break
        else:
            groups.append([f])
            centres.append((f.cx, f.cy, f.w))

    def weight(g: list[Face]) -> float:
        # a weakly found face (the back or side of a head) counts far less than a clear one
        total = sum(f.area * f.score * (1.0 if f.score >= DUO_SCORE else 0.3) for f in g)
        edge = sum(f.cx - f.w / 2 < 0.01 or f.cx + f.w / 2 > 0.99 for f in g) / len(g)
        centre = 1.0 - 0.4 * abs(median(f.cx for f in g) - 0.5)     # camera people frame the speaker
        main = MAIN_WEIGHT if _is_main(g) else 1.0                  # the campaign's main person wins
        return total * (1.0 - 0.7 * edge) * centre * main
    return sorted(((weight(g), g) for g in groups), key=lambda x: -x[0])


MAIN_WEIGHT = 8.0                # how much more the main person counts when choosing who to frame
MAIN_SHARE = 0.3                 # a group is the main person when this share of its faces matched


def _is_main(g: list[Face]) -> bool:
    return bool(g) and sum(f.mine for f in g) >= MAIN_SHARE * len(g)


def _summary(g: list[Face]) -> Face:
    return Face(median(f.cx for f in g), median(f.cy for f in g),
                median(f.w for f in g), median(f.h for f in g), max(f.score for f in g),
                max(f.who for f in g) if _is_main(g) else -1.0)


def _main_face(faces: list[Face]) -> Face | None:
    """The face that matters: big and present, not a passer-by."""
    if not faces:
        return None
    return _summary(_groups(faces)[0][1])


def _spread(values: list[float]) -> float:
    """Middle 80 % range of values (how much a face moves around)."""
    v = sorted(values)
    return v[int(len(v) * 0.9) - 1 if len(v) > 1 else 0] - v[len(v) // 10] if v else 0.0


def _duo(shot: list[Sample]) -> Piece | None:
    """
    Two people of the same size side by side in one wide shot (podcast,
    interview): too far apart for one 9:16 crop, so they get stacked
    too, left person on top. Strict rules so a crowd never triggers it.
    """
    gs = _groups([f for s in shot for f in s.faces])
    if len(gs) < 2:
        return None
    a, b = _summary(gs[0][1]), _summary(gs[1][1])
    present = min(len(gs[0][1]), len(gs[1][1])) >= 0.7 * len(shot)
    alike = min(a.w, b.w) >= 0.8 * max(a.w, b.w) and min(a.w, b.w) >= 0.05
    level = abs(a.cy - b.cy) < 0.15
    apart = abs(a.cx - b.cx) >= 0.30
    inside = all(0.01 < f.cx - f.w / 2 and f.cx + f.w / 2 < 0.99 for f in (a, b))
    # both faces clearly seen and sitting still: the back or side of a head in an
    # over-the-shoulder shot is found weakly and wanders, so it never makes a duo
    clear = all(median(f.score for f in g) >= DUO_SCORE for g in (gs[0][1], gs[1][1]))
    still = all(_spread([f.cx for f in g]) <= 0.35 * f0.w for g, f0 in ((gs[0][1], a), (gs[1][1], b)))
    if not (present and alike and level and apart and inside and clear and still):
        return None
    left, right = sorted((a, b), key=lambda f: f.cx)
    seam = (left.cx + right.cx) / 2
    # the campaign's main person always goes on top
    return Piece(shot[0].t, shot[-1].t, "stack", seam,
                 top=(left.cx / seam, left.cy), bottom=((right.cx - seam) / (1 - seam), right.cy),
                 swap=right.mine and not left.mine, locked=left.mine or right.mine)


def _side_faces(shot: list[Sample], seam: float, left: bool) -> tuple[list[Face], int]:
    """Faces inside one side, converted to 0..1 of that side. Also: samples that had one."""
    faces, hits = [], 0
    for s in shot:
        found = False
        for f in s.faces:
            if left and f.cx + f.w * 0.25 < seam:
                faces.append(Face(f.cx / seam, f.cy, f.w / seam, f.h, f.score, f.who))
                found = True
            elif not left and f.cx - f.w * 0.25 > seam:
                faces.append(Face((f.cx - seam) / (1 - seam), f.cy, f.w / (1 - seam), f.h, f.score, f.who))
                found = True
        hits += found
    return faces, hits


PANEL_SHARE = 0.6           # share of a shot's frames that must show picture boxes
BOX_B_COVER = 0.8           # neeche wala dabba shot ke itne frames mein same jagah ho


def _panels(shot: list[Sample]) -> Piece | None:
    """
    A show graphic: the main face sits inside a picture box on a flat
    background. Its box goes on top; the biggest other box (the tweet or
    video being discussed) is shown whole below.
    """
    with_boxes = [s for s in shot if s.panels]
    if len(with_boxes) < PANEL_SHARE * len(shot):
        return None
    boxes = [b for s in with_boxes for b in s.panels]
    face = _main_face([f for s in with_boxes for f in s.faces])
    if face is None:
        # nobody on screen (a full screen tweet on the show graphic): its biggest box, shown whole
        # sab se zyada frames mein same jagah wala dabba (barabar ho to bara)
        def cover(c):
            return sum(1 for x in with_boxes if any(_iou(b, c) > 0.6 for b in x.panels)) / len(with_boxes)
        steadiest = max(boxes, key=lambda b: (round(cover(b), 2), (b[2] - b[0]) * (b[3] - b[1])))
        box = _steady_box(boxes, steadiest) if cover(steadiest) >= BOX_B_COVER else ()
        return Piece(shot[0].t, shot[-1].t, "panels", box_a=box, fit=True) if box else None
    holding = [b for b in boxes if _inside(b, face.cx, face.cy)]
    if len(holding) < PANEL_SHARE * len(with_boxes):
        return None
    box_a = _steady_box(holding, holding[len(holding) // 2])
    if not box_a or not _inside(box_a, face.cx, face.cy):
        return None
    # neeche wala dabba: wo jo shot ke zyada tar frames mein ek hi jagah ho
    # (sirf kuch frames mein nazar aane wala dabba = background ka hissa dikhta, wo nahi)
    box_b: tuple = ()
    per_frame = [[b for b in s.panels if _iou(b, box_a) < 0.1 and not _inside(b, face.cx, face.cy)]
                 for s in with_boxes]
    others = [b for bs in per_frame for b in bs]
    best, best_cover = None, 0.0
    for cand in others:
        cover = sum(1 for bs in per_frame if any(_iou(b, cand) > 0.6 for b in bs)) / len(with_boxes)
        area = (cand[2] - cand[0]) * (cand[3] - cand[1])
        if best is None or (cover, area) > (best_cover, (best[2] - best[0]) * (best[3] - best[1])):
            best, best_cover = cand, cover
    if best is not None and best_cover >= BOX_B_COVER:
        box_b = _steady_box(others, best)
    # the face position inside its own box (0..1 of the box)
    fx = (face.cx - box_a[0]) / max(1e-6, box_a[2] - box_a[0])
    fy = (face.cy - box_a[1]) / max(1e-6, box_a[3] - box_a[1])
    return Piece(shot[0].t, shot[-1].t, "panels", top=(fx, fy), x_center=face.cx, face_y=face.cy,
                 face_w=face.w, box_a=box_a, box_b=box_b, locked=True)


_NO_SPLIT = threading.local()       # (15 Nov) campaign "no split content": upar neeche do hisse kabhi nahi


def plan_shot(shot: list[Sample]) -> Piece:
    panels = _panels(shot)
    if panels is not None:
        return panels
    no_split = getattr(_NO_SPLIT, "on", False)
    seams = [s.seam for s in shot if s.seam is not None]
    if len(seams) >= 0.6 * len(shot) and not no_split:
        seam = median(seams)
        steady = sum(abs(x - seam) < 0.015 for x in seams) >= 0.7 * len(seams)
        lf, lhits = _side_faces(shot, seam, True)
        rf, rhits = _side_faces(shot, seam, False)
        need = 0.4 * len(shot)
        if steady and lhits >= need and rhits >= need:
            a, b = _main_face(lf), _main_face(rf)
            # every steady face of each side (not only the main one) so titles keep off all of them
            steady_faces = tuple((side, round(f.cy, 3)) for side, faces in ((0, lf), (1, rf))
                                 for _, g in _groups(faces) if len(g) >= 0.3 * len(shot)
                                 for f in [_summary(g)])
            return Piece(shot[0].t, shot[-1].t, "stack", seam, top=(a.cx, a.cy), bottom=(b.cx, b.cy),
                         others=steady_faces, swap=b.mine and not a.mine, locked=a.mine or b.mine)
    duo = None if no_split else _duo(shot)
    if duo is not None:
        return duo
    face = _main_face([f for s in shot for f in s.faces])
    if face is None:
        return Piece(shot[0].t, shot[-1].t, "fit_blur")
    return Piece(shot[0].t, shot[-1].t, "crop", x_center=face.cx, face_y=face.cy, face_w=face.w)


def plan_pieces(samples: list[Sample], start: float, end: float) -> list[Piece]:
    """Contiguous pieces covering [start, end]; boundaries halfway between samples."""
    shots = split_shots(samples)
    # neighbouring split shots with the seam in the same place are one layout
    # (a camera cut inside one side must not make the other side jump)
    joined_shots: list[list[Sample]] = []
    for shot in shots:
        seams = [x.seam for x in shot if x.seam is not None]
        prev = joined_shots[-1] if joined_shots else None
        pseams = [x.seam for x in prev if x.seam is not None] if prev else []
        if (prev and len(seams) >= 0.5 * len(shot) and len(pseams) >= 0.5 * len(prev)
                and abs(median(seams) - median(pseams)) < 0.01):
            prev.extend(shot)
        else:
            joined_shots.append(list(shot))
    pieces = [plan_shot(shot) for shot in joined_shots]
    if not pieces:
        return []
    # neighbouring shots with the same framing become one piece
    joined = [pieces[0]]
    for p in pieces[1:]:
        q = joined[-1]
        same = p.mode == q.mode and (
            (p.mode == "crop" and abs(p.x_center - q.x_center) < 0.03
             and (not p.face_w or not q.face_w or 0.67 < p.face_w / q.face_w < 1.5))
            or (p.mode == "stack" and abs(p.seam - q.seam) < 0.01
                and abs(p.top[1] - q.top[1]) < 0.05 and abs(p.bottom[1] - q.bottom[1]) < 0.05)
            or (p.mode == "panels" and p.fit == q.fit and _iou(p.box_a, q.box_a) > 0.8
                and ((not p.box_b and not q.box_b) or (p.box_b and q.box_b and _iou(p.box_b, q.box_b) > 0.8)))
            or p.mode == "fit_blur")
        if same:
            q.end = p.end
        else:
            joined.append(p)
    half = 0.5 / SAMPLE_FPS
    for a, b in zip(joined, joined[1:]):
        a.end = b.start = round(b.start - half, 3)
    joined[0].start = start
    joined[-1].end = end
    return [p for p in joined if p.end - p.start > 0.01]


def _people(samples: list[Sample]) -> list[tuple[float, Face]]:
    """People who matter in a shot (weight, summary): big enough and there most of the time."""
    faces = [f for smp in samples for f in smp.faces]
    groups = _groups(faces) if faces else []
    if not groups:
        return []
    top_w, top = groups[0][0], _summary(groups[0][1])
    out = []
    for weight, g in groups[:4]:
        f = _summary(g)
        if weight >= 0.3 * top_w and f.w >= 0.5 * top.w and len(g) >= 0.4 * len(samples):
            out.append((weight, f))
    return out


def follow_speakers(pieces: list[Piece], samples: list[Sample], info: SourceInfo,
                    words: list[tuple[float, float]], cancel_event=None) -> list[Piece]:
    """Crop shots with several people: frame both when they fit, else follow who is talking."""
    from app.render.speaker import Person, choose_turns, measure_activity
    sw, sh = info.display_size
    crop_w = min(1.0, (sh * 9 / 16) / sw)
    out: list[Piece] = []
    for p in pieces:
        if p.mode != "crop":
            out.append(p)
            continue
        inside = [smp for smp in samples if p.start - 0.01 <= smp.t <= p.end + 0.01]
        people = _people(inside)
        if len(people) < 2:
            out.append(p)
            continue
        xs = [f.cx for _, f in people]
        span = max(xs) - min(xs) + max(f.w for _, f in people)
        if span <= crop_w * 0.95:                       # everyone fits: frame them together
            out.append(replace(p, x_center=(max(xs) + min(xs)) / 2))
            continue
        if p.end - p.start < 2 * 2.0:                   # too short to change speaker calmly
            out.append(p)
            continue
        persons = [Person(f.cx, f.cy, f.w) for _, f in people]
        try:
            times, acts = measure_activity(info.path, p.start, p.end, info.display_size, persons, cancel_event)
            turns = choose_turns(times, acts, words, p.start, p.end, default=0)
        except Cancelled:
            raise
        except Exception as exc:   # noqa: BLE001 - keep the main face if anything fails
            log.warning("Speaker following skipped: %s", exc)
            out.append(p)
            continue
        for tn in turns:
            out.append(replace(p, start=tn.start, end=tn.end, x_center=persons[tn.person].cx,
                               face_y=persons[tn.person].cy))
    return out


# ---------------------------------------------------------------------
#  Calm camera moves inside one shot (a speaker who walks or leans)
# ---------------------------------------------------------------------
MOVE_SECONDS = 0.6          # one smooth move
DEAD_MARGIN = 0.04          # face edge must stay this far inside the crop (share of frame width)
MIN_DEAD = 0.04             # never move for less than this (share of frame width)


def face_track(samples: list[Sample], start_x: float, start_w: float) -> list[tuple[float, float, float]]:
    """(time, x, width) of one person through a shot: always the face nearest to where they were."""
    track, x, w = [], start_x, start_w
    for smp in samples:
        near = [f for f in smp.faces if abs(f.cx - x) < max(0.25, 1.5 * w) and 0.5 * w < f.w < 2.0 * w]
        if not near:
            continue
        f = min(near, key=lambda f: abs(f.cx - x))
        track.append((smp.t, f.cx, f.w))
        x, w = f.cx, f.w
    return track


def crop_path(track: list[tuple[float, float, float]], crop_w: float, start: float, end: float,
              first_x: float) -> tuple:
    """
    Keyframes for a calm camera: the crop stays still while the face is
    comfortably inside it; when the face nears an edge, one smooth move
    (MOVE_SECONDS) brings it back, then the crop is still again.
    () when no move is needed.
    """
    half = crop_w / 2
    lo, hi = half, 1 - half

    def clamp(v: float) -> float:
        return min(hi, max(lo, v))
    c = clamp(first_x)
    keys = [(start, c)]
    busy_until = start
    # follow the person's average position over ~1.5 s, not every little sway
    smooth = []
    for i, (t, x, w) in enumerate(track):
        near = [tx for tt, tx, _ in track if abs(tt - t) <= 0.75]
        smooth.append((t, median(near), w))
    for t, x, w in smooth:
        dead = max(MIN_DEAD, half - w / 2 - DEAD_MARGIN)
        if abs(x - c) <= dead or t < busy_until:
            continue
        target = clamp(x - (dead * 0.3 if x > c else -dead * 0.3))   # a little past centre, not all the way
        t0 = max(t - 0.2, keys[-1][0])
        t1 = min(end, t0 + MOVE_SECONDS)
        if t1 - t0 < 0.15 or abs(target - c) < 0.01:
            continue
        keys += [(t0, c), (t1, target)]
        c, busy_until = target, t1
    if len(keys) == 1:
        return ()
    keys.append((end, c))
    out = []
    for t, x in keys:                     # drop repeats, keep times increasing
        if out and t <= out[-1][0] + 1e-3:
            out[-1] = (out[-1][0], x)
        else:
            out.append((round(t, 3), round(x, 4)))
    return tuple(out) if len(out) > 2 else ()


def follow_motion(pieces: list[Piece], samples: list[Sample], info: SourceInfo) -> list[Piece]:
    """Add calm camera moves to crop pieces whose person moves beyond the crop."""
    sw, sh = info.display_size
    crop_w = min(1.0, (sh * 9 / 16) / sw)
    out = []
    for p in pieces:
        if p.mode != "crop" or crop_w >= 0.99:
            out.append(p)
            continue
        inside = [smp for smp in samples if p.start - 0.01 <= smp.t <= p.end + 0.01]
        sizes = [f.w for smp in inside for f in smp.faces if abs(f.cx - p.x_center) < 0.15]
        if not sizes:
            out.append(p)
            continue
        track = face_track(inside, p.x_center, median(sizes))
        path = crop_path(track, crop_w, p.start, p.end, track[0][1] if track else p.x_center)
        out.append(replace(p, x_path=path) if path else p)
    return out


# ---------------------------------------------------------------------
#  Reaction shots: a short look at a listener during a long monologue
# ---------------------------------------------------------------------
REACT_PIECE = 7.0           # only crop pieces at least this long get a reaction
REACT_EVERY = 10.0          # at most one reaction per this many seconds of a piece
REACT_LEN = (1.2, 2.0)      # how long one reaction lasts
REACT_SAFE_START = 3.0      # never in the first seconds of a clip (the hook belongs to the speaker)
REACT_SAFE_END = 2.0        # nor in its last seconds (the payoff belongs to the speaker)


def _listeners(inside: list[Sample], speaker_x: float, crop_w: float) -> list[Face]:
    """Clear, steady faces in the shot that the speaker's crop does not show."""
    faces = [f for s in inside for f in s.faces if f.score >= DUO_SCORE]
    if not faces:
        return []
    main = [f for f in faces if abs(f.cx - speaker_x) < crop_w / 2]
    main_w = median(f.w for f in main) if main else median(f.w for f in faces)
    out = []
    for _, g in _groups(faces):
        f = _summary(g)
        if f.mine:                                          # the main person may be smaller than the speaker
            main_w = min(main_w, f.w / 0.6)
        if (abs(f.cx - speaker_x) > crop_w * 0.55 and f.w >= 0.6 * main_w
                and len(g) >= 0.6 * len(inside) and _spread([x.cx for x in g]) <= 0.35 * f.w
                and 0.01 < f.cx - f.w / 2 and f.cx + f.w / 2 < 0.99):
            out.append(f)
    return out


def _snap(t: float, words: list[tuple[float, float]], use_start: bool, lo: float, hi: float) -> float:
    """Nearest word start (or end) to t inside [lo, hi]; t itself when no word is near."""
    marks = [w[0] if use_start else w[1] for w in words]
    near = [m for m in marks if lo <= m <= hi and abs(m - t) <= 0.6]
    return min(near, key=lambda m: abs(m - t)) if near else t


def add_reactions(pieces: list[Piece], samples: list[Sample], info: SourceInfo,
                  words: list[tuple[float, float]], clip_start: float, clip_end: float,
                  main_mode: bool = False, quiet: list[tuple[float, float]] | None = None) -> list[Piece]:
    """
    `quiet`: source seconds where the main person is being attacked
    (protection guard); no reaction shot of him there.
    During a long stretch on one speaker, cut to a listener's face for
    1.2 to 2 seconds (the voice keeps going), then back. Only clear,
    steady faces that are really in the picture, never at the start or
    end of the clip, never in stacked or full picture shots.
    """
    sw, sh = info.display_size
    crop_w = min(1.0, (sh * 9 / 16) / sw)
    out: list[Piece] = []
    for p in pieces:
        lo, hi = max(p.start, clip_start + REACT_SAFE_START), min(p.end, clip_end - REACT_SAFE_END)
        if p.mode != "crop" or p.reaction or p.end - p.start < REACT_PIECE or hi - lo < 3.0 or crop_w >= 0.99:
            out.append(p)
            continue
        inside = [s for s in samples if p.start - 0.01 <= s.t <= p.end + 0.01]
        listeners = _listeners(inside, p.x_center, crop_w)
        if main_mode:
            # only ever cut TO the main person (a guest talking, him listening), never away from him
            on_him = any(f.mine and abs(f.cx - p.x_center) < crop_w / 2 for s in inside for f in s.faces)
            listeners = [] if on_him else [f for f in listeners if f.mine]
        if not listeners:
            out.append(p)
            continue
        count = max(1, min(2, int((p.end - p.start) // REACT_EVERY)))
        cur, made = p.start, 0
        for k in range(count):
            who = listeners[k % len(listeners)]
            centre = lo + (hi - lo) * (k + 1) / (count + 1)
            length = REACT_LEN[0] + (REACT_LEN[1] - REACT_LEN[0]) * ((k + int(p.start)) % 3) / 2
            a = _snap(centre - length / 2, words, True, lo, hi)
            b = _snap(a + length, words, False, a + REACT_LEN[0], min(hi, a + REACT_LEN[1] + 0.4))
            seen = [s for s in inside if a <= s.t <= b]
            # the listener must be on screen the whole time
            if any(a < q1 + 1.0 and b > q0 - 1.0 for q0, q1 in (quiet or [])):
                continue                     # hamle ke waqt us ka reaction shot nahi
            if (b - a < REACT_LEN[0] or a - cur < 1.0 or not seen
                    or not all(any(abs(f.cx - who.cx) < max(0.05, who.w) for f in s.faces) for s in seen)):
                continue
            out.append(replace(p, start=cur, end=a))
            out.append(replace(p, start=a, end=b, x_center=who.cx, face_y=who.cy, face_w=who.w,
                               x_path=(), reaction=True))
            cur, made = b, made + 1
        out.append(replace(p, start=cur) if made else p)
    return out


def avoid_text(pieces: list[Piece], samples: list[Sample]) -> list[Piece]:
    """
    While burned-in text shows at the bottom of a crop or stack piece,
    that stretch is framed from just above the text (the piece is cut
    in two or three; camera path and faces stay the same).
    """
    out: list[Piece] = []
    for p in pieces:
        inside = [s for s in samples if p.start - 0.01 <= s.t <= p.end + 0.01]
        spans = (text_spans([s.t for s in inside], [s.text for s in inside], 1 / SAMPLE_FPS)
                 if p.mode in ("crop", "stack") and inside else [])
        cur = p.start
        for a, b, band in spans:
            # never cut a face: the lowest steady face must stay above the line
            chins = [f.cy + f.h * 0.6 for s in inside if a <= s.t <= b for f in s.faces if f.h > 0.05]
            if chins and median(chins) > band:
                continue
            a, b = max(cur, a), min(p.end, b)
            if a - cur < MIN_PART:
                a = cur                                  # tiny left-over before: zoom from the start
            if p.end - b < MIN_PART:
                b = p.end
            if b - a < MIN_PART:
                continue
            if a > cur:
                out.append(replace(p, start=cur, end=a))
            out.append(replace(p, start=a, end=b, band=band))
            cur = b
        if cur < p.end:
            out.append(replace(p, start=cur) if cur > p.start else p)
    return out


# ---------------------------------------------------------------------
#  2x had: source ki tasveer kabhi 2 guna se zyada bari nahi (blur nahi)
#  Kaam: 1080x1920 output ke hisaab se har piece ka enlargement check.
#    crop / stack : text se bachne wala zoom (band) itna hi jitna 2x
#                   tak jaye; is se zyada ho to band hata do (tab
#                   captions ke peeche cover box lagta hai)
#    crop         : source hi itna chhota ho (720p) ke crop 2x se upar
#                   jaye: poori tasveer blur background pe (fit_blur)
#    panels       : speaker ka dabba 2x se zyada bara karna pare to wo
#                   dabba poora dikhao (fit), kaata hua nahi
# ---------------------------------------------------------------------
MAX_UP = 2.0
MAX_UP_FILL = 3.6       # "screen bharo" campaign: 720p video bhi zoom ho (thora soft, kaala hissa nahi)


def limit_zoom(pieces: list[Piece], info: SourceInfo, fill: bool = False) -> list[Piece]:
    from app.render.framing import OUTPUTS, panels_crops
    out_w, out_h = OUTPUTS["9:16"]
    sw, sh = info.display_size
    base = out_h / max(1, sh)                              # poori unchai 1920 tak
    top_up = MAX_UP_FILL if fill else MAX_UP
    out: list[Piece] = []
    for p in pieces:
        if p.mode in ("crop", "stack") and p.band < 1.0 and base / p.band > top_up:
            p = replace(p, band=1.0)
        if p.mode == "crop" and base > top_up:
            p = replace(p, mode="fit_blur", reaction=False)
        if p.mode == "panels" and not p.fit and p.box_a:
            try:
                cw, ch, _, _, slot_h = panels_crops(info, p)
                if ch <= 0 or slot_h / ch > MAX_UP:
                    p = replace(p, fit=True, box_b=())
            except Exception:  # noqa: BLE001 - check only
                pass
        out.append(p)
    return out


# ---------------------------------------------------------------------
#  Screen bharo (campaign switch "fill_screen")
#  Kaam: viral political shorts jaisa: kabhi upar / neeche kaala hissa
#  nahi. Door se dikhta banda (stage, podium) zoom ho kar kamar se upar
#  poori screen par:
#    * crop: chehra frame ki chaurai ka ~FILL_FACE ho, utna zoom (band =
#      upar ka hissa; neeche ki patti / ticker khud bahar)
#    * zoom kabhi MAX_UP_FILL se zyada nahi (warna bohot dhundla)
#    * jahan chehra na mile (poori tasveer): beech se crop, kaala nahi
#  Sar hamesha frame mein: chehra band ke upar wale aadhe mein na ho to
#  zoom kam.
# ---------------------------------------------------------------------
FILL_FACE = 0.24        # chehre ki chaurai / output ki chaurai (examples: ~0.22 se 0.30)


# (15 Nov) campaign ka "Zoom" slider (fit_zoom) screen bharo mein: kitna paas jaye.
# (chehre ka hissa, crop ke upar zyada se zyada zoom); 0 / purani campaigns = Large (pehle jaisa)
FILL_ZOOMS = {1.0: (0.0, 1.0), 1.3: (0.16, 1.3), 1.5: (0.20, 1.6), 1.7: (FILL_FACE, 99.0)}


def fill_setting(fit_zoom: float) -> tuple[float, float]:
    """(face share, max extra zoom) for the campaign's zoom slider."""
    z = float(fit_zoom or 0)
    if z <= 0:
        return FILL_ZOOMS[1.7]
    return FILL_ZOOMS[min(FILL_ZOOMS, key=lambda k: abs(k - z))]


def fill_band(info: SourceInfo, face_w: float, face_y: float, limit: float = 1.0,
              face_share: float = FILL_FACE, max_extra: float = 99.0) -> float:
    """Screen bharo ka zoom (band): chehra ~face_share chaura, sar upar wale hisse mein, MAX_UP_FILL tak."""
    from app.render.framing import OUTPUTS
    _, out_h = OUTPUTS["9:16"]
    sw, sh = info.display_size
    lowest = max(0.5, out_h / max(1, sh) / MAX_UP_FILL, 1.0 / max(1.0, max_extra))
    if face_w <= 0 or face_share <= 0:
        return limit
    band = max(lowest, min(1.0, face_w * sw / (face_share * sh * 9 / 16), limit))
    while band < limit and face_y > band * 0.42:              # sar / chehra upar wale hisse mein rahe
        band = min(limit, band + 0.05)
    return round(band, 3)


def fill_zoom(pieces: list[Piece], info: SourceInfo, face_share: float = FILL_FACE,
              max_extra: float = 99.0) -> list[Piece]:
    from app.render.framing import OUTPUTS
    _, out_h = OUTPUTS["9:16"]
    sw, sh = info.display_size
    base = out_h / max(1, sh)
    if base > MAX_UP_FILL:
        return pieces                                      # bohot chhoti video: zoom se tasveer kharab
    lowest = max(0.5, base / MAX_UP_FILL)
    out: list[Piece] = []
    for p in pieces:
        if p.mode == "fit_blur":
            p = replace(p, mode="crop", x_center=0.5, face_y=0.35, face_w=0.0)
        if p.mode == "panels" and getattr(p, "fit", False) and p.box_a:
            # (15 Nov) poora dabba beech mein (upar neeche khaali / kaala) screen bharo mein mana:
            # dabbe ke beech par seedha crop, poori unchai
            cx = (p.box_a[0] + p.box_a[2]) / 2
            p = replace(p, mode="crop", x_center=min(1.0, max(0.0, cx)), face_y=0.35, face_w=0.0, band=1.0,
                        fit=False, box_a=(), box_b=())
        if p.mode == "crop" and p.face_w > 0 and not p.reaction and not p.x_path:
            # (camera chal raha ho - x_path - to zoom nahi: chalne ki had chaure crop ke hisaab se bani hai)
            band = fill_band(info, p.face_w, p.face_y, p.band, face_share, max_extra)
            if band < p.band - 0.01:
                p = replace(p, band=band)
        out.append(p)
    return out


# ---------------------------------------------------------------------
#  Aadha chehra nahi (15 Nov 2026)
#  Kaam: screen bharo ke crop ke kinare par kisi ka aadha chehra (sirf
#  kaan, aadhi naak) na aaye. Crop thora sarakta hai: chehra poora andar
#  (main person ho to yahi pasand) ya poora bahar. Jis par crop hai wo
#  hamesha poora andar rehta hai.
# ---------------------------------------------------------------------
FACE_PAD = 0.35            # chehre ke saath baal / kaan: chaurai ka itna hissa har taraf


def no_cut_faces(pieces: list[Piece], samples: list[Sample], info: SourceInfo) -> list[Piece]:
    from app.render.framing import OUTPUTS
    out_w, out_h = OUTPUTS["9:16"]
    sw, sh = info.display_size
    out: list[Piece] = []
    for p in pieces:
        if p.mode != "crop" or p.x_path or p.reaction:
            out.append(p)
            continue
        cw = min(1.0, p.band * sh * out_w / out_h / max(1, sw))      # crop ki chaurai (frame ka hissa)
        if cw >= 0.999:
            out.append(p)
            continue
        inside = [f for x in samples if p.start - 0.01 <= x.t <= p.end + 0.01 for f in x.faces]
        groups = [_summary(g) for _w, g in _groups(inside) if len(g) >= 2]
        if not groups:
            out.append(p)
            continue
        main = min(groups, key=lambda f: abs(f.cx - p.x_center))
        half = cw / 2

        def span(f):
            pad = f.w * (0.5 + FACE_PAD)
            return f.cx - pad, f.cx + pad

        def ok(x: float) -> bool:
            lo, hi = x - half, x + half
            m0, m1 = span(main)
            if m0 < lo - 1e-6 or m1 > hi + 1e-6:
                return False
            for f in groups:
                if f is main:
                    continue
                a, b = span(f)
                if a < hi and b > lo and not (a >= lo and b <= hi):
                    return False                     # aadha andar aadha bahar
            return True

        x0 = min(1 - half, max(half, p.x_center))
        if ok(x0):
            out.append(p)
            continue
        best, score = None, 9.0
        for f in groups:
            a, b = span(f)
            for cand in (a + half, b - half, a - half - 0.001, b + half + 0.001):
                c = min(1 - half, max(half, cand))
                if not ok(c):
                    continue
                cost = abs(c - x0) - (0.05 if (f.who >= 0 and a >= c - half and b <= c + half) else 0)
                if cost < score:
                    best, score = c, cost
        if best is not None and abs(best - x0) < cw:
            p = replace(p, x_center=round(best, 4))
        elif main.cx - main.w / 2 < x0 - half or main.cx + main.w / 2 > x0 + half:
            # bohot paas wala chehra (poora fit nahi): kam se kam beech mein, aadha kinare par nahi
            p = replace(p, x_center=round(min(1 - half, max(half, main.cx)), 4))
        out.append(p)
    return out


# ---------------------------------------------------------------------
#  Sawal jawab upar neeche (Q&A stack, "screen bharo" campaign)
#  Kaam: viral political shorts jaisa: aik hi waqt mein do hisse:
#    upar  = sawal karne wala / audience
#    neeche = main speaker
#  Dono hisse hamesha usi lamhe ke (neeche "EK hi lamhe ke DO zoom" dekho).
# ---------------------------------------------------------------------
QA_MAIN = 0.5            # piece ke itne samples mein main speaker sab se bara chehra = main ka shot


def _main_share(p: Piece, samples: list[Sample]) -> float:
    inside = [x for x in samples if p.start - 0.01 <= x.t <= p.end + 0.01 and x.faces]
    if not inside:
        return 0.0
    return sum(1 for x in inside if max(x.faces, key=lambda f: f.area).mine) / len(inside)


TALK_MIN = 0.15          # honthon ki harkat (bolte waqt ~0.2 se 0.35, sunte waqt ~0.1 ya kam)


def _face_box(g: list[Face]) -> tuple[float, float, float, float, float]:
    left = sorted(f.cx - f.w / 2 for f in g)
    right = sorted(f.cx + f.w / 2 for f in g)
    x0 = left[int(len(left) * 0.1)]
    x1 = right[min(len(right) - 1, int(len(right) * 0.9))]
    return median(f.cx for f in g), median(f.cy for f in g), median(f.w for f in g), x0, x1


def _talker(p: Piece, samples: list[Sample], info: SourceInfo | None, words, cancel_event=None):
    """
    Is shot mein kaun bol raha hai (honth hil rahe): (chehra x, y, w, x0, x1, harkat) ya None.
    Sirf woh log jo shot ke kam az kam 30% mein nazar aayein (sab se bare 3). words = [(start, end)]
    bole gaye lafz (None = poora shot gino).
    """
    faces = [f for x in samples if p.start - 0.01 <= x.t <= p.end + 0.01 for f in x.faces]
    if not faces or info is None:
        return None
    n = max(1, sum(1 for x in samples if p.start - 0.01 <= x.t <= p.end + 0.01))
    groups = [g for _, g in _groups(faces) if len(g) >= 0.3 * n][:3]
    if not groups:
        return None
    from app.render.speaker import Person, measure_activity
    people = [_summary(g) for g in groups]
    times, acts = measure_activity(info.path, p.start, p.end, info.display_size,
                                   [Person(f.cx, f.cy, f.w) for f in people], cancel_event)
    if not times:
        return None
    spoken = [k for k, t in enumerate(times) if not words or any(a - 0.15 <= t <= b + 0.15 for a, b in words)]
    rows = [acts[k] for k in spoken] or acts
    score = [sum(r[j] for r in rows) / len(rows) for j in range(len(groups))]
    best = max(range(len(groups)), key=lambda j: score[j])
    return (*_face_box(groups[best]), score[best])


def _face_of(p: Piece, samples: list[Sample], info: SourceInfo | None = None, words=None, cancel_event=None,
             talking: bool = False):
    """
    Is shot ka asal shakhs: (x, y, chaurai, baayan kinara, daayan kinara, honthon ki harkat).
    talking=True: jo bol raha hai (honth hil rahe) wohi, warna sab se zyada / bara dikhne wala.
    Kinare us ke hilne ka poora daira (10% se 90%), taake crop chehra poora dikhaye.
    """
    faces = [f for x in samples if p.start - 0.01 <= x.t <= p.end + 0.01 for f in x.faces]
    if not faces:
        return None
    if talking and info is not None:
        try:
            got = _talker(p, samples, info, words, cancel_event)
            if got is not None:
                return got
        except Cancelled:
            raise
        except Exception as exc:  # noqa: BLE001 - honth na naap sakein to sab se bara chehra
            log.warning("Talking face check skipped: %s", exc)
    groups = _groups(faces)
    if not groups:
        return None
    return (*_face_box(groups[0][1]), -1.0)


def _mine_box(p: Piece, samples: list[Sample]):
    """Main speaker ke saare chehre (har jagah jahan wo shot mein gaya): poora daira, taake crop kabhi
    use aadha na kare. Na mile to sab se bara shakhs."""
    mine = [f for x in samples if p.start - 0.01 <= x.t <= p.end + 0.01 for f in x.faces if f.mine]
    if len(mine) >= 3:
        return (*_face_box(mine), -1.0)
    return _face_of(p, samples)


def _text_floor(p: Piece, samples: list[Sample]) -> float:
    """Shot mein source ki likhai (naam ki patti, banner) kahan se shuru: crop us se upar rahe (1.0 = kuch nahi)."""
    from app.render.subs import text_spans
    inside = [s for s in samples if p.start - 0.01 <= s.t <= p.end + 0.01]
    if not inside:
        return 1.0
    spans = text_spans([s.t for s in inside], [s.text for s in inside], 1 / SAMPLE_FPS, min_len=0.3)
    return min((b for _, _, b in spans), default=1.0)


# ---------------------------------------------------------------------
#  Upar neeche: EK hi lamhe ke DO zoom (29 Oct, user ki examples jaisa)
#  Kaam: doosra hissa kabhi kisi aur waqt ka nahi (warna munh hilta,
#  aawaz nahi). Har shot ke usi frame se:
#    * jo bol raha hai -> uske chehre par zoom (live)
#    * frame mein koi aur bhi ho (saath khada / sunne wala) -> us par zoom
#    * akela ho (podium par sirf main speaker) -> usi ka doosra zoom:
#      thora door, ek taraf ko, kandha / baazu nazar aaye (jaise koi
#      aur camera); close up neeche
#  Dono hisse bilkul usi waqt ke, is liye kisi ka munh bina aawaz nahi hilta.
# ---------------------------------------------------------------------
QA_OTHER_SHARE = 0.3       # doosra shakhs shot ke kam az kam itne hisse mein nazar aaye
QA_OTHER_MIN_W = 0.025     # itna chhota chehra (door ki bheed) zoom ke laayak nahi
QA_WIDE = 1.8              # akela ho to doosra zoom itna guna chaura (door se: kandha / baazu / stage)
QA_SIDE = 1.2              # aur chehra beech se itna (chehre ki chaurai ke hisaab se) ek taraf
QA_SIDE_MAX = 0.14         # (17 Nov) magar crop ki chaurai ke 14% se zyada nahi (chehra kinare par na jaye)
QA_FACE_SHARE = 0.24       # = framing.QA_FACE: chehra aadhe ki chaurai ka itna hissa
QA_MAX_CROP_W = 0.633      # 16:9 source mein aadhe (1080x960) ka sab se chaura crop (frame ki chaurai ka hissa)


EXCLUDE_OVERLAP = 0.15     # (18 Nov) doosre hisse ke crop mein main chehre ka itna hissa bhi nahi (warna wohi aadmi do dafa)


def shows_only(info: SourceInfo, box: tuple, avoid: tuple) -> bool:
    """Doosre hisse (box par crop) mein 'avoid' wala chehra (x, w) nazar na aaye: bodyguard ke saath main person nahi."""
    if info is None or not avoid or avoid[1] <= 0:
        return True
    from app.render.framing import OUTPUTS, slot_crop
    out_w, out_h = OUTPUTS["9:16"]
    sw = info.display_size[0]
    x0, x1 = (box[3], box[4]) if len(box) >= 5 else (-1.0, -1.0)
    cw, _ch, cx, _cy = slot_crop(info, box[0], box[1], box[2], out_w, out_h // 2, x0, x1)
    a0, a1 = (avoid[0] - avoid[1] / 2) * sw, (avoid[0] + avoid[1] / 2) * sw
    inter = max(0.0, min(cx + cw, a1) - max(cx, a0))
    return inter <= EXCLUDE_OVERLAP * max(1.0, a1 - a0)


def _second_view(p: Piece, samples: list[Sample], live) -> tuple:
    """Usi shot ka doosra zoom: frame ke kisi aur shakhs par, warna usi shakhs ka door / ek taraf wala."""
    faces = [f for x in samples if p.start - 0.01 <= x.t <= p.end + 0.01 for f in x.faces]
    n = max(1, sum(1 for x in samples if p.start - 0.01 <= x.t <= p.end + 0.01))
    lx, lw = live[0], max(live[2], 0.02)
    for _, g in _groups(faces):
        if len(g) < QA_OTHER_SHARE * n:
            continue
        box = _face_box(g)
        if abs(box[0] - lx) < max(lw, box[2]) * 1.2 or box[2] < QA_OTHER_MIN_W:
            continue                                      # wohi shakhs ya bohot door ki bheed
        return (*box, "other")
    # frame ke khule hisse ki taraf jagah. (17 Nov) qareeb ka chehra (close up): crop poori unchai tak pahunch kar
    # aur chaura nahi hota, to poora QA_SIDE chehre ko kinare (~23%) par dhakel deta tha. Had: chehra crop ke
    # beech se zyada se zyada QA_SIDE_MAX (crop ki chaurai ka hissa) hate, yaani ~36% par (look room phir bhi)
    crop_w = min(QA_WIDE * lw / QA_FACE_SHARE, QA_MAX_CROP_W)
    side = min(QA_SIDE * lw, QA_SIDE_MAX * crop_w)
    side = side if lx < 0.5 else -side
    # crop is "chaure chehre" ke hisaab se banta hai: chehra asal mein chhota dikhega (door wala shot)
    return (min(0.95, max(0.05, lx + side)), live[1], lw * QA_WIDE, -1.0, -1.0, "self")


# ---------------------------------------------------------------------
#  Sunne wali audience (29 Oct, user ka Hal 1)
#  Jab main speaker bole aur us ke frame mein koi aur na ho, doosre hisse
#  mein poori video se woh audience shot jahan aawaz main speaker ki thi
#  (audience chup sun rahi thi, app/render/listeners.py). Har shot ek
#  clip mein sirf ek dafa, kam az kam LISTEN_MIN; kam pade to us audience
#  ki ruki hui tasveer (halka slow zoom). Kuch bhi na ho to purana tareeqa
#  (usi lamhe ka door wala zoom). Sawal karne wala bole aur akela ho to
#  doosre hisse mein main speaker ki ruki tasveer (slow zoom).
# ---------------------------------------------------------------------
LISTEN_MIN = 2.0
LISTEN_FACES = 4           # ek audience shot mein zyada se zyada itne alag chehre (har clip mein alag zoom)
LISTEN_FACE_MIN = 0.015    # sab se bara chehra kam az kam itna
LISTEN_EXTRA_MIN = 0.025   # baaki chehre: is se chhote par zoom dhundla lagta hai
_POOL_MEMO: dict = {}


def _shot_faces(q: Piece, smp: list[Sample], info: SourceInfo, cancel_event) -> list[tuple]:
    """Shot ke sunne wale chehre (sab se bare pehle): [(x, y, w, x0, x1)], jin ke honth nahi hil rahe."""
    inside = [x for x in smp if q.start - 0.01 <= x.t <= q.end + 0.01]
    n = max(1, len(inside))
    faces = [f for x in inside for f in x.faces]
    groups = [g for _, g in _groups(faces) if len(g) >= 0.5 * n and not _is_main(g)]
    boxes = []
    for g in groups:
        box = _face_box(g)
        if box[2] < (LISTEN_FACE_MIN if not boxes else LISTEN_EXTRA_MIN):
            continue
        boxes.append(box)
        if len(boxes) >= LISTEN_FACES:
            break
    if not boxes:
        return []
    try:
        from app.render.speaker import Person, measure_activity
        times, acts = measure_activity(info.path, q.start, q.end, info.display_size,
                                       [Person(bx[0], bx[1], bx[2]) for bx in boxes], cancel_event)
        if times:
            talk = [sum(r[j] for r in acts) / len(acts) for j in range(len(boxes))]
            kept = [bx for bx, t in zip(boxes, talk) if t < TALK_MIN]
            return kept
    except Cancelled:
        raise
    except Exception as exc:  # noqa: BLE001 - honth na naap sakein to sirf sab se bara (pehle jaisa)
        log.warning("Listener mouth check skipped: %s", exc)
    return boxes[:1]


def _listen_pool(info: SourceInfo, listen, cancel_event, matcher, his_at) -> list[Piece]:
    """
    Sunne wale shots: har shot ke har sunne wale chehre ka apna tukra (listen_key = shot + chehra),
    taake alag clips mein alag chehre par zoom ho. Ek dafa naapo, phir yaad.
    """
    out = []
    for a, b in listen or ():
        key = (str(info.path), round(a, 2), round(b, 2))
        if key not in _POOL_MEMO:
            got = []
            try:
                smp = measure(info.path, a, b, info, cancel_event, matcher=matcher)
                if his_at is not None:
                    smp = known_from_scan(smp, his_at)
                # shot ke andar camera kat kar kahin aur gaya ho (main speaker / podium): sirf sab se lamba
                # saaf hissa, jis mein chehre hon aur main speaker na ho (camera cuts se tukre)
                best = None
                for pc in plan_pieces(smp, a, b):
                    inside = [x for x in smp if pc.start - 0.01 <= x.t <= pc.end + 0.01]
                    if not inside or any(f.mine for x in inside for f in x.faces):
                        continue
                    if sum(1 for x in inside if x.faces) < 0.8 * len(inside):
                        continue
                    if best is None or pc.end - pc.start > best[1] - best[0]:
                        best = (pc.start, pc.end)
                if best is None or best[1] - best[0] < LISTEN_MIN - 0.4:
                    raise ValueError("no clean audience part")
                s0, s1 = best[0] + 0.1, best[1] - 0.1
                q = Piece(s0, s1, "crop")
                if _main_share(q, smp) < QA_MAIN:
                    tt = _text_floor(q, smp)
                    for k, box in enumerate(_shot_faces(q, smp, info, cancel_event)):
                        got.append(replace(q, x_center=box[0], face_y=box[1], face_w=box[2], face_x0=box[3],
                                           face_x1=box[4], text_top=tt, listen_key=(round(a, 2), round(b, 2), k)))
            except Cancelled:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("Listening shot %.1f skipped: %s", a, exc)
            if len(_POOL_MEMO) > 2000:
                _POOL_MEMO.clear()
            _POOL_MEMO[key] = got
        out.extend(_POOL_MEMO[key])
    return out


def _comp_of(q: Piece, a: float, b: float, kind: str) -> tuple:
    return (a, b, q.x_center, q.face_y, q.face_w, q.face_x0, q.face_x1, q.text_top, kind)


def _shot(q: Piece) -> tuple:
    return tuple(q.listen_key[:2]) if q.listen_key else (round(q.start, 2), round(q.end, 2))


# ---------------------------------------------------------------------
#  Sunne walon ka hisaab (5 Nov 2026, user)
#  Kaam: poore batch mein har sunne wale chehre ko BARABAR baantna:
#    * har clip ko sab se kam istemal hua chehra pehle milta hai
#    * pichle clip mein jo shot aaya, agle clip mein nahi (lagataar nahi)
#    * ek clip ke andar koi shot do dafa nahi (loop nahi)
#  Ginti video ke work folder mein yaad (agli dafa usi video ke clips
#  bhi barabar chalein). Har clip (har re-edit bhi) apne sunne wale leta
#  hai, is liye ek moment ke 4 versions mein bhi alag log.
# ---------------------------------------------------------------------
class ListenerBook:
    def __init__(self, path: Path | None = None):
        import json
        self.pool: list[Piece] = []
        self.lock = threading.Lock()
        self.path = path
        self.face_use: dict[str, int] = {}
        self.shot_use: dict[str, int] = {}
        self.last: set = set()
        if path is not None and Path(path).exists():
            try:
                d = json.loads(Path(path).read_text(encoding="utf-8"))
                self.face_use = {str(k): int(v) for k, v in d.get("faces", {}).items()}
                self.shot_use = {str(k): int(v) for k, v in d.get("shots", {}).items()}
                self.last = {tuple(x) for x in d.get("last", [])}
            except (OSError, ValueError, TypeError, AttributeError):
                pass

    def set_pool(self, pool: list[Piece]) -> None:
        with self.lock:
            known = {q.listen_key for q in self.pool}
            self.pool.extend(q for q in pool if q.listen_key not in known)

    @staticmethod
    def _fk(q: Piece) -> str:
        return ":".join(str(x) for x in (q.listen_key or (round(q.start, 2), round(q.end, 2), 0)))

    @staticmethod
    def _sk(shot: tuple) -> str:
        return ":".join(str(x) for x in shot)

    def _order(self, cands: list[Piece], mid: float) -> list[Piece]:
        return sorted(cands, key=lambda q: (_shot(q) in self.last, self.face_use.get(self._fk(q), 0),
                                            self.shot_use.get(self._sk(_shot(q)), 0),
                                            abs((q.start + q.end) / 2 - mid)))

    def chain(self, need: float, mid: float, clip_used: set, picked: list | None = None,
              pool: list[Piece] | None = None) -> list[tuple]:
        """Itni lambai ke saathi tukre (har shot is clip mein ek dafa); kam pade to aakhir mein ruki tasveer."""
        pool = self.pool if pool is None else pool
        free = [q for q in pool if _shot(q) not in clip_used and q.end - q.start >= LISTEN_MIN]
        chain, total = [], 0.0
        while total < need:
            free = [q for q in free if _shot(q) not in clip_used]
            if not free:
                break
            q = self._order(free, mid)[0]
            take = min(q.end - q.start, max(LISTEN_MIN, need - total + 0.2))
            chain.append(_comp_of(q, q.start, q.start + take, "listen"))
            clip_used.add(_shot(q))
            if picked is not None:
                picked.append(q)
            total += take
        # (18 Nov, user) kam pade to ruki hui tasveer KABHI nahi: adhoori zanjeer = ye tukra upar neeche nahi banta
        return chain

    def assign(self, pieces: list[Piece]) -> list[Piece]:
        """Is clip (har version) ke sunne wale: barabar baant, phir ginti aage barhao."""
        import json
        if not any(getattr(pc, "listen_need", ()) for pc in pieces):
            return pieces
        with self.lock:
            if not self.pool:
                return pieces
            used: set = set()
            picked: list[Piece] = []
            out = []
            for pc in pieces:
                if pc.listen_need and pc.mode == "qa":
                    mine: list = []
                    comps = tuple(self.chain(pc.listen_need[0], pc.listen_need[1], used, mine))
                    if comps and chain_len(comps) >= pc.listen_need[0] - 0.05:
                        picked.extend(mine)
                        out.append(replace(pc, comp=comps[0][:7], comps=comps))
                    else:
                        out.append(solo(pc))         # sunne wale poore nahi: is tukre mein bolne wala poori screen
                else:
                    out.append(pc)
            for q in picked:
                self.face_use[self._fk(q)] = self.face_use.get(self._fk(q), 0) + 1
            for sh in {_shot(q) for q in picked}:
                self.shot_use[self._sk(sh)] = self.shot_use.get(self._sk(sh), 0) + 1
            self.last = {_shot(q) for q in picked}
            if self.path is not None:
                try:
                    Path(self.path).write_text(json.dumps({"faces": self.face_use, "shots": self.shot_use,
                                                           "last": [list(x) for x in self.last]}), encoding="utf-8")
                except OSError:
                    pass
            return out


def chain_len(comps) -> float:
    return sum(float(c[1]) - float(c[0]) for c in comps if len(c) < 9 or c[8] != "still")


def solo(pc: Piece) -> Piece:
    """Upar neeche ka tukra jo saaf nahi ban sakta: wohi shakhs poori screen par (crop), koi saathi nahi."""
    return replace(pc, mode="crop", comp=(), comps=(), listen_need=(), same_person=False)


def two_people_share(pieces: list[Piece]) -> float:
    """Clip ka kitna hissa sach mein do alag log / do tasveerein dikhata hai (qa, source ka split, do dabbe)."""
    total = sum(p.end - p.start for p in pieces) or 1.0
    two = sum(p.end - p.start for p in pieces
              if (p.mode == "qa" and getattr(p, "comps", ()) and not getattr(p, "same_person", False)
                  and not any(len(c) >= 9 and c[8] == "still" for c in p.comps))
              or p.mode == "stack" or (p.mode == "panels" and getattr(p, "box_b", None)))
    return two / total


def _listen_chain(pool: list[Piece], need: float, mid: float, used: set) -> list[tuple]:
    """(purana naam) Bina ginti ke zanjeer: qareeb / kam istemal wale pehle."""
    return ListenerBook().chain(need, mid, used, pool=pool)


def qa_stack(pieces: list[Piece], samples: list[Sample], info: SourceInfo, start: float, end: float,
             cancel_event=None, matcher=None, his_at=None, words=None, listen=None,
             book: "ListenerBook | None" = None) -> list[Piece]:
    try:
        pool = _listen_pool(info, listen, cancel_event, matcher, his_at) if listen else []
        if book is not None and pool:
            book.set_pool(pool)
        used: set = set()
        out = []
        keep_live: set = set()                         # audience shot jis ke doosre (live) hisse mein main speaker hai
        mains = []                                     # is clip ke main speaker wale shots (ruki tasveer ke liye)
        for p in pieces:
            if p.mode == "fit_blur" or p.end - p.start < 0.3:
                out.append(p)
                continue
            is_main = _main_share(p, samples) >= QA_MAIN
            face = _face_of(p, samples, info, words, cancel_event, talking=True)
            if face is None or face[2] <= 0.015:
                out.append(p)
                continue
            if is_main:
                own = _mine_box(p, samples)
                talks = face[5] >= TALK_MIN and own is not None and abs(face[0] - own[0]) < max(0.05, own[2])
                face = (*own[:5], face[5]) if own is not None else face
            else:
                talks = face[5] >= TALK_MIN
            second = _second_view(p, samples, face)
            if second[5] == "other" and not shows_only(info, second, (face[0], face[2])):
                second = (*second[:5], "self")             # (18 Nov) bodyguard ke crop mein main bhi aata: nahi chalega
            if not is_main:
                # (18 Nov, user) audience / sawal karne wala camera par: doosre hisse mein sirf ASAL main speaker
                # (usi frame mein, chalta hua). Na ho to ye tukra poori screen (ruki tasveer kabhi nahi, audience
                # dono taraf kabhi nahi)
                own = [f for x in samples if p.start - 0.01 <= x.t <= p.end + 0.01 for f in x.faces if f.mine]
                if not (second[5] == "other" and len(own) >= 3
                        and abs(median(f.cx for f in own) - second[0]) < max(0.05, second[2])):
                    out.append(p)
                    continue
            tt = _text_floor(p, samples)
            # +0.2 s: saathi kabhi chhota na pare (warna renderer ahista / rok deta, aur waqt hil jata)
            comps = ((p.start, p.end + 0.2, second[0], second[1], second[2], second[3], second[4], tt, "live"),)
            alone = second[5] == "self"
            # (15 Nov, user) speaker bol raha ho aur saath khara banda (guard / host) sirf sun raha ho:
            # har doosre tukre mein us ki jagah audience, taake neeche dono milte julte aayen
            mix_crowd = (is_main and talks and pool and second[5] == "other"
                         and int(round(p.start * 4)) % 2 == 0)
            need = ()
            if (alone or mix_crowd) and is_main and pool:
                # main speaker akela: doosre hisse mein sunne wali audience (poori video se), poori lambai ki
                want = p.end - p.start + 0.1
                chain = tuple(_listen_chain(pool, want, (p.start + p.end) / 2, used))
                if chain and chain_len(chain) >= want - 0.05:
                    comps = chain
                    need = (want, (p.start + p.end) / 2)
                    alone = False
            if alone:
                # (18 Nov, user) wohi shakhs upar neeche kabhi nahi: koi doosra saaf na mile to poori screen
                out.append(p)
                continue
            mine = replace(p, listen_need=need, mode="qa", live_top=not is_main, main_live=is_main, live_talks=talks,
                           x_path=(), band=fill_band(info, face[2], face[1]),
                           x_center=face[0], face_y=face[1],
                           face_w=face[2], face_x0=face[3], face_x1=face[4], text_top=tt,
                           same_person=False,
                           comp=comps[0][:7], comps=comps)
            out.append(mine)
        log.info("Q&A stack %.1f-%.1f: %d of %d shots upar neeche (%d sunne wale shots mile)", start, end,
                 sum(1 for p in out if p.mode == "qa"), len(out), len(pool))
        return out
    except Cancelled:
        raise
    except Exception as exc:  # noqa: BLE001 - framing kabhi clip na khoye
        log.warning("Q&A stack skipped: %s", exc)
        return pieces


# ---------------------------------------------------------------------
#  Source ke subtitles jo clip mein phir bhi nazar aate hain
#  Kaam: avoid_text ke baad bhi jahan likha hua text (subtitles, name
#  tag) tasveer mein reh gaya (crop/stack/blur mein kaata nahi ja saka),
#  clip ke kitne hisse mein wo dikhta hai (0..1). 30% ya zyada ho to
#  runner hamare captions ke peeche gehra cover box lagata hai.
# ---------------------------------------------------------------------
def visible_text_share(pieces: list[Piece], samples: list[Sample]) -> float:
    if not samples:
        return 0.0
    flags = [s.text is not None for s in samples]
    shown = 0
    for i, s in enumerate(samples):
        near = flags[max(0, i - 2):i + 3]
        if sum(near) * 2 <= len(near):                    # ek aadh frame ka text nahi ginte
            continue
        p = next((p for p in pieces if p.start - 0.01 <= s.t <= p.end + 0.01), None)
        if p is not None and p.mode != "panels" and p.band >= 0.999:
            shown += 1
    return round(shown / len(samples), 3)


# --- (14 Nov) source ke apne captions beech mein (hamare captions ki jagah) kitni dair dikhe ---
# Kaam: clip ke kitne hisse (0..1) mein beech wali likhi line frame ke andar nazar aati hai.
# Crop mein sirf wohi ginti hai jo 9:16 khirki ke andar ho; baqi modes mein poora frame dikhta hai.
CROP_HALF = 0.16                      # 16:9 se 9:16 khirki: frame ki chaurai ka ~32%


def mid_text_share(pieces: list[Piece], samples: list[Sample]) -> float:
    if not samples:
        return 0.0
    flags = [getattr(s, "mid", None) is not None for s in samples]
    shown = 0
    for i, s in enumerate(samples):
        near = flags[max(0, i - 2):i + 3]
        if not flags[i] or sum(near) * 2 <= len(near):     # ek aadh frame ka text nahi ginte
            continue
        p = next((p for p in pieces if p.start - 0.01 <= s.t <= p.end + 0.01), None)
        if p is None:
            continue
        left, right = s.mid
        if p.mode == "crop" and (right < p.x_center - CROP_HALF or left > p.x_center + CROP_HALF):
            continue                                        # line khirki se bahar: clip mein nazar nahi aati
        shown += 1
    return round(shown / len(samples), 3)


def analyse(info: SourceInfo, start: float, end: float, ratio: str,
            cancel_event: threading.Event | None = None,
            words: list[tuple[float, float]] | None = None, reactions: bool = False,
            matcher=None, stats: dict | None = None,
            quiet: list[tuple[float, float]] | None = None, fill: bool = False, his_at=None,
            listen=None, stack: bool = True, book: "ListenerBook | None" = None,
            fill_zoom_level: float = 0.0, no_split: bool = False) -> list[Piece]:
    """
    Framing pieces for a 9:16 clip from a landscape source. [] = use the old framing.
    With a main person matcher, `stats` gets "visible" and "speaking" (0..1 of the clip).
    """
    if ratio != "9:16" or info.is_vertical or not MODEL.exists():
        return []
    try:
        from app.render.speaker import refine_cut
        _NO_SPLIT.on = bool(no_split)
        samples = measure(info.path, start, end, info, cancel_event, matcher=matcher)
        if matcher is not None and his_at is not None:
            samples = known_from_scan(samples, his_at)
        pieces = plan_pieces(samples, start, end)
        # camera cuts to the exact frame
        for a, b in zip(pieces, pieces[1:]):
            exact = refine_cut(info.path, b.start, info.fps)
            if a.start + 0.1 < exact < b.end - 0.1:
                a.end = b.start = exact
        pieces = settle_animations(pieces, info.path, info.fps, start, end, cancel_event)
        pieces = follow_speakers(pieces, samples, info, words or [], cancel_event)
        pieces = follow_motion(pieces, samples, info)
        if reactions:
            pieces = add_reactions(pieces, samples, info, words or [], start, end, main_mode=matcher is not None,
                                   quiet=quiet)
        pieces = avoid_text(pieces, samples)
        pieces = limit_zoom(pieces, info, fill=fill)
        if fill:
            pieces = fill_zoom(pieces, info, *fill_setting(fill_zoom_level))
            pieces = no_cut_faces(pieces, samples, info)
        if stats is not None:
            stats["subs"] = visible_text_share(pieces, samples)
            stats["mid_subs"] = mid_text_share(pieces, samples)
        if matcher is not None and stats is not None:
            stats.update(person_stats(pieces, samples, info, words or [], cancel_event))
        if fill and stack and matcher is not None:
            pieces = qa_stack(pieces, samples, info, start, end, cancel_event, matcher, his_at, words=words,
                              listen=listen, book=book)
        log.info("Layout %.1f-%.1f: %s", start, end,
                 ", ".join(f"{p.mode}@{p.start:.2f}" + (f"x{p.x_center:.2f}" if p.mode == "crop" else "")
                           for p in pieces))
        return pieces
    except Cancelled:
        raise
    except Exception as exc:   # noqa: BLE001 - framing must never lose a clip
        log.warning("Layout analysis failed, using centre framing: %s", exc)
        return []


# ---------------------------------------------------------------------
#  Source animation: show graphic mein camera cut pe dabbe (picture
#  boxes) slide ho kar aate / jaate hain. Wo aadha khaali, hilta hua
#  hissa clip mein ghatiya lagta hai. Is liye us waqt saaf (settled)
#  frame rok dete hain (audio waisi hi chalti hai). Sirf "panels" pieces.
# ---------------------------------------------------------------------
ANIM_LOOK = 1.2                  # cut ke baad / pehle itne second dekho
ANIM_MAX = 0.8                   # is se lambi "animation" asal mein animation nahi
ANIM_MIN_DIFF = 12.0             # saaf frame se itna farq (0..255) = abhi hil raha hai


_ANIM_MEMO: dict = {}                # (source, waqt, dabbe, in/out) -> nateeja (ek moment ke cuts mein dobara nahi)


def _anim_check(path: Path, t: float, boxes: list[tuple], fps: float, entering: bool, cancel_event=None) -> float:
    """Animation ki lambai (second): cut ke baad aate dabbe (entering) ya cut se pehle jaate dabbe."""
    key = (str(path), round(t, 3), tuple(boxes), entering)
    known = _ANIM_MEMO.get(key)
    if known is not None:
        return known
    frames, rate = _box_frames(path, t if entering else t - ANIM_LOOK, ANIM_LOOK, fps, cancel_event)
    held = 0.0
    if frames:
        ref = frames[-1] if entering else frames[0]
        seq = frames if entering else list(reversed(frames))
        k = _unsettled([_region_diff(f, ref, boxes) for f in seq])
        if k and k / rate <= ANIM_MAX:
            held = round(k / rate, 3)
    if len(_ANIM_MEMO) > 5000:
        _ANIM_MEMO.clear()
    _ANIM_MEMO[key] = held
    return held


def _box_frames(path: Path, start: float, seconds: float, fps: float, cancel_event=None):
    import numpy as np
    w, h = 320, 180
    rate = min(30.0, fps or 25.0)
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "error", "-ss", f"{max(0.0, start):.3f}",
           "-t", f"{seconds:.3f}", "-i", str(path), "-an", "-vf", f"fps={rate},scale={w}:{h}:flags=area",
           "-f", "rawvideo", "-pix_fmt", "gray", "-"]
    if cancel_event is not None and cancel_event.is_set():
        raise Cancelled()
    proc = subprocess.run(cmd, capture_output=True, timeout=60,
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    raw = proc.stdout
    n = len(raw) // (w * h)
    frames = [np.frombuffer(raw[k * w * h:(k + 1) * w * h], np.uint8).reshape(h, w) for k in range(n)]
    return frames, rate


def _region_diff(a, b, boxes: list[tuple]) -> float:
    import numpy as np
    h, w = a.shape
    vals = []
    for x0, y0, x1, y1 in boxes:
        ya, yb, xa, xb = int(y0 * h), max(int(y0 * h) + 1, int(y1 * h)), int(x0 * w), max(int(x0 * w) + 1, int(x1 * w))
        vals.append(np.abs(a[ya:yb, xa:xb].astype(np.int16) - b[ya:yb, xa:xb].astype(np.int16)).mean())
    return float(max(vals)) if vals else 0.0


def _unsettled(diffs: list[float]) -> int:
    """Shuru ke kitne frames saaf frame se bohot alag hain (phir aakhir tak saaf rehte hain)."""
    if len(diffs) < 6:
        return 0
    calm = sorted(diffs[len(diffs) // 2:])
    thr = max(ANIM_MIN_DIFF, 3.0 * calm[len(calm) // 2])
    k = len(diffs)
    while k > 0 and diffs[k - 1] < thr:
        k -= 1
    return k if k < len(diffs) * 0.7 else 0


def settle_animations(pieces: list[Piece], path: Path, fps: float, clip_start: float, clip_end: float,
                      cancel_event=None) -> list[Piece]:
    for i, p in enumerate(pieces):
        if p.mode != "panels" or not p.box_a or p.end - p.start < 2 * ANIM_LOOK:
            continue
        boxes = [b for b in (p.box_a, p.box_b) if b]
        try:
            if i > 0 or p.start > clip_start + 0.05:            # asal camera cut, clip ka shuru nahi
                held = _anim_check(path, p.start, boxes, fps, True, cancel_event)
                if held:
                    p.still_until = round(p.start + held, 3)
            if i < len(pieces) - 1:
                held = _anim_check(path, p.end, boxes, fps, False, cancel_event)
                if held:
                    p.still_from = round(p.end - held, 3)
        except Cancelled:
            raise
        except Exception as exc:  # noqa: BLE001 - sirf behtari, framing kabhi na toote
            log.info("animation check skipped: %s", exc)
        if p.still_until or p.still_from:
            log.info("Source animation held in piece %.2f-%.2f: until %.2f, from %.2f", p.start, p.end,
                     p.still_until, p.still_from)
    return pieces


def _shown(piece: Piece, f: Face, crop_w: float) -> bool:
    """Is this face inside the output picture of the piece?"""
    if piece.mode == "crop":
        half = crop_w / 2
        xc = min(1 - half, max(half, piece.x_center))
        return abs(f.cx - xc) < half - f.w * 0.3
    if piece.mode == "panels":
        return _inside(piece.box_a, f.cx, f.cy) or _inside(piece.box_b, f.cx, f.cy)
    return True                                           # stack / qa shows both people, fit shows everything


def person_stats(pieces: list[Piece], samples: list[Sample], info: SourceInfo,
                 words: list[tuple[float, float]], cancel_event=None) -> dict:
    """
    How much of the clip shows the main person (visible) and how much of
    the speech is his (speaking). Speech counts as his when, at that
    moment, he is on screen and is the person framed (crop) or the one
    whose mouth moves (stack / full picture with others).
    """
    sw, sh = info.display_size
    crop_w = min(1.0, (sh * 9 / 16) / sw)

    def piece_at(t: float) -> Piece | None:
        for p in pieces:
            if p.start - 1e-3 <= t < p.end + 1e-3:
                return p
        return pieces[-1] if pieces else None

    def sample_at(t: float) -> Sample | None:
        return min(samples, key=lambda s: abs(s.t - t)) if samples else None
    visible = []
    for s in samples:
        p = piece_at(s.t)
        visible.append(bool(p) and any(f.mine and _shown(p, f, crop_w) for f in s.faces))
    # mouth movement only where he shares the screen with someone else
    talk: dict[int, list] = {}
    for k, p in enumerate(pieces):
        inside = [s for s in samples if p.start - 0.01 <= s.t <= p.end + 0.01]
        shown = [f for s in inside for f in s.faces if _shown(p, f, crop_w) and f.score >= DUO_SCORE]
        groups = [_summary(g) for _, g in _groups(shown) if len(g) >= 0.3 * len(inside)] if shown else []
        if len(groups) >= 2 and any(g.mine for g in groups):
            from app.render.speaker import Person, measure_activity
            persons = [Person(g.cx, g.cy, g.w) for g in groups[:3]]
            try:
                times, acts = measure_activity(info.path, p.start, p.end, info.display_size, persons, cancel_event)
                mine = next(i for i, g in enumerate(groups[:3]) if g.mine)
                talk[k] = [times, acts, mine]
            except Cancelled:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("Main person mouth check skipped: %s", exc)
    his = 0
    for a, b in words:
        t = (a + b) / 2
        s, p = sample_at(t), piece_at(t)
        if s is None or p is None:
            continue
        mine_on = [f for f in s.faces if f.mine and _shown(p, f, crop_w)]
        if not mine_on:
            continue
        k = pieces.index(p)
        if k in talk:
            times, acts, mine = talk[k]
            j = min(range(len(times)), key=lambda i: abs(times[i] - t)) if times else -1
            near = [acts[i] for i in range(len(times)) if abs(times[i] - t) <= 0.5]
            if near:
                score = [sum(row[i] for row in near) for i in range(len(near[0]))]
                his += score[mine] >= max(score) and score[mine] > 0
            elif j >= 0:
                his += 1
        else:
            his += 1                                      # he alone is framed while the words are heard
    first = [v for s, v in zip(samples, visible) if s.t < samples[0].t + 3.0] if samples else []
    return {"visible": round(sum(visible) / len(visible), 3) if visible else 0.0,
            "speaking": round(his / len(words), 3) if words else 0.0,
            "hook": round(sum(first) / len(first), 3) if first else 0.0}


# ---------------------------------------------------------------------
#  Chhota chehra (door se, stage par): 640 px ke sample mein itna chhota
#  ke pehchana na ja sake ("pata nahi"). Poori video ki scan (bari
#  tasveer, 960 px) us second mein keh chuki ho ke main person hi sab se
#  bara chehra hai, to sample ka sab se bara "pata nahi" chehra wohi.
#  (Warna stage wali videos mein wo "kam bolta" gina jata tha.)
# ---------------------------------------------------------------------
def known_from_scan(samples: list[Sample], his_at) -> list[Sample]:
    from app.render.person import MATCH
    out = []
    for smp in samples:
        faces = list(smp.faces)
        if faces and not any(f.mine for f in faces):
            big = max(range(len(faces)), key=lambda i: faces[i].area)
            if faces[big].who < 0 and his_at(smp.t) >= 1.0:
                faces[big] = replace(faces[big], who=MATCH)
                smp = replace(smp, faces=faces)
        out.append(smp)
    return out


def stacked_share(pieces: list[Piece]) -> float:
    total = sum(p.end - p.start for p in pieces)
    return sum(p.end - p.start for p in pieces if p.mode in ("stack", "panels", "qa")) / total if total > 0 else 0.0
