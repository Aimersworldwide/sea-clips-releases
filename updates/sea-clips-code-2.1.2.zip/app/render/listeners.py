"""
=====================================================================
  RENDER / LISTENERS   (upar neeche ka doosra hissa: sunne wali audience)
  Kaam: poori video mein woh shots dhoondna jahan camera AUDIENCE par
  hai magar aawaz MAIN SPEAKER ki hai, yaani audience chup kar ke sun
  rahi hai. Aise shots "doosre hisse" mein lagte hain jab main speaker
  bolta hai, to kisi ka munh bina aawaz nahi hilta.
  Pehchan aawaz se (honthon ke andaze se nahi):
    * har second ki aawaz ka rang (MFCC) naapo
    * jahan main speaker screen par hai = us ki aawaz ka namoona,
      jahan audience screen par hai = zyada tar sawal karne wale
    * dono ka farq seekh kar (Fisher) har audience second ko jaancho
    * shot chhota (2 se 10 s), dono taraf main speaker, aur aawaz main
      speaker jaisi = "sunne wala shot"
  Sab offline, sirf numpy. Nateeja video ke work folder mein yaad.
=====================================================================
"""
from __future__ import annotations

import json
import logging
import wave
from pathlib import Path

log = logging.getLogger("aimers.listeners")

MIN_SHOT, MAX_SHOT = 2, 10          # sunne wala shot itne second ka
SIDE = 4                            # shot ke dono taraf itne second main speaker screen par
SIDE_SHARE = 0.7
VOICE_MIN = 0.2                     # aawaz main speaker jaisi (Fisher score) kam az kam itni
MIN_SECONDS = 60                    # dono taraf kam az kam itne second hon to hi seekho


def _logmel(path: Path):
    import numpy as np
    with wave.open(str(path)) as w:
        sr, n, ch = w.getframerate(), w.getnframes(), w.getnchannels()
        x = np.frombuffer(w.readframes(n), np.int16).astype(np.float32)
    if ch > 1:
        x = x.reshape(-1, ch).mean(1)
    nfft, hop, win, nb = 512, int(sr * 0.01), int(sr * 0.025), 40

    def mel(f):
        return 2595 * np.log10(1 + f / 700)

    def imel(m):
        return 700 * (10 ** (m / 2595) - 1)
    pts = imel(np.linspace(mel(80), mel(sr / 2 * 0.95), nb + 2))
    bins = np.floor((nfft + 1) * pts / sr).astype(int)
    fb = np.zeros((nb, nfft // 2 + 1))
    for i in range(nb):
        a, b, c = bins[i], bins[i + 1], bins[i + 2]
        fb[i, a:b] = (np.arange(a, b) - a) / max(1, b - a)
        fb[i, b:c] = (c - np.arange(b, c)) / max(1, c - b)
    frames = max(0, 1 + (len(x) - win) // hop)
    hann = np.hanning(win)
    out = []
    for s in range(0, frames, 20000):
        k = np.arange(s, min(frames, s + 20000))
        seg = x[np.arange(win)[None, :] + hop * k[:, None]] * hann
        out.append(np.log((np.abs(np.fft.rfft(seg, nfft)) ** 2) @ fb.T + 1e-6))
    return np.concatenate(out) if out else np.zeros((0, nb))


def find_listening_shots(wav: Path, timeline, words, cache_file: Path | None = None) -> list[tuple[float, float]]:
    """(start, end) source seconds: camera audience par, aawaz main speaker ki. [] = pakka kuch nahi."""
    if cache_file is not None and cache_file.exists():
        try:
            return [tuple(x) for x in json.loads(cache_file.read_text(encoding="utf-8"))]
        except (OSError, ValueError):
            pass
    try:
        got = _find(wav, timeline, words)
    except Exception as exc:  # noqa: BLE001 - na mile to doosre hal
        log.warning("Listening shots not found: %s", exc)
        got = []
    if cache_file is not None:
        try:
            cache_file.write_text(json.dumps(got), encoding="utf-8")
        except OSError:
            pass
    log.info("Listening audience shots: %d (%.0f s)", len(got), sum(b - a for a, b in got))
    return got


def _find(wav: Path, timeline, words) -> list[tuple[float, float]]:
    import numpy as np
    if not timeline or not Path(wav).exists():
        return []
    F = _logmel(Path(wav))
    T = len(F) // 100
    if T < 30:
        return []
    on = np.zeros(T)
    for t, v in timeline:
        if 0 <= int(t) < T:
            on[int(t)] = v
    speech = np.zeros(T, bool)
    for w in words:
        for s in range(int(w.start), min(T, int(w.end) + 1)):
            speech[s] = True
    n = 40
    D = np.cos(np.pi * np.arange(13)[:, None] * (2 * np.arange(n)[None, :] + 1) / (2 * n))
    thr = np.percentile(F.mean(1), 40)
    X = np.zeros((T, 26))
    ok = np.zeros(T, bool)
    for s in range(T):
        f = F[s * 100:(s + 1) * 100]
        m = f[f.mean(1) > thr]
        if len(m) >= 20 and speech[s]:
            c = m @ D.T
            X[s, :13], X[s, 13:] = c.mean(0), c.std(0)
            ok[s] = True
    main, aud = ok & (on >= 1), ok & (on <= 0)
    if main.sum() < MIN_SECONDS or aud.sum() < MIN_SECONDS:
        return []
    mu, sd = X[ok].mean(0), X[ok].std(0) + 1e-6
    Z = (X - mu) / sd
    Sw = np.cov(Z[main].T) + np.cov(Z[aud].T) + 1e-3 * np.eye(26)
    p = Z @ np.linalg.solve(Sw, Z[main].mean(0) - Z[aud].mean(0))
    p -= (p[main].mean() + p[aud].mean()) / 2
    out, s = [], 0
    while s < T:
        if on[s] > 0:
            s += 1
            continue
        e = s
        while e + 1 < T and on[e + 1] <= 0:
            e += 1
        a, b = s, e + 1
        s = b
        if not MIN_SHOT <= b - a <= MAX_SHOT:
            continue
        before = on[max(0, a - SIDE):a].mean() if a > 0 else 0.0
        after = on[b:b + SIDE].mean() if b < T else 0.0
        pp = p[a:b][ok[a:b]]
        if before >= SIDE_SHARE and after >= SIDE_SHARE and len(pp) and pp.mean() > VOICE_MIN:
            out.append((float(a) + 0.3, float(b) - 0.3))         # cut ke kinare se thora andar
    return [(a, b) for a, b in out if b - a >= MIN_SHOT - 0.6]
