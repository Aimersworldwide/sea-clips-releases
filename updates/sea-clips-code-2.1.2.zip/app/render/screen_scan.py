"""
=====================================================================
  RENDER / SCREEN SCAN        (video ki screen ko naapna, OCR ke baghair)
  Kaam: do cheezein, sirf tasveer dekh kar (laptop par, offline):
    find_ticker_bands - news ki chalti patti (ticker) kahan hai: wo
        patli lakeer jis mein likhai baayen taraf khisakti rehti hai.
        Neeche ho ya video ke beech mein, dono jagah milti hai. Us ko
        blur kiya jata hai (doosri, unrelated khabrein clip mein na
        aayein). Logo aur baaki video saaf rehte hain.
    find_free_band    - frame mein khaali (saada, bina likhai / tasveer
        ke) jagah: disclosure "video ke neeche" wahan lagta hai, taake
        kisi cheez ke upar na aaye (jaise campaign ki 9:16 ads ka kaala
        hissa).
=====================================================================
"""
from __future__ import annotations

import logging
import subprocess
from pathlib import Path

log = logging.getLogger("aimers.scan")

SCAN_W = 640                 # isi chaurai par naapte hain (tez)
ROW = 6                      # ticker naapne ki patti ki unchai (px, SCAN_W par)
GAP_S = 0.2                  # do frames ke beech waqt (ticker itne mein khisak chuka hota hai)
MAX_SHIFT = 48               # zyada se zyada khisakna (px, SCAN_W par, GAP_S mein)
TICKER_MIN, TICKER_MAX = 0.006, 0.09   # ticker ki unchai (frame ka hissa)
PAD = 0.006                  # blur ke upar / neeche thori gunjaish


def _grab(path: Path, t: float, w: int, h: int):
    import numpy as np

    from app.media.ffmpeg_tools import ffmpeg_bin
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    raw = subprocess.run([ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-ss", f"{max(0.0, t):.3f}",
                          "-i", str(path), "-frames:v", "1", "-vf", f"scale={w}:{h}:flags=area",
                          "-f", "rawvideo", "-pix_fmt", "gray", "-"], capture_output=True, creationflags=flags).stdout
    if len(raw) < w * h:
        return None
    return np.frombuffer(raw[:w * h], np.uint8).reshape(h, w).astype("float32")


def _size(path: Path) -> tuple[int, int]:
    from app.media.probe import probe
    sw, sh = probe(path).display_size
    return SCAN_W, max(2, int(round(SCAN_W * sh / sw / 2)) * 2)


def _scrolls(a, b) -> bool:
    """Ye patli patti baayen (ya daayen) khisak rahi hai? (ticker) a, b: same patti, GAP_S ke faasle par."""
    import numpy as np
    w = a.shape[1]
    lo, hi = int(w * 0.12), int(w * 0.88)               # kinare (logo, ghari) chhor kar
    ref = b[:, lo:hi]
    texture = float(np.mean(np.abs(np.diff(a[:, lo:hi], axis=1))))
    if texture < 4.0:
        return False                                    # saada patti: likhai nahi
    still = float(np.mean(np.abs(a[:, lo:hi] - ref)))
    if still < 3.0:
        return False                                    # kuch nahi badla: ruki hui likhai (headline / logo)
    best, best_d = still, 0
    for d in range(2, MAX_SHIFT + 1):
        for s in (d, -d):
            if lo - s < 0 or hi - s > w:
                continue
            diff = float(np.mean(np.abs(a[:, lo - s:hi - s] - ref)))
            if diff < best:
                best, best_d = diff, s
    return best_d != 0 and best < still * 0.45


def find_ticker_bands(path: Path, start: float, end: float, samples: int = 6) -> list[tuple[float, float]]:
    """News ki chalti patti(yan): [(y0, y1)] frame ke hisse mein (0 = upar). Khaali = koi ticker nahi."""
    import numpy as np
    w, h = _size(path)
    span = max(0.5, end - start - GAP_S - 0.1)
    rows = list(range(0, h - ROW, ROW // 2))
    hits = np.zeros(len(rows))
    seen = 0
    for k in range(samples):
        t = start + span * (k + 0.5) / samples
        a, b = _grab(path, t, w, h), _grab(path, t + GAP_S, w, h)
        if a is None or b is None:
            continue
        seen += 1
        for i, y in enumerate(rows):
            if _scrolls(a[y:y + ROW], b[y:y + ROW]):
                hits[i] += 1
    if not seen:
        return []
    on = hits >= max(2, seen * 0.5)                      # aadhe se zyada frames mein khisakti mile
    bands: list[tuple[float, float]] = []
    i = 0
    while i < len(rows):
        if not on[i]:
            i += 1
            continue
        j = i
        while j + 1 < len(rows) and on[j + 1]:
            j += 1
        y0, y1 = rows[i] / h, (rows[j] + ROW) / h
        if TICKER_MIN <= y1 - y0 <= TICKER_MAX:
            bands.append((round(max(0.0, y0 - PAD), 4), round(min(1.0, y1 + PAD), 4)))
        i = j + 1
    if bands:
        log.info("News ticker found at %s", ", ".join(f"{a:.3f}-{b:.3f}" for a, b in bands))
    return bands


def find_free_region(path: Path, start: float, end: float, min_h: float, lo: float = 0.40, hi: float = 0.80,
                     samples: int = 6) -> tuple[float, float] | None:
    """
    Frame mein sab se upar wali khaali (saada: bina likhai / tasveer ke) jagah, lo..hi ke beech, kam az kam
    min_h unchi (frame ka hissa). Har sample frame mein khaali honi chahiye. (y0, y1) ya None.
    """
    import numpy as np
    w, h = _size(path)
    span = max(0.5, end - start - 0.1)
    busy = np.zeros(h)
    seen = 0
    for k in range(samples):
        a = _grab(path, start + span * (k + 0.5) / samples, w, h)
        if a is None:
            continue
        seen += 1
        gx = np.abs(np.diff(a, axis=1)).mean(axis=1)
        gy = np.concatenate([np.abs(np.diff(a, axis=0)).mean(axis=1), [0.0]])
        busy = np.maximum(busy, gx + gy)
    if not seen:
        return None
    free = busy < 2.5
    margin = max(2, int(0.008 * h))                     # upar / neeche wali cheez se thora faasla
    y = int(lo * h)
    while y < int(hi * h):
        if not free[y]:
            y += 1
            continue
        z = y
        while z + 1 < h and free[z + 1] and z + 1 < int(hi * h):
            z += 1
        a, b = y + (margin if y > 0 else 0), z + 1 - margin
        if (b - a) / h >= min_h:
            return round(a / h, 4), round(b / h, 4)
        y = z + 1
    return None


# ---------------------------------------------------------------------
#  Pehle se 9:16 ad ke andar asal video (31 Oct, Prop 42)
#  Kaam: campaign ki khari ads mein upar logo wala dabba, beech mein
#  asal video, neeche likhai. Har line (row) kitni hilti hai, waqt ke
#  saath naapo: sab se lamba hilne wala hissa = andar wali video.
#  Poori tasveer hilti ho (aam khari video) to None: koi zoom nahi.
# ---------------------------------------------------------------------
MOVE_MIN = 12.0            # row ki chamak waqt ke saath itni badle to "hilti" hai (0..255)


def find_inner_video(path: Path, duration: float, samples: int = 24) -> tuple[float, float] | None:
    """Khari video ke andar chalti video ka (upar, neeche) 0..1, ya None."""
    import numpy as np
    w, h = 108, 192
    frames = []
    for k in range(samples):
        t = max(0.0, duration) * (k + 0.5) / samples
        f = _grab(path, t, w, h)
        if f is not None:
            frames.append(f.astype(np.float32))
    if len(frames) < 6:
        return None
    move = np.stack(frames).std(0).mean(1)
    on = move >= MOVE_MIN
    best, i = None, 0
    while i < h:
        if not on[i]:
            i += 1
            continue
        j = i
        while j + 1 < h and on[j + 1]:
            j += 1
        if best is None or j - i > best[1] - best[0]:
            best = (i, j)
        i = j + 1
    if best is None:
        return None
    top, bottom = best[0] / h, (best[1] + 1) / h
    # sirf "dabbe ke andar video" wali ad: upar kam az kam 10% saakin, video 20%..80% unchi
    if top < 0.10 or not 0.20 <= bottom - top <= 0.80:
        return None
    return round(top, 4), round(bottom, 4)
