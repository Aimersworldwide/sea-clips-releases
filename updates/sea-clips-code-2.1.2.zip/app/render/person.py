"""
=====================================================================
  RENDER / MAIN PERSON  (the person a campaign is about, any campaign)
  Kaam: main person ko chehre se pehchanna (photos se).
  The user gives 1 to 5 photos of the person once (campaign settings).
  Every face the app sees is then compared with those photos:
    * YuNet finds the face and its 5 points (eyes, nose, mouth),
      SFace (OpenCV, free, offline, ~99 % on the standard LFW test)
      turns the aligned face into 128 numbers; two faces of the same
      person give a high cosine similarity.
    * MATCH (0.42) is stricter than the model's own advice (0.363):
      a wrong "yes" makes a wrong clip, a missed "yes" only costs a
      frame. Between UNSURE and MATCH the face counts as nobody.
    * Faces smaller than MIN_FACE_PX (back of a crowd) or seen from
      behind / far side are never called the main person.
    * Learning from the video: faces that match very clearly (0.55+)
      are added as extra references for that video (lighting, angle,
      age of the photo no longer matter as much). Capped, and only
      ever from clear matches, so it cannot drift to someone else.
  Photo check: each photo must show exactly one clear, big face, or
  the user is told which photo is not usable and why.
=====================================================================
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

from app.core.logging_setup import get_logger
from app.core.paths import resource

log = get_logger("person")

DETECT_MODEL = resource("assets", "models", "face_detection_yunet_2023mar.onnx")
RECOG_MODEL = resource("assets", "models", "face_recognition_sface_2021dec.onnx")
RECOG_SHA256 = "0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79"

MATCH = 0.42              # cosine similarity that means "this is the main person"
UNSURE = 0.30             # below this: surely someone else
LEARN = 0.55              # clear enough to learn from
MAX_LEARNED = 24
MIN_FACE_PX = 36          # smaller faces cannot be recognised reliably
PHOTO_MIN_PX = 80         # a reference photo needs a face at least this big
PHOTO_SCORE = 0.80
AGREE = 0.55               # a photo must look this much like the other photos of the person


def available() -> bool:
    return DETECT_MODEL.exists() and RECOG_MODEL.exists()


@dataclass
class PhotoCheck:
    path: str
    ok: bool
    message: str


class PersonMatcher:
    """Main person recogniser for one campaign (thread safe for reading after warm up)."""

    def __init__(self, photos: list[str]):
        import cv2
        import threading
        if not available():
            raise RuntimeError("face recognition model missing")
        self._lock = threading.Lock()
        self._recog = cv2.FaceRecognizerSF.create(str(RECOG_MODEL), "")
        self.refs = []
        self.learned = []
        self.checks: list[PhotoCheck] = []
        good: list[tuple[int, object]] = []
        for p in photos:
            check, feat = self._photo_feature(p)
            self.checks.append(check)
            if feat is not None:
                good.append((len(self.checks) - 1, feat))
        # with 3+ photos, one that does not look like the others (another person,
        # a covered face) is left out, so it can never pull in the wrong people
        if len(good) >= 3:
            import numpy as np
            keep = []
            for i, f in good:
                others = sorted(float(np.dot(f, g)) for j, g in good if j != i)
                if others[len(others) // 2] < AGREE:
                    self.checks[i] = PhotoCheck(self.checks[i].path, False,
                                                "does not look like the other photos (other person or face covered)")
                else:
                    keep.append(f)
            good = [(0, f) for f in keep]
        self.refs = [f for _, f in good]
        self.key = hashlib.sha1(b"".join(r.tobytes() for r in self.refs)).hexdigest()[:12] if self.refs else ""

    @property
    def usable(self) -> bool:
        return bool(self.refs)

    # --- photos ----------------------------------------------------
    def _photo_feature(self, path: str):
        import cv2
        import numpy as np
        img = None
        try:
            data = np.fromfile(path, np.uint8)          # works with any characters in the path
            img = cv2.imdecode(data, cv2.IMREAD_COLOR)
        except OSError:
            pass
        if img is None:
            return PhotoCheck(path, False, "cannot open this picture"), None
        h, w = img.shape[:2]
        scale = min(1.0, 1280 / max(h, w))
        if scale < 1.0:
            img = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
            h, w = img.shape[:2]
        det = cv2.FaceDetectorYN.create(str(DETECT_MODEL), "", (w, h), 0.6, 0.3, 50)
        _, faces = det.detect(img)
        faces = [] if faces is None else [f for f in faces if f[-1] >= 0.6]
        if not faces:
            return PhotoCheck(path, False, "no face found"), None
        faces.sort(key=lambda f: -f[2] * f[3])
        main = faces[0]
        if len(faces) > 1 and faces[1][2] * faces[1][3] > 0.35 * main[2] * main[3]:
            return PhotoCheck(path, False, "more than one person in the picture"), None
        if min(main[2], main[3]) < PHOTO_MIN_PX:
            return PhotoCheck(path, False, "face too small, use a closer picture"), None
        if main[-1] < PHOTO_SCORE:
            return PhotoCheck(path, False, "face not clear enough (turned away or covered)"), None
        feat = self._feature(img, main)
        return PhotoCheck(path, True, "good"), feat

    def _feature(self, img, raw):
        import numpy as np
        with self._lock:
            crop = self._recog.alignCrop(img, np.asarray(raw, np.float32).reshape(1, -1))
            feat = self._recog.feature(crop)
        f = feat.reshape(-1).astype(np.float32)
        return f / (np.linalg.norm(f) + 1e-9)

    # --- faces in the video ------------------------------------------
    def similarity(self, frame, raw) -> float:
        """Best cosine similarity of one detected face (YuNet row) to the person; -1 = cannot tell."""
        import numpy as np
        if not self.refs or min(raw[2], raw[3]) < MIN_FACE_PX or raw[-1] < 0.7:
            return -1.0
        f = self._feature(frame, raw)
        bank = self.refs + self.learned
        best = float(max(float(np.dot(f, r)) for r in bank))
        if best >= LEARN and len(self.learned) < MAX_LEARNED:
            with self._lock:
                if len(self.learned) < MAX_LEARNED:
                    self.learned.append(f)
        return best


# ---------------------------------------------------------------------
#  Kai main people ek saath (campaign mein 2-3 log)
#  Kaam: har shakhs ka apna PersonMatcher (har ek ki photos alag check
#  hoti hain), aur chehra jis se sab se zyada milta ho wahi score.
#  Matlab "in mein se koi bhi" screen pe ho to pehchana jata hai.
# ---------------------------------------------------------------------
class GroupMatcher:
    def __init__(self, matchers: list[PersonMatcher]):
        self.matchers = [m for m in matchers if m.usable]
        self.checks = [c for m in matchers for c in m.checks]
        self.refs = [r for m in self.matchers for r in m.refs]
        self.key = hashlib.sha1("|".join(m.key for m in self.matchers).encode()).hexdigest()[:12] \
            if self.matchers else ""

    @property
    def usable(self) -> bool:
        return bool(self.matchers)

    def similarity(self, frame, raw) -> float:
        return max((m.similarity(frame, raw) for m in self.matchers), default=-1.0)


def is_match(sim: float) -> bool:
    return sim >= MATCH


def check_photos(photos: list[str]) -> list[PhotoCheck]:
    """For the campaign screen: is every photo usable?"""
    if not available():
        return [PhotoCheck(p, False, "face recognition model missing") for p in photos]
    return PersonMatcher(photos).checks


# ---------------------------------------------------------------------
#  Ruk kar dobara (20 Nov): lambi scan beech mein ruke (RAM kam, ya pehle se
#  tayyari band hui) to agli dafa wahin se. Har CHECKPOINT_EVERY frames ke
#  baad ab tak ka kaam "<cache>.part" mein. Asal cache file sirf poori scan
#  ke baad likhi jati hai, is liye adhoori scan kabhi poori nahi samjhi jati.
# ---------------------------------------------------------------------
CHECKPOINT_EVERY = 30


def _part_file(cache_file: Path | None) -> Path | None:
    return None if cache_file is None else cache_file.with_name(cache_file.name + ".part")


def _read_part(part: Path | None, key: str) -> dict | None:
    import json
    if part is None or not part.exists():
        return None
    try:
        data = json.loads(part.read_text(encoding="utf-8"))
        return data if data.get("key") == key else None
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def _write_part(part: Path, data: dict) -> None:
    import json
    import os
    try:
        tmp = part.with_name(part.name + ".tmp")
        tmp.write_text(json.dumps(data), encoding="utf-8")
        os.replace(tmp, part)                     # poori file ek saath: aadhi likhi kabhi nahi
    except OSError:
        pass


def _drop_part(part: Path | None) -> None:
    try:
        if part is not None:
            part.unlink(missing_ok=True)
    except OSError:
        pass


# ---------------------------------------------------------------------
#  Whole video scan (1 frame a second): where is the person on screen?
# ---------------------------------------------------------------------
SCAN_FPS = 1.0
SCAN_W = 960


def scan(path: Path, duration: float, size: tuple[int, int], matcher: PersonMatcher,
         cache_file: Path | None = None, cancel_event=None) -> list[tuple[float, float]]:
    """
    [(time, share)] once a second: share = 1.0 when the person is the
    main face on screen, 0.5 when visible but someone else is bigger,
    0 when not on screen. Cached per video and photo set.
    """
    import json
    import subprocess

    import cv2
    import numpy as np

    from app.media.ffmpeg_tools import Cancelled, ffmpeg_bin
    if cache_file is not None and cache_file.exists():
        try:
            data = json.loads(cache_file.read_text(encoding="utf-8"))
            if data.get("key") == matcher.key:
                return [tuple(x) for x in data["timeline"]]
        except (ValueError, KeyError, TypeError):
            pass
    sw, sh = size
    w = SCAN_W
    h = max(2, int(round(w * sh / sw / 2)) * 2)
    det = cv2.FaceDetectorYN.create(str(DETECT_MODEL), "", (w, h), 0.6, 0.3, 50)
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "error", "-i", str(path), "-an",
           "-vf", f"fps={SCAN_FPS},scale={w}:{h}:flags=area", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    part = _part_file(cache_file)
    done = [tuple(x) for x in (_read_part(part, matcher.key) or {}).get("timeline", [])]
    if done:
        log.info("Main person scan resumes after %d seconds already checked", len(done))
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=flags)
    out: list[tuple[float, float]] = []
    k = 0
    try:
        while True:
            if cancel_event is not None and cancel_event.is_set():
                raise Cancelled()
            buf = proc.stdout.read(w * h * 3)
            if len(buf) < w * h * 3:
                break
            if k < len(done):
                # (20 Nov) pichli dafa ruki hui scan: ye second pehle hi check ho chuka (wohi frame, wohi nateeja)
                out.append(done[k])
                k += 1
                continue
            if part is not None and k and k % CHECKPOINT_EVERY == 0:
                _write_part(part, {"key": matcher.key, "timeline": out})
            frame = np.frombuffer(buf, np.uint8).reshape(h, w, 3)
            _, faces = det.detect(frame)
            share = 0.0
            if faces is not None and len(faces):
                faces = sorted(faces, key=lambda f: -f[2] * f[3])
                for i, f in enumerate(faces[:4]):
                    if is_match(matcher.similarity(frame, f)):
                        share = 1.0 if i == 0 else 0.5
                        break
            out.append((round(k / SCAN_FPS, 2), share))
            k += 1
    finally:
        proc.kill()
        proc.wait()
    if cache_file is not None:
        try:
            cache_file.write_text(json.dumps({"key": matcher.key, "timeline": out}), encoding="utf-8")
        except OSError:
            pass
        _drop_part(part)
    log.info("Main person on screen in %d of %d seconds", sum(1 for _, s in out if s > 0), len(out))
    return out


def screen_share(timeline: list[tuple[float, float]], start: float, end: float) -> float:
    """Share of [start, end] with the person on screen (main face counts full, visible counts half)."""
    vals = [s for t, s in timeline if start <= t <= end]
    return sum(vals) / len(vals) if vals else 0.0


def share_at(timeline: list[tuple[float, float]], t: float) -> float:
    """The person's screen value (0, 0.5, 1) at the scanned second nearest to t."""
    if not timeline:
        return 0.0
    k = min(len(timeline) - 1, max(0, int(round(t * SCAN_FPS))))
    return timeline[k][1]


# ---------------------------------------------------------------------
#  Main speaker khud pehchanna (campaign mein naam / photo nahi)
#  Kaam: video ke frames (har 2 second ek) mein sab se bara saaf chehra
#  lo, chehron ko "kaun kaun hai" mein baanto (SFace), aur jo shakhs sab
#  se zyada dafa bara chehra ho (yaani sab se zyada waqt screen ka
#  markaz, jo aksar wohi hota hai jo sab se zyada bolta hai) wohi main
#  speaker. Us ke chehre hi "photos" ki jagah use hote hain, phir baaki
#  sab (60% screen / baat, protection guard) waise hi chalta hai.
#  Laptop par hi, offline, kuch bahar nahi jata.
# ---------------------------------------------------------------------
AUTO_STEP = 2.0             # itne second baad ek frame
AUTO_MAX_FRAMES = 600       # lambi video: zyada se zyada itne frames
AUTO_SAME = 0.50            # do chehre ek hi shakhs (cluster) - MATCH se sakht
AUTO_MIN_SHARE = 0.25       # main speaker kam az kam itne frames mein bara chehra ho
AUTO_REFS = 8               # itne saaf chehre references bante hain


class FeatureMatcher(PersonMatcher):
    """PersonMatcher jo photos ki jagah video se nikle chehron (features) se bana ho."""

    def __init__(self, feats: list):
        import threading

        import cv2
        if not available():
            raise RuntimeError("face recognition model missing")
        self._lock = threading.Lock()
        self._recog = cv2.FaceRecognizerSF.create(str(RECOG_MODEL), "")
        self.refs = list(feats)
        self.learned = []
        self.checks = []
        self.key = "auto-" + hashlib.sha1(b"".join(r.tobytes() for r in self.refs)).hexdigest()[:12] if self.refs else ""


def cluster_main(feats: list, weights: list[float] | None = None, same: float = AUTO_SAME,
                 min_share: float = AUTO_MIN_SHARE) -> list[int]:
    """
    feats: har frame ke sab se bare chehre ke features (normalised). Wapas: main shakhs ke frames ke index
    (khaali = koi ek shakhs kaafi dafa nahi, yaani main speaker pakka nahi).
    """
    import numpy as np
    if not feats:
        return []
    weights = weights or [1.0] * len(feats)
    groups: list[dict] = []
    for i, f in enumerate(feats):
        best, best_s = None, same
        for g in groups:
            s = float(np.dot(f, g["c"]))
            if s >= best_s:
                best, best_s = g, s
        if best is None:
            groups.append({"c": f.copy(), "idx": [i], "w": weights[i]})
        else:
            best["idx"].append(i)
            best["w"] += weights[i]
            c = best["c"] * (len(best["idx"]) - 1) + f
            best["c"] = c / (np.linalg.norm(c) + 1e-9)
    groups.sort(key=lambda g: -g["w"])
    top = groups[0]
    if len(top["idx"]) / len(feats) < min_share:
        return []
    if len(groups) > 1 and groups[1]["w"] >= top["w"] * 0.9:
        return []                                    # do log barabar: kaun main hai pakka nahi
    return top["idx"]


def find_main_speaker(path: Path, duration: float, size: tuple[int, int], cache_file: Path | None = None,
                      cancel_event=None) -> FeatureMatcher | None:
    """Video ka main speaker (sab se zyada bara chehra). None = pata nahi chala."""
    import json
    import subprocess

    import cv2
    import numpy as np

    from app.media.ffmpeg_tools import Cancelled, ffmpeg_bin
    if not available():
        return None
    if cache_file is not None and cache_file.exists():
        try:
            data = json.loads(cache_file.read_text(encoding="utf-8"))
            refs = [np.asarray(r, np.float32) for r in data.get("refs", [])]
            return FeatureMatcher(refs) if refs else None
        except (ValueError, TypeError, OSError):
            pass
    sw, sh = size
    w = SCAN_W
    h = max(2, int(round(w * sh / sw / 2)) * 2)
    step = max(AUTO_STEP, duration / AUTO_MAX_FRAMES) if duration else AUTO_STEP
    det = cv2.FaceDetectorYN.create(str(DETECT_MODEL), "", (w, h), 0.6, 0.3, 50)
    recog = cv2.FaceRecognizerSF.create(str(RECOG_MODEL), "")
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "error", "-i", str(path), "-an",
           "-vf", f"fps=1/{step:.3f},scale={w}:{h}:flags=area", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    part = _part_file(cache_file)
    pkey = f"{step:.3f}:{w}x{h}"
    old = _read_part(part, pkey) or {}
    skip = int(old.get("frames", 0))
    feats = [np.asarray(v, np.float32) for v in old.get("feats", [])]
    weights = [float(x) for x in old.get("weights", [])]
    scores = [float(x) for x in old.get("scores", [])]
    if skip:
        log.info("Main speaker search resumes after %d frames already checked", skip)
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=flags)
    k = 0
    try:
        while True:
            if cancel_event is not None and cancel_event.is_set():
                raise Cancelled()
            buf = proc.stdout.read(w * h * 3)
            if len(buf) < w * h * 3:
                break
            k += 1
            if k <= skip:
                continue                              # (20 Nov) pichli dafa yahan tak ho chuka tha
            if part is not None and k % CHECKPOINT_EVERY == 0:
                _write_part(part, {"key": pkey, "frames": k - 1, "feats": [v.tolist() for v in feats],
                                   "weights": weights, "scores": scores})
            frame = np.frombuffer(buf, np.uint8).reshape(h, w, 3)
            _, faces = det.detect(frame)
            if faces is None or not len(faces):
                continue
            f = max(faces, key=lambda x: x[2] * x[3])
            if min(f[2], f[3]) < MIN_FACE_PX * 1.5 or f[-1] < 0.8:
                continue                              # chhota / dhundla: ginti mein nahi
            crop = recog.alignCrop(frame, np.asarray(f, np.float32).reshape(1, -1))
            v = recog.feature(crop).reshape(-1).astype(np.float32)
            feats.append(v / (np.linalg.norm(v) + 1e-9))
            weights.append(float(f[2] * f[3]) ** 0.5)
            scores.append(float(f[-1]) * float(min(f[2], f[3])))
    finally:
        proc.kill()
        proc.wait()
    _drop_part(part)
    idx = cluster_main(feats, weights)
    if not idx:
        log.info("Main speaker: no single clear main face in %d frames", len(feats))
        return None
    best = sorted(idx, key=lambda i: -scores[i])[:AUTO_REFS]
    refs = [feats[i] for i in best]
    if cache_file is not None:
        try:
            cache_file.write_text(json.dumps({"refs": [r.tolist() for r in refs]}), encoding="utf-8")
        except OSError:
            pass
    log.info("Main speaker found: biggest face in %d of %d frames", len(idx), len(feats))
    return FeatureMatcher(refs)
