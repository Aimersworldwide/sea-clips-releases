"""
=====================================================================
  RENDER / HUD               (20 Nov 2026, GTA 6 stream clips)
  Kaam: game ki video mein kab asal gameplay hai aur kab cutscene
  (kahani ka film wala hissa). Gameplay mein kone par minimap / HUD
  hota hai, cutscene mein nahi.
  Why: Rockstar akele cutscene wale videos hata deta hai, aur cutscene
  mein NPC bolte hain (captions unke, streamer ke nahi). Stream clips
  ke moments gameplay se aur streamer ke reaction se chune jaate hain.
  How: neeche baayen kona (GTA ka minimap; camera ka dabba chhor kar) har second ek
  chhoti tasveer. HUD ke kinare zyada tar frames mein ek hi jagah
  hote hain: wo "pakke kinare" har frame mein kitne milte hain = HUD
  dikh raha hai ya nahi. Jis kone mein ye sab se saaf do hisson mein
  bata ho, wahi HUD ka kona. Saaf na ho to None (koi rok nahi).
=====================================================================
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

from app.core.logging_setup import get_logger
from app.media.ffmpeg_tools import ffmpeg_bin
from app.media.probe import SourceInfo

log = get_logger("hud")

SIZE = (480, 270)
CORNER_W, CORNER_H = 0.30, 0.32     # neeche ke kone ka hissa
PERSIST = (0.30, 0.90)              # HUD ka kinara itne frames mein (har frame wala = streamer ka overlay / likhai, HUD nahi)
MIN_EDGES = 60                      # kam az kam itne pakke kinare pixel (warna HUD nahi)
MIN_GAP = 0.25                      # HUD dikhne / na dikhne ke score mein kam az kam itna farq


def _crops(path: Path, duration: float, boxes: list[tuple[int, int, int, int]], fps: float = 1.0) -> list[list]:
    """Har second (fps) har kone ki choti gray tasveer."""
    import numpy as np
    w, h = SIZE
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "error", "-skip_frame", "nokey", "-i", str(path),
           "-an", "-vf", f"fps={fps},scale={w}:{h}:flags=area", "-f", "rawvideo", "-pix_fmt", "gray", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=flags)
    out: list[list] = [[] for _ in boxes]
    try:
        while True:
            buf = proc.stdout.read(w * h)
            if len(buf) < w * h:
                break
            f = np.frombuffer(buf, np.uint8).reshape(h, w)
            for k, (x, y, bw, bh) in enumerate(boxes):
                out[k].append(f[y:y + bh, x:x + bw].copy())
    finally:
        proc.kill()
        proc.wait()
    return out


def presence(crops, mask=None):
    """Pakke kinare har frame mein kitne milte hain (0..1 har second), aur pakke kinaron ki ginti."""
    import cv2
    import numpy as np
    if len(crops) < 20:
        return None, 0
    edges = np.stack([cv2.Canny(c, 50, 130) > 0 for c in crops])
    share = edges.mean(axis=0)
    persist = (share >= PERSIST[0]) & (share <= PERSIST[1])
    if mask is not None:
        persist &= mask
    n = int(persist.sum())
    if n < MIN_EDGES:
        return None, n
    near = [cv2.dilate(e.astype(np.uint8), np.ones((3, 3), np.uint8)) > 0 for e in edges]
    score = np.array([float((nb & persist).sum()) / n for nb in near])
    return score, n


def split_score(score) -> tuple[float, float] | None:
    """Score do hisson mein (HUD / bina HUD), Otsu se: (had, dono hisson ki ausat ka farq). Saaf na ho to None."""
    import numpy as np
    if score is None or len(score) < 20:
        return None
    v = np.asarray(score, float)
    best = None
    for cut in np.linspace(float(v.min()) + 0.01, float(v.max()) - 0.01, 60):
        a, b = v[v < cut], v[v >= cut]
        if len(a) < 3 or len(b) < 3:
            continue
        between = len(a) * len(b) * (a.mean() - b.mean()) ** 2
        if best is None or between > best[0]:
            best = (between, float(cut), float(b.mean() - a.mean()))
    if best is None or best[2] < MIN_GAP:
        return None
    return best[1], best[2]


def gameplay_seconds(info: SourceInfo, cam_box: tuple | None = None, cache: Path | None = None) -> list[bool] | None:
    """Har second: True = gameplay (HUD dikh raha), False = cutscene. None = pata nahi (rok nahi)."""
    if cache is not None and cache.exists():
        try:
            d = json.loads(cache.read_text(encoding="utf-8"))
            return d.get("gameplay")
        except ValueError:
            pass
    import numpy as np
    w, h = SIZE
    cw, ch = int(w * CORNER_W), int(h * CORNER_H)
    # GTA (V aur VI) ka minimap hamesha neeche baayen. Daayen kona cutscene ke ruke hue shots se dhoka deta tha.
    boxes = [(0, h - ch, cw, ch)]
    result = None
    try:
        crops = _crops(info.path, info.duration, boxes)
        best = None
        for (x, y, bw, bh), cr in zip(boxes, crops):
            mask = np.ones((bh, bw), bool)
            if cam_box:
                cx0, cy0 = int(cam_box[0] * w) - x, int(cam_box[1] * h) - y
                cx1, cy1 = int((cam_box[0] + cam_box[2]) * w) - x, int((cam_box[1] + cam_box[3]) * h) - y
                mask[max(0, cy0):max(0, cy1), max(0, cx0):max(0, cx1)] = False      # streamer ka camera nahi
            score, n = presence(cr, mask)
            sp = split_score(score)
            if sp and (best is None or sp[1] > best[1]):
                best = (score, sp[1], sp[0])
        if best is not None:
            score, gap, cut = best
            result = [bool(v >= cut) for v in score]
            log.info("HUD: gameplay in %d of %d seconds (gap %.2f)", sum(result), len(result), gap)
        else:
            log.info("HUD: no clear game HUD found; cutscenes not checked")
    except Exception as exc:  # noqa: BLE001 - kabhi run na roke
        log.warning("HUD check failed: %s", exc)
    if cache is not None:
        try:
            cache.write_text(json.dumps({"gameplay": result}), encoding="utf-8")
        except OSError:
            pass
    return result


def gameplay_share(seconds: list[bool] | None, start: float, end: float) -> float:
    if not seconds:
        return 1.0
    a, b = max(0, int(start)), min(len(seconds), int(end) + 1)
    if b <= a:
        return 1.0
    part = seconds[a:b]
    return sum(part) / len(part)
