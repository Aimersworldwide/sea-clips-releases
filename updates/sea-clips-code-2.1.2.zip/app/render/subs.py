"""
=====================================================================
  RENDER / BURNED-IN TEXT  (subtitles, name tags, notes in the video)
  Kaam: source mein pehle se likha text (subtitles) dhoondna.
  Many videos (Jubilee, news, podcasts) already have text burned into
  the bottom of the picture: question cards, "Name / role" tags,
  "link in description" notes. A 9:16 crop cuts those lines at the
  sides and they clash with our own captions. While such text is on
  screen the picture is framed from just above it (a small zoom, at
  most 1.25x; text that sits higher, like big name tags, is left as
  it is rather than zooming in further or cutting it in half).

  A frame "has text" when the bottom 28 % of the picture holds a row
  of at least 10 letter shaped marks (bright, sharper than their
  surroundings, similar height, sitting on one baseline, close
  together). Busy pictures (stars, crowds, stage lights) fail the
  baseline and spacing test, so they are not mistaken for text.
=====================================================================
"""
from __future__ import annotations

from statistics import median

BAND_TOP = 0.72           # text is only looked for below this height
MIN_LETTERS = 10
PIECE_SHARE = 0.30        # piece is treated when this share of its frames has text
MIN_BAND = 0.80           # never zoom more than 1.25x; text higher than this is left alone
MARGIN = 0.012            # clear space kept above the text
MIN_SPAN = 1.0            # seconds of text needed before the picture zooms for it


def text_top(gray) -> float | None:
    """Top of burned-in text in the bottom of a grey frame (0..1 from the top), or None."""
    found = _text_line(gray, BAND_TOP, 0.985)
    return found[0] if found else None


# --- (14 Nov) beech mein likha text (andar chalti vertical video ke apne captions) ---
# Kaam: bottom band ke upar (30% se 72% unchai) koi likhi line: hamare captions isi
# jagah aate hain, dono ek doosre pe na charhen. (left, right) 0..1 ya None.
MID_TOP, MID_BOTTOM = 0.30, BAND_TOP


def mid_text(gray) -> tuple[float, float] | None:
    found = _text_line(gray, MID_TOP, MID_BOTTOM)
    return (found[1], found[2]) if found else None


def _text_line(gray, top_f: float, bottom_f: float) -> tuple[float, float, float] | None:
    """Best burned-in text line between two heights: (top 0..1, left 0..1, right 0..1) or None."""
    import cv2
    import numpy as np
    h, w = gray.shape
    y0 = int(h * top_f)
    band = gray[y0:int(h * bottom_f)]
    if band.size == 0:
        return None
    local = band.astype(np.int16) - cv2.blur(band, (15, 15))
    bright = ((band > 150) & (local > 35)).astype(np.uint8)
    _, _, stats, _ = cv2.connectedComponentsWithStats(bright, connectivity=8)
    k = h / 360
    marks = [(int(x), int(y), int(cw), int(ch)) for x, y, cw, ch, area in stats[1:]
             if 4 * k <= ch <= 24 * k and cw <= 2.2 * ch and area >= 4 * k * k]
    if len(marks) < MIN_LETTERS:
        return None
    best: tuple[int, int, int, int] | None = None          # (letters, top, left, right)
    for base in sorted({y + ch for _, y, _, ch in marks}):
        line = sorted((m for m in marks if abs(m[1] + m[3] - base) <= 2 * k), key=lambda m: m[0])
        if len(line) < MIN_LETTERS:
            continue
        size = median(m[3] for m in line)
        runs, cur = [], [line[0]]
        for m in line[1:]:
            if m[0] - cur[-1][0] <= 3.5 * size:
                cur.append(m)
            else:
                runs.append(cur)
                cur = [m]
        runs.append(cur)
        run = max(runs, key=len)
        left, right = run[0][0], run[-1][0] + run[-1][2]
        if len(run) < MIN_LETTERS or (right - left) / w < 0.12:
            continue
        if best is None or len(run) > best[0]:
            best = (len(run), min(m[1] for m in run), left, right)
    if best is None:
        return None
    _, top, left, right = best
    # a title line just above (a name over "role") belongs to the same block
    for x, y, cw, ch in marks:
        if y < top and left - 0.02 * w <= x <= right and top - y <= 2.5 * ch:
            top = min(top, y)
    return (y0 + top) / h, left / w, right / w


def piece_band(tops: list[float | None]) -> float:
    """Height (0..1) to frame above from frames' text tops; 1.0 = leave the picture as it is."""
    found = sorted(t for t in tops if t is not None)
    if not tops or len(found) < PIECE_SHARE * len(tops):
        return 1.0
    band = found[len(found) // 10] - MARGIN           # 10th percentile: one odd frame cannot zoom further
    return round(band, 4) if band >= MIN_BAND else 1.0


def text_spans(times: list[float], tops: list[float | None], step: float,
               min_len: float = MIN_SPAN) -> list[tuple[float, float, float]]:
    """
    (start, end, band) for each stretch where text stays on screen.
    On/off is decided by the majority of 5 neighbouring frames so one
    missed frame does not break a stretch; stretches shorter than
    min_len are ignored (a flash of text is not worth a zoom).
    """
    n = len(times)
    flags = [t is not None for t in tops]
    steady = [sum(flags[max(0, i - 2):i + 3]) * 2 > len(flags[max(0, i - 2):i + 3]) for i in range(n)]
    spans, i = [], 0
    while i < n:
        if not steady[i]:
            i += 1
            continue
        j = i
        while j + 1 < n and steady[j + 1]:
            j += 1
        start, end = times[i] - step / 2, times[j] + step / 2
        band = piece_band(tops[i:j + 1])
        if end - start >= min_len and band < 1.0:
            spans.append((start, end, band))
        i = j + 1
    return spans
