"""
=====================================================================
  RENDER / SPEAKER  (who is really talking, and exact cut frames)
  Kaam: asal mein kaun bol raha hai, aur camera cut ka sahi frame.
  Used inside one camera shot that has two or more people who do not
  fit in one 9:16 crop.

  Who is talking:
    * 6 frames a second, faces with their 5 landmarks (YuNet).
    * Mouth movement = change of the lip area between frames. Head
      movement moves the eyes too, so the eye area change is taken
      off; someone nodding or turning is not "talking".
    * Only moments when speech is heard count (word times from the
      transcript), so a person chewing or laughing in silence is not
      picked.
  Calm camera (no chasing):
    * scores are smoothed over about a second
    * the camera moves to another person only when that person clearly
      talks more (35 % more) for at least 2 seconds
    * the change happens at the start of a word, as a clean cut, never
      a pan; inside one turn the frame does not move at all
  Exact cuts:
    * a camera cut found at 3 frames a second is moved to the exact
      frame where the picture changes, so no frame of the old shot is
      framed for the new one (and the other way round).
=====================================================================
"""
from __future__ import annotations

import math
import subprocess
import threading
from dataclasses import dataclass
from pathlib import Path

from app.core.logging_setup import get_logger
from app.media.ffmpeg_tools import Cancelled, ffmpeg_bin

log = get_logger("speaker")

SPEAKER_FPS = 6
SPEAKER_W = 960          # bigger frames here: faces in wide shots are small
MIN_TURN = 2.0           # seconds a new speaker must lead before the camera moves
LEAD = 1.35              # how much more they must move their mouth
SMOOTH = 0.8             # seconds (exponential smoothing)
HEAD_SHARE = 0.6         # share of the eye area change taken off the mouth change


@dataclass
class Person:
    cx: float
    cy: float
    w: float


@dataclass
class Turn:
    start: float
    end: float
    person: int


# ---------------------------------------------------------------------
#  Mouth movement
# ---------------------------------------------------------------------
def _patch(gray, cx: float, cy: float, pw: float, ph: float):
    import cv2
    import numpy as np
    h, w = gray.shape
    x0, x1 = int(max(0, cx - pw / 2)), int(min(w, cx + pw / 2))
    y0, y1 = int(max(0, cy - ph / 2)), int(min(h, cy + ph / 2))
    if x1 - x0 < 6 or y1 - y0 < 4:
        return None
    roi = cv2.resize(gray[y0:y1, x0:x1], (32, 16), interpolation=cv2.INTER_AREA).astype(np.float32)
    std = roi.std()
    return (roi - roi.mean()) / std if std > 2 else None


def face_patches(gray, raw) -> tuple:
    """(mouth patch, eye patch) from one YuNet row [x y w h rex rey lex ley nx ny rmx rmy lmx lmy score]."""
    rex, rey, lex, ley = raw[4], raw[5], raw[6], raw[7]
    rmx, rmy, lmx, lmy = raw[10], raw[11], raw[12], raw[13]
    eye = math.hypot(lex - rex, ley - rey)
    mouth = max(math.hypot(lmx - rmx, lmy - rmy), eye * 0.5)
    mp = _patch(gray, (rmx + lmx) / 2, (rmy + lmy) / 2 + mouth * 0.15, mouth * 1.6, mouth * 1.0)
    ep = _patch(gray, (rex + lex) / 2, (rey + ley) / 2, eye * 2.0, eye * 0.8)
    return mp, ep


def _diff(a, b) -> float:
    import numpy as np
    return float(np.abs(a - b).mean()) if a is not None and b is not None else 0.0


# Har frame ke chehre (aur munh / aankh ke patches) yaad: ek moment ke saare cuts aur edits
# wohi source frames dobara nahi parhte (speed). Frames ek pakke grid (1/SPEAKER_FPS) pe.
from collections import OrderedDict as _OD

_FACES: "_OD" = _OD()              # (source, w, h, grid index) -> [(raw row, patches), ...]
_FACES_LOCK = threading.Lock()
_FACES_MAX = 20000


def _decode_faces(path: Path, first: int, last: int, w: int, h: int, cancel_event=None) -> dict[int, list]:
    import cv2
    import numpy as np
    from app.render.layout import MODEL
    det = cv2.FaceDetectorYN.create(str(MODEL), "", (w, h), 0.6, 0.3, 50)
    a = first / SPEAKER_FPS
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "error", "-ss", f"{a:.3f}",
           "-t", f"{max(0.2, (last + 1 - first) / SPEAKER_FPS):.3f}", "-i", str(path), "-an",
           "-vf", f"fps={SPEAKER_FPS},scale={w}:{h}:flags=area", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=flags)
    out: dict[int, list] = {}
    k = 0
    try:
        while first + k <= last:
            if cancel_event is not None and cancel_event.is_set():
                raise Cancelled()
            buf = proc.stdout.read(w * h * 3)
            if len(buf) < w * h * 3:
                break
            frame = np.frombuffer(buf, np.uint8).reshape(h, w, 3)
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            _, found = det.detect(frame)
            out[first + k] = [(np.array(raw[:15]), face_patches(gray, raw))
                              for raw in (found if found is not None else [])]
            k += 1
    finally:
        proc.kill()
        proc.wait()
    return out


def measure_activity(path: Path, start: float, end: float, display_size: tuple[int, int],
                     persons: list[Person], cancel_event: threading.Event | None = None
                     ) -> tuple[list[float], list[list[float]]]:
    """Times and, per time, the mouth movement of every person (0 = not seen / not moving)."""
    sw, sh = display_size
    w = SPEAKER_W
    h = max(2, int(round(w * sh / sw / 2)) * 2)
    first = math.ceil(start * SPEAKER_FPS - 1e-6)
    last = max(first, math.ceil(end * SPEAKER_FPS - 1e-6) - 1)
    ckey = (str(path), w, h)
    with _FACES_LOCK:
        missing = [i for i in range(first, last + 1) if (ckey, i) not in _FACES]
    runs: list[list[int]] = []
    for i in missing:
        if runs and i == runs[-1][-1] + 1:
            runs[-1].append(i)
        else:
            runs.append([i])
    for run in runs:
        got = _decode_faces(path, run[0], run[-1], w, h, cancel_event)
        with _FACES_LOCK:
            for i, faces in got.items():
                _FACES[(ckey, i)] = faces
            while len(_FACES) > _FACES_MAX:
                _FACES.popitem(last=False)
    with _FACES_LOCK:
        frames = []
        for i in range(first, last + 1):
            f = _FACES.get((ckey, i))
            if f is not None:
                _FACES.move_to_end((ckey, i))
                frames.append((i, f))
    times: list[float] = []
    acts: list[list[float]] = []
    prev: dict[int, tuple] = {}
    for i, faces in frames:
        row = [0.0] * len(persons)
        seen: dict[int, tuple] = {}
        for raw, patches in faces:
            fx, fw = (raw[0] + raw[2] / 2) / w, raw[2] / w
            best = min(range(len(persons)), key=lambda j: abs(persons[j].cx - fx), default=None)
            if best is None or abs(persons[best].cx - fx) > max(0.6 * persons[best].w, 0.6 * fw):
                continue
            seen[best] = patches
            if best in prev:
                mouth = _diff(patches[0], prev[best][0])
                head = _diff(patches[1], prev[best][1])
                row[best] = max(0.0, mouth - HEAD_SHARE * head)
        prev = seen
        times.append(i / SPEAKER_FPS)
        acts.append(row)
    return times, acts


# ---------------------------------------------------------------------
#  Turns (pure logic, tested without video)
# ---------------------------------------------------------------------
def _speaking(t: float, words: list[tuple[float, float]]) -> bool:
    return any(a - 0.15 <= t <= b + 0.15 for a, b in words)


def _snap(t: float, words: list[tuple[float, float]], lo: float, hi: float) -> float:
    """Nearest word start (just before it) within 0.8 s, so cuts land between words."""
    starts = [a - 0.05 for a, _ in words if lo < a - 0.05 < hi and abs(a - t) <= 0.8]
    return min(starts, key=lambda a: abs(a - t)) if starts else t


def choose_turns(times: list[float], acts: list[list[float]], words: list[tuple[float, float]],
                 start: float, end: float, default: int = 0) -> list[Turn]:
    if not times or not acts or not acts[0]:
        return [Turn(start, end, default)]
    n = len(acts[0])
    alpha = 1.0 - math.exp(-1.0 / (SPEAKER_FPS * SMOOTH))
    level = [0.0] * n
    leader: list[int | None] = []
    for t, row in zip(times, acts):
        talking = _speaking(t, words)
        for i in range(n):
            level[i] += alpha * ((row[i] if talking else 0.0) - level[i])
        order = sorted(range(n), key=lambda i: -level[i])
        top, second = order[0], (order[1] if n > 1 else None)
        clear = level[top] > 0.02 and (second is None or level[top] >= LEAD * max(level[second], 1e-6))
        leader.append(top if clear and talking else None)

    current = next((p for p in leader if p is not None), default)
    turns = [Turn(start, end, current)]
    run_who, run_from = None, None
    need = int(round(MIN_TURN * SPEAKER_FPS))
    count = 0
    for t, who in zip(times, leader):
        if who is not None and who != current:
            if who == run_who:
                count += 1
            else:
                run_who, run_from, count = who, t, 1
            if count >= need:
                cut = _snap(run_from, words, turns[-1].start + MIN_TURN, end - MIN_TURN)
                if cut - turns[-1].start >= MIN_TURN and end - cut >= MIN_TURN:
                    turns[-1].end = cut
                    turns.append(Turn(cut, end, who))
                    current = who
                run_who, count = None, 0
        elif who == current:
            run_who, count = None, 0
    return turns


# ---------------------------------------------------------------------
#  Exact cut frame
# ---------------------------------------------------------------------
def frame_diffs(frames) -> list[float]:
    import numpy as np
    return [float(np.abs(b.astype(np.int16) - a.astype(np.int16)).mean()) for a, b in zip(frames, frames[1:])]


_CUT_MEMO: dict = {}          # (source, waqt) -> pakka cut (ek moment ke cuts / edits mein dobara nahi)


def refine_cut(path: Path, around: float, fps: float, window: float = 0.5) -> float:
    key = (str(path), round(around, 3), round(fps or 0, 3), window)
    if key not in _CUT_MEMO:
        if len(_CUT_MEMO) > 5000:
            _CUT_MEMO.clear()
        _CUT_MEMO[key] = _refine_cut(path, around, fps, window)
    return _CUT_MEMO[key]


def _refine_cut(path: Path, around: float, fps: float, window: float = 0.5) -> float:
    """
    Boundary time halfway between the last frame of the old shot and the
    first frame of the new one (falls back to `around`). Frame times are
    read from the decoder (showinfo), so files whose timestamps do not
    start at zero are handled too.
    """
    import re
    import numpy as np
    t0 = max(0.0, around - window)
    w, h = 160, 90
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        proc = subprocess.run([ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "info", "-ss", f"{t0:.4f}",
                               "-t", f"{2 * window:.4f}", "-i", str(path), "-an",
                               "-vf", f"scale={w}:{h}:flags=area,showinfo", "-fps_mode", "passthrough",
                               "-f", "rawvideo", "-pix_fmt", "gray", "-"],
                              capture_output=True, timeout=60, creationflags=flags)
    except Exception:  # noqa: BLE001
        return around
    raw = proc.stdout
    # one "n: <i> pts: <p> pts_time: <t>" line per frame; passthrough keeps frames and lines in step
    stamps = [float(x) for x in re.findall(r"n:\s*\d+\s+pts:\s*-?\d+\s+pts_time:\s*(-?[\d.]+)",
                                           proc.stderr.decode("utf-8", "replace"))]
    n = min(len(raw) // (w * h), len(stamps))
    if n < 3:
        return around
    frames = [np.frombuffer(raw[i * w * h:(i + 1) * w * h], np.uint8) for i in range(n)]
    diffs = frame_diffs(frames)
    k = int(np.argmax(diffs))
    if diffs[k] < 2.5 * (sorted(diffs)[len(diffs) // 2] + 1.0):
        return around                       # no clear jump: keep the estimate
    return round(t0 + (stamps[k] + stamps[k + 1]) / 2, 4)
