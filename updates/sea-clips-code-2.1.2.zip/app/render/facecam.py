"""
=====================================================================
  RENDER / FACECAM            (20 Nov 2026, GTA 6 stream clips)
  Kaam: streamer ki gameplay video mein us ka camera (facecam) dabba
  dhoondna, taa ke 9:16 clip mein chehra alag (gol ya upar) aur game
  alag dikhe.
  A facecam is the one face that never moves: same place in every
  sampled frame. Game characters (cutscenes, NPCs) move around, so we
  keep only a face cluster that is seen in many frames at one spot.
  The box edge is where the picture is always split: the average edge
  strength over many frames is high there (gameplay edges average out).
  If no clear edge is found, the box is the face padded to a webcam
  shape. Cached next to the transcript, so it runs once per video.
=====================================================================
"""
from __future__ import annotations

import json
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path

from app.core.logging_setup import get_logger
from app.core.paths import resource
from app.media.ffmpeg_tools import ffmpeg_bin
from app.media.probe import SourceInfo

log = get_logger("facecam")

SAMPLES = 40
SIZE = (960, 540)
MIN_SEEN = 0.30          # itne frames mein chehra usi jagah ho (cutscene / NPC chehre itne nahi)
MAX_DRIFT = 0.035        # chehre ka markaz itna hi hile (frame ki chaurai ka hissa)
MIN_FACE = 0.018         # chehra kam az kam itna chaura (frame ka hissa)
MAX_CAM = 0.32           # dabba is se bara: ye "sirf baatein" wali poori screen hai, gameplay nahi
MIN_CAM = 0.012
ROOM_LEVEL = 0.55        # webcam ka kamra: game ki ausat harkat ke itne hisse se kam badalta hai
GAME_LEVEL = 0.75        # game: ausat harkat ke itne hisse se zyada


@dataclass
class Facecam:
    x: float          # dabba (0..1 frame ka hissa)
    y: float
    w: float
    h: float
    fx: float         # chehre ka markaz
    fy: float
    fs: float         # chehre ki chaurai
    seen: float = 0.0

    def box(self) -> tuple[float, float, float, float]:
        return (self.x, self.y, self.w, self.h)

    def face(self) -> tuple[float, float, float]:
        return (self.fx, self.fy, self.fs)


def _frames(path: Path, duration: float, count: int = SAMPLES, size: tuple[int, int] = SIZE) -> list:
    """Video bhar mein phaile ~count rangeen frames (sirf key frames: tez)."""
    import numpy as np
    w, h = size
    rate = f",fps={count / duration:.6f}" if duration > 0 else ""
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "error", "-skip_frame", "nokey",
           "-i", str(path), "-an", "-vf", f"scale={w}:{h}:flags=area{rate}",
           "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=flags)
    frames: list = []
    n = w * h * 3
    try:
        while len(frames) < count * 2:
            buf = proc.stdout.read(n)
            if len(buf) < n:
                break
            frames.append(np.frombuffer(buf, np.uint8).reshape(h, w, 3).copy())
    finally:
        proc.kill()
        proc.wait()
    if len(frames) > count:
        step = len(frames) / count
        frames = [frames[int(i * step)] for i in range(count)]
    return frames


def _faces(frames) -> list[list[tuple[float, float, float, float, float]]]:
    """Har frame ke chehre: (cx, cy, w, h, score) frame ke hisse mein."""
    import cv2
    if not frames:
        return []
    h, w = frames[0].shape[:2]
    model = resource("assets", "models", "face_detection_yunet_2023mar.onnx")
    det = cv2.FaceDetectorYN.create(str(model), "", (w, h), 0.7, 0.3, 50)
    out = []
    for f in frames:
        _, r = det.detect(f)
        faces = []
        for b in (r if r is not None else []):
            bx, by, bw, bh = (float(v) for v in b[:4])
            if bw / w >= MIN_FACE:
                faces.append(((bx + bw / 2) / w, (by + bh / 2) / h, bw / w, bh / h, float(b[-1])))
        out.append(faces)
    return out


def _stable_face(per_frame) -> tuple[float, float, float, float, float] | None:
    """Wo chehra jo sab se zyada frames mein ek hi jagah hai: (cx, cy, w, h, seen share)."""
    import numpy as np
    pts = [(i, f) for i, faces in enumerate(per_frame) for f in faces]
    if not pts or not per_frame:
        return None
    best = None
    for _, (cx, cy, fw, fh, _s) in pts:
        near = [f for i, f in pts if abs(f[0] - cx) < MAX_DRIFT * 1.5 and abs(f[1] - cy) < MAX_DRIFT * 2.6]
        frames_seen = len({i for i, f in pts if abs(f[0] - cx) < MAX_DRIFT * 1.5 and abs(f[1] - cy) < MAX_DRIFT * 2.6})
        if best is None or frames_seen > best[0]:
            best = (frames_seen, near)
    seen = best[0] / len(per_frame)
    arr = np.array([f[:4] for f in best[1]])
    if seen < MIN_SEEN or arr[:, 0].std() > MAX_DRIFT or arr[:, 1].std() > MAX_DRIFT * 1.8:
        return None
    cx, cy, fw, fh = np.median(arr, axis=0)
    return float(cx), float(cy), float(fw), float(fh), float(seen)


def _change_map(frames):
    """Har pixel kitna badalta hai (median se ausat farq): kamra (webcam) kam, game zyada."""
    import cv2
    import numpy as np
    g = np.stack([cv2.GaussianBlur(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), (5, 5), 0) for f in frames]).astype(np.float32)
    med = np.median(g, axis=0)
    return cv2.GaussianBlur(np.median(np.abs(g - med), axis=0), (5, 5), 0)


def _walk(prof, start: int, stop: int, game: float) -> int | None:
    """Chehre se bahar ki taraf: pehle kamra (kam badle), phir game (zyada badle, kuch der tak) = dabbe ka kinara."""
    import numpy as np
    step = 1 if stop > start else -1
    low_run, seen_low = 0, False
    hold = max(6, abs(stop - start) // 12)
    for x in range(start, stop, step):
        v = prof[x]
        if v < ROOM_LEVEL * game:
            low_run += 1
            seen_low = seen_low or low_run >= 3
            continue
        low_run = 0
        if seen_low and v > GAME_LEVEL * game:
            ahead = prof[x: x + step * hold: step] if step > 0 else prof[max(0, x - hold + 1): x + 1][::-1]
            if len(ahead) >= hold // 2 and float(np.median(ahead)) > GAME_LEVEL * game:
                return x
    return None


def _snap_box(frames, face) -> tuple[float, float, float, float]:
    """Chehre ke gird camera dabba: chehre se bahar chalte hue kamra (webcam ka peechha, kam badalta) khatam
    ho kar game (zyada badalta) shuru ho, wahi kinara. Na mile to frame ka kinara (camera kone se laga ho)
    ya webcam ki shakal."""
    import numpy as np
    h, w = frames[0].shape[:2]
    cx, cy, fw, fh = face[0] * w, face[1] * h, face[2] * w, face[3] * h
    D = _change_map(frames)
    mask = np.ones_like(D, bool)
    mask[int(max(0, cy - 3 * fh)):int(min(h, cy + 3 * fh)), int(max(0, cx - 4 * fw)):int(min(w, cx + 4 * fw))] = False
    game = float(np.median(D[mask])) if mask.any() else float(np.median(D))
    reach_x, reach_y = 4.0 * fw, 3.0 * fh
    edge_px = 6
    L, R = cx - 1.9 * fw, cx + 1.9 * fw
    T, B = cy - 1.5 * fh, cy + 1.7 * fh
    for rnd in range(3):
        ys = (int(max(0, cy - 0.9 * fh)), int(min(h, cy + 0.9 * fh))) if rnd == 0 else \
            (int(max(0, T + 0.1 * (B - T))), int(min(h, B - 0.1 * (B - T))))
        xs = (int(max(0, cx - 0.9 * fw)), int(min(w, cx + 0.9 * fw))) if rnd == 0 else \
            (int(max(0, L + 0.1 * (R - L))), int(min(w, R - 0.1 * (R - L))))
        col = np.median(D[ys[0]:ys[1]], axis=0)
        row = np.median(D[:, xs[0]:xs[1]], axis=1)
        nl = _walk(col, int(cx - 0.6 * fw), int(max(-1, cx - reach_x)), game)
        nr = _walk(col, int(cx + 0.6 * fw), int(min(w, cx + reach_x)), game)
        nt = _walk(row, int(cy - 0.7 * fh), int(max(-1, cy - reach_y)), game)
        nb = _walk(row, int(cy + 0.7 * fh), int(min(h, cy + reach_y)), game)
        L = nl + 1 if nl is not None else (0 if cx - reach_x <= edge_px else cx - 1.9 * fw)
        R = nr if nr is not None else (w if cx + reach_x >= w - edge_px else cx + 1.9 * fw)
        T = nt + 1 if nt is not None else (0 if cy - reach_y <= edge_px else cy - 1.5 * fh)
        B = nb if nb is not None else (h if cy + reach_y >= h - edge_px else cy + 1.7 * fh)
    L, R, T, B = max(0, L), min(w, R), max(0, T), min(h, B)
    return L / w, T / h, (R - L) / w, (B - T) / h


def find_facecam(frames) -> Facecam | None:
    """Pure image logic (synthetic frames par test)."""
    if len(frames) < 8:
        return None
    face = _stable_face(_faces(frames))
    if face is None:
        return None
    bx, by, bw, bh = _snap_box(frames, face)
    area = bw * bh
    if not (MIN_CAM <= area <= MAX_CAM):
        log.info("Facecam: face box %.1f%% of the frame, not a corner camera", area * 100)
        return None
    return Facecam(round(bx, 4), round(by, 4), round(bw, 4), round(bh, 4),
                   round(face[0], 4), round(face[1], 4), round(face[2], 4), round(face[4], 3))


def detect(info: SourceInfo, cache: Path | None = None) -> Facecam | None:
    if cache is not None and cache.exists():
        try:
            d = json.loads(cache.read_text(encoding="utf-8"))
            return Facecam(**d) if d else None
        except (ValueError, TypeError):
            pass
    try:
        cam = find_facecam(_frames(info.path, info.duration))
    except Exception as exc:  # noqa: BLE001 - kabhi run na roke
        log.warning("Facecam search failed: %s", exc)
        cam = None
    if cache is not None:
        try:
            cache.write_text(json.dumps(asdict(cam) if cam else {}), encoding="utf-8")
        except OSError:
            pass
    log.info("Facecam: %s", cam)
    return cam
