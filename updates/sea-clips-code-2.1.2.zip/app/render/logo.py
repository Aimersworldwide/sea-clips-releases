"""
=====================================================================
  RENDER / SOURCE LOGO  (find the channel watermark in the source)
  Kaam: source video ka channel logo dhoondna (chhupane / rakhne ke liye).
  A channel logo is the one thing that never changes: same pixels,
  same place, in every shot. We look at 48 key frames spread over the
  whole video (key frames only: fast) and keep pixels that
     * have an edge in at least 75 % of the frames, and
     * almost never change brightness (std < 8 grey levels),
  then keep only the corners of the frame (watermarks always sit in a
  corner; static scenery in the middle is ignored). The biggest such
  group, padded a little, is the logo box.
  Result is cached next to the transcript, so it runs once per video.

  Campaign options use the box:
    keep  nothing changes
    hide  the box is filled from its surroundings (ffmpeg delogo), and
          stacked framing moves past it when the faces allow
  Only hide a logo when the campaign has the rights to the content.
=====================================================================
"""
from __future__ import annotations

import json
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path

from app.core.logging_setup import get_logger
from app.media.ffmpeg_tools import ffmpeg_bin
from app.media.probe import SourceInfo

log = get_logger("logo")

SAMPLES = 48
SIZE = (640, 360)
EDGE_SHARE = 0.75
STILL_STD = 8.0
CORNER = 0.25            # corner zones: outer 25 % of width and height
MIN_AREA = 0.0008        # share of the frame
MAX_AREA = 0.05
PAD = 0.012              # padding around the box (share of the frame)


@dataclass
class LogoBox:
    x: float     # 0..1 of the frame
    y: float
    w: float
    h: float

    def pixels(self, width: int, height: int) -> tuple[int, int, int, int]:
        """Integer box inside the frame with a 1 px margin (delogo needs it)."""
        x = max(1, int(self.x * width))
        y = max(1, int(self.y * height))
        w = min(width - x - 1, max(4, int(round(self.w * width))))
        h = min(height - y - 1, max(4, int(round(self.h * height))))
        return x, y, w, h


def _keyframes(path: Path, size: tuple[int, int], count: int, duration: float = 0.0) -> list:
    """
    About `count` frames spread over the video, decoding key frames only
    (fast). Frames are read one by one and thinned on the fly, so even a
    3 hour video never holds more than `count` frames in memory.
    """
    import numpy as np
    w, h = size
    rate = f",fps={count / duration:.6f}" if duration > 0 else ""
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "error", "-skip_frame", "nokey",
           "-i", str(path), "-an", "-vf", f"scale={w}:{h}:flags=area{rate}",
           "-f", "rawvideo", "-pix_fmt", "gray", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=flags)
    frames: list = []
    step, seen = 1, 0
    try:
        while True:
            buf = proc.stdout.read(w * h)
            if len(buf) < w * h:
                break
            if seen % step == 0:
                frames.append(np.frombuffer(buf, np.uint8).reshape(h, w).copy())
                if len(frames) >= 2 * count:            # too many: keep every other one
                    frames = frames[::2]
                    step *= 2
            seen += 1
    finally:
        proc.kill()
        proc.wait()
    if len(frames) <= count:
        return frames
    pick = len(frames) / count
    return [frames[int(i * pick)] for i in range(count)]


def find_box(frames) -> LogoBox | None:
    """Pure image logic (tested on synthetic frames)."""
    import cv2
    import numpy as np
    if len(frames) < 8:
        return None
    stack = np.stack(frames).astype(np.float32)
    h, w = stack.shape[1:]
    std = stack.std(axis=0)
    edges = np.stack([cv2.Canny(f.astype(np.uint8), 60, 140) > 0 for f in stack]).mean(axis=0)
    mask = ((edges >= EDGE_SHARE) & (std < STILL_STD)).astype(np.uint8)
    corner = np.zeros_like(mask)
    cw, ch = int(w * CORNER), int(h * CORNER)
    for ys in (slice(0, ch), slice(h - ch, h)):
        for xs in (slice(0, cw), slice(w - cw, w)):
            corner[ys, xs] = 1
    mask &= corner
    mask = cv2.dilate(mask * 255, np.ones((5, 5), np.uint8))
    # A logo is often an icon plus a line of text: everything still in
    # the same corner belongs together. Take the corner with most of it.
    best = None
    for ys in (slice(0, ch), slice(h - ch, h)):
        for xs in (slice(0, cw), slice(w - cw, w)):
            part = mask[ys, xs]
            n, _, stats, _ = cv2.connectedComponentsWithStats(part)
            # drop noisy specks and anything touching the frame border (borders, not logos)
            keep = [st for st in stats[1:] if st[4] >= 12
                    and st[0] + xs.start > 2 and st[0] + st[2] + xs.start < w - 2
                    and st[1] + ys.start > 2 and st[1] + st[3] + ys.start < h - 2]
            if not keep:
                continue
            x0 = min(st[0] for st in keep) + xs.start
            y0 = min(st[1] for st in keep) + ys.start
            x1 = max(st[0] + st[2] for st in keep) + xs.start
            y1 = max(st[1] + st[3] for st in keep) + ys.start
            area = sum(st[4] for st in keep)
            share = (x1 - x0) * (y1 - y0) / (w * h)
            if MIN_AREA <= share <= MAX_AREA and (best is None or area > best[4]):
                best = (x0, y0, x1 - x0, y1 - y0, area)
    if best is None:
        return None
    x, y, bw, bh, _ = best
    px, py = PAD, PAD * w / h
    x0, y0 = max(0.0, x / w - px), max(0.0, y / h - py)
    x1, y1 = min(1.0, (x + bw) / w + px), min(1.0, (y + bh) / h + py)
    return LogoBox(round(float(x0), 4), round(float(y0), 4), round(float(x1 - x0), 4), round(float(y1 - y0), 4))


def detect(info: SourceInfo, cache_file: Path | None = None) -> LogoBox | None:
    """Logo box of this video, or None. Never raises."""
    if cache_file is not None and cache_file.exists():
        try:
            data = json.loads(cache_file.read_text(encoding="utf-8"))
            return LogoBox(**data["box"]) if data.get("box") else None
        except (ValueError, KeyError, TypeError):
            pass
    box = None
    try:
        box = find_box(_keyframes(info.path, SIZE, SAMPLES, info.duration))
        log.info("Source logo: %s", asdict(box) if box else "none found")
    except Exception as exc:  # noqa: BLE001 - a missing logo box must never stop a run
        log.warning("Logo search failed: %s", exc)
        return None
    if cache_file is not None:
        try:
            cache_file.write_text(json.dumps({"box": asdict(box) if box else None}), encoding="utf-8")
        except OSError:
            pass
    return box


SOURCE_LOGO_MODES = ("keep", "blur", "replace")
POSITIONS = ("top_left", "top_right", "bottom_left", "bottom_right")
FEATHER = 24          # px soft edge of the blurred patch (1080p source)


def source_logo_graph(box: LogoBox, width: int, height: int, mode: str, in_label: str, out_label: str,
                      brand_label: str = "", tag: str = "lg") -> str:
    """
    blur    : delogo, then a soft-edged blur over the area so no streaks show
    replace : the same, with the campaign logo centred on top
    """
    x, y, w, h = box.pixels(width, height)
    f = max(8, int(FEATHER * height / 1080))
    px, py = max(0, x - f), max(0, y - f)
    pw, ph = min(width - px, w + 2 * f), min(height - py, h + 2 * f)
    pw, ph = pw - pw % 2, ph - ph % 2
    alpha = f"255*min(1,min(min(X,W-1-X),min(Y,H-1-Y))/{f})"      # inside quotes: commas are safe
    graph = (
        f"[{in_label}]delogo=x={x}:y={y}:w={w}:h={h},split[{tag}m][{tag}r];"
        f"[{tag}r]crop={pw}:{ph}:{px}:{py},gblur=sigma={max(4, f // 2)},format=yuva420p,"
        f"geq=lum='lum(X,Y)':cb='cb(X,Y)':cr='cr(X,Y)':a='{alpha}'[{tag}p];"
        f"[{tag}m][{tag}p]overlay={px}:{py}"
    )
    if mode == "replace" and brand_label:
        bw, bh = int(w * 0.92) // 2 * 2, int(h * 0.92) // 2 * 2
        graph += (f"[{tag}b];[{brand_label}]scale={bw}:{bh}:force_original_aspect_ratio=decrease:flags=lanczos,"
                  f"format=rgba[{tag}i];[{tag}b][{tag}i]overlay=x={x}+({w}-w)/2:y={y}+({h}-h)/2:format=auto")
    return graph + f",setsar=1[{out_label}]"


def ticker_blur_graph(in_label: str, out_label: str, bands, width: int, height: int, tag: str = "tk") -> str:
    """News ki chalti patti(yan) blur: likhai na parhi jaye, baaki video aur logo saaf. bands = [(y0, y1)]
    source frame ke hisse mein."""
    parts, cur = [], in_label
    for i, (y0, y1) in enumerate(bands):
        by = max(0, int(y0 * height) // 2 * 2)
        bh = max(2, min(height - by, int((y1 - y0) * height + 1)) // 2 * 2)
        sigma = max(6, bh // 2)
        nxt = f"{tag}o{i}"
        parts.append(f"[{cur}]split[{tag}m{i}][{tag}c{i}];"
                     f"[{tag}c{i}]crop={width}:{bh}:0:{by},gblur=sigma={sigma},gblur=sigma={sigma},"
                     f"eq=brightness=-0.05:saturation=0.7[{tag}b{i}];"
                     f"[{tag}m{i}][{tag}b{i}]overlay=0:{by}[{nxt}]")
        cur = nxt
    parts.append(f"[{cur}]setsar=1[{out_label}]")
    return ";".join(parts)


def brand_overlay_graph(in_label: str, brand_label: str, out_label: str, out_w: int, out_h: int,
                        position: str, size_pct: float, opacity: float, tag: str = "bl", bottom_offset: int = 0,
                        top_offset: int = 0) -> str:
    """Campaign logo in a corner of the finished frame (bottom_offset / top_offset: disclosure ki patti
    neeche / upar ho to logo us se hat kar)."""
    width = max(32, int(out_w * max(4.0, min(size_pct, 40.0)) / 100)) // 2 * 2
    margin = int(out_w * 0.04)
    pos = position if position in POSITIONS else "top_right"
    x = str(margin) if pos.endswith("left") else f"W-w-{margin}"
    y = str(margin + 20 + top_offset) if pos.startswith("top") else f"H-h-{margin + 20 + bottom_offset}"
    a = max(0.1, min(opacity, 1.0))
    return (f"[{brand_label}]scale={width}:-2:flags=lanczos,format=rgba,colorchannelmixer=aa={a:.2f}[{tag}i];"
            f"[{in_label}][{tag}i]overlay=x={x}:y={y}:format=auto[{out_label}]")
