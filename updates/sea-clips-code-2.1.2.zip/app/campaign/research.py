"""
=====================================================================
  CAMPAIGN / RESEARCH  (turn "these politicians" into names)
  Kaam: "ye politicians" jaise group ke asli naam online dhoondna.
  A brief often names a group instead of people. To follow it, the
  app needs the actual names:
    1. Gemini with Google Search (user's free key): best and current
    2. Wikipedia (free public API, no key): the matching "List of ..."
       page, people's names taken from its links
  Names always go to the summary with their source, so the user can
  check them before saving. Nothing is looked up when the user turned
  research off, and no data about the user is ever sent.
=====================================================================
"""
from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request

from app.campaign.ai import gemini_text  # noqa: F401 (purana, tests ke liye; kabhi nahi chalta)
from app.campaign.brief import MAX_NAMES, BriefResult
from app.core.logging_setup import get_logger

log = get_logger("research")

WIKI = "https://en.wikipedia.org/w/api.php"
UA = "AIMERS-Auto-Clipping-Tool/1.0 (github.com/Aimersworldwide)"
NAME_RE = re.compile(r"^[A-Z][A-Za-z.'\-]+(?: [A-Z][A-Za-z.'\-]+){1,3}$")
NOT_NAMES = ("List", "Party", "United States", "House", "Senate", "Election", "Committee", "Congress",
             "Republic", "Department", "University", "County", "District", "State", "Wikipedia", "Category")


def plausible_name(text: str) -> bool:
    text = text.strip()
    return bool(NAME_RE.match(text)) and not any(w in text for w in NOT_NAMES) and not re.search(r"\d", text)


def _names_from_lines(text: str) -> list[str]:
    out = []
    for line in text.splitlines():
        name = re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", line).split(" (")[0].split(" - ")[0].strip(" .,*")
        if plausible_name(name) and name not in out:
            out.append(name)
    return out[:MAX_NAMES]


def via_gemini(phrase: str, context: str, key: str, model: str = "") -> tuple[list[str], str]:
    prompt = (f"A short-video campaign brief says not to include: \"{phrase}\".\n"
              f"Brief context: {context[:1500]}\n"
              f"Using current information, list the full names of the people (or brands) this most likely means, "
              f"the {MAX_NAMES // 2} most prominent at most. One name per line, nothing else.")
    text, sources = gemini_text(prompt, key, model, search=True)
    names = _names_from_lines(text)
    src = "Google Search (Gemini)" + (f": {', '.join(sources[:3])}" if sources else "")
    return names, src


def _wiki(params: dict) -> dict:
    url = WIKI + "?" + urllib.parse.urlencode({**params, "format": "json"})
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=20) as resp:   # noqa: S310 - fixed https
        return json.loads(resp.read().decode("utf-8"))


def via_wikipedia(phrase: str) -> tuple[list[str], str]:
    found = _wiki({"action": "query", "list": "search", "srsearch": f"List of {phrase}", "srlimit": 5})
    titles = [h["title"] for h in found.get("query", {}).get("search", [])]
    title = next((t for t in titles if t.lower().startswith("list of")), None)
    if not title:
        return [], ""
    links = _wiki({"action": "parse", "page": title, "prop": "links"})
    names = [ln.get("*", "") for ln in links.get("parse", {}).get("links", []) if ln.get("ns") == 0]
    names = [n for n in dict.fromkeys(names) if plausible_name(n)][:MAX_NAMES]
    return names, f"Wikipedia: {title}"


def expand_groups(r: BriefResult, brief_text: str, key: str = "", model: str = "") -> BriefResult:
    """Look up names for every group in the brief and add them to the right list."""
    for g in r.groups:
        phrase, names, src = g["phrase"], [], ""
        # Gemini kabhi nahi (user ka faisla): sirf Wikipedia ki public list
        if not names:
            try:
                names, src = via_wikipedia(phrase)
            except Exception as exc:  # noqa: BLE001 - offline / blocked: the summary says so
                log.info("Wikipedia research skipped for %s: %s", phrase, exc)
        if names:
            bucket = r.mute_words if g["target"] == "mute" else r.avoid_topics
            for n in names:
                extra = [n]
                if g["target"] == "mute" and len(n.split()) >= 2 and len(n.split()[-1]) >= 5:
                    extra.append(n.split()[-1])         # speakers mostly say the surname only
                for item in extra:
                    if item.lower() not in (x.lower() for x in bucket):
                        bucket.append(item)
            for n in names:                               # group ke log bhi spelling list mein
                if n.lower() not in (x.lower() for x in r.names):
                    r.names.append(n)
            r.sources[phrase] = f"{len(names)} names from {src}"
            if "research" not in r.engine:
                r.engine.append("research")
    return r


def read_and_research(text: str, settings) -> BriefResult:
    """Full brief reading: rules, then AI (if available), then research. Never raises."""
    from app.campaign.ai import read_brief
    from app.campaign.brief import clean, merge, parse_rules
    result = parse_rules(text)
    key = getattr(settings, "gemini_api_key", "") or ""
    model = getattr(settings, "gemini_model", "") or ""
    try:
        ai = read_brief(text, key, model)
        # AI understands free-style briefs better, but explicit numbers found by the rules stay
        result = merge(result, ai, extra_wins=False) if ai else result
    except Exception as exc:  # noqa: BLE001
        log.warning("AI reading failed: %s", exc)
    if getattr(settings, "research_online", True) and result.groups:
        try:
            result = expand_groups(result, text, key, model)
        except Exception as exc:  # noqa: BLE001
            log.warning("Research failed: %s", exc)
    return clean(result)
