"""
=====================================================================
  CAMPAIGN / AI READING  (free options only)
  Kaam: campaign ki rules AI (Gemini ya laptop wala model) se parhna, jawab check kar ke.
    gemini : Google Gemini with the user's own free API key (Google AI
             Studio). Best results; also used for research with Google
             Search. Free tier note: Google may use free-tier text to
             improve its products, so do not paste secret briefs.
    ollama : a local model on this laptop (http://127.0.0.1:11434) if
             the user installed Ollama. Free and fully offline.
  The key is sent in a header (never in the link) and never written to
  the log. Every answer is parsed as strict JSON and cleaned by
  brief.clean(), so a wrong or strange answer cannot break a campaign.
=====================================================================
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request

from app.campaign.brief import SCALARS, BriefResult
from app.core.logging_setup import get_logger

log = get_logger("brief_ai")

GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
GEMINI_MODELS = ("gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash")
OLLAMA = "http://127.0.0.1:11434"
TIMEOUT = 60

PROMPT = """You read short-video clipping campaign briefs and turn them into tool settings.
Rules:
- Only set what the brief clearly REQUIRES that could make a clip ineligible. Do not invent rules.
- Anything not mentioned stays null (or an empty list).
- mute_words: only exact words/names the brief says to mute, bleep or never say.
- avoid_topics: only subjects/names the brief says never to mention or show (clips that mention them are skipped).
- groups: when the brief refers to a GROUP instead of names (e.g. "Democratic politicians", "competitor brands"),
  add {"phrase": "<the group as written>", "target": "mute" or "avoid"} so names can be looked up.
- names: every person, show, channel and place named in the brief, spelled correctly (for the captions).
  If the brief names a group of people (e.g. "these hosts"), list the members too.
- notes: requirements the editing tool cannot do itself (posting times, tagging accounts, filming rules), short.
- evidence: for each setting you set, the exact sentence of the brief it came from.
- Lengths are in seconds. ratio is "9:16" or "16:9". platform is "shorts", "tiktok" or "reels".
- profanity is "strict" (no swearing at all), "standard" (bleep strong swearing) or "off".
- source_logo is "keep" (other channel logos must stay) or "blur" (other logos/watermarks must not show).
Return ONLY JSON with exactly these keys:
{"min_length": null, "max_length": null, "ratio": null, "platform": null, "captions": null, "profanity": null,
 "music_allowed": null, "source_logo": null, "disclosure": null, "disclosure_text": null, "hashtags": null,
 "post_text": null, "title": null, "mute_words": [], "avoid_topics": [], "groups": [], "names": [], "notes": [],
 "evidence": {}}

BRIEF:
"""


class AIUnavailable(RuntimeError):
    pass


# ---------------------------------------------------------------------
#  Transport
# ---------------------------------------------------------------------
def _post(url: str, payload: dict, headers: dict | None = None, timeout: int = TIMEOUT) -> dict:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST",
                                 headers={"Content-Type": "application/json", **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as resp:    # noqa: S310 - fixed https / localhost
        return json.loads(resp.read().decode("utf-8"))


def gemini_text(prompt: str, key: str, model: str = "", search: bool = False, json_mode: bool = False) -> tuple[str, list]:
    """Gemini band hai (user ka faisla, 25 Oct 2026): free tier mein Google data parh sakta hai.
    Is liye ye kabhi kuch nahi bhejta; har jagah tool ke apne qaide / laptop ki AI chalti hai."""
    raise AIUnavailable("Gemini is not used in this app")
    if not key:  # noqa: unreachable - purana rasta, kabhi nahi chalta
        raise AIUnavailable("no Gemini key")
    payload: dict = {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"temperature": 0}}
    if json_mode:
        payload["generationConfig"]["responseMimeType"] = "application/json"
    if search:
        payload["tools"] = [{"google_search": {}}]
    last: Exception | None = None
    for name in ([model] if model else []) + [m for m in GEMINI_MODELS if m != model]:
        try:
            out = _post(GEMINI_URL.format(model=name), payload, {"x-goog-api-key": key})
        except urllib.error.HTTPError as exc:
            last = exc
            if exc.code in (400, 404):          # model name not available here: try the next one
                continue
            if exc.code in (401, 403):
                raise AIUnavailable("the Gemini key was not accepted") from exc
            if exc.code == 429:
                raise AIUnavailable("Gemini free limit reached for now, try again later") from exc
            raise AIUnavailable(f"Gemini error {exc.code}") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise AIUnavailable("no internet connection to Gemini") from exc
        cand = (out.get("candidates") or [{}])[0]
        text = "".join(p.get("text", "") for p in cand.get("content", {}).get("parts", []))
        chunks = cand.get("groundingMetadata", {}).get("groundingChunks", []) or []
        sources = [c.get("web", {}).get("title") or c.get("web", {}).get("uri", "") for c in chunks if c.get("web")]
        if text.strip():
            return text, [s for s in sources if s]
    raise AIUnavailable(f"no Gemini model answered ({last})")


def ollama_model() -> str:
    """Name of a local model if Ollama is running, else ''."""
    try:
        with urllib.request.urlopen(OLLAMA + "/api/tags", timeout=3) as resp:   # noqa: S310 - localhost
            models = [m.get("name", "") for m in json.loads(resp.read()).get("models", [])]
    except Exception:  # noqa: BLE001
        return ""
    for pref in ("qwen", "llama3", "mistral", "gemma", "phi"):
        for m in models:
            if m.lower().startswith(pref):
                return m
    return models[0] if models else ""


def ollama_text(prompt: str, model: str) -> str:
    try:
        out = _post(OLLAMA + "/api/generate",
                    {"model": model, "prompt": prompt, "format": "json", "stream": False,
                     "options": {"temperature": 0}}, timeout=300)
    except Exception as exc:  # noqa: BLE001
        raise AIUnavailable(f"local model did not answer ({exc})") from exc
    return out.get("response", "")


# ---------------------------------------------------------------------
#  Brief reading
# ---------------------------------------------------------------------
def parse_answer(text: str, engine: str) -> BriefResult:
    """Strict JSON -> BriefResult; unknown or badly typed fields are dropped."""
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("no JSON in the answer")
    data = json.loads(text[start:end + 1])
    r = BriefResult(engine=[engine])
    kinds = {"min_length": int, "max_length": int, "captions": bool, "music_allowed": bool, "disclosure": bool}
    for name in SCALARS:
        value = data.get(name)
        if value is None:
            continue
        want = kinds.get(name, str)
        if want is int and isinstance(value, (int, float)) and not isinstance(value, bool):
            setattr(r, name, int(value))
        elif want is bool and isinstance(value, bool):
            setattr(r, name, value)
        elif want is str and isinstance(value, str) and value.strip():
            setattr(r, name, value.strip())
    for name in ("mute_words", "avoid_topics", "notes", "names"):
        value = data.get(name) or []
        if isinstance(value, list):
            setattr(r, name, [str(v).strip() for v in value if isinstance(v, (str, int)) and str(v).strip()])
    for g in data.get("groups") or []:
        if isinstance(g, dict) and isinstance(g.get("phrase"), str) and g.get("phrase").strip():
            r.groups.append({"phrase": g["phrase"].strip(), "target": "mute" if g.get("target") == "mute" else "avoid"})
    ev = data.get("evidence") or {}
    if isinstance(ev, dict):
        r.evidence = {str(k): str(v)[:200] for k, v in ev.items() if isinstance(v, str)}
    return r


def read_brief(text: str, gemini_key: str = "", gemini_model: str = "") -> BriefResult | None:
    """AI reading of the brief (Gemini first, then a local model). None if no AI is available."""
    prompt = PROMPT + text.strip()[:12000]
    if gemini_key:
        try:
            answer, _ = gemini_text(prompt, gemini_key, gemini_model, json_mode=True)
            return parse_answer(answer, "Gemini")
        except (AIUnavailable, ValueError) as exc:
            log.warning("Gemini brief reading not used: %s", exc)
    model = ollama_model()
    if model:
        try:
            return parse_answer(ollama_text(prompt, model), f"local AI ({model})")
        except (AIUnavailable, ValueError) as exc:
            log.warning("Local AI brief reading not used: %s", exc)
    return None
