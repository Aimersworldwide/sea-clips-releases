"""
=====================================================================
  CAMPAIGN / CHANNEL SCAN
  Kaam: YouTube channel ke "Videos" tab ki sab lambi videos (Shorts aur
  Live us tab mein nahi hote), pichle kuch saal ki, kam az kam itne
  second ki. Tareekh YouTube ki "2 years ago" wali (andaze ki), jo
  purane / naye ki tarteeb ke liye kaafi hai.
=====================================================================
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

from app.core.logging_setup import get_logger

log = get_logger("channel_scan")


def videos_tab(url: str) -> str:
    """@channel ya channel link se uska /videos tab."""
    u = url.strip().split("?")[0].rstrip("/")
    u = re.sub(r"/(videos|shorts|streams|featured|live|playlists|community|about)$", "", u)
    return u + "/videos"


def _day(e: dict) -> str:
    d = str(e.get("upload_date") or "")
    if re.fullmatch(r"\d{8}", d):
        return f"{d[:4]}-{d[4:6]}-{d[6:]}"
    ts = e.get("timestamp") or e.get("release_timestamp")
    if ts:
        return datetime.utcfromtimestamp(int(ts)).strftime("%Y-%m-%d")
    return ""


def scan(url: str, years: float = 4, min_seconds: int = 240, ydl_opts: dict | None = None) -> list[dict]:
    """[{id, link, title, uploaded (YYYY-MM-DD), minutes, channel}] naye se purane."""
    import yt_dlp
    cutoff = (date.today() - timedelta(days=int(365.25 * years))).isoformat()
    opts = dict(quiet=True, no_warnings=True, skip_download=True, extract_flat="in_playlist",
                extractor_args={"youtubetab": {"approximate_date": [""]}}, **(ydl_opts or {}))
    with yt_dlp.YoutubeDL(opts) as y:
        d = y.extract_info(videos_tab(url), download=False)
    channel = str(d.get("channel") or d.get("uploader") or d.get("title") or "").replace(" - Videos", "")
    out, older = [], 0
    for e in d.get("entries") or []:
        vid = str(e.get("id") or "")
        if not re.fullmatch(r"[A-Za-z0-9_-]{11}", vid):
            continue
        day = _day(e)
        if day and day < cutoff:
            older += 1
            if older >= 15:                    # tab naye se purane: kaafi purani aa gayin, bas
                break
            continue
        dur = float(e.get("duration") or 0)
        if dur < min_seconds or (e.get("live_status") or "") in ("is_live", "is_upcoming"):
            continue
        out.append({"id": vid, "link": f"https://youtu.be/{vid}", "title": str(e.get("title") or ""),
                    "uploaded": day, "minutes": round(dur / 60, 1), "channel": channel})
    log.info("Channel scan %s: %d long videos since %s", url, len(out), cutoff)
    return out
