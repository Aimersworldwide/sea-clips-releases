"""
=====================================================================
  CAMPAIGN / TEMPLATES   (ek click mein campaign ki settings)
  Kaam: aam qism ki campaigns ke liye tayyar settings. Template sirf
  wahi cheezen badalta hai jo is mein likhi hain; naam, folder, logo,
  main people aur pasted rules waise hi rehte hain. Baad mein har
  cheez haath se badli ja sakti hai.
    Debate     : siyasi bahas (Jubilee jaisi), 20-40 s, protection on
    Interview  : ek mehmaan se baat-cheet, 20-45 s
    Podcast    : lambi guftagu, 25-60 s, kam sakhti
    Main person: ek (ya kai) shakhs ki fan campaign (Clipit jaisi),
                 20-40 s, protection on, sakht alfaaz
  "Political preset" (balanced word rules): sirf asli khatre band
  (graphic violence / maut ki tafseel); garam bahas allowed.
=====================================================================
"""
from __future__ import annotations

POLITICAL_TOPICS = ["assassination", "assassinated", "massacre", "beheaded", "beheading", "mass shooting",
                    "school shooting", "suicide bombing", "genocide"]

TEMPLATES: dict[str, dict] = {
    "debate": {"min_length": 20, "max_length": 40, "ratio": "9:16", "profanity_level": "standard",
               "protect_main_person": True, "versions_per_moment": 4, "banned_topics": POLITICAL_TOPICS,
               "captions_enabled": True, "music_allowed": False},
    "interview": {"min_length": 20, "max_length": 45, "ratio": "9:16", "profanity_level": "standard",
                  "protect_main_person": True, "versions_per_moment": 4, "captions_enabled": True,
                  "music_allowed": False},
    "podcast": {"min_length": 25, "max_length": 60, "ratio": "9:16", "profanity_level": "standard",
                "protect_main_person": False, "versions_per_moment": 4, "captions_enabled": True},
    "main_person": {"min_length": 20, "max_length": 40, "ratio": "9:16", "profanity_level": "standard",
                    "protect_main_person": True, "versions_per_moment": 4, "banned_topics": POLITICAL_TOPICS,
                    "captions_enabled": True, "music_allowed": False, "source_logo": "keep",
                    "main_person_min_screen": 60, "main_person_min_speaking": 60},
}


def apply_template(profile, key: str) -> list[str]:
    """Template ki settings campaign mein; wapas: kya kya badla (summary ke liye)."""
    tpl = TEMPLATES.get(key)
    if not tpl:
        return []
    changed = []
    for attr, value in tpl.items():
        if attr == "banned_topics":
            merged = list(dict.fromkeys([*profile.banned_topics, *value]))
            if merged != profile.banned_topics:
                profile.banned_topics = merged
                changed.append(attr)
            continue
        if getattr(profile, attr, None) != value:
            setattr(profile, attr, value)
            changed.append(attr)
    return changed
