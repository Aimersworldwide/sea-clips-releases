"""
=====================================================================
  CAMPAIGN / BRIEF READER  (paste the requirements, settings fill in)
  Kaam: paste ki hui campaign rules parh kar campaign ki settings bharna.
  A campaign brief is plain text from the brand. This module turns it
  into campaign settings, in three layers:
    1. built-in rules  (always, offline): lengths, ratio, platform,
       captions, hashtags, disclosure, music, swearing, logo, words to
       mute, topics never to mention, post text
    2. AI reading      (optional, app.campaign.ai): Gemini with the
       user's free key, or a local Ollama model, for briefs written in
       free style; its answer is checked and limited before use
    3. research        (optional, app.campaign.research): a brief that
       names a group ("these politicians", "competitor brands") gets
       the actual names, with their source
  Only what can make a video ineligible is set. Nice-to-have wishes go
  to "notes" for the user, so the app never over-applies a brief.
  Nothing is saved until the user looks at the summary and presses
  Save on the campaign page.
=====================================================================
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

GROUP_WORDS = ("politician", "candidate", "senator", "congressman", "congresswoman", "representative",
               "governor", "president", "minister", "party", "parties", "brand", "competitor", "celebrit",
               "influencer", "athlete", "team", "company", "companies", "member", "leader", "commentator", "pundit",
               "podcaster", "youtuber", "streamer", "creator", "host", "channel", "network", "outlet")
MAX_NAMES = 60


@dataclass
class BriefResult:
    min_length: int | None = None
    max_length: int | None = None
    ratio: str | None = None
    platform: str | None = None
    captions: bool | None = None
    profanity: str | None = None             # strict | standard | off
    music_allowed: bool | None = None
    source_logo: str | None = None           # keep | blur
    disclosure: bool | None = None
    disclosure_text: str | None = None
    hashtags: str | None = None
    post_text: str | None = None
    title: str | None = None
    title_style: str | None = None           # viral | clean (clickbait / hype mana ho to clean)
    political_words: bool | None = None      # title / hashtags mein siyasi lafz aa sakte hain?
    title_emoji: str | None = None           # on | off
    title_must: str | None = None            # har title mein ye naam / topic
    max_hashtags: int | None = None          # zyada se zyada hashtags
    own_ads: bool | None = None              # videos campaign ke apne ads hain (ad wale hisse na kaato)
    keep_old_disclosure: bool | None = None  # video ka purana disclosure dikhta rahe
    disclosure_place: str | None = None      # below_video | top | bottom
    hide_ticker: bool | None = None          # news ki chalti patti blur
    topic_guard: bool | None = None          # topic ke khilaf lamhe clip nahi
    topic_terms: str | None = None           # topic ke naam
    cold_open_mode: str | None = None        # auto | on | off
    hook_mode: str | None = None             # auto | on | off
    main_person: str | None = None           # (15 Nov) jis par campaign hai (har clip mein screen par)
    main_min_screen: int | None = None       # wo clip ke kam az kam itne % mein screen par
    screen_text: str | None = None           # har clip mein screen par ye line (campaign line)
    light_edit: bool | None = None           # "light editing only": koi bhaari effect nahi
    no_bars: bool | None = None              # "no black bars / empty space": screen hamesha bhari
    no_split: bool | None = None             # "no split content": upar neeche do hisse nahi
    mute_words: list[str] = field(default_factory=list)       # beeped / muted in the clip
    avoid_topics: list[str] = field(default_factory=list)     # clips that mention these are skipped
    names: list[str] = field(default_factory=list)            # log / shows / jagahen: spelling dictionary
    groups: list[dict] = field(default_factory=list)          # {"phrase", "target": mute|avoid}
    notes: list[str] = field(default_factory=list)            # wishes the app cannot do itself
    evidence: dict[str, str] = field(default_factory=dict)    # setting -> sentence of the brief
    sources: dict[str, str] = field(default_factory=dict)     # researched name group -> where from
    engine: list[str] = field(default_factory=list)           # which layers were used
    confirmed: list[tuple[str, str, str]] = field(default_factory=list)   # brief ne manga, campaign mein pehle se sahi
    always: list[str] = field(default_factory=list)           # brief ne manga, tool har clip mein khud karta hai


# ---------------------------------------------------------------------
#  Layer 1: built-in rules
# ---------------------------------------------------------------------
def _sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [p.strip(" -*•\t") for p in parts if p.strip(" -*•\t")]


def _items(chunk: str) -> list[str]:
    """'Trump, Biden or Harris' -> ['Trump', 'Biden', 'Harris'] (quotes respected)."""
    quoted = re.findall(r"[\"“‘']([^\"”’']{1,60})[\"”’']", chunk)
    if quoted:
        return [q.strip() for q in quoted if q.strip()]
    chunk = re.split(r"\b(?:because|since|as it|so that|otherwise|in the video|in your clips?|at all)\b", chunk)[0]
    raw = re.split(r",|;|/|\bor\b|\band\b|\bnor\b", chunk)
    out = []
    for item in raw:
        item = re.sub(r"^(?:the|any|anything about|anything related to|about|words? like|names? like|of)\s+",
                      "", item.strip(" .:\"'"), flags=re.I).strip(" .:\"'")
        if 1 <= len(item) <= 60 and len(item.split()) <= 6:
            out.append(item)
    return out


def _seconds(num: str, unit: str) -> int:
    value = float(num)
    return int(round(value * 60)) if unit.lower().startswith("m") else int(round(value))


_UNIT = r"(s|sec|secs|second|seconds|min|mins|minute|minutes)\b"


def parse_rules(text: str) -> BriefResult:
    r = BriefResult(engine=["rules"])
    lower = text.lower()

    def note(key: str, sentence: str) -> None:
        r.evidence.setdefault(key, sentence[:200])

    for s in _sentences(text):
        sl = s.lower()

        # --- length -----------------------------------------------------
        m = re.search(r"(\d{1,3}(?:\.\d)?)\s*(?:-|–|to)\s*(\d{1,3}(?:\.\d)?)\s*" + _UNIT, sl)
        if m:
            r.min_length, r.max_length = _seconds(m.group(1), m.group(3)), _seconds(m.group(2), m.group(3))
            note("length", s)
        else:
            m = re.search(r"(?:at least|minimum(?: of)?|min\.?|no shorter than|longer than)\s*"
                          r"(?:(?:video|clip)\s*length\s*(?:=|:|is|of)?\s*)?(\d{1,3}(?:\.\d)?)\s*" + _UNIT, sl)
            if m:
                r.min_length = _seconds(m.group(1), m.group(2))
                note("length", s)
            m = re.search(r"(?:under|max(?:imum)?(?: of)?|no longer than|up to|less than|shorter than|at most)\s*"
                          r"(\d{1,3}(?:\.\d)?)\s*" + _UNIT, sl)
            if m:
                r.max_length = _seconds(m.group(1), m.group(2))
                note("length", s)

        # --- format -----------------------------------------------------
        if re.search(r"\b9\s*:\s*16\b|\bvertical\b|\bportrait\b", sl):
            r.ratio = "9:16"
            note("ratio", s)
        elif re.search(r"\b16\s*:\s*9\b|\bhorizontal\b|\blandscape\b", sl):
            r.ratio = "16:9"
            note("ratio", s)
        for word, value in (("tiktok", "tiktok"), ("reels", "reels"), ("instagram", "reels"), ("shorts", "shorts")):
            # "YouTube Shorts are not allowed" / "no Shorts": wo platform NAHI (30 Oct, Prop 42)
            banned = re.search(rf"\b(?:no|not|never|without)\b[^.]{{0,25}}\b{word}\b|\b{word}\b[^.]{{0,25}}"
                               rf"\b(?:not allowed|are not|is not|isn'?t|aren'?t|banned|prohibited)\b", sl)
            if word in sl and r.platform is None and not banned:
                r.platform = value
                note("platform", s)

        # --- captions ---------------------------------------------------
        if re.search(r"\b(?:no|without|don'?t (?:add|use)|do not (?:add|use))\s+(?:captions|subtitles)\b", sl):
            r.captions = False
            note("captions", s)
        elif re.search(r"\b(?:captions|subtitles)\b.*\b(?:required|must|mandatory|needed)\b|"
                       r"\b(?:must|need to|required to)\b.*\b(?:captions|subtitles)\b", sl):
            r.captions = True
            note("captions", s)

        # --- music ------------------------------------------------------
        if re.search(r"\bno (?:background |copyrighted )?music\b|\b(?:don'?t|do not) (?:add|use) (?:any )?music\b", sl):
            r.music_allowed = False
            note("music", s)

        # --- swearing ---------------------------------------------------
        if re.search(r"\b(?:no|zero) (?:swearing|cursing|profanity|bad words|cuss words|explicit language)\b|"
                     r"\bfamily[- ]friendly\b|\bclean language\b|\bbrand[- ]safe\b", sl):
            r.profanity = "strict"
            note("profanity", s)
        elif re.search(r"\b(?:bleep|censor|mute)\b.*\b(?:swear|curse|profanit|bad words)", sl) and r.profanity is None:
            r.profanity = "standard"
            note("profanity", s)

        # --- logo -------------------------------------------------------
        if re.search(r"\b(?:keep|don'?t remove|do not remove|leave)\b.*\b(?:logo|watermark)\b", sl):
            r.source_logo = "keep"
            note("source_logo", s)
        elif re.search(r"\b(?:other|competing|competitor|third[- ]party)\b[^.]*\bwatermarks?\b", sl) \
                and not re.search(r"\b(?:remove|hide|blur)\b", sl):
            msg = "No other watermark or logo is ever added (only your campaign logo, if you set one)"
            if msg not in r.always:
                r.always.append(msg)
        elif re.search(r"\b(?:remove|hide|blur|no)\b.*\b(?:watermarks?|other logos?|channel logos?|third[- ]party logos?)\b",
                       sl):
            r.source_logo = "blur"
            note("source_logo", s)
        if re.search(r"\b(?:add|include|put|place|show)\b.*\b(?:our|brand|the brand'?s?|campaign)\s+logo\b", sl):
            r.notes.append("Add the brand logo: choose the logo file under LOGO > Add our logo.")

        # --- sponsor / ad segments: tool hamesha khud kaat deta hai ------
        if re.search(r"\b(?:no|without|do not|don'?t|never|avoid|must not)\b.*\b(?:sponsor\w*|ad reads?|ads|"
                     r"advertisements?|commercials?|promotions?)\b", sl) and "#ad" not in sl:
            msg = "Sponsor segments and ads inside the video are always cut out"
            if msg not in r.always:
                r.always.append(msg)

        # --- title rules (har campaign ke apne) ---------------------------
        _title_rules(r, s, sl, note)
        _video_rules(r, s, sl, note)
        _person_and_line(r, s, sl, note)

        # --- words to mute ---------------------------------------------
        m = re.search(r"\b(?:mute|bleep|beep|censor)\b\s+(?:out\s+)?(?:the\s+|any\s+)?(?:words?|names?|phrases?)?\s*"
                      r"(?:like|such as|:)?\s*(.+)", s, re.I)
        if m and not re.search(r"swear|curse|profanit|bad words", m.group(1), re.I):
            _add_targets(r, m.group(1), "mute", s)
        m = re.search(r"\b(?:do not|don'?t|never|avoid)\s+(?:say|use|saying|using)\s+(?:the\s+)?"
                      r"(?:words?|phrases?|terms?)\s*(?:like|such as|:)?\s*(.+)", s, re.I)
        if m:
            _add_targets(r, m.group(1), "mute", s)

        # --- topics never to mention -----------------------------------
        m = re.search(r"\b(?:do not|don'?t|never|no|avoid|must not)\s+(?:mention(?:ing)?|talk(?:ing)? about|"
                      r"referenc(?:e|ing)|discuss(?:ing)?|feature|featuring|show(?:ing)?|include clips? (?:of|about))\s+"
                      r"(.+)", s, re.I)
        if m:
            _add_targets(r, m.group(1), "avoid", s)

        # --- hashtags / post text / title -------------------------------
        m = re.search(r"disclos\w*[^:]{0,80}(?:word for word|verbatim|exactly|mandatory|required)[^:]{0,40}:\s*(.{20,})", s, re.I)
        if m and not r.post_text:
            r.post_text = m.group(1).strip()          # ye line har post ke caption mein (uploader copy kare)
            note("post_text", s)
        m = re.match(r"(?:post text|caption text|description|post caption|copy)\s*[:\-]\s*(.+)", s, re.I)
        if m:
            r.post_text = m.group(1).strip()
            note("post_text", s)
        m = re.match(r"title\s*[:\-]\s*(.+)", s, re.I)
        if m:
            r.title = m.group(1).strip()[:80]
            note("title", s)

    tags = re.findall(r"(?<![\w#])#[A-Za-z0-9_]{2,40}", text)
    disclosure_tags = {"#ad", "#sponsored", "#partner", "#paidpartnership", "#advertisement"}
    keep = [t for t in dict.fromkeys(tags) if t.lower() not in disclosure_tags]
    if keep:
        r.hashtags = " ".join(keep)
        r.evidence.setdefault("hashtags", " ".join(keep))
    # disclosure: (1) poori line (siyasi ad ki "paid for by ..." ya "copy this exactly" ke neeche wali line)
    # caption ke liye post text mein; (2) SCREEN par sirf tab jab rules saaf "on screen" kahein
    line = _disclosure_line(text)
    if line and not r.post_text:
        r.post_text = line
        r.evidence.setdefault("post_text", line[:200])
    # siyasi / brand ad ("paid for by ...") ya seedhi line "Videos are ads: yes": videos khud ad hain
    if re.search(r"^\s*(?:videos? are (?:the campaign'?s? own )?ads|own ads)\s*[:\-]\s*yes", lower, re.M) \
            or (line and re.search(r"paid for by", line, re.I)):
        r.own_ads = True
        r.evidence.setdefault("own_ads", "the videos are the campaign's own ads")
        r.always = [a for a in r.always if not a.startswith("Sponsor segments")]
    on_screen = re.search(r"\bon[- ]?screen\b|\bin the video\b|\bburn(?:ed|t)? in\b|\bvisible in the clip\b", lower) \
        and re.search(r"disclos|paid for by", lower)
    # (30 Oct) "Disclosures go in the caption, NOT on the screen": screen par patti nahi
    caption_only = re.search(r"\bnot (?:on|in) (?:the )?(?:screen|video)\b|disclosures? (?:must |should |will )?go(?:es)? "
                             r"in (?:the |your )?(?:post )?caption", lower)
    if caption_only:
        r.disclosure = False
        r.evidence.setdefault("disclosure", "the disclosure goes in the post caption, NOT on the screen")
    elif on_screen:
        found = [t for t in tags if t.lower() in disclosure_tags]
        r.disclosure = True
        r.disclosure_text = line or (found[0] if found else "Sponsored")
        r.evidence.setdefault("disclosure", "the rules ask for the disclosure ON SCREEN, word for word")
    elif re.search(r"#ad\b|#sponsored\b|paid partnership|\bdisclos(?:e|ure)\b|\bsponsored\b", lower):
        found = [t for t in tags if t.lower() in disclosure_tags]
        tag = found[0] if found else "#ad"
        msg = f"Ad disclosure goes in the post caption ({tag}): the uploader adds it"
        if msg not in r.notes and not line:
            r.notes.append(msg)
    if r.min_length and r.max_length and r.max_length <= r.min_length:
        r.max_length = r.min_length + 1
    # rules mein jitne log / shows / jagahen hain: spelling dictionary ke liye
    from app.transcribe.names import names_in_text
    def heading(line: str) -> bool:                   # "CLIPPER RULES - PROJECT 42" jaisi heading naam nahi
        letters = [c for c in line if c.isalpha()]
        return len(letters) >= 6 and sum(c.isupper() for c in letters) / len(letters) > 0.6
    r.names = [n for n in names_in_text("\n".join(ln for ln in text.splitlines() if not heading(ln)))
               if not re.search(r"\b(?:target|tier|rules?|campaign)\b", n, re.I)]
    return r


# ---------------------------------------------------------------------
#  Title rules: andaaz, siyasi lafz, emoji, zaroori naam, hashtags ki ginti
#  Do tarah samajhta hai:
#    * seedhi lines (hum khud likh kar dete hain):
#        Title style: clean | viral
#        Political words: allowed | not allowed
#        Emojis: allowed | not allowed
#        Titles must mention: Prop 42
#        Max hashtags: 3
#    * campaign ki apni zabaan: "no clickbait", "exaggerated hooks",
#      "no politically sensitive wording", "no emojis", "up to 3 hashtags" ...
# ---------------------------------------------------------------------
_NO = r"(?:no|not|never|avoid|don'?t|do not|must not|without|zero|❌)"
_ALLOWED = r"(?:allowed|ok|okay|fine|welcome|encouraged|yes)"


_YES = r"(yes|on|keep|allowed|true)"
_OFFV = r"(no|off|cover|hide|not allowed|false)"


def _video_rules(r: BriefResult, s: str, sl: str, note) -> None:
    """Disclosure ki jagah, purana disclosure, news ticker, topic guard, cold open / hook (seedhi lines ya aam zabaan)."""
    m = re.match(r"\s*(?:keep )?(?:old|original|existing) disclosure\s*[:\-]\s*" + "(?:" + _YES + "|" + _OFFV + ")", sl)
    if m:
        r.keep_old_disclosure = m.group(1) is not None
        note("keep_old_disclosure", s)
    m = re.match(r"\s*disclosure (?:position|place|placement)\s*[:\-]\s*(below(?: the)? video|top|bottom)", sl)
    if m:
        r.disclosure_place = {"top": "top", "bottom": "bottom"}.get(m.group(1), "below_video")
        note("disclosure_place", s)
    m = re.match(r"\s*(?:hide|blur) (?:the )?(?:news )?ticker\s*[:\-]\s*" + "(?:" + _YES + "|" + _OFFV + ")", sl)
    if m:
        r.hide_ticker = m.group(1) is not None
        note("hide_ticker", s)
    m = re.match(r"\s*protect (?:the )?topic\s*[:\-]\s*(.+)", s.strip(), re.I)
    if m and m.group(1).strip().lower() not in ("no", "off"):
        r.topic_guard, r.topic_terms = True, m.group(1).strip().rstrip(".")
        note("topic_guard", s)
    else:
        m = re.search(r"(?:can ?not|can't|must not|do not|don't|never) (?:show|portray|present|make) (.{2,40}?) "
                      r"(?:in|look) (?:a )?(?:negative|bad)", sl)
        if m or re.search(r"no (?:bad representation|negative framing)", sl):
            r.topic_guard = True
            if m and not r.topic_terms:
                name = re.sub(r"^(?:the|our)\s+", "", m.group(1).strip())
                name = re.sub(r"^pro\s+(\d+)$", r"Prop \1", name)          # "PRO 42" aksar Prop 42 ki ghalti
                if name not in ("it", "them", "this", "us"):
                    r.topic_terms = name.title() if name.islower() else name
            note("topic_guard", s)
    for key, attr in (("cold open", "cold_open_mode"), ("hook text", "hook_mode")):
        m = re.match(r"\s*" + key + r"\s*[:\-]\s*(auto|on|off|yes|no)", sl)
        if m:
            setattr(r, attr, {"yes": "on", "no": "off"}.get(m.group(1), m.group(1)))
            note(attr, s)


def _title_rules(r: BriefResult, s: str, sl: str, note) -> None:
    m = re.match(r"\s*title\s*style\s*[:\-]\s*(clean|viral)", sl)
    if m:
        r.title_style = m.group(1)
        note("title_style", s)
    elif re.search(r"click\s*-?\s*bait|exaggerat|over[- ]the[- ]top|rage\s*bait|hate\s*bait|sensational|"
                   r"misleading (?:title|hook|caption)|hype claims?", sl) and not re.search(_ALLOWED + r"\b", sl):
        r.title_style = "clean"                  # brief mein inka zikr = hamesha mana (koi campaign inhein nahi maangti)
        note("title_style", s)

    m = re.match(r"\s*political\s*(?:words?|wording|content)?\s*[:\-]\s*(not allowed|no|allowed|yes)", sl)
    if m:
        r.political_words = m.group(1) in ("allowed", "yes")
        note("political_words", s)
    elif re.search(r"politic", sl):
        if re.search(_NO + r"\b[^.]*politic|politic\w*[^.]*\b(?:not allowed|prohibited|banned|forbidden)", sl) \
                or re.search(r"politically sensitive", sl):
            r.political_words = False
            note("political_words", s)
        elif re.search(r"politic\w*[^.]*\b" + _ALLOWED + r"\b", sl):
            r.political_words = True
            note("political_words", s)

    m = re.match(r"\s*emojis?\s*(?:in titles?)?\s*[:\-]\s*(not allowed|no|allowed|yes)", sl)
    if m:
        r.title_emoji = "on" if m.group(1) in ("allowed", "yes") else "off"
        note("title_emoji", s)
    elif re.search(_NO + r"\s+emojis?\b|emojis?\b[^.]*\b(?:not allowed|prohibited)", sl):
        r.title_emoji = "off"
        note("title_emoji", s)

    m = re.match(r"\s*titles?\s*must\s*(?:mention|include|contain)\s*[:\-]?\s*(.+)", s, re.I)
    if m:
        r.title_must = m.group(1).strip().strip("\"'“”.")[:40]
        note("title_must", s)

    m = re.match(r"\s*max(?:imum)?\s*hashtags\s*[:\-]\s*(\d{1,2})", sl)
    n = None
    if m:
        n = int(m.group(1))
    else:
        m = re.search(r"(?:up to|max(?:imum)?(?: of)?|no more than|at most)\s*(\d{1,2})\s*(additional |more |extra )?hashtags", sl)
        if m:
            extra = len(re.findall(r"(?<![\w#])#[A-Za-z0-9_]{2,40}", s)) if m.group(2) else 0
            n = int(m.group(1)) + (1 if m.group(2) and not extra else 0)
    if n:
        r.max_hashtags = max(1, min(n, 10))
        note("max_hashtags", s)


# ---------------------------------------------------------------------
#  Main person, screen share aur campaign line (15 Nov 2026)
#    "Ami must be on screen for at least 50% of the clip"
#    "Clips featuring Ben Shapiro" / "Main person: Ami Horowitz"
#    'Show the text "Natural diamonds are forever" on screen'
#    "On-screen text: ..." / "Text overlay: ..."
# ---------------------------------------------------------------------
_NAME = r"([A-Z][a-zA-Z'\-]+(?:\s+[A-Z][a-zA-Z'\-]+){0,3})"
_QUOTED = r"[\"“”']([^\"“”']{3,90})[\"“”']"


def _person_and_line(r: BriefResult, s: str, sl: str, note) -> None:
    m = re.match(r"(?i:\s*main\s*(?:person|speaker|talent|creator)\s*[:\-]\s*)" + _NAME, s)
    if not m:
        m = re.search(_NAME + r"\s+(?:must|should|has to|needs to)\s+(?:be|appear)\s+"
                      r"(?:clearly\s+)?(?:on[- ]screen|visible|in (?:every|each|the) (?:clip|video|frame))", s)
    if not m:
        m = re.search(r"\b(?:clips?|videos?|content)\s+(?:of|featuring|starring|with)\s+" + _NAME, s)
    if m and r.main_person is None:
        name = m.group(1).strip()
        if name.lower() not in ("the", "every", "each", "clips", "your", "our", "this", "all"):
            r.main_person = name
            note("main_person", s)
    m = re.search(r"(?:at least|minimum(?: of)?|min\.?)\s*(\d{1,3})\s*%", sl)
    if m and re.search(r"screen|visible|appear|frame", sl):
        r.main_min_screen = max(5, min(95, int(m.group(1))))
        note("main_min_screen", s)
    m = re.search(r"(?:on[- ]?screen\s*(?:text|line|caption|message)|text\s*overlay|overlay\s*text|"
                  r"screen\s*text)\s*[:\-]\s*(.+)", s, re.I)
    text = None
    if m:
        q = re.search(_QUOTED, m.group(1))
        text = (q.group(1) if q else m.group(1)).strip().strip(".")
    else:
        m = re.search(r"\b(?:show|display|add|put|include|use|place|overlay)\b[^.]{0,40}?" + _QUOTED +
                      r"[^.]{0,30}?\bon[- ]?(?:the\s+)?screen", s, re.I)
        if m:
            text = m.group(1).strip()
    if text and r.screen_text is None and 3 <= len(text) <= 90:
        r.screen_text = text
        note("screen_text", s)
    m = re.search(r"\b(?i:mention)\s+" + _NAME + r"\s+in\s+(?:every|each|all)\s+(?:post|clip|video)s?", s)
    if m and not r.title_must:
        r.title_must = m.group(1).strip()[:40]          # har post mein naam: title mein + screen par
        note("title_must", s)
        full = m.group(1).strip()
        if r.main_person is None or full.lower().startswith(r.main_person.lower()):
            r.main_person = full                       # "Ami" se poora naam "Ami Horowitz" behtar
            note("main_person", s)
    m = re.search(r"(?:cannot|can't|do not|don't|never)\s+(?:show|portray|present)\s+" + _NAME +
                  r"\s+in\s+a\s+(?:negative|bad)", s, re.I)
    if m and r.main_person is None and m.group(1).lower() not in ("prop", "the"):
        r.main_person = m.group(1).strip().title() if m.group(1).isupper() else m.group(1).strip()
        note("main_person", s)
    if re.search(r"light (?:editing|edits?)|no heavy edit|no (?:ai|ai-style) effects", sl):
        r.light_edit = True
        note("light_edit", s)
    if re.search(r"no (?:black )?bars|no empty space|no letterbox", sl):
        r.no_bars = True
        note("no_bars", s)
    if re.search(r"no split(?:[- ]screen)? content|no split[- ]screen", sl):
        r.no_split = True
        note("no_split", s)
    m = re.search(r"\b(?:every|each|all)\s+titles?\s+(?:must|should|need to|has to|have to)\s+"
                  r"(?:mention|include|contain|have|say)\s+" + _QUOTED, s, re.I) or \
        re.search(r"\binclude\s+" + _QUOTED + r"\s+in\s+(?:every|each|all|the)\s+titles?", s, re.I)
    if m and not r.title_must:
        r.title_must = m.group(1).strip()[:40]
        note("title_must", s)


def _disclosure_line(text: str) -> str:
    """Rules mein di gayi disclosure ki poori line, bilkul jaisi likhi hai (koi harf nahi badalta)."""
    lines = [ln.strip() for ln in text.splitlines()]
    body = [ln for ln in lines if ln and not ln.startswith("```")]
    for ln in body:                                    # siyasi ad: "This post was paid for by ..."
        if re.search(r"\bpaid for by\b", ln, re.I) and len(ln) >= 40:
            m = re.search(r"this post was paid for by", ln, re.I) or re.search(r"paid for by", ln, re.I)
            return ln[m.start():].strip()
    for i, ln in enumerate(lines):                     # "COPY THIS EXACTLY:" / "word for word:" ke baad wali line
        if re.search(r"copy (?:this|it) exactly|word for word|verbatim|exactly like this", ln, re.I) and ln.rstrip().endswith(":"):
            for nxt in lines[i + 1:i + 6]:
                if nxt and not nxt.startswith(("```", "#", ">", "-", "*")) and len(nxt) >= 20:
                    return nxt
    return ""


def _add_targets(r: BriefResult, chunk: str, target: str, sentence: str) -> None:
    items = _items(chunk)
    added = False
    for item in items:
        low = item.lower()
        if any(g in low for g in GROUP_WORDS) and not any(ch.isupper() for ch in item[1:]):
            # "republican politicians", "competitor brands": names come from research
            if not any(g["phrase"].lower() == low for g in r.groups):
                r.groups.append({"phrase": item, "target": target})
            continue
        bucket = r.mute_words if target == "mute" else r.avoid_topics
        if low not in (x.lower() for x in bucket) and len(item) >= 2:
            bucket.append(item)
            added = True
    key = "mute_words" if target == "mute" else "avoid_topics"
    if added:
        r.evidence.setdefault(key, sentence[:200])


# ---------------------------------------------------------------------
#  Merging layers and applying to a campaign
# ---------------------------------------------------------------------
SCALARS = ("min_length", "max_length", "ratio", "platform", "captions", "profanity", "music_allowed",
           "source_logo", "disclosure", "disclosure_text", "hashtags", "post_text", "title",
           "title_style", "political_words", "title_emoji", "title_must", "max_hashtags", "own_ads",
           "keep_old_disclosure", "disclosure_place", "hide_ticker", "topic_guard", "topic_terms", "cold_open_mode",
           "hook_mode")


def merge(base: BriefResult, extra: BriefResult | None, extra_wins: bool = True) -> BriefResult:
    if extra is None:
        return base
    for name in SCALARS:
        value = getattr(extra, name)
        if value is not None and (extra_wins or getattr(base, name) is None):
            setattr(base, name, value)
    for name in ("mute_words", "avoid_topics", "notes", "names", "always"):
        have = getattr(base, name)
        for item in getattr(extra, name):
            if item.lower() not in (x.lower() for x in have):
                have.append(item)
    for g in extra.groups:
        if not any(x["phrase"].lower() == g["phrase"].lower() for x in base.groups):
            base.groups.append(g)
    for k, v in extra.evidence.items():
        base.evidence.setdefault(k, v)
    base.sources.update(extra.sources)
    base.engine.extend(e for e in extra.engine if e not in base.engine)
    return base


def clean(r: BriefResult) -> BriefResult:
    """Keep every value inside what the app supports (AI answers are never trusted blindly)."""
    from app.core.config import PLATFORMS, PROFANITY_LEVELS, RATIOS
    if r.min_length is not None:
        r.min_length = max(5, min(int(r.min_length), 600))
    if r.max_length is not None:
        r.max_length = max(6, min(int(r.max_length), 600))
    if r.min_length and r.max_length and r.max_length <= r.min_length:
        r.max_length = r.min_length + 1
    if r.ratio not in (None, *RATIOS):
        r.ratio = None
    if r.platform not in (None, *PLATFORMS):
        r.platform = None
    if r.profanity not in (None, *PROFANITY_LEVELS):
        r.profanity = None
    if r.source_logo not in (None, "keep", "blur"):
        r.source_logo = None
    if r.title_style not in (None, "viral", "clean"):
        r.title_style = None
    if r.title_emoji not in (None, "on", "off"):
        r.title_emoji = None
    if r.max_hashtags is not None:
        r.max_hashtags = max(1, min(int(r.max_hashtags), 10))
    if r.disclosure_place not in (None, "below_video", "top", "bottom"):
        r.disclosure_place = None
    for attr in ("cold_open_mode", "hook_mode"):
        if getattr(r, attr) not in (None, "auto", "on", "off"):
            setattr(r, attr, None)
    if r.topic_terms:
        r.topic_terms = r.topic_terms[:120]
    if r.main_person:
        r.main_person = r.main_person.strip()[:60] or None
    if r.screen_text:
        r.screen_text = r.screen_text.strip()[:90] or None
    r.mute_words = [w.strip()[:60] for w in r.mute_words if w and w.strip()][:MAX_NAMES]
    r.avoid_topics = [w.strip()[:60] for w in r.avoid_topics if w and w.strip()][:MAX_NAMES * 2]
    r.names = list(dict.fromkeys(re.sub(r"^(?:Mention|Include|Tag)\s+", "", n.strip())[:60]
                                 for n in r.names if n and n.strip() and len(n.split()) <= 5))[:MAX_NAMES]
    if r.hashtags:
        r.hashtags = " ".join(t for t in r.hashtags.split() if t.startswith("#"))[:300] or None
    return r


def apply(profile, r: BriefResult) -> list[tuple[str, str, str]]:
    """Write the brief into the campaign. Returns (setting, new value, reason) for the summary."""
    changes: list[tuple[str, str, str]] = []

    def put(attr: str, value, label: str, key: str) -> None:
        if value is None:
            return
        if getattr(profile, attr) == value:
            # brief ki maang pehle se poori: summary mein dikhao taake user ko pata ho ke ye bhi parha gaya
            r.confirmed.append((label, str(value), r.evidence.get(key, "")))
            return
        setattr(profile, attr, value)
        changes.append((label, str(value), r.evidence.get(key, "")))

    put("min_length", r.min_length, "Min length (s)", "length")
    put("max_length", r.max_length, "Max length (s)", "length")
    put("ratio", r.ratio, "Format", "ratio")
    put("platform", r.platform, "Platform", "platform")
    put("captions_enabled", r.captions, "Captions", "captions")
    put("profanity_level", r.profanity, "Swearing filter", "profanity")
    put("music_allowed", r.music_allowed, "Music allowed", "music")
    put("source_logo", r.source_logo, "Channel logo", "source_logo")
    put("disclosure_enabled", r.disclosure, "Disclosure", "disclosure")
    put("disclosure_text", r.disclosure_text, "Disclosure text", "disclosure")
    put("hashtags", r.hashtags, "Hashtags", "hashtags")
    put("delivery_note", r.post_text, "Post text", "post_text")
    put("title", r.title, "Title", "title")
    put("title_style", r.title_style, "Title style", "title_style")
    put("political_words", r.political_words, "Political words in titles", "political_words")
    put("title_emoji", r.title_emoji, "Emojis in titles", "title_emoji")
    put("title_must", r.title_must, "Every title mentions", "title_must")
    put("max_hashtags", r.max_hashtags, "Max hashtags", "max_hashtags")
    put("keep_old_disclosure", r.keep_old_disclosure, "Keep the video's own disclosure", "keep_old_disclosure")
    put("disclosure_place", r.disclosure_place, "Disclosure position", "disclosure_place")
    put("hide_ticker", r.hide_ticker, "Blur news ticker", "hide_ticker")
    put("topic_guard", r.topic_guard, "Topic protection guard", "topic_guard")
    put("topic_terms", r.topic_terms, "Topic names", "topic_guard")
    put("cold_open_mode", r.cold_open_mode, "Cold open", "cold_open_mode")
    put("hook_mode", r.hook_mode, "Hook text", "hook_mode")
    put("main_person_name", r.main_person, "Main person", "main_person")
    put("main_person_min_screen", r.main_min_screen, "Main person on screen (%)", "main_min_screen")
    put("super_link", r.screen_text, "Campaign line on screen", "screen_text")
    put("light_edit", r.light_edit, "Light editing only", "light_edit")
    if r.no_bars and (profile.whole_picture or not profile.fill_screen):
        profile.whole_picture, profile.fill_screen = False, True
        changes.append(("Screen always full (no bars)", "On", r.evidence.get("no_bars", "")))
    if r.no_split and profile.stack_layout and profile.fill_screen:
        profile.stack_layout = False
        changes.append(("No split screen (one picture)", "On", r.evidence.get("no_split", "")))
    if r.own_ads is not None:
        # switch "Cut sponsor / ad parts": Off jab videos campaign ke apne ads hon
        if profile.own_ads != r.own_ads:
            profile.own_ads = r.own_ads
            changes.append(("Cut sponsor / ad parts", "Off" if r.own_ads else "On", r.evidence.get("own_ads", "")))
    if r.names:
        # rules mein aaye naam: campaign ki spelling list mein (speech model + fixes)
        merged = list(dict.fromkeys([*getattr(profile, "names", []), *r.names]))
        if merged != profile.names:
            profile.names = merged
            changes.append(("Names (spelling)", ", ".join(r.names[:12]) + (" ..." if len(r.names) > 12 else ""), ""))
    if r.mute_words:
        merged = list(dict.fromkeys([*profile.banned_words, *r.mute_words]))
        if merged != profile.banned_words:
            profile.banned_words = merged
            changes.append(("Words to mute", ", ".join(r.mute_words), r.evidence.get("mute_words", "")))
    if r.avoid_topics:
        merged = list(dict.fromkeys([*profile.banned_topics, *r.avoid_topics]))
        if merged != profile.banned_topics:
            profile.banned_topics = merged
            changes.append(("Never mention (clip skipped)", ", ".join(r.avoid_topics),
                            r.evidence.get("avoid_topics", "")))
    return changes


def _shown(value: str) -> str:
    return {"True": "On", "False": "Off"}.get(value, value)


def summary_text(r: BriefResult, changes: list[tuple[str, str, str]]) -> str:
    lines = [f"Read with: {', '.join(r.engine)}", ""]
    if changes:
        lines.append("SET IN THIS CAMPAIGN")
        for label, value, why in changes:
            lines.append(f"  {label}: {_shown(value)}")
            if why:
                lines.append(f"      from the brief: “{why}”")
    elif not r.confirmed:
        lines.append("Nothing new to set from this brief.")
    if r.confirmed:
        lines += ["", "ALREADY RIGHT IN THIS CAMPAIGN (the brief asks for it)"]
        for label, value, why in r.confirmed:
            lines.append(f"  {label}: {_shown(value)}")
            if why:
                lines.append(f"      from the brief: “{why}”")
    if r.always:
        lines += ["", "THE TOOL ALWAYS DOES THIS"]
        lines += [f"  {a}" for a in r.always]
    if r.sources:
        lines += ["", "NAMES FOUND BY RESEARCH (please check)"]
        for group, src in r.sources.items():
            lines.append(f"  {group}: {src}")
    open_groups = [g["phrase"] for g in r.groups if g["phrase"] not in r.sources]
    if open_groups:
        lines += ["", "COULD NOT LOOK UP (add the names yourself if needed)"]
        lines += [f"  {g}" for g in open_groups]
    if r.notes:
        lines += ["", "NOTES (the app cannot do these by itself)"]
        lines += [f"  {n}" for n in r.notes]
    return "\n".join(lines)


# ---------------------------------------------------------------------
#  "The tool understood": brief ke neeche chhote tags (Campaign page)
#  Kaam: user ek nazar mein dekh le ke brief se kya kya samjha gaya.
# ---------------------------------------------------------------------
def understood_tags(profile) -> list[tuple[str, str]]:
    """(tag text, setting key) for what the campaign now follows. Built from the saved campaign."""
    p = profile
    tags: list[tuple[str, str]] = []
    if p.min_length or p.max_length:
        lo, hi = p.min_length, p.max_length
        tags.append((f"Length {lo} to {hi} s" if lo and hi else (f"Min {lo} s" if lo else f"Max {hi} s"), "length"))
    if p.main_person_name:
        tags.append((f"Main person: {p.main_person_name}", "main_person"))
        if p.main_person_min_screen:
            tags.append((f"On screen {p.main_person_min_screen}%+", "main_person"))
    if p.title_must:
        tags.append((f"Titles say: {p.title_must}", "title_must"))
    if p.super_link:
        tags.append((f"Line: {p.super_link}", "screen_text"))
    for tag in (p.hashtags or "").split()[:4]:
        tags.append((tag, "hashtags"))
    if p.banned_topics:
        tags.append(("Avoid: " + ", ".join(p.banned_topics[:3]) + (" ..." if len(p.banned_topics) > 3 else ""),
                     "avoid"))
    if p.title_banned_words:
        tags.append((f"{len(p.title_banned_words)} words never in titles", "title_banned"))
    if p.ratio:
        tags.append((p.ratio, "ratio"))
    if p.source_logo == "blur":
        tags.append(("Hide other logos", "source_logo"))
    if getattr(p, "fill_screen", False) and not getattr(p, "whole_picture", False):
        tags.append(("No black bars", "layout"))
    if getattr(p, "fill_screen", False) and not getattr(p, "stack_layout", True):
        tags.append(("No split screen", "layout"))
    if getattr(p, "light_edit", False):
        tags.append(("Light editing", "layout"))
    if getattr(p, "strict_edits", False):
        tags.append(("Meaning never changed", "layout"))
    if getattr(p, "protect_main_person", False) and p.main_person_name:
        tags.append((f"{p.main_person_name} protected", "main_person"))
    if getattr(p, "title_style", "") == "clean":
        tags.append(("Clean titles, no clickbait", "title_style"))
    if getattr(p, "political_words", True) is False:
        tags.append(("No political words in titles", "political_words"))
    if p.disclosure_enabled:
        tags.append((f"Disclosure: {p.disclosure_text}", "disclosure"))
    if p.delivery_note:
        tags.append(("Post text saved", "post_text"))
    if p.profanity_level == "strict":
        tags.append(("Swearing beeped", "profanity"))
    return tags
