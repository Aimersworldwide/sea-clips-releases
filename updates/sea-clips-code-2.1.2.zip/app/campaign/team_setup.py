"""
=====================================================================
  CAMPAIGN / TEAM SETUP              (20 Nov 2026)
  Kaam: malik ke tool (A) ke chune hue campaigns ek dafa dost ke tool
  (B) mein: campaign settings + main person photos, wohi link sheets,
  Drive ke Clip Pool folders, Google key file aur editing settings.
  Ye ek private file hai ("SEA CLIPS Team Setup.seaclips"), WhatsApp se
  jati hai; GitHub par kabhi nahi (wahan sirf code).
  Kabhi nahi jata: folders ke raste, Gmail ka login (har tool khud
  login karta hai), cookies, API keys, license, clip history, queue.
=====================================================================
"""
from __future__ import annotations

import base64
import json
from datetime import datetime
from pathlib import Path

from app.core.logging_setup import get_logger
from app.core.paths import app_data_dir

log = get_logger("team_setup")

KIND = "sea-clips-team-setup"
FILE_NAME = "SEA CLIPS Team Setup.seaclips"
TEAM_CAMPAIGNS = ("Political of USA", "Debate")

# editing ki settings jo dost ka tool bhi wohi rakhe (raste, hardware, accounts aur keys kabhi nahi)
SHARED_SETTINGS = (
    "min_length", "max_length", "hook_titles", "zoom_effects", "reaction_shots", "better_moments",
    "sound_effects", "youtube_hq", "clip_count", "clips_per_minute", "cold_open", "name_card", "title_cards",
    "titles_enabled", "hashtags_enabled", "upload_names", "preview_pack", "ratio", "platform", "block_size",
    "captions_enabled", "default_caption_style", "rotate_caption_styles", "silence_level",
    "color_looks_enabled", "emphasis_zoom", "progress_bar", "sharpen", "sensitive_blur", "loudness_normalize",
    "beep_mode", "max_beeps_per_clip", "profanity_level", "general_banned_words", "vip_names",
    "names_dictionary", "auto_delete_source", "research_online", "auto_person_photos", "drive_upload",
    "drive_batch",
)
PHOTO_KEYS = ("main_person_photos", "main_person_auto_photos")


class TeamSetupError(RuntimeError):
    pass


# ---------------------------------------------------------------------
#  Banana (malik ki taraf)
# ---------------------------------------------------------------------
def _pack_photo(path: str, photos: dict) -> str:
    p = Path(path)
    if not p.is_file():
        return ""
    key = f"{len(photos):03d}_{p.name}"
    photos[key] = base64.b64encode(p.read_bytes()).decode("ascii")
    return key


def build(profiles: list[dict], settings: dict, sources: list[dict], client_json: str,
          device: str = "B") -> dict:
    """profiles: campaign dicts (to_dict); settings: AppSettings ka dict; sources: link_sources entries."""
    names = {p.get("name") for p in profiles}
    photos: dict[str, str] = {}
    camps = []
    for p in profiles:
        p = json.loads(json.dumps(p))                     # apni copy
        for k in PHOTO_KEYS:
            p[k] = [x for x in (_pack_photo(f, photos) for f in p.get(k) or []) if x]
        for item in p.get("more_people") or []:
            if isinstance(item, dict):
                for k in ("photos", "auto_photos"):
                    item[k] = [x for x in (_pack_photo(f, photos) for f in item.get(k) or []) if x]
        camps.append(p)
    srcs = []
    for s in sources:
        if s.get("campaign") in names:
            srcs.append({k: s[k] for k in ("campaign", "channel", "years", "min_seconds", "sheet_id", "sheet_url",
                                           "pending_gid", "used_gid", "last_scan") if k in s})
    folders = {k: v for k, v in (settings.get("drive_folders") or {}).items() if k in names}
    shared = {k: settings[k] for k in SHARED_SETTINGS if k in settings}
    return {"kind": KIND, "version": 1, "made": datetime.now().isoformat(timespec="seconds"),
            "device_code": device, "campaigns": camps, "photos": photos, "link_sources": srcs,
            "drive_folders": folders, "settings": shared, "drive_client": client_json or ""}


def write(data: dict, path: Path) -> Path:
    path = Path(path)
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return path


# ---------------------------------------------------------------------
#  Lagana (dost ki taraf): ek dafa
# ---------------------------------------------------------------------
def read(path: Path) -> dict:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise TeamSetupError(f"This file could not be read ({exc}).") from exc
    if not isinstance(data, dict) or data.get("kind") != KIND:
        raise TeamSetupError("This is not a SEA CLIPS Team Setup file.")
    return data


def apply(data: dict, db, settings) -> list[str]:
    """Campaigns, sheets, Drive folders, key file aur settings is tool mein. Returns kya kya laga (UI ke liye)."""
    from app.campaign import link_sheets as ls
    from app.core.config import CampaignProfile
    done: list[str] = []
    folder = app_data_dir() / "people" / "team"
    folder.mkdir(parents=True, exist_ok=True)
    saved: dict[str, str] = {}
    for key, b64 in (data.get("photos") or {}).items():
        safe = "".join(ch for ch in key if ch.isalnum() or ch in "._-")[:120] or "photo.jpg"
        out = folder / safe
        out.write_bytes(base64.b64decode(b64))
        saved[key] = str(out)

    def fix(lst):
        return [saved[k] for k in lst or [] if k in saved]

    for raw in data.get("campaigns") or []:
        p = dict(raw)
        for k in PHOTO_KEYS:
            p[k] = fix(p.get(k))
        for item in p.get("more_people") or []:
            if isinstance(item, dict):
                item["photos"], item["auto_photos"] = fix(item.get("photos")), fix(item.get("auto_photos"))
        prof = CampaignProfile.from_dict(p)
        cid = db.find_campaign(prof.name, include_hidden=True)
        if cid:
            db.update_campaign(cid, prof)
        else:
            db.create_campaign(prof)
        done.append(f"Campaign: {prof.name}")
    for s in data.get("link_sources") or []:
        camp = s.get("campaign")
        if camp:
            ls.update_source(camp, **{k: v for k, v in s.items() if k != "campaign"})
            done.append(f"Link sheet: {camp}")
    for k, v in (data.get("settings") or {}).items():
        if hasattr(settings, k):
            setattr(settings, k, v)
    folders = dict(settings.drive_folders or {})
    folders.update(data.get("drive_folders") or {})
    settings.drive_folders = folders
    if data.get("drive_folders"):
        done.append("Drive Clip Pool folders: " + ", ".join(sorted(data["drive_folders"])))
    settings.device_code = (data.get("device_code") or "B").strip().upper()[:3] or "B"
    done.append(f"This tool is Tool {settings.device_code} (clips named ..._{settings.device_code}_001)")
    if data.get("drive_client"):
        from app.drive import client as dc
        tmp = app_data_dir() / "team_key.tmp.json"
        tmp.write_text(data["drive_client"], encoding="utf-8")
        try:
            dc.save_client(tmp)
            done.append("Google key file added")
        finally:
            tmp.unlink(missing_ok=True)
    log.info("Team setup applied: %s", "; ".join(done))
    return done
