"""
=====================================================================
  RESEARCH / MATCH  (viral shorts se milana: moments, titles, hashtags)
  Kaam:
    * ViralScorer   : har moment ko viral shorts ki baat se milao; jo
                      asal mein viral hui baat jaisa ho us ko +8 tak.
    * TitleEngine   : viral titles ke "saanche" ({N} = main person)
                      is clip ki baat se bharo. Saancha tabhi jab us
                      ke saare asal lafz clip mein hon (jhoota title kabhi
                      nahi), phir jo clip se sab se zyada mile + zyada
                      views wala ho woh.
    * hashtags      : milti hui viral shorts ke hashtags (doosre logon
                      ke naam wale nahi), naam aur topic ke sath.
  Matching model (embed.py) na ho to seedhe lafzon ka milan (thora kam).
=====================================================================
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from app.core.logging_setup import get_logger
from app.edit.titles import TOPICS
from app.research.viral import ViralItem

log = get_logger("match")

# ---------------------------------------------------------------------
#  Lafz jo "asal baat" nahi (title ka andaaz): in ka clip mein hona zaroori nahi
# ---------------------------------------------------------------------
STOP = set("""a an the of on in to for and or at by with from as is are was were be been being it its it's this that
these those there here then than so too very just only even also not no yes do does did done doing have has had
having will would can could should shall may might must i you he she we they me him her us them my your his our
their mine yours what who whom whose which when where why how all any some every each more most much many own
same such into over under again once out up down off about after before while if because until against between
through during above below both few other nor s t don't didn't doesn't isn't aren't wasn't weren't won't can't
couldn't shouldn't wouldn't he's she's they're we're you're i'm that's what's here's there's let's""".split())
HYPE = set("""point argument logic sense moment moments clip clips video watch wait see listen hear heard said says
say saying told tell talk talks talking best perfect perfectly real really truth true actually literally finally
simply simple easy instantly completely totally insane wild crazy epic legendary iconic brutal hits hit different
better good great amazing must need needs nobody anyone everyone everything nothing time times others won't
else""".split())
POWER = {"destroys", "destroyed", "destroy", "shuts", "shut", "silences", "silenced", "schools", "schooled",
         "dismantles", "dismantled", "exposes", "exposed", "owns", "owned", "debunks", "debunked", "flips",
         "obliterates", "wrecks", "humbles", "humbled", "corrects", "corrected", "shocks", "challenges", "fact"}
QA_WORDS = {"answer", "answers", "response", "responses", "reply", "question", "questions", "ready", "expect",
            "expected", "expecting", "asked", "asks", "ask", "debate", "debates", "debated", "debating", "vs"}
VISUAL = {"reaction", "reactions", "face", "faces", "expression", "smirk", "smiled", "smile", "look", "looks",
          "looked", "eyes", "throw", "throws", "dance", "dancing", "football", "height", "tall", "short", "wearing",
          "hidden", "talent", "sign", "baby", "wife", "husband", "dog", "dies", "died", "death", "dead", "kill",
          "killed", "shot", "d*ed", "make", "makes", "worth", "salary", "pay", "paid", "rich", "net", "age", "old",
          "secret", "hidden", "real", "actually", "finally", "moments", "compilation", "part",
          # saboot / ilzaam ka daawa: clip ki baat se saabit nahi (aur campaign mein reject ka khatra)
          "receipt", "receipts", "proof", "proves", "proved", "evidence", "exposed", "exposes", "expose",
          "caught", "lied", "lies", "lying", "liar"}
FEMALE = {"she", "her", "hers", "herself", "girl", "woman", "lady", "mom", "mother", "wife", "daughter", "sister"}
MALE = {"he", "him", "his", "himself", "guy", "man", "bro", "dad", "father", "husband", "son", "brother"}

EMOJI_KIND = {"😳": "shock", "🔥": "fire", "😂": "laugh", "🤣": "laugh", "😭": "cry", "🤯": "mindblown",
              "👀": "eyes", "🤔": "think", "💀": "skull", "❤": "heart", "🥹": "heart", "👏": "clap", "💯": "hundred",
              "😮": "wow", "😯": "wow", "🤦": "facepalm", "🇺": "usa", "🏈": "fire", "💍": "heart"}
EMOJI_RE = re.compile("[\U0001F000-\U0001FAFF☀-➿️‍\U0001F1E6-\U0001F1FF]+")
TAG_RE = re.compile(r"#\w+")
BROAD_TAGS = {"#debate", "#debates", "#politics", "#political", "#shorts", "#viral", "#trending", "#fyp",
              "#foryou", "#podcast", "#news", "#interview", "#comedy", "#funny"}
GENERIC_TAGS = {"#debate", "#debates", "#politics", "#political", "#shorts", "#viral", "#trending", "#fyp",
                "#foryou", "#podcast", "#news", "#interview", "#christian", "#christianity", "#faith", "#god",
                "#jesus", "#america", "#usa", "#conservative", "#liberal", "#college", "#students", "#comedy",
                "#funny", "#motivation", "#truth", "#freespeech", "#election", "#economy", "#history"}
WORD_RE = re.compile(r"[a-z][a-z']*")


def _words(text: str) -> list[str]:
    return WORD_RE.findall(text.lower().replace("’", "'"))


def _stem(w: str) -> str:
    if w.endswith("'s"):
        w = w[:-2]
    return w.rstrip("'")[:5]


@dataclass
class Template:
    text: str             # "{N} SILENCES a Socialist Student with ONE Simple Question" (emoji / hashtag ke baghair)
    emoji: str            # hamari emoji tasveer ka naam (shock, fire ...) ya ""
    weight: float         # views ka wazan 0..1
    content: tuple        # asal lafz (stem) jo clip mein hone chahiyen
    female: bool
    male: bool
    has_name: bool
    hashtags: tuple
    qa: bool              # sawal / jawab / debate ka daawa: sirf sawal-jawab wale clip pe
    numbers: tuple        # title ke number (clip mein bhi hon)
    builtin: bool         # built-in library (doosre channels): hashtags sirf aam wale


def templatize(item: ViralItem) -> Template | None:
    title = item.title.replace("’", "'").strip()
    kinds = [EMOJI_KIND.get(ch[0]) for ch in EMOJI_RE.findall(title)]
    emoji = next((k for k in kinds if k), "")
    title = TAG_RE.sub("", EMOJI_RE.sub("", title))
    title = re.sub(r"\s+", " ", title).strip(" -|:")
    if len(title) < 8 or len(title) > 90:
        return None
    for name in sorted(item.subject or [], key=len, reverse=True):
        title = re.sub(rf"\b{re.escape(name)}\b", "{N}", title, flags=re.I)
    has_name = "{N}" in title
    ws = _words(title.replace("{N}", " "))
    low = set(ws)
    if low & VISUAL:
        return None                       # dikhne wali baat (chehra, qad, kapre): clip ki baat se saabit nahi
    content = tuple(dict.fromkeys(_stem(w) for w in ws if w not in STOP and w not in HYPE and w not in QA_WORDS
                                  and w not in POWER and len(w) > 2))
    numbers = tuple(re.findall(r"\d+", title))
    return Template(title, emoji, item.weight, content, bool(low & FEMALE), bool(low & MALE), has_name,
                    tuple(item.hashtags), bool(low & (QA_WORDS | POWER)), numbers, bool(getattr(item, "builtin", False)))


def fits(t: Template, clip_words: set[str], clip_stems: set[str], has_name: bool, qa: bool = False,
         clip_text: str = "") -> bool:
    """Saancha is clip pe sach hai? (asal lafz clip mein, naam ho to naam wala, she/he ka khayal)"""
    if t.has_name and not has_name:
        return False
    if not t.has_name:
        # naam nahi to main topic zaroor (user ka qaida): "Is Trump a Great President?" haan, "Wait For It" nahi
        low = t.text.lower()
        if not any(any(k in low for k in keys) and any(k in clip_text.lower() for k in keys)
                   for keys, _, _ in TOPICS):
            return False
    if t.qa and not qa:
        return False                      # "jawab / sawal / debate" ka daawa sirf sawal-jawab wale clip pe
    if any(n not in clip_text for n in t.numbers):
        return False
    if any(c not in clip_stems for c in t.content):
        return False
    if t.female and not (clip_words & {"she", "her", "hers"}):
        return False
    if t.male and not t.has_name and (clip_words & {"she", "her"}) and not (clip_words & {"he", "his", "him"}):
        return False
    return True


# ---------------------------------------------------------------------
#  Title engine
# ---------------------------------------------------------------------
SAME_TITLE = 0.86        # do titles itne milte hon (matlab mein) to ek jaise


class TitleEngine:
    def __init__(self, items: list[ViralItem], name: str, embedder=None):
        self.name = name.strip()
        self.emb = embedder
        seen, temps = set(), []
        for it in items:
            t = templatize(it)
            if t is None or t.text.lower() in seen:
                continue
            seen.add(t.text.lower())
            temps.append(t)
        self.temps = temps
        self.filled = [self.fill(t) for t in temps]
        self.vecs = None
        self.used_vecs: list = []                 # is run ke titles (milte julte titles dobara nahi)
        if self.emb is not None and temps:
            try:
                self.vecs = self.emb.encode(self.filled)
            except Exception as exc:  # noqa: BLE001
                log.warning("Title matching without the model: %s", exc)
                self.vecs = None
        log.info("Title engine: %d viral title shapes", len(temps))

    def fill(self, t: Template) -> str:
        text = t.text.replace("{N}", self.name or "He")
        return re.sub(r"\s+", " ", text).strip()

    def best(self, clip_text: str, avoid: set[str], seed: int = 0, qa: bool = False) -> tuple[str, str] | None:
        """(title, emoji) sab se mauzoon viral saanche se, ya None."""
        if not self.temps:
            return None
        words = set(_words(clip_text))
        stems = {_stem(w) for w in words}
        has_name = bool(self.name)
        if self.vecs is not None:
            import numpy as np
            cv = self.emb.encode([clip_text[:1500]])[0]
            sims = self.vecs @ cv
            order = np.argsort(-sims)[:400]
            cand = [(float(sims[i]), i) for i in order]
        else:
            cand = []
            for i, t in enumerate(self.temps):
                overlap = len(set(t.content) & stems) / (len(t.content) + 2)
                cand.append((overlap, i))
            cand.sort(reverse=True)
            cand = cand[:400]
        scored = []
        for sim, i in cand:
            t = self.temps[i]
            if not fits(t, words, stems, has_name, qa, clip_text):
                continue
            title = self.filled[i]
            if len(title) > 75 or title.lower() in avoid:
                continue
            score = 0.55 * sim + 0.30 * t.weight + (0.15 if t.has_name else 0.0) + 0.05 * min(len(t.content), 3)
            scored.append((score, i, title))
        if not scored:
            return None
        scored.sort(reverse=True)
        if self.vecs is not None and self.used_vecs:
            import numpy as np
            used = np.stack(self.used_vecs)
            # milta julta title (sirf "wasn't" / "was NOT" ka farq) dobara nahi: dusra saancha lo
            fresh = [x for x in scored if float(np.max(used @ self.vecs[x[1]])) < SAME_TITLE]
            scored = fresh or scored
        top = scored[:5]                                  # pehle 5 mein se seed se (har clip alag)
        _, i, title = top[seed % len(top)]
        if self.vecs is not None:
            self.used_vecs.append(self.vecs[i])
        return title, self.temps[i].emoji

    def hashtags(self, clip_text: str, own: list[str], k: int = 12) -> list[str]:
        """Milti hui viral shorts ke hashtags (doosre logon ke naam wale nahi)."""
        if not self.temps:
            return []
        clip_low = clip_text.lower().replace(" ", "")
        if self.vecs is not None:
            import numpy as np
            cv = self.emb.encode([clip_text[:1500]])[0]
            idx = list(np.argsort(-(self.vecs @ cv))[:60])
        else:
            idx = list(range(min(60, len(self.temps))))
        count: dict[str, float] = {}
        for i in idx:
            for tag in self.temps[i].hashtags:
                count[tag] = count.get(tag, 0.0) + self.temps[i].weight
        bad = {w.lower() for w in own}
        builtin_tags = {tag for i in idx if self.temps[i].builtin for tag in self.temps[i].hashtags}
        seen_in = {}
        for t in self.temps:
            if not t.builtin:
                for tag in t.hashtags:
                    seen_in[tag] = seen_in.get(tag, 0) + 1
        out = []
        for tag, _ in sorted(count.items(), key=lambda kv: -kv[1]):
            if any(b and b in tag for b in bad):
                continue
            if tag in builtin_tags and tag not in GENERIC_TAGS:
                continue                  # doosre channels ke logon / tanzeemon ke naam wale tags nahi
            if (tag in builtin_tags or tag in GENERIC_TAGS) and tag not in BROAD_TAGS \
                    and tag[1:] not in clip_low and tag[1:].rstrip("s") not in clip_low:
                continue                  # topic wala tag (#christian, #election) tabhi jab clip mein wo baat ho
            if tag not in GENERIC_TAGS and tag not in builtin_tags and seen_in.get(tag, 0) < 3:
                continue                  # is person ki research mein kam se kam 3 shorts pe ho
            out.append(tag)
            if len(out) >= k:
                break
        return out


# ---------------------------------------------------------------------
#  Moments: viral baat jaisa moment +8 tak
# ---------------------------------------------------------------------
VIRAL_MAX = 8
VIRAL_FLOOR = 0.55        # is se kam milan = koi bonus nahi
VIRAL_SPAN = 0.25         # floor + span pe poora bonus


class ViralScorer:
    def __init__(self, items: list[ViralItem], sentences: list[str], embedder):
        import numpy as np
        texts = [it for it in items if len(it.text) > 60]
        self.ok = embedder is not None and len(texts) >= 10 and bool(sentences)
        if not self.ok:
            return
        self.items = texts
        self.mat = embedder.encode([it.text[:1500] for it in texts])
        self.w = np.array([0.6 + 0.4 * it.weight for it in texts], dtype=np.float32)
        self.sent = embedder.encode([s[:600] or " " for s in sentences])

    def bonus(self, s_first: int, s_last: int) -> tuple[int, str]:
        if not self.ok:
            return 0, ""
        import numpy as np
        v = self.sent[s_first:s_last + 1].mean(axis=0)
        v = v / max(float(np.linalg.norm(v)), 1e-9)
        sims = (self.mat @ v) * self.w
        k = int(np.argmax(sims))
        s = float(sims[k])
        pts = int(round(VIRAL_MAX * max(0.0, min(1.0, (s - VIRAL_FLOOR) / VIRAL_SPAN))))
        if pts <= 0:
            return 0, ""
        views = self.items[k].views
        return pts, f"like a viral short ({views / 1e6:.1f}M views)" if views >= 1e6 else \
            f"like a viral short ({views // 1000}K views)"
