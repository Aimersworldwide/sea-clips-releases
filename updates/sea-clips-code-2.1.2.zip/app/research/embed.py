"""
=====================================================================
  RESEARCH / EMBED  (matching model, sirf is laptop pe)
  Kaam: do baatein kitni milti hain (0..1), BGE base English model se
  (MIT licence, ONNX, ~110 MB, assets/models/bge-base). Ye kuch likhta
  nahi, sirf "matlab" ko number mein badalta hai. Internet ya Google ko
  kuch nahi jata. CPU pe tez (ek jumla ~10 ms), GPU zaroori nahi.
  Model na mile to None: phir tool ke purane qaide chalte hain.
=====================================================================
"""
from __future__ import annotations

import threading
from functools import lru_cache

from app.core.logging_setup import get_logger
from app.core.paths import resource

log = get_logger("embed")

MODEL_DIR = resource("assets", "models", "bge-base")
MAX_TOKENS = 256
BATCH = 16


class Embedder:
    def __init__(self):
        import onnxruntime as ort
        from tokenizers import Tokenizer
        self.tok = Tokenizer.from_file(str(MODEL_DIR / "tokenizer.json"))
        self.tok.enable_truncation(MAX_TOKENS)
        self.tok.enable_padding()
        opts = ort.SessionOptions()
        opts.intra_op_num_threads = 2                 # rendering ke sath chale, CPU na ghere
        opts.log_severity_level = 3
        self.sess = ort.InferenceSession(str(MODEL_DIR / "model_quantized.onnx"), opts,
                                         providers=["CPUExecutionProvider"])
        self.inputs = {i.name for i in self.sess.get_inputs()}
        self.lock = threading.Lock()
        self.cache: dict[str, object] = {}

    def encode(self, texts: list[str]):
        """Har text ka unit vector (numpy, N x 768). Wahi text dobara aaye to yaad se."""
        import numpy as np
        out = [None] * len(texts)
        todo = [i for i, t in enumerate(texts) if t not in self.cache]
        for k in range(0, len(todo), BATCH):
            chunk = [texts[i] for i in todo[k:k + BATCH]]
            enc = self.tok.encode_batch([c or " " for c in chunk])
            ids = np.array([e.ids for e in enc], dtype=np.int64)
            mask = np.array([e.attention_mask for e in enc], dtype=np.int64)
            feed = {"input_ids": ids, "attention_mask": mask}
            if "token_type_ids" in self.inputs:
                feed["token_type_ids"] = np.zeros_like(ids)
            with self.lock:
                hidden = self.sess.run(None, feed)[0]
            vec = hidden[:, 0]                          # BGE: CLS token
            vec = vec / np.maximum(np.linalg.norm(vec, axis=1, keepdims=True), 1e-9)
            for j, i in enumerate(todo[k:k + BATCH]):
                self.cache[texts[i]] = vec[j].astype(np.float32)
        for i, t in enumerate(texts):
            out[i] = self.cache[t]
        return np.stack(out) if out else np.zeros((0, 768), dtype=np.float32)


@lru_cache(maxsize=1)
def embedder() -> Embedder | None:
    """Ek hi model poore app mein. Na mile / na chale to None (qaide chalte hain)."""
    if not (MODEL_DIR / "model_quantized.onnx").is_file() or not (MODEL_DIR / "tokenizer.json").is_file():
        log.info("Research model not found (%s); built-in rules are used", MODEL_DIR)
        return None
    try:
        return Embedder()
    except Exception as exc:  # noqa: BLE001 - kabhi run na roke
        log.warning("Research model could not start: %s", exc)
        return None
