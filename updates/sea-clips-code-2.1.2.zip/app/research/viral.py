"""
=====================================================================
  RESEARCH / VIRAL  (viral shorts se seekhna, bina Gemini)
  Kaam: campaign ke main person (ya video ke topic) ki YouTube pe sab
  se zyada chalne wali shorts dhoondna aur un se seekhna:
    * titles (kis andaaz ke title lakhon views le rahe hain)
    * hashtags (wahi jo un shorts pe lage the)
    * un ki baat (YouTube ki apni captions, video download nahi hoti)
  Har person ki research ek dafa, phir 7 din tak yaad (AppData/research).
  Internet na ho / YouTube roke: jo pehle se yaad hai + built-in library
  (assets/research/builtin.json: bade debate channels ke 1700+ titles).
  Kuch bhi bahar NAHI bheja jata: sirf YouTube pe naam search hota hai,
  jaise koi browser mein search kare.
=====================================================================
"""
from __future__ import annotations

import json
import math
import re
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

from app.core.logging_setup import get_logger
from app.core.paths import app_data_dir, resource

log = get_logger("viral")

REFRESH_DAYS = 7          # research kitne din baad taaza
SEARCH_N = 300            # YouTube search se kitni videos ki list
DETAIL_N = 120            # sab se zyada views wali kitni ki poori details (hashtags, captions)
MAX_SHORT_SEC = 180       # is se lambi video short nahi
BUILTIN = resource("assets", "research", "builtin.json")


@dataclass
class ViralItem:
    title: str
    views: int
    hashtags: list[str] = field(default_factory=list)
    text: str = ""                       # short ki baat (captions), na mile to ""
    subject: list[str] = field(default_factory=list)   # is item ke main person ke naam (title mein {N} banane ke liye)
    builtin: bool = False                # built-in library ka (doosre channels) ya is person ki apni research

    @property
    def weight(self) -> float:
        """Views ka wazan 0..1 (1 lakh ~0.71, 10 lakh ~0.86, 1 crore 1.0)."""
        return max(0.0, min(1.0, math.log10(max(self.views, 1)) / 7.0))


def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:60] or "topic"


def _store(query: str) -> Path:
    return app_data_dir() / "research" / f"{slug(query)}.json"


# ---------------------------------------------------------------------
#  Yaad-dasht: pehle ki research aur built-in library
# ---------------------------------------------------------------------
def load_saved(query: str) -> tuple[list[ViralItem], float]:
    """(items, kab bani thi epoch). Na ho to ([], 0)."""
    path = _store(query)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        items = [ViralItem(**d) for d in data.get("items", [])]
        return items, float(data.get("made", 0))
    except (OSError, ValueError, TypeError):
        return [], 0.0


def load_builtin() -> list[ViralItem]:
    try:
        data = json.loads(BUILTIN.read_text(encoding="utf-8"))
        return [ViralItem(**{**d, "builtin": True}) for d in data.get("items", [])]
    except (OSError, ValueError, TypeError):
        return []


def is_stale(made: float) -> bool:
    return (time.time() - made) > REFRESH_DAYS * 86400


# ---------------------------------------------------------------------
#  YouTube se research (sirf public cheezen parhna)
# ---------------------------------------------------------------------
HASHTAG = re.compile(r"#[A-Za-z][A-Za-z0-9_]{1,40}")


def vtt_text(raw: str) -> str:
    """YouTube ki .vtt captions se saaf text (time stamps, tags, dohrai hui lines hata kar)."""
    out: list[str] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or "-->" in line or line.startswith(("WEBVTT", "Kind:", "Language:", "NOTE")):
            continue
        line = re.sub(r"<[^>]+>", "", line)
        if out and (line == out[-1] or out[-1].endswith(line)):
            continue
        out.append(line)
    return " ".join(out)[:3000]


def collect(query: str, subject: list[str], on_log=None, cancel=None) -> list[ViralItem]:
    """YouTube Shorts pe `query` dhoondo; top shorts ke titles, views, hashtags aur captions.
    Koi bhi masla (internet, YouTube ki rok) ho to jitna mila utna, kabhi exception nahi."""
    say = on_log or (lambda m: None)
    try:
        import yt_dlp  # type: ignore

        from app.media.download import _deno_options
    except ImportError:
        return []
    base = {"quiet": True, "no_warnings": True, "ignoreerrors": True, "skip_download": True,
            "socket_timeout": 20}                       # internet atke to research hamesha ke liye na ruke
    base.update(_deno_options())
    found: list[dict] = []
    try:
        with yt_dlp.YoutubeDL({**base, "extract_flat": "in_playlist"}) as ydl:
            info = ydl.extract_info(f"ytsearch{SEARCH_N}:{query} shorts", download=False) or {}
        for e in info.get("entries") or []:
            if not e or not e.get("id"):
                continue
            dur = e.get("duration") or 0
            if dur and dur > MAX_SHORT_SEC:
                continue
            found.append({"id": e["id"], "title": e.get("title") or "", "views": int(e.get("view_count") or 0)})
    except Exception as exc:  # noqa: BLE001
        log.warning("Research search failed for %s: %s", query, exc)
        say(f"Research: YouTube search not available now ({str(exc)[:80]})")
        return []
    found.sort(key=lambda d: -d["views"])
    say(f"Research: {len(found)} shorts found for '{query}', reading the top {min(DETAIL_N, len(found))}...")
    items: list[ViralItem] = []
    with tempfile.TemporaryDirectory(prefix="aimers_research_") as tmp:
        opts = {**base, "writeautomaticsub": True, "writesubtitles": True, "subtitleslangs": ["en", "en-US", "en.*"],
                "subtitlesformat": "vtt", "outtmpl": str(Path(tmp) / "%(id)s.%(ext)s")}
        with yt_dlp.YoutubeDL(opts) as ydl:
            for n, d in enumerate(found[:DETAIL_N]):
                if cancel is not None and cancel.is_set():
                    break
                try:
                    full = ydl.extract_info(f"https://www.youtube.com/shorts/{d['id']}", download=True) or {}
                except Exception as exc:  # noqa: BLE001 - ek video ka masla, baaki chalein
                    log.info("Research detail skipped %s: %s", d["id"], exc)
                    full = {}
                desc = full.get("description") or ""
                tags = list(dict.fromkeys(t.lower() for t in HASHTAG.findall(f"{d['title']} {desc}")))
                text = ""
                for sub in Path(tmp).glob(f"{d['id']}*.vtt"):
                    try:
                        text = vtt_text(sub.read_text(encoding="utf-8", errors="ignore"))
                    except OSError:
                        text = ""
                    break
                items.append(ViralItem(title=d["title"], views=int(full.get("view_count") or d["views"]),
                                       hashtags=tags, text=text, subject=list(subject)))
                if (n + 1) % 20 == 0:
                    say(f"Research: {n + 1} of {min(DETAIL_N, len(found))} shorts read")
    for d in found[DETAIL_N:]:                         # baaki sirf title + views (hashtags title se)
        items.append(ViralItem(title=d["title"], views=d["views"],
                               hashtags=[t.lower() for t in HASHTAG.findall(d["title"])], subject=list(subject)))
    return items


def research(query: str, subject: list[str], online: bool = True, on_log=None, cancel=None) -> list[ViralItem]:
    """Is person / topic ki research: yaad se, purani ho to taaza (online), sath built-in library."""
    items, made = load_saved(query) if query else ([], 0.0)
    if query and online and (not items or is_stale(made)):
        fresh = collect(query, subject, on_log, cancel)
        if len(fresh) >= 20:
            items = fresh
            path = _store(query)
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                tmp = path.with_suffix(".tmp")
                tmp.write_text(json.dumps({"query": query, "made": time.time(),
                                           "items": [it.__dict__ for it in items]}, ensure_ascii=False),
                               encoding="utf-8")
                tmp.replace(path)
            except OSError as exc:
                log.warning("Research could not be saved: %s", exc)
    return items + load_builtin()
