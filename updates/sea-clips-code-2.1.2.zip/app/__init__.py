"""
AIMERS Auto Clipping Tool.

Download settings for the speech model (set before any library loads):
  * HF_HUB_DISABLE_XET: use plain HTTPS downloads that resume after a
    dropped connection (the newer "xet" transfer kept failing on
    slower home connections).
  * symlink warning off: Windows without Developer Mode copies files
    instead, which works fine.
"""
import os

os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "60")
