"""
=====================================================================
  TRANSCRIBE / RECHECK        (shak wale lafz dobara suno)
  Kaam: speech model har lafz ke saath batata hai use kitna yaqeen hai.
  Jahan yaqeen kam ho, ya jahan NUMBER ho (48%, $1,684, 2030), wo
  chhota sa hissa (aas paas 1 second) dobara zyada dhyan se suna jata
  hai (beam 10). Dono dafa ek hi aaye: pakka. Alag aaye: lafz par
  "shak" ka nishaan (doubt = doosri dafa kya suna), taake clip "Check"
  mein jaye ya screen ke likhe number se theek ho.
  Accent ki wajah se ghalat suna lafz isi se pakda jata hai.
=====================================================================
"""
from __future__ import annotations

import logging
import re

from app.transcribe.models import Word

log = logging.getLogger("aimers.recheck")

LOW_PROB = 0.6               # is se kam yaqeen wala lafz dobara suna jata hai
PAD = 1.0                    # lafz ke aas paas itne second (poora jumla sa mile)
MAX_WINDOWS = 400            # bohat lambi video: zyada se zyada itne hisse
RATE = 16000
NUM_RE = re.compile(r"\d")
NUM_WORDS = re.compile(r"^(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|"
                       r"fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|"
                       r"seventy|eighty|ninety|hundred|thousand|million|billion|percent)$")


def is_number(text: str) -> bool:
    t = text.lower().strip(".,!?;:\"'")
    return bool(NUM_RE.search(t) or NUM_WORDS.match(t))


def norm(text: str) -> str:
    """Muqabla: chhote huroof, sirf harf / number ($ , % hata kar)."""
    t = text.lower().replace("percent", "%")
    return re.sub(r"[^a-z0-9.%]", "", t).strip(".")


def needs_check(w: Word) -> bool:
    return is_number(w.text) or w.prob < LOW_PROB


def windows(words: list[Word]) -> list[tuple[float, float, list[int]]]:
    """Shak wale lafzon ke hisse (start, end, lafzon ke number), paas paas wale ek hisse mein."""
    out: list[tuple[float, float, list[int]]] = []
    for i, w in enumerate(words):
        if not needs_check(w):
            continue
        a, b = max(0.0, w.start - PAD), w.end + PAD
        if out and a <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b), out[-1][2] + [i])
        else:
            out.append((a, b, [i]))
    return out[:MAX_WINDOWS]


def recheck(model, audio, words: list[Word], hotwords: str | None = None, cancel_event=None) -> int:
    """
    Shak wale lafz dobara suno. words badalte hain (prob / doubt). Lautata hai kitne lafzon par shak raha.
    model: faster-whisper WhisperModel (ya test ke liye koi bhi .transcribe wala).
    """
    if audio is None or isinstance(audio, str) or not len(words):
        return 0
    doubtful = 0
    for a, b, idx in windows(words):
        if cancel_event is not None and cancel_event.is_set():
            break
        piece = audio[int(a * RATE):int(b * RATE)]
        if len(piece) < RATE // 4:
            continue
        try:
            segs, _ = model.transcribe(piece, language="en", word_timestamps=True, beam_size=10, temperature=0.0,
                                       condition_on_previous_text=False, vad_filter=False,
                                       hotwords=hotwords or None)
            heard = [(a + float(x.start), a + float(x.end), x.word.strip()) for s in segs for x in (s.words or [])]
        except Exception as exc:  # noqa: BLE001 - dobara sunna na ho sake to pehla hi rehta hai
            log.warning("Recheck failed at %.1fs: %s", a, exc)
            continue
        for i in idx:
            w = words[i]
            mid = (w.start + w.end) / 2
            near = [h for h in heard if h[0] - 0.25 <= mid <= h[1] + 0.25]
            if any(norm(h[2]) == norm(w.text) for h in near):
                words[i] = Word(w.text, w.start, w.end, max(w.prob, 0.9), w.speaker)        # dono dafa same: pakka
            else:
                alt = min(near, key=lambda h: abs((h[0] + h[1]) / 2 - mid))[2] if near else "?"
                words[i] = Word(w.text, w.start, w.end, w.prob, w.speaker, doubt=alt)
                doubtful += 1
    if doubtful:
        log.info("Recheck: %d word(s) still unsure", doubtful)
    return doubtful
