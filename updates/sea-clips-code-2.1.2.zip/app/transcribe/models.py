"""
=====================================================================
  TRANSCRIBE / DATA MODELS
  Kaam: lafz aur transcript ka data.
  Word  - one spoken word with exact start/end time
  Transcript - all words of a source + language, saved as JSON cache
=====================================================================
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class Word:
    text: str
    start: float
    end: float
    prob: float = 1.0
    speaker: int | None = None
    doubt: str = ""          # dobara sunne par kuch aur suna (shak): wo lafz; "" = pakka / check nahi hua

    @property
    def clean(self) -> str:
        """Lowercase word without punctuation (for matching)."""
        return "".join(ch for ch in self.text.lower() if ch.isalnum() or ch == "'").strip("'")

    @property
    def ends_sentence(self) -> bool:
        return self.text.rstrip().endswith((".", "?", "!"))


@dataclass
class Transcript:
    words: list[Word] = field(default_factory=list)
    language: str = "en"
    translated: bool = False          # True when non-English speech was translated
    duration: float = 0.0
    engine: str = ""

    def save(self, path: Path) -> None:
        data = {
            "language": self.language, "translated": self.translated,
            "duration": self.duration, "engine": self.engine,
            "words": [asdict(w) for w in self.words],
        }
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)

    @classmethod
    def load(cls, path: Path) -> "Transcript":
        data = json.loads(path.read_text(encoding="utf-8"))
        return cls(
            words=[Word(**{k: v for k, v in w.items() if k in Word.__dataclass_fields__}) for w in data["words"]],
            language=data.get("language", "en"),
            translated=data.get("translated", False),
            duration=data.get("duration", 0.0),
            engine=data.get("engine", ""),
        )

    def words_between(self, start: float, end: float) -> list[Word]:
        return [w for w in self.words if w.start >= start - 1e-3 and w.end <= end + 1e-3]
