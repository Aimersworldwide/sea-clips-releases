"""
=====================================================================
  TRANSCRIBE / SPEECH TO TEXT  (faster-whisper)
  Kaam: awaaz se lafz (faster-whisper), GPU ho to GPU pe.
  * English speech  -> large-v3-turbo, word timestamps (fast, accurate)
  * Other languages -> large-v3 with task=translate (turbo cannot
    translate); English words are spread over each segment's time.
  * GPU (NVIDIA) used when it works, else CPU int8. If the GPU fails
    in the middle, the same pass is redone on the CPU automatically.
  * Language is detected inside the English pass (model loads once).
  * Deterministic settings so the same video always gives the same
    transcript: temperature 0, beam 5, VAD on.
  * Names dictionary is passed as hotwords so names are spelled right.
=====================================================================
"""
from __future__ import annotations

import gc
import os
import sys
import threading
from pathlib import Path
from typing import Callable

from app.core.logging_setup import get_logger
from app.media.ffmpeg_tools import Cancelled
from app.transcribe.models import Transcript, Word

log = get_logger("asr")

ENGLISH_MODEL = "large-v3-turbo"
TRANSLATE_MODEL = "large-v3"


_DLLS_DONE = False


def _register_cuda_dlls() -> None:
    """
    Windows: the CUDA libraries (cuBLAS, cuDNN) come as pip packages
    under site-packages/nvidia/*/bin. Windows does not search there by
    itself, so we add those folders before ctranslate2 loads.
    """
    global _DLLS_DONE
    if _DLLS_DONE or sys.platform != "win32":
        return
    _DLLS_DONE = True
    for base in map(Path, sys.path):
        nvidia = base / "nvidia"
        if not nvidia.is_dir():
            continue
        for bin_dir in nvidia.glob("*/bin"):
            try:
                os.add_dll_directory(str(bin_dir))
                os.environ["PATH"] = str(bin_dir) + os.pathsep + os.environ.get("PATH", "")
            except OSError:
                pass


# Best first. Older NVIDIA cards (GTX 10xx and earlier) have no fast
# float16, so they get int8 on the GPU instead, still far faster than CPU.
GPU_COMPUTE_PREFERENCE = ("float16", "int8_float16", "int8", "int8_float32", "float32")


def pick_device() -> tuple[str, str]:
    """Return (device, compute_type). Falls back to CPU on any GPU problem."""
    _register_cuda_dlls()
    try:
        import ctranslate2  # type: ignore
        if ctranslate2.get_cuda_device_count() > 0:
            supported = set(ctranslate2.get_supported_compute_types("cuda"))
            for compute in GPU_COMPUTE_PREFERENCE:
                if compute in supported:
                    return "cuda", compute
    except Exception as exc:  # missing CUDA DLLs etc.
        log.info("GPU not usable, using CPU: %s", exc)
    return "cpu", "int8"


def _load_model(name: str, models_dir: Path, device: str | None = None):
    from faster_whisper import WhisperModel  # type: ignore
    if device == "cpu":
        compute = "int8"
    else:
        device, compute = pick_device()
    source = str(local_model_dir(name, models_dir) or name)     # hand-placed folder wins
    try:
        model = WhisperModel(source, device=device, compute_type=compute, download_root=str(models_dir))
        log.info("Loaded %s on %s (%s)", name, device, compute)
        return model, device
    except Exception as exc:
        if device == "cuda":
            log.warning("GPU load failed (%s); retrying on CPU", exc)
            model = WhisperModel(source, device="cpu", compute_type="int8", download_root=str(models_dir))
            return model, "cpu"
        raise


MODEL_FILES = ("model.bin", "config.json", "tokenizer.json", "vocabulary.json", "preprocessor_config.json")


def local_model_dir(name: str, models_dir: Path) -> Path | None:
    """
    A model placed by hand: <models>/<name>/ with all MODEL_FILES inside
    (used when the automatic download is too slow or blocked; the
    model.bin can be downloaded in a browser and dropped there).
    """
    folder = models_dir / name
    if folder.is_dir() and not (folder / "model.bin").is_file():
        _adopt_browser_download(folder)
    if all((folder / f).is_file() for f in MODEL_FILES) and (folder / "model.bin").stat().st_size > 100_000_000:
        return folder
    # Installed app: the model ships inside the installation folder (no download at all).
    from app.core.paths import resource
    bundled = resource("models", name)
    if all((bundled / f).is_file() for f in MODEL_FILES) and (bundled / "model.bin").stat().st_size > 100_000_000:
        return bundled
    return None


MIN_TURBO_BYTES = 1_500_000_000      # large-v3-turbo model.bin is about 1.62 GB


def _adopt_browser_download(folder: Path) -> None:
    """
    If model.bin was downloaded in a browser, it sits in Downloads.
    Move a finished one (no .crdownload/.part left, full size) into the
    model folder, so nobody has to move a hidden-folder file by hand.
    """
    import shutil
    downloads = Path.home() / "Downloads"
    if not downloads.is_dir():
        return
    for cand in sorted(downloads.glob("model*.bin"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            if cand.stat().st_size < MIN_TURBO_BYTES:
                continue
            shutil.move(str(cand), str(folder / "model.bin"))
            log.info("Moved browser-downloaded %s into %s", cand.name, folder)
            return
        except OSError as exc:   # still being written / locked: try again next time
            log.warning("Could not move %s yet: %s", cand, exc)


def model_ready(name: str, models_dir: Path) -> bool:
    """True when the model is already on disk (no download needed)."""
    if local_model_dir(name, models_dir):
        return True
    try:
        from faster_whisper.utils import download_model  # type: ignore
        download_model(name, cache_dir=str(models_dir), local_files_only=True)
        return True
    except Exception:  # noqa: BLE001 - any failure means "not ready"
        return False


def fetch_model(name: str, models_dir: Path, attempts: int = 4) -> str:
    """
    Download a model now (installer / first run). A dropped connection
    is retried; each retry resumes where the last one stopped.
    """
    import time
    from faster_whisper.utils import download_model  # type: ignore
    models_dir.mkdir(parents=True, exist_ok=True)
    for n in range(1, attempts + 1):
        try:
            return download_model(name, cache_dir=str(models_dir))
        except Exception as exc:  # noqa: BLE001 - network errors come in many types
            if n == attempts:
                raise
            log.warning("Model download attempt %d failed (%s); retrying", n, str(exc)[:200])
            time.sleep(5 * n)
    raise RuntimeError("unreachable")


def _common_options(hotwords: str | None) -> dict:
    return dict(
        beam_size=5,
        temperature=0.0,
        condition_on_previous_text=False,
        vad_filter=True,
        vad_parameters={"min_silence_duration_ms": 500},
        hotwords=hotwords or None,
    )


def load_wav(path: Path):
    """
    Read our own 16 kHz mono 16-bit WAV straight into a float32 array.
    Passing samples (not a path) means faster-whisper never needs PyAV
    to decode, so PyAV version changes cannot break transcription.
    """
    import wave
    import numpy as np
    with wave.open(str(path), "rb") as w:
        if w.getsampwidth() != 2 or w.getnchannels() != 1:
            raise ValueError(f"unexpected WAV format: {w.getnchannels()} ch, {w.getsampwidth() * 8} bit")
        frames = w.readframes(w.getnframes())
    return np.frombuffer(frames, dtype="<i2").astype(np.float32) / 32768.0


CPU_BATCH = 0          # (16 Nov) test: batched sirf 1.3x tez aur kuch alfaz badle (legal/illegal), is liye band


def _engine(model, device: str):
    """GPU par model khud (bilkul purana tareeqa). CPU par usi model ka batched runner."""
    if device != "cpu" or not CPU_BATCH:
        return model, {}
    try:
        from faster_whisper import BatchedInferencePipeline  # type: ignore
        return BatchedInferencePipeline(model=model), {"batch_size": CPU_BATCH}
    except Exception as exc:  # noqa: BLE001 - purana faster-whisper: seedha model
        log.info("Batched listening not available (%s)", exc)
        return model, {}


def _run(model, wav: Path, english: bool, hotwords: str | None, duration: float,
         on_progress, cancel_event, device: str = "cuda") -> tuple[list[Word], str]:
    """
    One pass. For the English model the language is detected inside
    the same call (first 30 s), so the model loads only once. Returns
    (words, language); words is empty when the speech is not English.
    """
    words: list[Word] = []
    audio = load_wav(wav) if Path(wav).is_file() else str(wav)
    runner, extra = _engine(model, device)
    if english:
        segments, info = runner.transcribe(audio, language=None, word_timestamps=True,
                                           **_common_options(hotwords), **extra)
        language = info.language or "en"
        if language != "en":
            if (info.language_probability or 0) >= 0.6:
                return [], language            # clearly another language -> translate pass
            # unsure: treat as English and force English decoding
            segments, _ = runner.transcribe(audio, language="en", word_timestamps=True,
                                            **_common_options(hotwords), **extra)
        for seg in segments:
            if cancel_event is not None and cancel_event.is_set():
                raise Cancelled()
            for w in seg.words or []:
                text = w.word.strip()
                if text:
                    words.append(Word(text=text, start=float(w.start), end=float(w.end), prob=float(w.probability)))
            if on_progress and duration:
                on_progress(min(0.99, seg.end / duration))
        # shak wale lafz (kam yaqeen / numbers) dobara suno: accent ki ghalti yahin pakdi jati hai
        from app.transcribe.recheck import recheck
        try:
            recheck(model, audio, words, hotwords, cancel_event)
        except Exception as exc:  # noqa: BLE001 - dobara sunna kabhi transcript na roke
            log.warning("Recheck skipped: %s", exc)
        return words, "en"
    segments, info = model.transcribe(audio, task="translate", **_common_options(hotwords))
    for seg in segments:
        if cancel_event is not None and cancel_event.is_set():
            raise Cancelled()
        words.extend(spread_words(seg.text, float(seg.start), float(seg.end)))
        if on_progress and duration:
            on_progress(min(0.99, seg.end / duration))
    return words, info.language or "unknown"


def transcribe(
    wav: Path,
    duration: float,
    models_dir: Path,
    names: list[str] | None = None,
    on_progress: Callable[[float], None] | None = None,
    cancel_event: threading.Event | None = None,
) -> Transcript:
    models_dir.mkdir(parents=True, exist_ok=True)
    hotwords = " ".join(names) if names else None
    passes = [(ENGLISH_MODEL, True)]
    words: list[Word] = []
    language, model_name, device = "en", ENGLISH_MODEL, "cpu"
    force_cpu = False
    while passes:
        model_name, english = passes.pop(0)
        model, device = _load_model(model_name, models_dir, "cpu" if force_cpu else None)
        try:
            words, language = _run(model, wav, english, hotwords, duration, on_progress, cancel_event, device)
        except Cancelled:
            raise
        except Exception as exc:
            # A GPU can load fine and still fail on the first batch (driver,
            # missing cuDNN, out of memory). Redo the same pass on the CPU.
            if device != "cuda":
                raise
            log.warning("GPU failed during transcription (%s); redoing on CPU", exc)
            force_cpu = True
            passes.insert(0, (model_name, english))
            continue
        finally:
            del model
            gc.collect()   # free RAM before the next heavy stage
        if english and not words and language != "en":
            log.info("Speech is %s; translating to English with %s", language, TRANSLATE_MODEL)
            passes.append((TRANSLATE_MODEL, False))

    if on_progress:
        on_progress(1.0)
    translated = model_name == TRANSLATE_MODEL
    return Transcript(words=fix_word_times(words), language=language, translated=translated,
                      duration=duration, engine=f"{model_name}@{device}")


def spread_words(text: str, start: float, end: float) -> list[Word]:
    """
    Translated text has no real word timings. Spread words across the
    segment in proportion to their length (captions then sync per phrase).
    """
    tokens = text.split()
    if not tokens or end <= start:
        return []
    total = sum(len(t) + 1 for t in tokens)
    out, cursor = [], start
    for tok in tokens:
        span = (end - start) * (len(tok) + 1) / total
        out.append(Word(text=tok, start=round(cursor, 3), end=round(cursor + span, 3), prob=0.9))
        cursor += span
    return out


def fix_word_times(words: list[Word]) -> list[Word]:
    """Guarantee increasing, non-overlapping times with a sane minimum length."""
    fixed: list[Word] = []
    for w in words:
        start = max(w.start, fixed[-1].end if fixed else 0.0)
        end = max(w.end, start + 0.06)
        fixed.append(Word(w.text, round(start, 3), round(end, 3), w.prob, w.speaker, w.doubt))
    return fixed


def apply_names_dictionary(transcript: Transcript, names: dict[str, str]) -> Transcript:
    """Force exact spellings: {'emran': 'Imran'} (keys compared lowercase)."""
    if not names:
        return transcript
    lookup = {k.lower(): v for k, v in names.items()}
    for w in transcript.words:
        key = w.clean
        if key in lookup:
            stripped = w.text.rstrip(".,!?;:\"')")
            trail = w.text[len(stripped):]
            w.text = lookup[key] + trail
    return transcript
