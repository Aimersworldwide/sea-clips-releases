"""
=====================================================================
  TRANSCRIBE / NAMES DICTIONARY  (naamon ki sahi spelling)
  Kaam: naam shuru se hi sahi likhe jayein, baad mein check karke nahi.
    1. Naamon ki list  : built-in (siyasat, hosts, shows, jagahen) +
                         campaign ke main people + campaign ke apne naam
                         + Settings ki names dictionary
    2. Speech model    : ye naam sunne se pehle model ko diye jate hain
                         (hotwords), taake wo pehli dafa sahi likhe
    3. Pakki fixes     : jaani pehchani ghalat spellings badal do
                         ("Shapira" -> "Shapiro")
    4. Qareeb wali fix : naam jaisa lafz (1-2 harf ka farq, bara harf,
                         ya pichla lafz naam ka pehla hissa) sahi naam
    5. Aakhri check    : yahi kaam har clip ke lafzon aur hook pe dobara
                         (milliseconds), extra hifazat
=====================================================================
"""
from __future__ import annotations

import re
from functools import lru_cache

from app.filters.profanity import _load_list
from app.transcribe.models import Transcript, Word

MAX_HOTWORDS = 48          # model ko itne naam se zyada nahi (zyada naam = ulta asar)
MIN_FUZZY = 5              # is se chhote naam ki qareeb wali fix nahi (ghalti ka khatra)


# ---------------------------------------------------------------------
#  Lists (files se, ek dafa)
# ---------------------------------------------------------------------
@lru_cache(maxsize=1)
def builtin_names() -> tuple[str, ...]:
    return tuple(_load_list("names_builtin.txt"))


@lru_cache(maxsize=1)
def builtin_fixes() -> tuple[tuple[str, str], ...]:
    out = []
    for line in _load_list("name_fixes.txt"):
        if "=" in line:
            wrong, right = (x.strip() for x in line.split("=", 1))
            if wrong and right and wrong.lower() != right.lower():
                out.append((wrong, right))
    return tuple(out)


def _norm(text: str) -> str:
    return "".join(ch for ch in text.lower() if ch.isalnum() or ch == "'").strip("'")


# ---------------------------------------------------------------------
#  Ek campaign ke saare naam (pehle campaign ke, phir baaki)
# ---------------------------------------------------------------------
def campaign_names(profile=None, settings=None) -> list[str]:
    names: list[str] = []
    if profile is not None:
        names += profile.main_names() + list(getattr(profile, "names", []) or [])
    if settings is not None:
        names += list(settings.names_dictionary.values()) + list(settings.vip_names)
    names += list(builtin_names())
    seen, out = set(), []
    for n in names:
        n = (n or "").strip()
        if n and n.lower() not in seen:
            seen.add(n.lower())
            out.append(n)
    return out


def hotwords(names: list[str]) -> list[str]:
    """Speech model ke liye: sab se zaroori naam pehle, had se zyada nahi."""
    return names[:MAX_HOTWORDS]


# ---------------------------------------------------------------------
#  Do lafzon ka farq (kitne harf badalne se ek doosra banta hai)
# ---------------------------------------------------------------------
def _distance(a: str, b: str, limit: int) -> int:
    if abs(len(a) - len(b)) > limit:
        return limit + 1
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb))
        if min(cur) > limit:
            return limit + 1
        prev = cur
    return prev[-1]


# ---------------------------------------------------------------------
#  Fixer: naamon ki list se ek baar banta hai, phir har lafz pe chalta hai
# ---------------------------------------------------------------------
class NameFixer:
    def __init__(self, names: list[str], fixes: dict[str, str] | None = None):
        self.single: dict[str, str] = {}               # ghalat lafz -> sahi lafz
        self.phrases: list[tuple[list[str], list[str]]] = []
        for wrong, right in list(builtin_fixes()) + list((fixes or {}).items()):
            w, r = wrong.split(), right.split()
            if len(w) == 1 and len(r) == 1:
                self.single[_norm(w[0])] = r[0]
            elif w:
                self.phrases.append(([_norm(x) for x in w], r))
        self.tokens: dict[str, str] = {}                # naam ka tukra (chhota) -> sahi likhai
        self.firsts: set[str] = set()                   # pehle naam ("ben"), qareeb wali fix ka sahara
        for n in names:
            parts = [p for p in re.split(r"\s+", n.strip()) if p]
            for k, p in enumerate(parts):
                key = _norm(p)
                if len(key) >= 3:
                    self.tokens.setdefault(key, p.strip(",."))
                    if k == 0 and len(parts) > 1:
                        self.firsts.add(key)
        self._by_first: dict[str, list[str]] = {}
        for key in self.tokens:
            if len(key) >= MIN_FUZZY:
                self._by_first.setdefault(key[0], []).append(key)

    def _near(self, key: str) -> str | None:
        limit = 1 if len(key) < 8 else 2
        best, best_d = None, limit + 1
        for cand in self._by_first.get(key[0], []):
            d = _distance(key, cand, limit)
            if d < best_d:
                best, best_d = cand, d
        return best if best_d <= limit else None

    def fix_words(self, words: list[Word]) -> int:
        """Lafz jagah pe theek karta hai. Wapas: kitne badle."""
        changed = 0
        clean = [w.clean for w in words]
        # kai lafzon wali pakki fixes ("charlie kurt" -> "Charlie Kirk")
        for wrong, right in self.phrases:
            n = len(wrong)
            for i in range(len(clean) - n + 1):
                if clean[i:i + n] == wrong and len(right) == n:
                    for k in range(n):
                        changed += self._put(words[i + k], right[k])
                        clean[i + k] = _norm(right[k])
        for i, w in enumerate(words):
            key = clean[i]
            if not key:
                continue
            if key in self.single:
                changed += self._put(w, self.single[key])
                continue
            if key in self.tokens:
                right = self.tokens[key]
                if w.text[:1].isupper() and w.text.rstrip(".,!?;:\"')") != right and _norm(right) == key:
                    changed += self._put(w, right)        # "mcconnell" -> "McConnell" (sirf jab bara harf ho)
                continue
            if len(key) < MIN_FUZZY or not w.text[:1].isupper():
                continue
            near = self._near(key)
            if near is None:
                continue
            first_of_sentence = i == 0 or words[i - 1].ends_sentence
            after_first = i > 0 and clean[i - 1] in self.firsts
            if first_of_sentence and not after_first:
                continue                                  # jumle ka pehla lafz: sirf naam ke saath
            changed += self._put(w, self.tokens[near])
        return changed

    @staticmethod
    def _put(w: Word, right: str) -> int:
        stripped = w.text.rstrip(".,!?;:\"')")
        trail = w.text[len(stripped):]
        lead = "" if stripped[:1].isalnum() else stripped[:1]
        new = lead + right + trail
        if new == w.text:
            return 0
        w.text = new
        return 1

    def fix_text(self, text: str) -> str:
        """Hook / title jaisi chhoti line ke liye (aakhri check)."""
        words = [Word(x, 0.0, 0.0) for x in text.split()]
        self.fix_words(words)
        return " ".join(w.text for w in words)


def fix_transcript(transcript: Transcript, fixer: NameFixer) -> int:
    join_split_words(transcript)
    return fixer.fix_words(transcript.words)


# ---------------------------------------------------------------------
#  Toote hue lafz jorna: "full" + "-grown" -> "full-grown"
#  Kaam: speech model kabhi kabhi hyphen wala hissa alag lafz bana deta
#  hai; captions mein "FULL -GROWN" bura lagta hai.
# ---------------------------------------------------------------------
def join_split_words(transcript: Transcript) -> int:
    out: list[Word] = []
    joined = 0
    for w in transcript.words:
        if out and w.text[:1] in ("-", "\u2011") and len(w.text) > 1 and w.start - out[-1].end < 0.4:
            prev = out[-1]
            out[-1] = Word(prev.text.rstrip() + w.text, prev.start, max(prev.end, w.end), min(prev.prob, w.prob),
                           prev.speaker, prev.doubt or w.doubt)
            joined += 1
            continue
        out.append(w)
    transcript.words = out
    return joined


# ---------------------------------------------------------------------
#  Campaign rules mein se naam (log, shows, jagahen): bina internet
# ---------------------------------------------------------------------
_NAME_RUN = re.compile(r"\b([A-Z][a-zA-Z'\-]+(?:\s+(?:[A-Z]\.|[A-Z][a-zA-Z'\-]+)){1,3})\b")
_NOT_NAME = {"The", "This", "That", "These", "Those", "Do", "Don't", "Never", "Only", "All", "Any", "No",
             "Please", "Each", "Every", "Videos", "Video", "Clips", "Clip", "Content", "Make", "Use", "Must",
             "Post", "Posts", "Include", "Avoid", "If", "When", "You", "Your", "We", "Our", "It", "Rules",
             "Requirements", "Campaign", "Brand", "Shorts", "Reels", "TikTok", "YouTube", "Instagram", "Facebook",
             "Twitter", "Snapchat", "Clipit", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday",
             "Sunday", "January", "February", "March", "April", "May", "June", "July", "August", "September",
             "October", "November", "December", "English", "US", "USA", "AI", "CPM", "Discord"}


def names_in_text(text: str, limit: int = 40) -> list[str]:
    out: list[str] = []
    for m in _NAME_RUN.finditer(text or ""):
        parts = m.group(1).split()
        while parts and parts[0] in _NOT_NAME:
            parts = parts[1:]
        while parts and parts[-1] in _NOT_NAME:
            parts = parts[:-1]
        if len(parts) < 2:
            continue
        name = " ".join(parts)
        if name.lower() not in (x.lower() for x in out):
            out.append(name)
        if len(out) >= limit:
            break
    return out
