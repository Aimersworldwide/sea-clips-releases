"""
=====================================================================
  QUEUE / PROCESS
  Kaam: video alag process mein banti hai, is liye app kabhi nahi
  atakti (kaam chalte waqt bhi har page aaram se khulta hai).
  One child process per video. It reads the item from the database,
  runs the normal pipeline with the item's own campaign copy, and
  reports everything back as small messages on a queue. Pause, stop
  and the preview answer travel the other way.
=====================================================================
"""
from __future__ import annotations

import dataclasses
import threading
import traceback


def child_main(item_id: int, out_q, in_q, pause_ev, cancel_ev) -> None:
    """Runs inside the child process. Never raises: every end is a message."""
    def send(*msg) -> None:
        try:
            out_q.put(msg)
        except Exception:  # noqa: BLE001 - parent gone
            pass

    try:
        from app.core.logging_setup import get_logger, setup_logging
        setup_logging(filename="worker.log")
        log = get_logger("queue.child")
        from pathlib import Path
        from app.core.config import AppSettings
        from app.core.db import Database
        from app.core.i18n import set_language
        from app.core.paths import temp_dir
        from app.media.download import DownloadError
        from app.pipeline.runner import Events, JobRequest, Pipeline, PipelineError, PreviewGate
        from app.queue.store import QueueStore
        from app.ui.worker import make_thumbnail

        settings = AppSettings.validate(AppSettings.load())
        set_language(settings.language)
        db = Database()
        item = QueueStore(db, reset_running=False).get(item_id)
        if item is None:
            send("failed", "msg.error", "queue item missing", "")
            return
        from app.queue.caps import cap_reached
        if cap_reached(db, item.campaign_name):     # campaign ki had poori: is video ko rok kar agli par
            log.info("Queue item %s: %s clip limit reached, skipped", item_id, item.campaign_name)
            from app.pipeline.runner import RunSummary
            send("finished", dataclasses.asdict(RunSummary(cancelled=True)))
            return

        # pause / stop: parent ke multiprocessing events ko pipeline ke threading events se jorna
        pause_t, cancel_t = threading.Event(), threading.Event()
        gate = PreviewGate()
        stop_mirror = threading.Event()

        def mirror() -> None:
            import queue as _q
            while not stop_mirror.is_set():
                pause_t.set() if pause_ev.is_set() else pause_t.clear()
                if cancel_ev.is_set():
                    cancel_t.set()
                try:
                    msg = in_q.get(timeout=0.2)
                    if msg and msg[0] == "preview_answer":
                        gate.reply(msg[1])
                except _q.Empty:
                    pass
                except (EOFError, OSError):
                    cancel_t.set()
                    return
        threading.Thread(target=mirror, daemon=True).start()

        thumbs = temp_dir() / "thumbs"
        thumbs.mkdir(parents=True, exist_ok=True)

        def clip_done(done: int, total: int, info: dict) -> None:
            if info.get("file"):
                thumb = make_thumbnail(Path(info["file"]), thumbs / f"{info['label']}.jpg")
                info = dict(info, thumb=str(thumb) if thumb else "")
            send("clip", done, total, _plain(info))
            if cap_reached(db, item.campaign_name):
                log.info("Queue item %s: %s clip limit reached, stopping", item_id, item.campaign_name)
                cancel_t.set()

        events = Events(stage=lambda n: send("stage", n),
                        progress=lambda v, t: send("progress", float(v), str(t)),
                        clip_done=clip_done,
                        warning=lambda k, d: send("warning", k, _plain(d)),
                        log=lambda m: send("log", str(m)),
                        preview=lambda infos: send("preview", [_plain(i) for i in infos]))
        req = JobRequest(source=item.source, campaign_id=item.campaign_id, clip_count=item.left or 1,
                         min_len=item.min_len, max_len=item.max_len,
                         ratio=(item.profile or {}).get("ratio") or None,
                         profile=item.profile or None, preview=bool(item.preview))
        try:
            summary = Pipeline(settings, db, req, events, cancel_t, pause_t, preview_gate=gate).run()
            send("finished", dataclasses.asdict(summary))
        except PipelineError as exc:
            log.warning("Queue item %s stopped: %s %s", item_id, exc.key, exc.detail)
            send("failed", exc.key, exc.detail, "")
        except DownloadError as exc:
            send("failed", "msg.download_failed", str(exc), "")
        except Exception as exc:  # noqa: BLE001
            log.exception("Queue item %s crashed", item_id)
            send("failed", "msg.error", str(exc), traceback.format_exc())
        finally:
            stop_mirror.set()
    except Exception as exc:  # noqa: BLE001 - even imports failing must reach the parent
        send("failed", "msg.error", str(exc), traceback.format_exc())


def _plain(d):
    """Sirf saada values (process ki seema paar karne ke liye)."""
    if isinstance(d, dict):
        return {str(k): _plain(v) for k, v in d.items()}
    if isinstance(d, (list, tuple)):
        return [_plain(v) for v in d]
    if isinstance(d, (str, int, float, bool)) or d is None:
        return d
    return str(d)
