"""
=====================================================================
  QUEUE / PREFETCH JOB
  Kaam: line ki EK agli video ki tayyari (download, audio, transcript,
  main person scan), alag chhote process mein. prefetch.py ka supervisor
  ise chalata hai aur RAM kam ho to band kar deta hai (20 Nov 2026).
  Exit code 0 = tayyar, 1 = nahi hua (asal run khud karega).
=====================================================================
"""
from __future__ import annotations

import json
import sys


def _alive(pid: int) -> bool:
    import os
    try:
        if os.name == "nt":
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x100000, False, pid)        # SYNCHRONIZE
            if not h:
                return False
            r = ctypes.windll.kernel32.WaitForSingleObject(h, 0)
            ctypes.windll.kernel32.CloseHandle(h)
            return r != 0                                                        # 0 = band ho chuka
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _exit_with_parent(pid: int) -> None:
    """Supervisor (ya app) band ho jaye to ye bhi foran band: koi yateem kaam peeche na chale."""
    import os
    import threading
    import time

    def watch() -> None:
        while _alive(pid):
            time.sleep(2.0)
        os._exit(1)
    threading.Thread(target=watch, daemon=True).start()


def main(argv: list[str]) -> int:
    from app.queue.prefetch import lower_priority
    lower_priority()
    if len(argv) > 1 and argv[1].isdigit():
        _exit_with_parent(int(argv[1]))
    try:
        from app.core.config import AppSettings
        from app.core.db import Database
        from app.core.logging_setup import get_logger, setup_logging
        setup_logging(filename="worker.log")
        log = get_logger("queue.prefetch")
        from app.pipeline.runner import Events, JobRequest, Pipeline
        job = json.loads(argv[0])
        settings = AppSettings.validate(AppSettings.load())
        req = JobRequest(source=str(job["source"]), campaign_id=int(job.get("campaign_id") or 0), clip_count=1,
                         min_len=job.get("min_len"), max_len=job.get("max_len"),
                         profile=job.get("profile") or None, preview=False, prefetch_only=True)
        summary = Pipeline(settings, Database(), req, Events(), None).run()
        if getattr(summary, "error", None) or getattr(summary, "cancelled", False):
            log.warning("Prefetch job for %s: %s", job.get("source"), getattr(summary, "error", "") or "cancelled")
            return 1
        return 0
    except Exception as exc:  # noqa: BLE001 - asal run ye kaam khud kar lega
        try:
            log.warning("Prefetch job failed: %s", str(exc)[:300])
        except Exception:  # noqa: BLE001
            pass
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
