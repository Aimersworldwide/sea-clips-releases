"""
=====================================================================
  QUEUE / CONTROLLER
  Kaam: line chalana. Ek video khatam, agli khud shuru. Window ke
  liye saare signals, waqt ka andaza, pause / stop / preview.
  Lives in the window (main thread). Starts one child process per
  video, reads its messages every 150 ms and turns them into Qt
  signals, keeps the database line up to date (clips made, status),
  and learns the laptop's speed for the time estimates.
=====================================================================
"""
from __future__ import annotations

import multiprocessing as mp
import queue as _queue
import time
from datetime import datetime

from PySide6.QtCore import QObject, QTimer, Signal

from app.core.logging_setup import get_logger
from app.queue import eta
from app.queue.prefetch import prefetch_main
from app.queue.process import child_main
from app.queue.store import DONE, FAILED, PAUSED, RUNNING, STOPPED, WAITING, QueueItem, QueueStore

log = get_logger("queue")
POLL_MS = 150
PREFETCH_AHEAD = 2            # (20 Nov) clips bante waqt agli itni videos pehle se tayyar
PREFETCH_MAX_WAIT = 45 * 60   # agli video ki tayyari is se zyada atke to chhor kar khud chalao


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


class QueueController(QObject):
    lineChanged = Signal()                       # line badli: dobara banao
    itemStarted = Signal(int)                    # item id
    stage = Signal(str)
    progress = Signal(float, str)
    clipDone = Signal(int, int, dict)            # (is video mein bane, is video ka total, info)
    warning = Signal(str, dict)
    logMessage = Signal(str)
    preview = Signal(list)
    itemFinished = Signal(int, dict)             # item id, RunSummary dict
    itemFailed = Signal(int, str, str, str)      # item id, key, detail, trace
    idle = Signal()                              # line khatam / ruki

    def __init__(self, store: QueueStore | None = None, parent=None):
        super().__init__(parent)
        self.store = store or QueueStore()
        self.ctx = mp.get_context("spawn")
        self.proc = None
        self.current: QueueItem | None = None
        self.live: eta.LiveRun | None = None
        self.speed = eta.Speed.load()
        self.hold = False                        # "Finish current": agli khud shuru na ho
        self._base_made = 0
        self._base_counts: dict = {}
        self._stop_mode = ""                     # "" | "pause" (baad mein wahin se) | "close"
        self._ended = False
        self._timer = QTimer(self)
        self._timer.setInterval(POLL_MS)
        self._timer.timeout.connect(self._poll)
        # agli videos ki tayyari (alag, halka process)
        self.pre_proc = None
        self._pre_q = None
        self._pre_cancel = None
        self._pre_active = ""                    # jis link ki tayyari abhi chal rahi hai
        self._pre_tried: set[str] = set()
        self.extra_sources = lambda: []          # line ke baad ke links (sheet target deta hai)
        self._wait_since = 0.0                   # agli video tayyari ka intezar kab se

    # ------------------------------------------------------------ state
    @property
    def running(self) -> bool:
        return self.proc is not None

    @property
    def paused(self) -> bool:
        return bool(self.running and self._pause_ev.is_set())

    # ------------------------------------------------------------ add
    def add(self, item: QueueItem) -> int:
        item_id = self.store.add(item)
        self.lineChanged.emit()
        if not self.running and not self.hold:
            QTimer.singleShot(0, self.start_next)
        return item_id

    # ------------------------------------------------------------ run
    def start_next(self) -> bool:
        if self.running:
            return False
        item = self.store.next_waiting()
        if item is None:
            self._wait_since = 0.0
            self.idle.emit()
            return False
        if self._prefetching(item.source):
            # isi video ki tayyari chal rahi hai: khatam hone do (dobara download nahi), phir shuru
            if not self._wait_since:
                self._wait_since = time.time()
                log.info("Queue: item %s is being prepared, starting when ready", item.id)
            if time.time() - self._wait_since < PREFETCH_MAX_WAIT:
                QTimer.singleShot(1000, self._start_after_wait)
                return True
            log.warning("Queue: preparing item %s took too long, starting it anyway", item.id)
            self.stop_prefetch()
        self._wait_since = 0.0
        self._launch(item)
        return True

    def _start_after_wait(self) -> None:
        if self.hold or self._stop_mode == "close":
            self._wait_since = 0.0               # beech mein Stop dabaya: intezar khatam, line ruki
            self.idle.emit()
            return
        self.start_next()

    # ------------------------------------------------------------ prefetch
    def _pre_poll(self) -> None:
        if self._pre_q is None:
            return
        while True:
            try:
                kind, src = self._pre_q.get_nowait()
            except Exception:  # noqa: BLE001 - khali / band
                break
            if kind == "start":
                self._pre_active = src
            elif kind == "done" and self._pre_active == src:
                self._pre_active = ""
        if self.pre_proc is not None and not self.pre_proc.is_alive():
            self.pre_proc.join(0.1)
            self.pre_proc = None
            self._pre_active = ""

    def _prefetching(self, source: str) -> bool:
        self._pre_poll()
        return self.pre_proc is not None and bool(source) and self._pre_active == source

    def start_prefetch(self) -> None:
        """Chalti video ke saath line ki agli videos tayyar karo (sirf links)."""
        self._pre_poll()
        if self.pre_proc is not None or self._stop_mode or PREFETCH_AHEAD <= 0:
            return
        cur = self.current.id if self.current else 0
        jobs = [dict(source=it.source, campaign_id=it.campaign_id, campaign_name=it.campaign_name,
                     profile=it.profile or {}, min_len=it.min_len, max_len=it.max_len, item_id=it.id)
                for it in self.store.items(0) if it.status == WAITING and it.id != cur]
        try:
            jobs += [dict(j) for j in (self.extra_sources() or [])]
        except Exception:  # noqa: BLE001 - sirf behtari
            pass
        seen, todo = set(self._pre_tried), []
        if self.current:
            seen.add(self.current.source)
        for j in jobs:
            src = str(j.get("source") or "")
            if "://" in src and src not in seen:
                seen.add(src)
                todo.append(j)
        todo = todo[:PREFETCH_AHEAD]
        if not todo:
            return
        self._pre_tried.update(j["source"] for j in todo)
        self._pre_q = self.ctx.Queue()
        self._pre_cancel = self.ctx.Event()
        self.pre_proc = self.ctx.Process(target=prefetch_main, name="clip-prefetch",
                                         args=(todo, self._pre_q, self._pre_cancel), daemon=True)
        self.pre_proc.start()
        log.info("Queue: preparing next videos in the background: %s", [j["source"] for j in todo])

    def stop_prefetch(self, wait: float = 5.0) -> None:
        if self.pre_proc is None:
            return
        try:
            self._pre_cancel.set()
            self.pre_proc.join(wait)
            if self.pre_proc.is_alive():
                self.pre_proc.terminate()
        except Exception:  # noqa: BLE001
            pass
        self.pre_proc = None
        self._pre_active = ""

    def resume_line(self) -> None:
        """Ruki hui line dobara (ya app khulne par jo bacha tha)."""
        self.hold = False
        if self.running and self._pause_ev.is_set():
            self._pause_ev.clear()
            self.lineChanged.emit()
            return
        self.start_next()

    def _launch(self, item: QueueItem) -> None:
        self.current = item
        self._base_made = item.made
        self._base_counts = dict(item.counts or {})
        self._stop_mode = ""
        self._ended = False
        self._out = self.ctx.Queue()
        self._in = self.ctx.Queue()
        self._pause_ev = self.ctx.Event()
        self._cancel_ev = self.ctx.Event()
        self.store.update(item.id, status=RUNNING, started_at=item.started_at or _now(), error="")
        self.proc = self.ctx.Process(target=child_main, name=f"clip-item-{item.id}",
                                     args=(item.id, self._out, self._in, self._pause_ev, self._cancel_ev),
                                     daemon=True)
        self.proc.start()
        self.live = eta.LiveRun()
        self._timer.start()
        log.info("Queue: started item %s (%s, %s clips left)", item.id, item.source, item.left)
        self.itemStarted.emit(item.id)
        self.lineChanged.emit()

    # ------------------------------------------------------------ controls
    def pause(self) -> None:
        if self.running:
            self._pause_ev.set()
            self.lineChanged.emit()

    def unpause(self) -> None:
        if self.running:
            self._pause_ev.clear()
            self.lineChanged.emit()

    def finish_current(self) -> None:
        """Ye video poori ho, phir line ruk jaye."""
        self.hold = True
        self.lineChanged.emit()

    def stop_current(self) -> None:
        """Abhi rok do (bane clips mehfooz); ye video baad mein wahin se chalegi."""
        self.stop_prefetch()
        if self.running:
            self.hold = True
            self._stop_mode = "pause"
            self._pause_ev.clear()
            self._cancel_ev.set()

    def answer_preview(self, answer: str) -> None:
        if self.running:
            try:
                self._in.put(("preview_answer", answer))
            except Exception:  # noqa: BLE001
                pass

    def shutdown(self, wait: float = 8.0) -> None:
        """Window band: chalti video rok do; agli dafa app khulte hi wahin se."""
        self.stop_prefetch(2.0)
        if not self.running:
            return
        self._stop_mode = "close"
        self._pause_ev.clear()
        self._cancel_ev.set()
        self.proc.join(wait)
        if self.proc.is_alive():
            self.proc.terminate()
        if self.current:
            self.store.update(self.current.id, status=WAITING)
        self.proc = None

    # ------------------------------------------------------------ item edits
    def set_paused(self, item_id: int, paused: bool) -> None:
        item = self.store.get(item_id)
        if not item or item.status == RUNNING:
            return
        if paused and item.status == WAITING:
            self.store.update(item_id, status=PAUSED)
        elif not paused and item.status in (PAUSED, STOPPED, FAILED):
            self.store.update(item_id, status=WAITING, error="")
            if not self.running and not self.hold:
                QTimer.singleShot(0, self.start_next)
        self.lineChanged.emit()

    def remove(self, item_id: int) -> None:
        self.store.remove(item_id)
        self.lineChanged.emit()

    def move(self, item_id: int, up: bool) -> None:
        self.store.move(item_id, up)
        self.lineChanged.emit()

    def change(self, item_id: int, **values) -> None:
        item = self.store.get(item_id)
        if not item or item.status == RUNNING:
            return                               # chalti video ki settings nahi badalti
        self.store.update(item_id, **values)
        self.lineChanged.emit()

    # ------------------------------------------------------------ ETA
    def item_eta(self, item: QueueItem) -> float:
        if self.current and item.id == self.current.id and self.live:
            return eta.estimate_running(self.live, item.left, item.min_len, item.max_len, self.speed)
        return eta.estimate_item(item.left, item.min_len, item.max_len, self.speed)

    def line_eta(self) -> float:
        total = 0.0
        for item in self.store.items(0):
            if item.status in (WAITING, RUNNING):
                total += self.item_eta(item)
        return total

    # ------------------------------------------------------------ messages
    def _poll(self) -> None:
        if not self.proc:
            self._timer.stop()
            return
        for _ in range(200):
            try:
                msg = self._out.get_nowait()
            except _queue.Empty:
                break
            except (EOFError, OSError):
                break
            self._handle(msg)
        if self.proc and not self.proc.is_alive() and not self._ended:
            # bina khabar band hua (crash ya bijli): sirf is video ko 'ruka' maano
            try:
                while True:
                    self._handle(self._out.get_nowait())
            except Exception:  # noqa: BLE001
                pass
            if not self._ended:
                self._end_failed("msg.error", "The worker stopped unexpectedly.", "")

    def _handle(self, msg) -> None:
        kind = msg[0]
        item = self.current
        if kind == "stage":
            if self.live:
                self.live.on_stage(msg[1])
            if msg[1] in ("plan", "render"):
                # is video ka transcript ho gaya (GPU khaali): ab agli videos ki tayyari
                QTimer.singleShot(0, self.start_prefetch)
            self.stage.emit(msg[1])
        elif kind == "progress":
            self.progress.emit(msg[1], msg[2])
        elif kind == "clip":
            done, total, info = msg[1], msg[2], msg[3]
            if self.live:
                self.live.on_clip(done, total)
            if item:
                counts = dict(self._base_counts)
                rating = info.get("rating") or info.get("folder") or ""
                if rating:
                    counts[rating] = counts.get(rating, 0) + 1
                self._base_counts = counts
                item.made = self._base_made + done
                item.counts = counts
                self.store.update(item.id, made=item.made, counts=counts)
            self.clipDone.emit(done, total, info)
        elif kind == "warning":
            if msg[1] == "info.video_title":
                if item and not item.title:
                    item.title = str(msg[2].get("title") or "")
                    self.store.update(item.id, title=item.title)
                    self.lineChanged.emit()
                return
            self.warning.emit(msg[1], msg[2])
        elif kind == "log":
            self.logMessage.emit(msg[1])
        elif kind == "preview":
            self.preview.emit(msg[1])
        elif kind == "finished":
            self._end_finished(msg[1])
        elif kind == "failed":
            self._end_failed(msg[1], msg[2], msg[3])

    def _learn(self) -> None:
        if self.live:
            per = self.live.per_clip()
            if per and self.current:
                per = per / eta.clip_factor(self.current.min_len, self.current.max_len)
            self.speed.learn(self.live.start_seconds(), per)
            self.speed.save()

    def _close_proc(self) -> None:
        self._ended = True
        if self.proc:
            self.proc.join(3)
            if self.proc.is_alive():
                self.proc.terminate()
        self.proc = None
        self._timer.stop()

    def _end_finished(self, summary: dict) -> None:
        item = self.current
        self._learn()
        self._close_proc()
        if item:
            if summary.get("cancelled"):
                status = WAITING if self._stop_mode == "close" else PAUSED
                self.store.update(item.id, status=status)
            else:
                self.store.update(item.id, status=DONE, finished_at=_now())
            self.itemFinished.emit(item.id, summary)
        self._after()

    def _end_failed(self, key: str, detail: str, trace: str) -> None:
        item = self.current
        self._close_proc()
        if item:
            self.store.update(item.id, status=FAILED, error=(detail or key)[:500], finished_at=_now())
            self.itemFailed.emit(item.id, key, detail, trace)
        self._after()

    def _after(self) -> None:
        self.current = None
        self.live = None
        self.lineChanged.emit()
        if self._stop_mode == "close":
            return
        if not self.hold:
            QTimer.singleShot(500, self.start_next)    # ek video ki ghalti agli ko nahi rokti
        else:
            self.idle.emit()
