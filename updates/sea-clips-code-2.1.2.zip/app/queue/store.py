"""
=====================================================================
  QUEUE / STORE
  Kaam: line ki har video database mein (app band ho ya laptop band
  ho jaye, line yaad rahe aur wahin se chale).
  Every item keeps a copy of its campaign settings from the moment it
  was added, plus its own clip count, length and preview choice, so a
  campaign edited later only changes videos added after the edit.
=====================================================================
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any

from app.core.db import Database

WAITING, RUNNING, PAUSED, DONE, FAILED, STOPPED = "waiting", "running", "paused", "done", "failed", "stopped"
OPEN = (WAITING, RUNNING, PAUSED)

_DDL = """
CREATE TABLE IF NOT EXISTS queue_items (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    position      REAL    NOT NULL,
    source        TEXT    NOT NULL,
    title         TEXT    NOT NULL DEFAULT '',
    campaign_id   INTEGER NOT NULL,
    campaign_name TEXT    NOT NULL DEFAULT '',
    profile       TEXT    NOT NULL DEFAULT '{}',
    clip_count    INTEGER NOT NULL,
    min_len       INTEGER NOT NULL,
    max_len       INTEGER NOT NULL,
    preview       INTEGER NOT NULL DEFAULT 0,
    status        TEXT    NOT NULL DEFAULT 'waiting',
    made          INTEGER NOT NULL DEFAULT 0,
    counts        TEXT    NOT NULL DEFAULT '{}',
    error         TEXT    NOT NULL DEFAULT '',
    duration      REAL    NOT NULL DEFAULT 0,
    added_at      TEXT    NOT NULL,
    started_at    TEXT    NOT NULL DEFAULT '',
    finished_at   TEXT    NOT NULL DEFAULT ''
);
"""


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


@dataclass
class QueueItem:
    id: int = 0
    position: float = 0
    source: str = ""
    title: str = ""
    campaign_id: int = 0
    campaign_name: str = ""
    profile: dict = field(default_factory=dict)
    clip_count: int = 30
    min_len: int = 15
    max_len: int = 25
    preview: bool = False
    status: str = WAITING
    made: int = 0
    counts: dict = field(default_factory=dict)
    error: str = ""
    duration: float = 0.0          # video ki lambai (second), ETA ke liye
    added_at: str = ""
    started_at: str = ""
    finished_at: str = ""

    @property
    def left(self) -> int:
        return max(0, self.clip_count - self.made)

    @property
    def is_open(self) -> bool:
        return self.status in OPEN

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_row(cls, row) -> "QueueItem":
        d = dict(row)
        d["profile"] = json.loads(d.get("profile") or "{}")
        d["counts"] = json.loads(d.get("counts") or "{}")
        d["preview"] = bool(d.get("preview"))
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class QueueStore:
    """Line ki saari baatein ek jagah. Every method is one transaction."""

    def __init__(self, db: Database | None = None, reset_running: bool = True):
        self.db = db or Database()
        with self.db._conn() as c:
            c.executescript(_DDL)
            # app band hote waqt jo chal raha tha wo dobara chalega (bane hue clips dobara nahi bante).
            # Sirf window (app khulne par) ye karti hai; video banane wala process nahi.
            if reset_running:
                c.execute("UPDATE queue_items SET status=? WHERE status=?", (WAITING, RUNNING))

    # --- add / list ---------------------------------------------------
    def add(self, item: QueueItem) -> int:
        with self.db._conn() as c:
            row = c.execute("SELECT COALESCE(MAX(position), 0) FROM queue_items").fetchone()
            item.position = float(row[0]) + 1
            item.added_at = _now()
            cur = c.execute(
                "INSERT INTO queue_items(position, source, title, campaign_id, campaign_name, profile, clip_count,"
                " min_len, max_len, preview, status, made, counts, duration, added_at)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (item.position, item.source, item.title, item.campaign_id, item.campaign_name,
                 json.dumps(item.profile), int(item.clip_count), int(item.min_len), int(item.max_len),
                 int(bool(item.preview)), WAITING, 0, "{}", float(item.duration), item.added_at))
            return int(cur.lastrowid)

    def get(self, item_id: int) -> QueueItem | None:
        with self.db._conn() as c:
            row = c.execute("SELECT * FROM queue_items WHERE id=?", (item_id,)).fetchone()
        return QueueItem.from_row(row) if row else None

    def items(self, include_finished: int = 8) -> list[QueueItem]:
        """Open items in order, then the latest few finished ones."""
        with self.db._conn() as c:
            open_rows = c.execute(
                f"SELECT * FROM queue_items WHERE status IN ({','.join('?' * len(OPEN))}) ORDER BY position",
                OPEN).fetchall()
            done_rows = c.execute(
                f"SELECT * FROM queue_items WHERE status NOT IN ({','.join('?' * len(OPEN))})"
                " ORDER BY finished_at DESC, id DESC LIMIT ?", (*OPEN, include_finished)).fetchall()
        return [QueueItem.from_row(r) for r in open_rows] + [QueueItem.from_row(r) for r in done_rows]

    def next_waiting(self) -> QueueItem | None:
        with self.db._conn() as c:
            row = c.execute("SELECT * FROM queue_items WHERE status=? ORDER BY position LIMIT 1",
                            (WAITING,)).fetchone()
        return QueueItem.from_row(row) if row else None

    # --- change -------------------------------------------------------
    _EDITABLE = {"clip_count", "min_len", "max_len", "preview", "status", "made", "counts", "error",
                 "title", "duration", "started_at", "finished_at", "position"}

    def update(self, item_id: int, **values: Any) -> None:
        bad = set(values) - self._EDITABLE
        if bad:
            raise ValueError(f"not editable: {bad}")
        if "counts" in values:
            values["counts"] = json.dumps(values["counts"])
        if "preview" in values:
            values["preview"] = int(bool(values["preview"]))
        cols = ", ".join(f"{k}=?" for k in values)
        with self.db._conn() as c:
            c.execute(f"UPDATE queue_items SET {cols} WHERE id=?", (*values.values(), item_id))

    def remove(self, item_id: int) -> None:
        """Sirf line se hatata hai. Bane hue clips aur files waise hi rehte hain."""
        with self.db._conn() as c:
            c.execute("DELETE FROM queue_items WHERE id=? AND status!=?", (item_id, RUNNING))

    def move(self, item_id: int, up: bool) -> None:
        """Ek jagah upar / neeche (sirf intezaar wali videos ke beech)."""
        items = [i for i in self.items(0) if i.status in (WAITING, PAUSED)]
        ids = [i.id for i in items]
        if item_id not in ids:
            return
        k = ids.index(item_id)
        j = k - 1 if up else k + 1
        if not 0 <= j < len(items):
            return
        a, b = items[k], items[j]
        with self.db._conn() as c:
            c.execute("UPDATE queue_items SET position=? WHERE id=?", (b.position, a.id))
            c.execute("UPDATE queue_items SET position=? WHERE id=?", (a.position, b.id))

    def clear_finished(self) -> None:
        with self.db._conn() as c:
            c.execute(f"DELETE FROM queue_items WHERE status NOT IN ({','.join('?' * len(OPEN))})", OPEN)

    def open_count(self) -> int:
        with self.db._conn() as c:
            return int(c.execute(f"SELECT COUNT(*) FROM queue_items WHERE status IN ({','.join('?' * len(OPEN))})",
                                 OPEN).fetchone()[0])
