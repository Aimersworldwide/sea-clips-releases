"""
=====================================================================
  QUEUE / CAPS
  Kaam: kisi campaign ke clips ki had (jaise Ami: 130). Had poori hote
  hi us campaign ki video ruk jati hai (bane clips mehfooz) aur line
  agli campaign ki video par chali jati hai.
  campaign_caps.json in the app data folder:
    {"Ami Horowitz": {"limit": 130, "since": "2026-11-18T02:00:00"}}
  Only clips made on or after "since" count. No file = no caps.
=====================================================================
"""
from __future__ import annotations

import json

from app.core.paths import app_data_dir

CAPS_FILE = "campaign_caps.json"


def load_caps() -> dict:
    path = app_data_dir() / CAPS_FILE
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:  # noqa: BLE001 - missing or broken file means no caps
        return {}


def cap_status(db, campaign_name: str) -> tuple[int, int] | None:
    """(made since, limit) for a capped campaign, else None."""
    cap = load_caps().get(campaign_name or "")
    if not isinstance(cap, dict) or int(cap.get("limit") or 0) <= 0:
        return None
    since = str(cap.get("since") or "")
    with db._conn() as c:
        made = c.execute("SELECT COUNT(*) FROM clips k JOIN campaigns c ON c.id = k.campaign_id "
                         "WHERE c.name = ? AND k.created_at >= ?", (campaign_name, since)).fetchone()[0]
    return int(made), int(cap["limit"])


def cap_reached(db, campaign_name: str) -> bool:
    try:
        st = cap_status(db, campaign_name)
    except Exception:  # noqa: BLE001 - a cap check never stops work by mistake
        return False
    return bool(st and st[0] >= st[1])
