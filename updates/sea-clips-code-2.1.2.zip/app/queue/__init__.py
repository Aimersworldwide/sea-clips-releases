"""Line (queue) of videos: store, background process, time estimates."""
