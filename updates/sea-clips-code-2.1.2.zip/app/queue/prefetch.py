"""
=====================================================================
  QUEUE / PREFETCH
  Kaam: jab ek video ki clips ban rahi hon, line ki agli 1-2 videos
  pehle se tayyar ho jayen (download, audio, transcript). Phir wo
  video shuru hote hi seedha clips banana shuru (20 Nov 2026, user).
  Runs in its own low-priority process so the clip render keeps the
  CPU. Everything it makes goes into the normal per-source cache, so
  the real run simply finds it there. Any error here is only logged:
  the real run will do that step itself as before.
=====================================================================
"""
from __future__ import annotations

import sys

MIN_FREE_RAM_GB = 3.0       # is se kam RAM khali ho to tayyari shuru nahi (asal run khud karega)
PAUSE_RAM_GB = 2.0          # (20 Nov) chalti tayyari: is se kam RAM bache to foran band (clips ko RAM pehle)
RESUME_RAM_GB = 3.5         # band hui tayyari: itni RAM ...
RESUME_STEADY_S = 30        # ... itne second lagataar khali rahe tab dobara
WATCH_EVERY_S = 2.0


def lower_priority() -> None:
    """Is process (aur is ke ffmpeg) ko 'below normal': clips ka render pehle."""
    try:
        if sys.platform == "win32":
            import ctypes
            BELOW_NORMAL = 0x00004000
            ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), BELOW_NORMAL)
        else:
            import os
            os.nice(10)
    except Exception:  # noqa: BLE001 - sirf behtari, kabhi kaam na roke
        pass


def prefetch_main(jobs: list, out_q, cancel_ev) -> None:
    """Child process (supervisor). jobs: [{source, campaign_id, campaign_name, profile, min_len, max_len,
    item_id?}]. Har job: ("start", source) ... ("done", source). Kabhi raise nahi.

    (20 Nov) Har video ki tayyari apne alag chhote process mein (prefetch_job). Ye supervisor RAM dekhta
    rehta hai: RAM kam ho to wo process foran band (us ki saari RAM wapas, clips ka render chalta rahe),
    RAM wapas aaye to dobara shuru; download, transcript aur poori hui scan cache mein hain, adhoori scan
    wahin se aage chalti hai. Jab tak tayyari band hai, line us video ka intezar nahi karti."""
    def send(*msg) -> None:
        try:
            out_q.put(msg)
        except Exception:  # noqa: BLE001
            pass

    lower_priority()
    try:
        import json
        import os
        import subprocess
        import time
        from pathlib import Path

        from app.core.db import Database
        from app.core.logging_setup import get_logger, setup_logging
        setup_logging(filename="worker.log")
        log = get_logger("queue.prefetch")
        from app.media.download import is_url
        from app.pipeline.runner import free_ram_gb
        from app.queue.caps import cap_reached
        from app.queue.store import RUNNING, WAITING, QueueStore
        db = Database()
        store = QueueStore(db, reset_running=False)
        root = Path(__file__).resolve().parents[2]
    except Exception:  # noqa: BLE001
        for j in jobs:
            send("done", j.get("source", ""))
        return

    def being_made(src: str) -> bool:
        """Asal run ne ye video shuru kar di? (phir tayyari ka koi faida nahi)"""
        try:
            return any(it.source == src and it.status == RUNNING for it in store.items(0))
        except Exception:  # noqa: BLE001
            return False

    def kill(proc) -> None:
        try:
            if sys.platform == "win32":                # poora khandan: python + us ke ffmpeg
                subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)], capture_output=True,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), timeout=30)
            else:
                proc.kill()
            proc.wait(10)
        except Exception:  # noqa: BLE001
            pass

    def run_job(job: dict) -> str:
        """'ready' | 'failed' | 'paused' | 'cancelled'"""
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)
        env = dict(os.environ, PYTHONPATH=str(root) + os.pathsep + os.environ.get("PYTHONPATH", ""))
        proc = subprocess.Popen([sys.executable, "-m", "app.queue.prefetch_job", json.dumps(job), str(os.getpid())], cwd=str(root),
                                env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, creationflags=flags)
        while True:
            try:
                code = proc.wait(WATCH_EVERY_S)
                return "ready" if code == 0 else "failed"
            except subprocess.TimeoutExpired:
                pass
            if cancel_ev.is_set():
                kill(proc)
                return "cancelled"
            ram = free_ram_gb()
            if 0 < ram < PAUSE_RAM_GB:
                kill(proc)
                log.info("Prefetch paused for %s: only %.1f GB RAM free (clips keep the RAM)",
                         job.get("source"), ram)
                return "paused"

    def wait_for_ram() -> bool:
        steady = 0.0
        while not cancel_ev.is_set():
            ram = free_ram_gb()
            steady = steady + WATCH_EVERY_S if ram <= 0 or ram >= RESUME_RAM_GB else 0.0
            if steady >= RESUME_STEADY_S:
                return True
            time.sleep(WATCH_EVERY_S)
        return False

    for job in jobs:
        if cancel_ev.is_set():
            break
        src = str(job.get("source") or "")
        try:
            if job.get("item_id"):
                item = store.get(int(job["item_id"]))
                if item is None or item.status != WAITING:
                    continue
            if not is_url(src.strip().strip('"')) or cap_reached(db, job.get("campaign_name", "")):
                continue
            ram = free_ram_gb()
            if 0 < ram < MIN_FREE_RAM_GB and not wait_for_ram():
                break
            while not cancel_ev.is_set() and not being_made(src):
                send("start", src)
                log.info("Prefetch: preparing %s", src)
                state = run_job(job)
                send("done", src)                      # band ho to line is video ka intezar na kare
                if state == "ready":
                    log.info("Prefetch: ready %s", src)
                    break
                if state != "paused":
                    if state == "failed":
                        log.warning("Prefetch not finished for %s (the real run does it)", src)
                    break
                if not wait_for_ram():
                    break
                log.info("Prefetch: RAM is free again, resuming %s", src)
        except Exception as exc:  # noqa: BLE001 - asal run ye kaam khud kar lega
            log.warning("Prefetch not finished for %s: %s", src, str(exc)[:300])
        finally:
            send("done", src)
