"""
=====================================================================
  QUEUE / ETA
  Kaam: kitna waqt aur lagega (har video aur poori line).
  Learns this laptop's real speed from finished runs: how long the
  start of a video takes (download, listening, faces) and how many
  seconds one clip takes to make. Before the first runs it uses safe
  middle values; after the first 2 or 3 clips of a video it switches
  to that video's live speed, so the estimate corrects itself.
=====================================================================
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field

from app.core.paths import app_data_dir

DEFAULT_START = 6 * 60.0       # download + sunna + chehre (ek video), second
DEFAULT_PER_CLIP = 40.0        # ek clip banane ka waqt, second
LEARN = 0.3                    # naya nateeja kitna asar kare (purana 70%)
LIVE_AFTER = 2                 # itne clips ke baad is video ki apni speed


def _file():
    return app_data_dir() / "speed.json"


@dataclass
class Speed:
    start_sec: float = DEFAULT_START
    per_clip_sec: float = DEFAULT_PER_CLIP
    runs: int = 0

    @classmethod
    def load(cls) -> "Speed":
        try:
            d = json.loads(_file().read_text(encoding="utf-8"))
            return cls(float(d.get("start_sec", DEFAULT_START)), float(d.get("per_clip_sec", DEFAULT_PER_CLIP)),
                       int(d.get("runs", 0)))
        except (OSError, ValueError, TypeError):
            return cls()

    def save(self) -> None:
        try:
            _file().write_text(json.dumps({"start_sec": round(self.start_sec, 1),
                                           "per_clip_sec": round(self.per_clip_sec, 2), "runs": self.runs}),
                               encoding="utf-8")
        except OSError:
            pass

    def learn(self, start_sec: float | None, per_clip_sec: float | None) -> None:
        """Pehla run poora maana jata hai, baad wale aahista asar karte hain."""
        w = 1.0 if self.runs == 0 else LEARN
        if start_sec and 5 < start_sec < 4 * 3600:
            self.start_sec = (1 - w) * self.start_sec + w * start_sec
        if per_clip_sec and 2 < per_clip_sec < 30 * 60:
            self.per_clip_sec = (1 - w) * self.per_clip_sec + w * per_clip_sec
        self.runs += 1


def clip_factor(min_len: int, max_len: int) -> float:
    """Lambi clips zyada waqt leti hain (20 s ko 1.0 maan kar)."""
    mid = (min_len + max_len) / 2 if max_len else 20
    return max(0.5, min(3.0, 0.4 + 0.6 * mid / 20))


@dataclass
class LiveRun:
    """Chalti video ka hisaab: kab shuru hui, pehla clip kab bana."""
    started: float = field(default_factory=time.time)
    render_started: float = 0.0
    done: int = 0
    total: int = 0

    def on_stage(self, name: str) -> None:
        if name == "render" and not self.render_started:
            self.render_started = time.time()

    def on_clip(self, done: int, total: int) -> None:
        if not self.render_started:
            self.render_started = time.time()
        self.done, self.total = done, total

    def start_seconds(self) -> float | None:
        return (self.render_started - self.started) if self.render_started else None

    def per_clip(self) -> float | None:
        if self.done >= LIVE_AFTER and self.render_started:
            return (time.time() - self.render_started) / self.done
        return None


def estimate_item(left: int, min_len: int, max_len: int, speed: Speed, cached_start: bool = False) -> float:
    """Jo video abhi shuru nahi hui: shuru ka waqt + baaqi clips."""
    start = speed.start_sec * (0.25 if cached_start else 1.0)
    return start + left * speed.per_clip_sec * clip_factor(min_len, max_len)


def estimate_running(live: LiveRun, left: int, min_len: int, max_len: int, speed: Speed) -> float:
    """Chalti video: pehle 2 clips ke baad isi video ki asal speed."""
    per = live.per_clip()
    if per is None:
        per = speed.per_clip_sec * clip_factor(min_len, max_len)
    if not live.render_started:
        spent = time.time() - live.started
        return max(30.0, speed.start_sec - spent) + left * per
    return left * per


def fmt_duration(sec: float) -> str:
    sec = max(0, int(sec))
    h, m = divmod(sec // 60, 60)
    if h:
        return f"{h}h {m:02d}m"
    return f"{max(1, m)}m"


def fmt_clock(epoch: float) -> str:
    t = time.localtime(epoch)
    hour = t.tm_hour % 12 or 12
    return f"{hour}:{t.tm_min:02d} {'AM' if t.tm_hour < 12 else 'PM'}"
