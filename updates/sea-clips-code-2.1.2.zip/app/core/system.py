"""
=====================================================================
  CORE / SYSTEM HELPERS
  Kaam: laptop ke chhote kaam (neend na aaye, disk ki jagah, GPU).
  keep_awake(): stops Windows from sleeping while clips are being
  made (the screen may still turn off). Does nothing on other OSes.
=====================================================================
"""
from __future__ import annotations

import sys
from contextlib import contextmanager
from typing import Iterator

_ES_CONTINUOUS = 0x80000000
_ES_SYSTEM_REQUIRED = 0x00000001


@contextmanager
def keep_awake() -> Iterator[None]:
    if sys.platform != "win32":
        yield
        return
    import ctypes
    kernel = ctypes.windll.kernel32  # type: ignore[attr-defined]
    kernel.SetThreadExecutionState(_ES_CONTINUOUS | _ES_SYSTEM_REQUIRED)
    try:
        yield
    finally:
        kernel.SetThreadExecutionState(_ES_CONTINUOUS)
