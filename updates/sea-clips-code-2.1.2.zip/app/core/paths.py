"""
=====================================================================
  CORE / PATHS
  Kaam: app ke folders (data, cache, temp, models) ka pata.
  Where the app keeps its data, models, logs and default output.
  Rules:
    * App data lives in the user's local app-data folder (never in
      the install folder, so updates never touch user data).
    * Default clip output avoids OneDrive / synced folders, because
      sync locks files while ffmpeg is writing them.
=====================================================================
"""
from __future__ import annotations

import os
import string
import sys
from pathlib import Path

APP_FOLDER_NAME = "AIMERS Auto Clipping Tool"


# ---------------------------------------------------------------------
#  App data folders
# ---------------------------------------------------------------------
def app_data_dir() -> Path:
    """Root folder for settings, database, logs, backups."""
    override = os.environ.get("AIMERS_DATA_DIR")
    if override:
        root = Path(override)
    elif sys.platform == "win32":
        root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / APP_FOLDER_NAME
    else:
        root = Path.home() / ".aimers_clipper"
    root.mkdir(parents=True, exist_ok=True)
    return root


def sub_dir(name: str) -> Path:
    path = app_data_dir() / name
    path.mkdir(parents=True, exist_ok=True)
    return path


def models_dir(custom: str = "") -> Path:
    """Speech models (about 1.6 GB, downloaded once). Custom folder if set."""
    path = Path(custom) if custom else app_data_dir() / "models"
    path.mkdir(parents=True, exist_ok=True)
    return path


def logs_dir() -> Path:
    return sub_dir("logs")


def backups_dir() -> Path:
    return sub_dir("backups")


def cache_dir() -> Path:
    """Analysis cache (transcripts, scores) so re-renders are identical."""
    return sub_dir("cache")


def temp_dir() -> Path:
    """Short ASCII temp path: ffmpeg filter strings break on odd paths."""
    return sub_dir("tmp")


def database_path() -> Path:
    return app_data_dir() / "aimers.db"


def settings_path() -> Path:
    return app_data_dir() / "settings.json"


# ---------------------------------------------------------------------
#  Bundled resources (fonts, word lists, ffmpeg) - works frozen or not
# ---------------------------------------------------------------------
def resource_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parents[2]


def resource(*parts: str) -> Path:
    return resource_root().joinpath(*parts)


# ---------------------------------------------------------------------
#  Output folder
# ---------------------------------------------------------------------
def is_synced_folder(path: Path) -> bool:
    lowered = str(path).lower()
    return any(tag in lowered for tag in ("onedrive", "dropbox", "google drive", "icloud"))


def default_output_dir() -> Path:
    """Prefer D:\\SEA CLIPS (or the first non-system drive), else ~/SEA CLIPS."""
    if sys.platform == "win32":
        for letter in string.ascii_uppercase[3:]:  # D: onwards
            drive = Path(f"{letter}:\\")
            if drive.exists():
                return drive / "SEA CLIPS"
        candidate = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Videos" / "SEA CLIPS"
        if is_synced_folder(candidate):
            candidate = Path(os.environ.get("SystemDrive", "C:") + "\\") / "SEA CLIPS"
        return candidate
    return Path.home() / "SEA CLIPS"


def safe_filename(text: str, max_len: int = 100) -> str:
    """Remove characters Windows does not allow in file names."""
    bad = '<>:"/\\|?*'
    cleaned = "".join(" " if ch in bad or ord(ch) < 32 else ch for ch in text)
    cleaned = " ".join(cleaned.split()).strip(" .")
    return cleaned[:max_len].rstrip(" .")


TITLE_LOOKALIKE = {"?": "\uff1f", ":": "\ua789", '"': "\u201d", "/": "\u2044", "|": "\u2022", "*": "\u2217",
                   "<": "\u2039", ">": "\u203a", "\\": "\u29f5"}


def title_filename(text: str, max_len: int = 150) -> str:
    """Post ke title se file ka naam: Windows ke mana nishaan (? : " / |) ki jagah dikhne mein wahi nishaan,
    taake file ka naam copy kar ke seedha caption mein lag sake."""
    out, opened = [], False
    for ch in text or "":
        if ch == '"':                                      # khulne wala “ aur band hone wala ”
            out.append("\u201d" if opened else "\u201c")
            opened = not opened
        else:
            out.append(TITLE_LOOKALIKE.get(ch, ch))
    return safe_filename("".join(out), max_len)


def move_with_retry(src: Path, dst: Path, attempts: int = 6, wait: float = 0.5) -> None:
    """
    Move a file, retrying briefly: on Windows an antivirus scan or the
    Explorer preview pane can hold a brand-new file for a moment.
    """
    import shutil
    import time
    for n in range(attempts):
        try:
            shutil.move(str(src), str(dst))
            return
        except PermissionError:
            if n == attempts - 1:
                raise
            time.sleep(wait)
