"""
=====================================================================
  CORE / LOGGING
  Kaam: log files likhna (ghalti dhoondne ke liye).
  Rotating log files + crash capture. The "Export diagnostics" button
  zips these logs so problems can be fixed quickly.
=====================================================================
"""
from __future__ import annotations

import faulthandler
import logging
import sys
import zipfile
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path

from app.core.paths import logs_dir

_CONFIGURED = False
_FAULT_FILE = None


def setup_logging(level: int = logging.INFO, filename: str = "app.log") -> logging.Logger:
    """Configure root logging once (file + console). The line's worker process writes worker.log."""
    global _CONFIGURED, _FAULT_FILE
    logger = logging.getLogger("aimers")
    if _CONFIGURED:
        return logger

    fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(name)s | %(message)s")
    file_handler = RotatingFileHandler(logs_dir() / filename, maxBytes=2_000_000, backupCount=5, encoding="utf-8")
    file_handler.setFormatter(fmt)
    console = logging.StreamHandler(sys.stderr)
    console.setFormatter(fmt)

    logger.setLevel(level)
    logger.addHandler(file_handler)
    logger.addHandler(console)
    logger.propagate = False

    # Native crashes (ffmpeg bindings, CUDA) get written here.
    _FAULT_FILE = open(logs_dir() / ("crash.log" if filename == "app.log" else "worker_crash.log"), "a",
                       encoding="utf-8")
    faulthandler.enable(file=_FAULT_FILE)

    def _excepthook(exc_type, exc, tb):
        logger.critical("Unhandled error", exc_info=(exc_type, exc, tb))

    sys.excepthook = _excepthook
    _CONFIGURED = True
    return logger


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"aimers.{name}")


def export_diagnostics(target_dir: Path) -> Path:
    """Zip all logs into one file the user can send for support."""
    target_dir.mkdir(parents=True, exist_ok=True)
    out = target_dir / f"AIMERS_diagnostics_{datetime.now():%Y%m%d_%H%M%S}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in logs_dir().glob("*.log*"):
            zf.write(path, path.name)
    return out
