"""
=====================================================================
  CORE / CONFIG
  Kaam: app aur har campaign ki settings (save / load).
  Two kinds of settings:
    1. AppSettings      - general settings for the whole app
    2. CampaignProfile  - rules for one campaign (overrides general)
  Both are plain dataclasses saved as JSON. Unknown keys are ignored
  and missing keys fall back to defaults, so old settings files keep
  working after an update.
=====================================================================
"""
from __future__ import annotations

import json
import shutil
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime
from pathlib import Path
from typing import Any, ClassVar

from app.core.paths import backups_dir, default_output_dir, settings_path

SETTINGS_SCHEMA = 2      # 2: chehra asli (colour looks + sharpen default band, 24 Oct 2026)

# ---------------------------------------------------------------------
#  Allowed option values (used by UI dropdowns and validation)
# ---------------------------------------------------------------------
TITLE_CARD_MODES = ("auto", "always", "off")    # title card: jahan faida ho / har clip (jahan fit ho) / koi nahi
LANGUAGES = ("en",)          # app sirf English mein (user ka faisla, 24 Oct 2026)
RATIOS = ("9:16", "16:9")
PLATFORMS = ("shorts", "tiktok", "reels")
SILENCE_LEVELS = ("off", "light", "medium", "strong")
BEEP_MODES = ("beep", "mute", "cut")
PROFANITY_LEVELS = ("strict", "standard", "off")
CAPTION_STYLES = (
    "yellow_pop", "authority", "box_highlight", "ice_blue", "anton_impact",
    "minimal_weight", "dim_to_lit", "newsroom_box", "debate_duo", "gold_premium",
    "bebas_red", "green_chip",
    "clean_pop", "clean_caps", "glow_karaoke", "karaoke_clean", "pill_highlight", "pill_round", "soft_box",
    "bold_two", "bold_two_bebas",
)


def _from_dict(cls, data: dict[str, Any] | None):
    """Build a dataclass from a dict, ignoring unknown keys."""
    data = data or {}
    known = {f.name for f in fields(cls)}
    return cls(**{k: v for k, v in data.items() if k in known})


# ---------------------------------------------------------------------
#  General app settings
# ---------------------------------------------------------------------
@dataclass
class AppSettings:
    RESET_NOTICE: ClassVar[bool] = False     # set when a broken settings file was replaced
    schema: int = SETTINGS_SCHEMA
    language: str = "en"
    output_dir: str = field(default_factory=lambda: str(default_output_dir()))
    models_dir: str = ""                 # empty = app data folder
    device_code: str = "A"               # A on owner laptop, B on friend's
    default_campaign: str = "My Campaign"
    welcomed: bool = False               # (15 Nov) pehli dafa ka welcome screen dikh chuka

    # Clip generation defaults
    min_length: int = 20
    max_length: int = 25
    render_workers: int = 0            # clips rendered at the same time (0 = automatic by CPU cores)
    hook_titles: bool = True           # hook title at the start of clips (Phase 3)
    zoom_effects: bool = True          # gentle punch / push zooms (Phase 3)
    reaction_shots: bool = True        # short looks at a listener during long monologues
    better_moments: bool = True        # stricter moment choice (strong start, clear payoff)
    sound_effects: bool = False        # soft whoosh / pop / hit at zooms, hooks and cuts
    youtube_hq: bool = False          # YouTube HQ: 1440x2560 clips (YouTube deta hai behtar compression)
    gpu_encode: bool = False          # GPU Fast encoding (NVENC): 2-3x tez, quality thori kam; sirf GPU laptop
    clip_count: int = 50
    clips_per_minute: int = 100          # phase mode: video ke har minute ke itne clips (1 phase)
    cold_open: bool = True               # clip ki sab se mazboot line shuru mein ek dafa (on/off)
    name_card: bool = False              # shuru mein main person ka naam aur mahina (on/off)
    title_cards: str = "auto"            # safed title card (viral channels jaisa): auto (jahan faida) | always | off
    titles_enabled: bool = True          # har clip ka viral andaaz ka title
    hashtags_enabled: bool = True        # har clip ke hashtags
    upload_names: bool = False           # file ka naam sirf "Title 😳 #hashtags" (YouTube khud title bhare)
    show_channel_name: bool = False      # title card ke upar channel ka naam (user: zyada tar band)
    channel_name: str = ""               # wo naam (maslan "AIMERS CLIPS")
    preview_pack: bool = False           # pehle 10 best clips dikha kar OK / Cancel (20 min baad khud chalta hai)
    ratio: str = "9:16"
    platform: str = "shorts"
    block_size: int = 50                 # no repeated moment inside a block

    # Captions
    captions_enabled: bool = True
    default_caption_style: str = "clean_pop"
    rotate_caption_styles: bool = True

    # Editing
    silence_level: str = "light"
    color_looks_enabled: bool = False   # chehra asli rang mein (user, 24 Oct)
    emphasis_zoom: bool = True
    progress_bar: bool = False
    sharpen: bool = False               # chehra asli (koi tezi nahi)
    sensitive_blur: bool = True

    # Audio and filters
    loudness_normalize: bool = True
    beep_mode: str = "beep"
    max_beeps_per_clip: int = 3
    profanity_level: str = "standard"
    general_banned_words: list[str] = field(default_factory=list)
    vip_names: list[str] = field(default_factory=list)
    names_dictionary: dict[str, str] = field(default_factory=dict)

    # System
    auto_delete_source: bool = False
    check_updates: bool = True
    license_key: str = ""                # built in, not enforced yet
    youtube_cookies: str = ""            # optional cookies.txt for links that need a sign-in
    gemini_api_key: str = ""             # Gemini band (25 Oct 2026): hamesha khali, kuch Google ko nahi jata
    gemini_model: str = ""               # empty = best free Flash model
    research_online: bool = True         # look up names for groups named in a brief
    auto_person_photos: bool = True      # main people ki mazeed photos YouTube se khud dhoondo

    # (18 Nov) Google Drive: nayi clips 50 ke batch mein campaign ke "Clip Pool" folder mein, phir laptop se delete
    drive_upload: bool = False           # Studio ka "Drive upload" switch
    drive_batch: int = 50                # itni nayi clips jama hon to ek saath upload
    drive_since: str = ""                # Drive jorne ka waqt: sirf is ke baad bani clips jati hain
    drive_folders: dict[str, str] = field(default_factory=dict)   # campaign naam -> Clip Pool folder id (haath se chuna)

    # --- persistence -------------------------------------------------
    @classmethod
    def from_data(cls, data: Any, strict: bool = True) -> "AppSettings":
        """
        Build settings from parsed JSON, checking every value's type.
        Raises ValueError with a readable reason (used by Import).
        strict=False (app start): ek ghalat field sirf apni default leta hai,
        baaki settings (laptop code, keys) wohi rehti hain.
        """
        if not isinstance(data, dict):
            raise ValueError("this is not an AIMERS settings file")
        defaults = cls()
        clean: dict[str, Any] = {}
        for f in fields(cls):
            if f.name not in data:
                continue
            value, want = data[f.name], type(getattr(defaults, f.name))
            if want is bool:
                ok = isinstance(value, bool)
            elif want is int:
                ok = isinstance(value, int) and not isinstance(value, bool)
            elif want is list:
                ok = isinstance(value, list) and all(isinstance(x, str) for x in value)
            elif want is dict:
                ok = isinstance(value, dict) and all(isinstance(k, str) and isinstance(v, str)
                                                     for k, v in value.items())
            else:
                ok = isinstance(value, want)
            if not ok:
                if strict:
                    raise ValueError(f"wrong value for '{f.name}'")
                AppSettings.RESET_NOTICE = True
                continue
            clean[f.name] = value
        return cls.validate(cls(**clean))

    @classmethod
    def load(cls, path: Path | None = None) -> "AppSettings":
        path = path or settings_path()
        if not path.exists():
            return cls()
        try:
            return cls.from_data(json.loads(path.read_text(encoding="utf-8")), strict=False)
        except (json.JSONDecodeError, TypeError, ValueError, UnicodeDecodeError):
            # Corrupt file: keep a copy for diagnosis, start from defaults,
            # and let the app tell the user once (RESET_NOTICE).
            AppSettings.RESET_NOTICE = True
            try:
                shutil.copy(path, backups_dir() / f"settings_corrupt_{datetime.now():%Y%m%d_%H%M%S}.json")
            except OSError:
                pass
            return cls()

    def save(self, path: Path | None = None) -> None:
        path = path or settings_path()
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(asdict(self), indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)   # atomic: never leaves a half-written file

    @classmethod
    def validate(cls, s: "AppSettings") -> "AppSettings":
        """Clamp values to safe ranges so a bad edit can never crash a run."""
        if s.schema < 2:
            # purani settings: chehra asli rakhne ka faisla (24 Oct 2026) ek dafa lagao
            s.color_looks_enabled, s.sharpen, s.schema = False, False, 2
        if s.language not in LANGUAGES:
            s.language = "en"
        if s.ratio not in RATIOS:
            s.ratio = "9:16"
        if s.platform not in PLATFORMS:
            s.platform = "shorts"
        if s.silence_level not in SILENCE_LEVELS or s.silence_level == "off":
            s.silence_level = "light"          # khamoshi hamesha kat ti hai (user, 24 Oct)
        s.gemini_api_key, s.gemini_model = "", ""     # Gemini kabhi istemal nahi hota (user ka faisla)
        if s.title_cards not in TITLE_CARD_MODES:
            s.title_cards = "auto"           # purana "mixed" bhi ab auto
        s.channel_name = str(s.channel_name or "").strip()[:40]
        if s.beep_mode not in BEEP_MODES:
            s.beep_mode = "beep"
        if s.profanity_level not in PROFANITY_LEVELS:
            s.profanity_level = "standard"
        if s.default_caption_style not in CAPTION_STYLES:
            s.default_caption_style = "clean_pop"
        s.min_length = max(5, min(int(s.min_length), 600))
        s.max_length = max(s.min_length + 1, min(int(s.max_length), 600))
        s.clip_count = max(1, min(int(s.clip_count), 5000))
        s.clips_per_minute = max(5, min(int(s.clips_per_minute), 500))
        s.render_workers = max(0, min(int(s.render_workers), 4))
        s.block_size = max(5, min(int(s.block_size), 500))
        s.max_beeps_per_clip = max(0, min(int(s.max_beeps_per_clip), 20))
        s.device_code = (s.device_code or "A").strip().upper()[:3] or "A"
        s.drive_batch = max(1, min(int(s.drive_batch), 500))
        return s


# ---------------------------------------------------------------------
#  Campaign profile
# ---------------------------------------------------------------------
@dataclass
class OverlaySpec:
    enabled: bool = False
    path: str = ""            # image file (logo / watermark)
    text: str = ""            # or text watermark
    position: str = "top_right"   # top_left | top_right | bottom_left | bottom_right
    size_pct: float = 11.0    # width as % of frame width
    opacity: float = 0.65
    timing: str = "full"      # full | start | end


@dataclass
class CampaignProfile:
    name: str = "My Campaign"
    platform: str = "shorts"
    min_length: int | None = None         # None = use app default
    max_length: int | None = None
    ratio: str = "9:16"
    captions_enabled: bool = True
    caption_style: str = ""               # empty = app default / rotation
    banned_words: list[str] = field(default_factory=list)
    banned_topics: list[str] = field(default_factory=list)
    title_banned_words: list[str] = field(default_factory=list)   # (15 Nov) sirf title / screen ke title mein mana (captions mein waise hi)
    profanity_level: str = ""             # empty = app default
    music_allowed: bool = False
    music_folder: str = ""                # (17 Nov) background music ke gaane (mp3 / wav / m4a); khaali = tool ka apna test gaana
    music_volume: float = 0.20            # music kitni oonchi (aawaz ke neeche, bolte waqt aur dheemi)
    max_face_width: float = 0.0           # (17 Nov, Ami) 9:16 crop mein chehra screen ki chaurai ke is hisse se bara zyada der = clip nahi (0 = band)
    preferred_person: str = ""            # (17 Nov) auto main speaker: ye shakhs video mein ho to wohi main (assets/people/<naam>.json)
    classic_style: bool = False           # (17 Nov) Classic: square video beech mein, upar title, black / white pattiyan
    classic_min_screen: int = 60          # Classic sirf jab main person clip ke itne % mein screen par ho
    fresh_since: str = ""                 # (19 Nov) is waqt se pehle bane clips moments nahi rokte (dobara naya andaaz)
    classic_split: bool = True            # (19 Nov) Off = split kabhi nahi (Diamonds: "no split content"):
                                          # har moment kaala + safed Classic, baqi versions campaign ka apna andaaz
    stream_layout: str = ""               # (20 Nov, GTA 6) streamer ka camera + game: "" band | round | stack | mix
    loud_master: bool = False             # (18 Nov) reference jaisi oonchi, dabi hui aawaz (~-10 LUFS), Political
    versions_per_moment: int = 4
    max_per_moment: int = 0           # (16 Nov) ek moment ke kul clips (cuts + re-edits); 0 = koi had nahi
    logo: OverlaySpec = field(default_factory=OverlaySpec)   # the campaign's own logo
    source_logo: str = "keep"             # channel logo in the source: keep | blur | replace
    main_person_name: str = ""            # the person the campaign is about (any name)
    main_person_photos: list[str] = field(default_factory=list)   # 1 to 5 photos, copied into app data
    main_person_min_screen: int = 60      # % of the clip he must be on screen
    main_person_min_speaking: int = 60    # % of the speech that must be his
    main_person_auto_photos: list[str] = field(default_factory=list)   # tool ki khud dhoondi photos (YouTube)
    more_people: list[dict] = field(default_factory=list)   # aur main people: [{"name", "photos", "auto_photos"}]
    people_mode: str = "any"              # any = koi bhi ek kaafi, all = sab har clip mein
    protect_main_person: bool = True      # Main Person Protection Guard (on / off)
    names: list[str] = field(default_factory=list)          # campaign ki spellings (naam, show, jagah)
    source_links: list[str] = field(default_factory=list)   # campaign ke video sources (channel, account)
    watermark: OverlaySpec = field(default_factory=OverlaySpec)
    brand_text: str = ""
    own_ads: bool = False                 # videos campaign ke apne ads hain: ad / sponsor wale hisse NA kaato
    keep_old_disclosure: bool = False     # video ka apna purana disclosure dikhta rahe (On) ya hamari patti dhak de (Off)
    disclosure_place: str = "below_video" # below_video (video ke neeche, app ke buttons se upar) | top | bottom
    background: str = "black"             # poori video beech mein ho to upar / neeche: black | white | blur | mix (har clip alag)
    hide_ticker: bool = False             # news ki chalti patti (doosri khabrein) blur
    topic_guard: bool = False             # campaign ke topic ke khilaf baat wala lamha clip na bane
    topic_terms: str = ""                 # topic ke naam (jaise "Prop 42, Yes on 42"); khaali = title_must
    topic_bad_words: str = ""             # apne mazeed khilaf lafz / jumle (comma se)
    cold_open_mode: str = "auto"          # auto (clean titles: band) | on | off: sab se mazboot line shuru mein
    hook_mode: str = "auto"               # auto (clean titles: band) | on | off: shuru mein screen par jumla
    preview_minutes: int = 20             # pehli 10 clips ke baad itne minute intezaar (phir khud aage)
    auto_main_speaker: bool = False       # naam na likha ho to jo sab se zyada bole wohi main person (guard)
    complete_point: bool = False          # clip nayi baat se shuru, baat ke natije par khatam
    fill_screen: bool = False             # kabhi kaala hissa nahi: door ka banda zoom (720p bhi), kamar se upar
    word_chip: bool = False               # caption style: bolte lafz ke peeche chhota rangeen nishaan
    fit_bars: str = "full"                # poori video beech mein ho to kaali pattiyan: full (poori video) | half (thora zoom)
    level_voices: bool = False            # har bolne wale ki aawaz barabar (sawal karne wala dheema na rahe)
    stack_layout: bool = True             # fill screen ke saath upar neeche (audience / sunne wala + speaker); Off = speaker akela
    titles: bool = True                   # is campaign ke clips ka title (file naam / title card); Off = koi title nahi
    fit_zoom: float = 0.0                 # poori video beech mein: kitni bari (1.7 = medium, sample jaisi); 0 = tool ka apna
    whole_picture: bool = False           # poori video bina kaate beech mein, upar neeche usi ka blur (zoom / crop nahi)
    super_link: str = ""                  # Super: shuru mein screen par jumla jo A ko B se jore ("Natural Diamonds | Botswana"); khaali = band
    name_super: bool = False              # (15 Nov) shuru ke ~4.5 s screen par title (title_must ka naam saath): har clip mein naam
    strict_edits: bool = False            # (15 Nov) baat ka matlab na badle: clip ke beech se kuch na kaato (guard / gaali), sirf beep
    look: str = ""                        # (15 Nov) editing style card: solo_focus | dual_split | street_talk | full_frame | clean_fill | cinematic ("" = purana / apna)
    light_edit: bool = False              # (15 Nov) brief "light editing only": rang ke looks, sound effects, jhatke wale zoom nahi
    line_on: bool = True                  # (15 Nov) campaign line (Super) screen par; Off = kabhi nahi
    mix_styles: bool = False              # captions: hamare styles + bolte lafz ke rangeen dabbe wale (laal / peela) mila kar
    disclosure_enabled: bool = False
    disclosure_text: str = "Sponsored"
    title: str = ""                       # optional base title
    hashtags: str = ""                    # optional, same on every clip
    delivery_note: str = ""               # required post text from brief
    raw_rules: str = ""                   # pasted brief, kept for reference
    # ---- title rules (campaign ke rules se, har campaign ke apne) ----
    title_style: str = "viral"            # viral = viral channels jaisa | clean = seedha, sach, koi hype / clickbait nahi
    political_words: bool = True          # title / hashtags mein siyasi lafz (party, siyasatdan, garam topics) aa sakte hain?
    title_emoji: str = "auto"             # auto (viral: haan, clean: nahi) | on | off
    title_must: str = ""                  # har title mein ye naam / topic zaroor (jaise "Prop 42")
    title_suffix: str = ""                # post title ke aakhir mein (jaise "Vote Yes on 42"); screen par nahi
    file_name: str = "label"              # clip file ka naam: label (number + title) | title (sirf title, post ke liye)
    max_hashtags: int = 0                 # 0 = tool ka apna (5); campaign kahe "up to 3" to 3
    output_folder: str = ""               # chosen when campaign created
    start_date: str = ""
    end_date: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CampaignProfile":
        profile = _from_dict(cls, data)
        profile.logo = _from_dict(OverlaySpec, data.get("logo") if isinstance(data.get("logo"), dict) else None)
        profile.watermark = _from_dict(OverlaySpec, data.get("watermark") if isinstance(data.get("watermark"), dict) else None)
        return profile

    # Effective values = campaign value if set, else app default.
    def length_range(self, app: AppSettings) -> tuple[int, int]:
        lo = self.min_length if self.min_length else app.min_length
        hi = self.max_length if self.max_length else app.max_length
        return (lo, max(hi, lo + 1))

    # -----------------------------------------------------------------
    #  Saare main people (pehla + aur), sirf jin ka naam ya photo ho
    # -----------------------------------------------------------------
    def main_people(self) -> list[tuple[str, list[str]]]:
        out: list[tuple[str, list[str]]] = []
        if self.main_person_name.strip() or self.main_person_photos:
            out.append((self.main_person_name.strip(), list(self.main_person_photos)))
        for item in self.more_people or []:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "").strip()
            photos = [str(x) for x in (item.get("photos") or []) if isinstance(x, str)]
            if name or photos:
                out.append((name, photos))
        return out

    # -----------------------------------------------------------------
    #  Pehchan ke liye: user ki photos + tool ki dhoondi photos
    # -----------------------------------------------------------------
    def people_for_matching(self) -> list[tuple[str, list[str]]]:
        out = []
        auto_lists = [list(self.main_person_auto_photos)] if (self.main_person_name.strip() or
                                                              self.main_person_photos) else []
        for item in self.more_people or []:
            if isinstance(item, dict) and (str(item.get("name") or "").strip() or item.get("photos")):
                auto_lists.append([str(x) for x in (item.get("auto_photos") or []) if isinstance(x, str)])
        for (name, photos), auto in zip(self.main_people(), auto_lists + [[]] * 10):
            out.append((name, photos + [a for a in auto if a not in photos]))
        return out

    def main_names(self) -> list[str]:
        return [n for n, _ in self.main_people() if n]

    def title_rules(self):
        from app.edit.title_rules import TitleRules
        return TitleRules.from_profile(self)

    def effective_profanity(self, app: AppSettings) -> str:
        return self.profanity_level or app.profanity_level
