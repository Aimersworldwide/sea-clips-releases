"""
=====================================================================
  CORE / PACKAGES        (app ke zaroori hisse: khud check, khud install)
  Kaam: app khulte hi dekhna ke requirements ki har cheez (Python
  packages) is laptop par maujood hai. Koi missing ho to app ke andar
  "Update" window aata hai aur sirf wahi hisse install hote hain
  (tool ke apne .venv mein; laptop ki koi aur cheez nahi badalti).
    requirements.txt       - aam packages
    requirements-ocr.txt   - --no-deps se (doosra OpenCV na aaye)
  GPU wale packages (requirements-gpu.txt) yahan nahi: wo installer
  ka kaam hai (NVIDIA ho to).
=====================================================================
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

from app.core.paths import resource

log = logging.getLogger("aimers.packages")

FILES = (("requirements.txt", False), ("requirements-ocr.txt", True))   # (file, --no-deps)


def _lines(path: Path) -> list[str]:
    if not path.is_file():
        return []
    out = []
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.split("#", 1)[0].strip()
        if line and not line.startswith("-"):
            out.append(line)
    return out


def _satisfied(spec: str) -> bool:
    from importlib.metadata import PackageNotFoundError, version

    from packaging.requirements import Requirement
    try:
        req = Requirement(spec)
    except Exception:  # noqa: BLE001 - samajh na aaye to chhod do (kabhi app na ruke)
        return True
    if req.marker is not None and not req.marker.evaluate():
        return True
    try:
        have = version(req.name)
    except PackageNotFoundError:
        return False
    return not req.specifier or req.specifier.contains(have, prereleases=True)


def missing(root: Path | None = None) -> list[tuple[list[str], bool]]:
    """Jo packages missing / purane hain: [(specs, no_deps), ...]; khali = sab theek."""
    root = root or resource()
    groups = []
    for name, no_deps in FILES:
        specs = [s for s in _lines(root / name) if not _satisfied(s)]
        if specs:
            groups.append((specs, no_deps))
    return groups


def python_exe() -> str:
    """Tool ke .venv ka python.exe (pythonw nahi, taake pip chal sake)."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe":
        cand = exe.with_name("python.exe")
        if cand.is_file():
            return str(cand)
    return str(exe)


def pip_commands(groups: list[tuple[list[str], bool]]) -> list[list[str]]:
    """Har group ke liye pip ka hukm (args, program alag)."""
    cmds = []
    for specs, no_deps in groups:
        cmds.append(["-m", "pip", "install", "--disable-pip-version-check", "--no-input"]
                    + (["--no-deps"] if no_deps else []) + specs)
    return cmds
