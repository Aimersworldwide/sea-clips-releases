"""
=====================================================================
  CORE / NOTIFICATIONS, NEW VIDEO ALERT, UPDATES
  Kaam (halka sa, kabhi kaam nahi rokta):
    * Notifications : ek chhoti list (bell icon). Naye videos, naya
                      app update. File: <app data>/notifications.json
    * New videos    : har campaign ke source links (YouTube channel,
                      TikTok account). App khuli ho to kabhi kabhi check;
                      naye uploads ki ginti campaign pe badge ban kar.
                      Pehli dafa: jo videos pehle se hain wo "dekhe hue".
                      Google Drive folder bina key ke check nahi hota:
                      ek line mein bata deta hai.
    * Updates       : GitHub (Aimersworldwide) pe naya version hai? Bell
                      mein aur ek dafa front pe. Kabhi zabardasti nahi;
                      "Update now" Settings > Updates mein.
  Internet na ho / koi ghalti: chup chaap kuch nahi badalta.
=====================================================================
"""
from __future__ import annotations

import json
import re
import threading
from datetime import datetime
from pathlib import Path
from typing import Callable

from app.core.logging_setup import get_logger
from app.core.paths import app_data_dir

log = get_logger("notify")

MAX_ITEMS = 60
_LOCK = threading.Lock()


# ---------------------------------------------------------------------
#  Chhota sa JSON store (app data folder mein)
# ---------------------------------------------------------------------
def _path(name: str) -> Path:
    return app_data_dir() / name


def _load(name: str, default):
    try:
        return json.loads(_path(name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _save(name: str, data) -> None:
    try:
        _path(name).write_text(json.dumps(data, indent=1), encoding="utf-8")
    except OSError as exc:
        log.info("could not save %s: %s", name, exc)


# ---------------------------------------------------------------------
#  Notifications list (bell)
# ---------------------------------------------------------------------
def notifications() -> list[dict]:
    with _LOCK:
        items = _load("notifications.json", [])
    return [i for i in items if isinstance(i, dict)]


def add_notification(kind: str, text: str, key: str = "") -> bool:
    """Nayi notification; same `key` dobara nahi aati. True = nayi thi."""
    with _LOCK:
        items = [i for i in _load("notifications.json", []) if isinstance(i, dict)]
        if key and any(i.get("key") == key for i in items):
            return False
        items.insert(0, {"kind": kind, "text": text, "key": key or text,
                         "time": datetime.now().isoformat(timespec="minutes"), "read": False})
        _save("notifications.json", items[:MAX_ITEMS])
    return True


def unread_count() -> int:
    return sum(1 for i in notifications() if not i.get("read"))


def mark_all_read() -> None:
    with _LOCK:
        items = [dict(i, read=True) for i in _load("notifications.json", []) if isinstance(i, dict)]
        _save("notifications.json", items)


def first_time(key: str) -> bool:
    """Koi cheez sirf ek dafa dikhani ho (jaise update ka front notice)."""
    with _LOCK:
        shown = _load("shown_once.json", [])
        if key in shown:
            return False
        _save("shown_once.json", (shown + [key])[-200:])
    return True


# ---------------------------------------------------------------------
#  New video alert: har campaign ke links
# ---------------------------------------------------------------------
def link_kind(url: str) -> str:
    u = url.lower()
    if "drive.google." in u:
        return "drive"
    if "youtube.com" in u or "youtu.be" in u:
        return "youtube"
    if "tiktok.com" in u:
        return "tiktok"
    return "other"


def list_videos(url: str) -> list[str]:
    """Link pe abhi kaun se videos hain (ID). Ghalti ho to exception."""
    kind = link_kind(url)
    if kind == "drive":
        raise RuntimeError("Google Drive folders cannot be checked without a Google key")
    import yt_dlp  # type: ignore
    target = url
    if kind == "youtube" and re.search(r"youtube\.com/(@|c/|channel/|user/)", url) and "/videos" not in url:
        target = url.rstrip("/") + "/videos"
    opts = {"quiet": True, "no_warnings": True, "extract_flat": True, "playlistend": 30, "skip_download": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(target, download=False) or {}
    entries = info.get("entries") or []
    ids = [str(e.get("id")) for e in entries if isinstance(e, dict) and e.get("id")]
    if not ids and info.get("id"):
        ids = [str(info["id"])]
    return ids


def check_new_videos(campaigns: list[tuple[int, str, list[str]]],
                     lister: Callable[[str], list[str]] = list_videos) -> dict[int, dict]:
    """
    campaigns: (id, naam, links). Wapas: {id: {"new": n, "errors": [...]}}.
    Naye video IDs "pending" mein jama hote hain jab tak user "Seen" na dabaye.
    """
    state = _load("video_state.json", {})
    out: dict[int, dict] = {}
    for cid, name, links in campaigns:
        st = state.setdefault(str(cid), {"seen": {}, "pending": []})
        errors = []
        for link in links:
            link = link.strip()
            if not link:
                continue
            try:
                ids = lister(link)
            except Exception as exc:  # noqa: BLE001 - ek line mein batao
                errors.append(f"{link[:60]}: {str(exc)[:80]}")
                continue
            known = st["seen"].get(link)
            if known is None:
                st["seen"][link] = ids                  # pehli dafa: purane videos naye nahi
                continue
            fresh = [i for i in ids if i not in known and i not in st["pending"]]
            st["pending"].extend(fresh)
            st["seen"][link] = list(dict.fromkeys(known + ids))[-300:]
        count = len(st["pending"])
        out[cid] = {"new": count, "errors": errors}
        if count:
            add_notification("videos", f"{name}: {count} new videos uploaded", key=f"videos:{cid}:{count}")
    _save("video_state.json", state)
    return out


def new_video_count(campaign_id: int) -> int:
    st = _load("video_state.json", {}).get(str(campaign_id)) or {}
    return len(st.get("pending") or [])


def mark_videos_seen(campaign_id: int) -> None:
    state = _load("video_state.json", {})
    if str(campaign_id) in state:
        state[str(campaign_id)]["pending"] = []
        _save("video_state.json", state)


# ---------------------------------------------------------------------
#  Updates (GitHub releases)
# ---------------------------------------------------------------------
def _version_tuple(v: str) -> tuple[int, ...]:
    nums = re.findall(r"\d+", v or "")
    return tuple(int(n) for n in nums[:4]) or (0,)


def is_newer(remote: str, local: str) -> bool:
    return _version_tuple(remote) > _version_tuple(local)


def latest_release(repo: str, fetch=None) -> dict | None:
    """{"version", "notes", "url" (installer .exe), "page"} ya None."""
    if fetch is None:
        import urllib.request

        def fetch(url: str) -> dict:
            req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json",
                                                       "User-Agent": "AIMERS-Auto-Clipping-Tool"})
            with urllib.request.urlopen(req, timeout=15) as r:      # noqa: S310 - fixed https host
                return json.loads(r.read().decode("utf-8"))
    rel, man = None, None
    try:
        rel = _from_release(fetch(f"https://api.github.com/repos/{repo}/releases/latest"))
    except Exception as exc:  # noqa: BLE001 - release na ho (404) to manifest dekho
        log.info("no GitHub release: %s", exc)
    try:
        # (20 Nov) repo ki latest.json: naye updates ab yahin aate hain (release banana zaroori nahi).
        # Download ke baad dastakhat wohi check hota hai, is liye naqli file kabhi install nahi hoti.
        man = _from_manifest(fetch(f"https://raw.githubusercontent.com/{repo}/main/latest.json"))
    except Exception as exc:  # noqa: BLE001
        log.info("no update manifest: %s", exc)
    if rel and man:
        return man if is_newer(man["version"], rel["version"]) else rel
    return rel or man


def _from_manifest(data) -> dict | None:
    if not isinstance(data, dict) or not data.get("version"):
        return None
    out = {"version": str(data["version"]).lstrip("vV"), "notes": str(data.get("notes") or "")[:3000],
           "url": str(data.get("installer_url") or ""), "page": str(data.get("page") or "")}
    if data.get("code_url") and data.get("sig_url"):
        out.update(code_url=str(data["code_url"]), sig_url=str(data["sig_url"]),
                   size_mb=max(1, int(data.get("size_mb") or 1)))
    return out


def _from_release(data) -> dict | None:
    if not isinstance(data, dict) or not data.get("tag_name"):
        return None
    assets = [a for a in data.get("assets") or [] if isinstance(a, dict)]
    exe = next((a.get("browser_download_url") for a in assets
                if str(a.get("name", "")).lower().endswith(".exe")), "")
    # (15 Nov) chhota code update: sea-clips-code-<v>.zip + .sig (dastakhat); sirf badla hua code
    code = next((a for a in assets if str(a.get("name", "")).lower().startswith("sea-clips-code-")
                 and str(a.get("name", "")).lower().endswith(".zip")), None)
    sig = next((a for a in assets if code and str(a.get("name", "")) == str(code.get("name", "")) + ".sig"), None)
    out = {"version": str(data["tag_name"]).lstrip("vV"), "notes": str(data.get("body") or "")[:3000],
           "url": exe or "", "page": str(data.get("html_url") or "")}
    if code and sig:
        out.update(code_url=str(code.get("browser_download_url") or ""),
                   sig_url=str(sig.get("browser_download_url") or ""),
                   size_mb=max(1, round(int(code.get("size") or 0) / 1_048_576)))
    return out


def check_update(local_version: str, repo: str, fetch=None) -> dict | None:
    """Naya version ho to us ki info (aur bell notification), warna None."""
    try:
        rel = latest_release(repo, fetch)
    except Exception as exc:  # noqa: BLE001 - internet nahi: kuch nahi
        log.info("update check skipped: %s", exc)
        return None
    if not rel or not is_newer(rel["version"], local_version):
        return None
    add_notification("update", f"New version {rel['version']} is available (Settings > Updates).",
                     key=f"update:{rel['version']}")
    return rel
