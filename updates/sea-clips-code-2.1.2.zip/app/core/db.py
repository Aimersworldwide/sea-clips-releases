"""
=====================================================================
  CORE / DATABASE  (SQLite)
  Kaam: database: campaigns, clip numbers, clips ki history, deliveries.
  The single record of truth. Folders, numbering, sheets and the
  delivery tracker all read from here, so they can never disagree.

  Tables
    campaigns   - one row per campaign, profile stored as JSON
    counters    - running clip number per campaign + laptop code
    clips       - every clip ever made (number, times, score, file)
    deliveries  - who received which clips and when
  Safety
    * WAL mode (no corruption on power cut)
    * one short-lived connection per call (thread safe)
    * schema version in PRAGMA user_version for future upgrades
=====================================================================
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterator

from app.core.config import CampaignProfile
from app.core.paths import database_path

SCHEMA_VERSION = 3
_LOCK = threading.RLock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS campaigns (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE COLLATE NOCASE,
    profile     TEXT NOT NULL,
    hidden      INTEGER NOT NULL DEFAULT 0,  -- "deleted" campaigns are hidden, never erased
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS counters (
    campaign_id INTEGER NOT NULL,
    device_code TEXT    NOT NULL,
    next_number INTEGER NOT NULL DEFAULT 1,
    batch_label TEXT    NOT NULL DEFAULT '',
    PRIMARY KEY (campaign_id, device_code)
);
CREATE TABLE IF NOT EXISTS clips (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id   INTEGER NOT NULL,
    label         TEXT    NOT NULL,          -- e.g. Debate_A_001
    number        INTEGER NOT NULL,
    device_code   TEXT    NOT NULL,
    batch_label   TEXT    NOT NULL DEFAULT '',
    source_path   TEXT    NOT NULL,
    source_hash   TEXT    NOT NULL,
    moment_id     TEXT    NOT NULL,
    version       INTEGER NOT NULL,
    block         INTEGER NOT NULL,
    start_sec     REAL    NOT NULL,
    end_sec       REAL    NOT NULL,
    duration      REAL    NOT NULL DEFAULT 0, -- final clip length after silence cuts
    score         INTEGER NOT NULL,
    score_reasons TEXT    NOT NULL DEFAULT '',
    rating        TEXT    NOT NULL,          -- recommended | medium | below
    file_path     TEXT    NOT NULL,
    style         TEXT    NOT NULL DEFAULT '{}',
    fingerprint   TEXT    NOT NULL DEFAULT '',
    beeps         INTEGER NOT NULL DEFAULT 0,
    repaired      INTEGER NOT NULL DEFAULT 0,
    delivered_to  TEXT    NOT NULL DEFAULT '',
    delivered_at  TEXT    NOT NULL DEFAULT '',
    created_at    TEXT    NOT NULL,
    deleted_at    TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_clips_campaign ON clips(campaign_id, number);
CREATE INDEX IF NOT EXISTS idx_clips_source ON clips(source_hash, start_sec, end_sec);
CREATE TABLE IF NOT EXISTS deliveries (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id INTEGER NOT NULL,
    receiver    TEXT    NOT NULL,
    clip_count  INTEGER NOT NULL,
    first_label TEXT    NOT NULL,
    last_label  TEXT    NOT NULL,
    created_at  TEXT    NOT NULL
);
"""


# (table, column, definition) added after schema v1 shipped to testers.
_ADDED_COLUMNS = (
    ("campaigns", "hidden", "hidden INTEGER NOT NULL DEFAULT 0"),
    ("clips", "duration", "duration REAL NOT NULL DEFAULT 0"),
    ("clips", "deleted_at", "deleted_at TEXT NOT NULL DEFAULT ''"),   # v3: clip laptop se hat gaya (history baaki)
    ("clips", "drive_id", "drive_id TEXT NOT NULL DEFAULT ''"),       # (18 Nov) clip Google Drive ke Clip Pool mein
    ("clips", "drive_at", "drive_at TEXT NOT NULL DEFAULT ''"),
)


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


@dataclass
class ClipRecord:
    id: int
    campaign_id: int
    label: str
    number: int
    rating: str
    score: int
    file_path: str
    start_sec: float
    end_sec: float
    duration: float
    batch_label: str
    moment_id: str
    delivered_to: str
    delivered_at: str
    source_path: str
    score_reasons: str
    beeps: int
    repaired: int
    created_at: str
    deleted_at: str = ""
    style: str = "{}"
    drive_id: str = ""
    drive_at: str = ""

    @property
    def extra(self) -> dict:
        """style JSON (edit choices, tag, rules report)."""
        try:
            d = json.loads(self.style or "{}")
            return d if isinstance(d, dict) else {}
        except ValueError:
            return {}

    @property
    def deleted(self) -> bool:
        return bool(self.deleted_at)

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> "ClipRecord":
        keys = row.keys()
        return cls(**{k: row[k] for k in cls.__dataclass_fields__ if k in keys})


class Database:
    """Thin, explicit wrapper. Every public method is one transaction."""

    def __init__(self, path: Path | None = None):
        self.path = Path(path or database_path())
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._migrate()

    # --- connection ---------------------------------------------------
    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        with _LOCK:
            conn = sqlite3.connect(self.path, timeout=30)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            try:
                yield conn
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()

    def _migrate(self) -> None:
        with self._conn() as c:
            version = c.execute("PRAGMA user_version").fetchone()[0]
            if version < 1:
                c.executescript(_SCHEMA)
            # v2: columns added after the first test builds. Adding only what
            # is missing makes this safe to run on any older database.
            for table, column, ddl in _ADDED_COLUMNS:
                have = {r["name"] for r in c.execute(f"PRAGMA table_info({table})")}
                if column not in have:
                    c.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")
            if version < SCHEMA_VERSION:
                c.execute(f"PRAGMA user_version={SCHEMA_VERSION}")

    # --- campaigns ----------------------------------------------------
    def create_campaign(self, profile: CampaignProfile) -> int:
        """
        New campaign. If a campaign with this name was deleted before, it
        is brought back (same id), so its clip numbering continues and a
        label like Debate_A_001 can never be made twice.
        """
        name = profile.name.strip()
        with self._conn() as c:
            row = c.execute("SELECT id FROM campaigns WHERE name=? AND hidden=1", (name,)).fetchone()
            if row:
                c.execute("UPDATE campaigns SET hidden=0, name=?, profile=?, updated_at=? WHERE id=?",
                          (name, json.dumps(profile.to_dict()), _now(), row["id"]))
                return int(row["id"])
            cur = c.execute(
                "INSERT INTO campaigns(name, profile, created_at, updated_at) VALUES(?,?,?,?)",
                (name, json.dumps(profile.to_dict()), _now(), _now()),
            )
            return int(cur.lastrowid)

    def update_campaign(self, campaign_id: int, profile: CampaignProfile) -> None:
        with self._conn() as c:
            c.execute(
                "UPDATE campaigns SET name=?, profile=?, updated_at=? WHERE id=?",
                (profile.name.strip(), json.dumps(profile.to_dict()), _now(), campaign_id),
            )

    def get_campaign(self, campaign_id: int) -> CampaignProfile | None:
        with self._conn() as c:
            row = c.execute("SELECT profile FROM campaigns WHERE id=?", (campaign_id,)).fetchone()
        return CampaignProfile.from_dict(json.loads(row["profile"])) if row else None

    def find_campaign(self, name: str, include_hidden: bool = False) -> int | None:
        sql = "SELECT id FROM campaigns WHERE name=?" + ("" if include_hidden else " AND hidden=0")
        with self._conn() as c:
            row = c.execute(sql, (name.strip(),)).fetchone()
        return int(row["id"]) if row else None

    def ensure_campaign(self, name: str) -> int:
        existing = self.find_campaign(name)
        return existing if existing is not None else self.create_campaign(CampaignProfile(name=name))

    def list_campaigns(self) -> list[tuple[int, str]]:
        with self._conn() as c:
            rows = c.execute("SELECT id, name FROM campaigns WHERE hidden=0 ORDER BY name").fetchall()
        return [(int(r["id"]), r["name"]) for r in rows]

    def delete_campaign(self, campaign_id: int) -> None:
        """Hides the campaign. Clips, numbering and files are all kept."""
        with self._conn() as c:
            c.execute("UPDATE campaigns SET hidden=1, updated_at=? WHERE id=?", (_now(), campaign_id))

    def purge_campaign_clips(self, campaign_id: int) -> None:
        """TEST TOOL ONLY: forget every clip, number and delivery of a
        campaign so the same source can be clipped again from scratch.
        The app itself never calls this (real clips are never forgotten)."""
        with self._conn() as c:
            for table in ("clips", "counters", "deliveries"):
                c.execute(f"DELETE FROM {table} WHERE campaign_id=?", (campaign_id,))

    # --- numbering ----------------------------------------------------
    def reserve_numbers(self, campaign_id: int, device_code: str, count: int) -> tuple[list[int], str]:
        """Atomically reserve `count` clip numbers. Returns (numbers, batch_label)."""
        with self._conn() as c:
            c.execute("BEGIN IMMEDIATE")      # write lock first: no two reservations can interleave
            row = c.execute(
                "SELECT next_number, batch_label FROM counters WHERE campaign_id=? AND device_code=?",
                (campaign_id, device_code),
            ).fetchone()
            start, batch = (int(row["next_number"]), row["batch_label"]) if row else (1, "")
            c.execute(
                "INSERT INTO counters(campaign_id, device_code, next_number, batch_label) VALUES(?,?,?,?) "
                "ON CONFLICT(campaign_id, device_code) DO UPDATE SET next_number=excluded.next_number",
                (campaign_id, device_code, start + count, batch),
            )
        return list(range(start, start + count)), batch

    def current_batch(self, campaign_id: int, device_code: str) -> str:
        """Batch folder label in use ('' until numbering is reset once)."""
        with self._conn() as c:
            row = c.execute("SELECT batch_label FROM counters WHERE campaign_id=? AND device_code=?",
                            (campaign_id, device_code)).fetchone()
        return row["batch_label"] if row else ""

    def peek_next_number(self, campaign_id: int, device_code: str) -> int:
        with self._conn() as c:
            row = c.execute(
                "SELECT next_number FROM counters WHERE campaign_id=? AND device_code=?",
                (campaign_id, device_code),
            ).fetchone()
        return int(row["next_number"]) if row else 1

    def reset_numbering(self, campaign_id: int, device_code: str) -> str:
        """Start again from 001. A dated batch folder keeps old files safe."""
        batch = date.today().isoformat()
        with self._conn() as c:
            c.execute("BEGIN IMMEDIATE")
            existing = c.execute(
                "SELECT COUNT(*) FROM clips WHERE campaign_id=? AND device_code=? AND batch_label=?",
                (campaign_id, device_code, batch),
            ).fetchone()[0]
            if existing:   # reset twice on the same day -> suffix
                batch = f"{batch}_{datetime.now():%H%M%S}"
            c.execute(
                "INSERT INTO counters(campaign_id, device_code, next_number, batch_label) VALUES(?,?,1,?) "
                "ON CONFLICT(campaign_id, device_code) DO UPDATE SET next_number=1, batch_label=excluded.batch_label",
                (campaign_id, device_code, batch),
            )
        return batch

    # --- clips --------------------------------------------------------
    def add_clip(self, **values: Any) -> int:
        values.setdefault("created_at", _now())
        cols = ", ".join(values)
        marks = ", ".join("?" for _ in values)
        with self._conn() as c:
            cur = c.execute(f"INSERT INTO clips({cols}) VALUES({marks})", tuple(values.values()))
            return int(cur.lastrowid)

    def update_clip(self, clip_id: int, **values: Any) -> None:
        sets = ", ".join(f"{k}=?" for k in values)
        with self._conn() as c:
            c.execute(f"UPDATE clips SET {sets} WHERE id=?", (*values.values(), clip_id))

    def clips_for_campaign(self, campaign_id: int | None, rating: str | None = None,
                           undelivered_only: bool = False, state: str = "present") -> list[ClipRecord]:
        """state: present (laptop pe), deleted (sirf history), all. campaign_id None = sab campaigns."""
        sql = "SELECT * FROM clips WHERE 1=1"
        args: list[Any] = []
        if campaign_id is not None:
            sql += " AND campaign_id=?"
            args.append(campaign_id)
        if state == "present":
            sql += " AND deleted_at=''"
        elif state == "deleted":
            sql += " AND deleted_at<>''"
        if rating:
            sql += " AND rating=?"
            args.append(rating)
        if undelivered_only:
            sql += " AND delivered_to=''"
        sql += " ORDER BY campaign_id, number"
        with self._conn() as c:
            return [ClipRecord.from_row(r) for r in c.execute(sql, args).fetchall()]

    # --- delete aur folder sync (history hamesha baaki) ------------------
    def mark_deleted(self, clip_ids: list[int]) -> int:
        """Clips 'Deleted' history mein (file pehle hi hat chuki / hata di gayi)."""
        if not clip_ids:
            return 0
        marks = ",".join("?" for _ in clip_ids)
        with self._conn() as c:
            cur = c.execute(f"UPDATE clips SET deleted_at=? WHERE id IN ({marks}) AND deleted_at=''",
                            (_now(), *clip_ids))
            return cur.rowcount

    def sync_missing_files(self, campaign_id: int | None = None) -> int:
        """Jo clip file laptop pe nahi rahi (haath se delete), us ko Deleted history mein daal do."""
        missing = [c.id for c in self.clips_for_campaign(campaign_id, state="present")
                   if not Path(c.file_path).exists()]
        return self.mark_deleted(missing)

    def campaign_names(self, include_hidden: bool = True) -> dict[int, str]:
        sql = "SELECT id, name FROM campaigns" + ("" if include_hidden else " WHERE hidden=0")
        with self._conn() as c:
            return {int(r["id"]): r["name"] for r in c.execute(sql).fetchall()}

    def count_from_source(self, campaign_id: int, source_hash: str) -> int:
        """Is campaign mein is video se ab tak kitne clips bane (phases ke liye)."""
        with self._conn() as c:
            row = c.execute("SELECT COUNT(*) FROM clips WHERE campaign_id=? AND source_hash=?",
                            (campaign_id, source_hash)).fetchone()
        return int(row[0]) if row else 0

    def used_windows(self, source_hash: str, since: str = "") -> list[tuple[float, float, str]]:
        """Every (start, end, fingerprint) already made from this source (since = sirf is waqt ke baad wale)."""
        with self._conn() as c:
            rows = c.execute(
                "SELECT start_sec, end_sec, fingerprint FROM clips WHERE source_hash=? AND created_at >= ? ORDER BY id",
                (source_hash, since or "")).fetchall()
        return [(float(r[0]), float(r[1]), r[2]) for r in rows]

    def made_edits(self, source_hash: str) -> list[tuple[float, float, str]]:
        """(start, end, style json) of every clip made from this source."""
        with self._conn() as c:
            rows = c.execute("SELECT start_sec, end_sec, style FROM clips WHERE source_hash=? ORDER BY id",
                             (source_hash,)).fetchall()
        return [(float(r[0]), float(r[1]), r[2] or "") for r in rows]

    def campaign_counts(self, campaign_id: int) -> dict[str, int]:
        with self._conn() as c:
            rows = c.execute(
                "SELECT rating, COUNT(*) n, SUM(delivered_to<>'') d FROM clips "
                "WHERE campaign_id=? AND deleted_at='' GROUP BY rating",
                (campaign_id,),
            ).fetchall()
        out = {"recommended": 0, "medium": 0, "below": 0, "check": 0, "made": 0, "delivered": 0}
        for r in rows:
            out[r["rating"]] = int(r["n"])
            out["made"] += int(r["n"])
            out["delivered"] += int(r["d"] or 0)
        out["remaining"] = out["made"] - out["delivered"]
        return out

    # --- deliveries ---------------------------------------------------
    def record_delivery(self, campaign_id: int, receiver: str, clip_ids: list[int]) -> int:
        if not clip_ids:
            raise ValueError("No clips selected for delivery")
        stamp = _now()
        with self._conn() as c:
            marks = ",".join("?" for _ in clip_ids)
            labels = [r[0] for r in c.execute(
                f"SELECT label FROM clips WHERE id IN ({marks}) ORDER BY number", clip_ids).fetchall()]
            c.execute(
                f"UPDATE clips SET delivered_to=?, delivered_at=? WHERE id IN ({marks}) AND delivered_to=''",
                (receiver, stamp, *clip_ids),
            )
            cur = c.execute(
                "INSERT INTO deliveries(campaign_id, receiver, clip_count, first_label, last_label, created_at) "
                "VALUES(?,?,?,?,?,?)",
                (campaign_id, receiver, len(clip_ids), labels[0], labels[-1], stamp),
            )
            return int(cur.lastrowid)

    def delivery_history(self, campaign_id: int) -> list[dict[str, Any]]:
        with self._conn() as c:
            rows = c.execute(
                "SELECT * FROM deliveries WHERE campaign_id=? ORDER BY id DESC", (campaign_id,)
            ).fetchall()
        return [dict(r) for r in rows]
