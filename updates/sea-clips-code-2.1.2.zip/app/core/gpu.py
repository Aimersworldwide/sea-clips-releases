"""
=====================================================================
  CORE / GPU CHECK
  Kaam: pata karta hai ke is laptop pe NVIDIA GPU hai ya nahi, aur
  ffmpeg us se video encode (NVENC) aur decode (CUDA) kar sakta hai
  ya nahi. Har check sirf ek dafa chalta hai (cache), phir yaad rehta
  hai. GPU na ho to sab False, aur tool CPU pe wahi kaam karta hai.
=====================================================================
"""
from __future__ import annotations

import os

import subprocess
import sys
from functools import lru_cache

from app.core.logging_setup import get_logger

log = get_logger("gpu")

_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


# ---------------------------------------------------------------------
#  Chhota sa ffmpeg test chalao (1 frame), kamyab hua to True
# ---------------------------------------------------------------------
def _ffmpeg_ok(args: list[str], timeout: float = 20.0) -> bool:
    try:
        from app.media.ffmpeg_tools import ffmpeg_bin
        proc = subprocess.run([ffmpeg_bin(), "-hide_banner", "-loglevel", "error", *args],
                              capture_output=True, timeout=timeout, creationflags=_NO_WINDOW)
        if proc.returncode != 0:
            err = proc.stderr.decode("utf-8", "replace").strip().splitlines()[:15]   # poori wajah (pehli lines asal hoti hain)
            log.info("GPU test failed: %s", " | ".join(err))
        return proc.returncode == 0
    except Exception as exc:  # noqa: BLE001 - koi bhi masla = GPU nahi
        log.info("GPU test failed: %s", exc)
        return False


# ---------------------------------------------------------------------
#  NVENC: GPU se encoding ("GPU Fast encoding" option ke liye)
# ---------------------------------------------------------------------
@lru_cache(maxsize=1)
def nvenc_available() -> bool:
    ok = _ffmpeg_ok(["-f", "lavfi", "-i", "color=c=black:s=256x256:d=0.2", "-frames:v", "2",
                     "-c:v", "h264_nvenc", "-f", "null", "-"])
    log.info("NVENC encoder %s", "found" if ok else "not available")
    return ok


# ---------------------------------------------------------------------
#  CUDA decode: GPU se video parhna (quality pe koi asar nahi)
# ---------------------------------------------------------------------
#  NVENC chalta hai to CUDA bhi hai (dono NVIDIA ke hain). Agar kisi video
#  pe GPU decode fail ho, renderer khud CPU decode se dobara chala leta hai.
_DEC: bool | None = None


def cuda_decode_available() -> bool:
    """
    (16 Nov) GPU se video PARHNA (NVDEC) encoder se alag hai: purane driver par
    NVENC na chale tab bhi aksar chalta hai. Asal test: ek chhota H.264 bana kar
    GPU se parho aur CPU wale frames se milao (bilkul same hon tabhi haan).
    """
    global _DEC
    if _DEC is not None:
        return _DEC
    _DEC = False
    try:
        import hashlib
        import subprocess
        import tempfile
        from app.media.ffmpeg_tools import ffmpeg_bin
        ff = str(ffmpeg_bin())
        flags = 0x08000000 if os.name == "nt" else 0
        with tempfile.TemporaryDirectory() as td:
            src = os.path.join(td, "t.mp4")
            subprocess.run([ff, "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=640x360:r=30:d=1",
                            "-c:v", "libx264", "-pix_fmt", "yuv420p", src], check=True, timeout=60,
                           capture_output=True, creationflags=flags)

            def frames(hw: bool) -> str:
                args = [ff, "-v", "error", *(["-hwaccel", "cuda"] if hw else []), "-i", src,
                        "-f", "rawvideo", "-pix_fmt", "yuv420p", "-"]
                out = subprocess.run(args, check=True, timeout=60, capture_output=True, creationflags=flags)
                return hashlib.sha1(out.stdout).hexdigest() if out.stdout else ""

            cpu, gpu = frames(False), frames(True)
            _DEC = bool(cpu) and cpu == gpu
        log.info("GPU video decode %s", "available (frames identical to CPU)" if _DEC else "not available")
    except Exception as exc:  # noqa: BLE001
        log.info("GPU video decode not available: %s", str(exc)[:200])
        _DEC = False
    return _DEC


# ---------------------------------------------------------------------
#  Kya laptop pe GPU hai? (Settings mein switch on/grey karne ke liye)
# ---------------------------------------------------------------------
def has_gpu() -> bool:
    return nvenc_available()
