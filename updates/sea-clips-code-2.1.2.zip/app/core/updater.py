"""
=====================================================================
  CORE / UPDATER            (auto update: sirf badla hua code)
  Kaam: naya version aaye to chhota code pack (kuch MB) download,
  AIMERS ka dastakhat check, app band, naya code lagao, app dobara
  khulo. Campaigns, photos, clips, settings: sab waise hi.
  Flow:
    1. release on GitHub has sea-clips-code-<v>.zip and its .sig
    2. download both into the cache, verify the Ed25519 signature
       with the public key below (a fake or broken file is refused)
    3. unpack to a staging folder and check it is a real app folder
    4. a tiny helper (copied to temp) waits for the app to close,
       copies the new files over the app folder (old ones kept in
       updates/backup), then starts the app again
  Models, the Python runtime and ffmpeg are not in the code pack, so a
  normal update stays small. User data lives in app data, never in
  the app folder, so an update cannot touch it.
=====================================================================
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable

from app.core import ed25519
from app.core.logging_setup import get_logger
from app.core.paths import cache_dir, resource_root

log = get_logger("updater")

PUBLIC_KEY = bytes.fromhex("b4d09a1375c47b3b684477ea01474980f5a4e600c154a216fae035e39a1d57e6")
# code pack mein sirf ye cheezen; models / .venv / ffmpeg kabhi nahi
PACK_ROOTS = ("app", "assets", "requirements.txt", "requirements-ocr.txt", "requirements-gpu.txt")
NEVER_PACK = ("assets/models/",)
MAX_PACK_MB = 400


class UpdateError(RuntimeError):
    pass


def _get(url: str, dest: Path, on_progress: Callable[[float], None] | None = None) -> Path:
    req = urllib.request.Request(url, headers={"User-Agent": "SEA-CLIPS-Auto-Clipper"})
    with urllib.request.urlopen(req, timeout=60) as r:      # noqa: S310 - https GitHub links from the release
        total = int(r.headers.get("Content-Length") or 0)
        if total > MAX_PACK_MB * 1_048_576:
            raise UpdateError("Update file is too big.")
        got = 0
        tmp = dest.with_suffix(dest.suffix + ".part")
        with open(tmp, "wb") as f:
            while True:
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if on_progress and total:
                    on_progress(min(1.0, got / total))
    tmp.replace(dest)
    return dest


def verify_pack(zip_path: Path, sig_text: str) -> bool:
    """Dastakhat: zip ke sha512 par (file kitni bhi bari ho, ek hi chhota check)."""
    try:
        sig = bytes.fromhex(sig_text.strip())
    except ValueError:
        return False
    digest = hashlib.sha512(zip_path.read_bytes()).digest()
    return ed25519.verify(PUBLIC_KEY, digest, sig)


def download(rel: dict, on_progress: Callable[[float], None] | None = None) -> Path:
    """Code pack download + dastakhat check. Returns the verified zip."""
    if not rel.get("code_url") or not rel.get("sig_url"):
        raise UpdateError("This release has no small update pack.")
    folder = cache_dir() / "updates"
    folder.mkdir(parents=True, exist_ok=True)
    zp = folder / f"sea-clips-code-{rel['version']}.zip"
    sp = folder / (zp.name + ".sig")
    _get(rel["sig_url"], sp)
    _get(rel["code_url"], zp, on_progress)
    if not verify_pack(zp, sp.read_text(encoding="utf-8", errors="ignore")):
        zp.unlink(missing_ok=True)
        raise UpdateError("The update file is not signed by AIMERS Worldwide, so it was not installed.")
    return zp


def stage(zip_path: Path) -> Path:
    """Zip ko alag folder mein kholo aur check karo ke andar sahi app hai."""
    out = zip_path.with_suffix("")
    if out.exists():
        shutil.rmtree(out, ignore_errors=True)
    with zipfile.ZipFile(zip_path) as z:
        for name in z.namelist():
            norm = name.replace("\\", "/")
            if norm.startswith("/") or ".." in norm.split("/"):
                raise UpdateError("Update file has a bad path.")
            if not norm.split("/")[0] in PACK_ROOTS:
                raise UpdateError("Update file has unexpected content.")
        z.extractall(out)
    if not (out / "app" / "main.py").is_file() or not (out / "app" / "version.py").is_file():
        raise UpdateError("Update file is incomplete.")
    return out


HELPER = r'''
import os, shutil, subprocess, sys, time
staged, root, pid, py = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4]
for _ in range(240):                       # app band hone ka intezaar (max 2 minute)
    try:
        if os.name == "nt":
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x100000, False, pid)
            if not h:
                break
            r = ctypes.windll.kernel32.WaitForSingleObject(h, 0)
            ctypes.windll.kernel32.CloseHandle(h)
            if r == 0:
                break
        else:
            os.kill(pid, 0)
    except OSError:
        break
    time.sleep(0.5)
time.sleep(1.0)
backup = os.path.join(os.path.dirname(staged), "backup")
shutil.rmtree(backup, ignore_errors=True)
for name in os.listdir(staged):
    src, dst = os.path.join(staged, name), os.path.join(root, name)
    if os.path.exists(dst) and name == "app":
        shutil.copytree(dst, os.path.join(backup, name), dirs_exist_ok=True)
    if os.path.isdir(src):
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src, dst)
flags = 0x00000008 if os.name == "nt" else 0
subprocess.Popen([py, "-m", "app.main"], cwd=root, creationflags=flags, close_fds=True)
'''


def apply_and_restart(staged: Path) -> None:
    """Helper chalao (temp se) aur app band karne ke liye tayyar. Caller app quit kare."""
    helper = staged.parent / "apply_update.py"
    helper.write_text(HELPER, encoding="utf-8")
    py = sys.executable
    if os.name == "nt" and py.lower().endswith("python.exe"):
        cand = Path(py).with_name("pythonw.exe")
        py = str(cand) if cand.exists() else py
    flags = (0x00000008 | 0x00000200) if os.name == "nt" else 0     # detached, own group
    subprocess.Popen([py, str(helper), str(staged), str(resource_root()), str(os.getpid()), py],
                     cwd=str(staged.parent), creationflags=flags, close_fds=True)
    log.info("Update helper started for %s", staged)


# ---------------------------------------------------------------------
#  Release banane wala hissa (developer ki taraf, app ke andar istemal nahi)
# ---------------------------------------------------------------------
def build_pack(root: Path, out_dir: Path, version: str, secret_hex: str) -> tuple[Path, Path]:
    """App folder se sea-clips-code-<v>.zip aur .sig banao."""
    out_dir.mkdir(parents=True, exist_ok=True)
    zp = out_dir / f"sea-clips-code-{version}.zip"
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for top in PACK_ROOTS:
            base = root / top
            files = [base] if base.is_file() else sorted(p for p in base.rglob("*") if p.is_file()) \
                if base.exists() else []
            for f in files:
                rel = f.relative_to(root).as_posix()
                if "__pycache__" in rel or rel.endswith(".pyc") or any(rel.startswith(n) for n in NEVER_PACK):
                    continue
                z.write(f, rel)
    digest = hashlib.sha512(zp.read_bytes()).digest()
    sig = ed25519.sign(bytes.fromhex(secret_hex.strip()), digest).hex()
    sp = out_dir / (zp.name + ".sig")
    sp.write_text(sig, encoding="utf-8")
    (out_dir / "release.json").write_text(json.dumps({"version": version, "zip": zp.name,
                                                      "size": zp.stat().st_size}), encoding="utf-8")
    return zp, sp
