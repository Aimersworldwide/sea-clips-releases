"""
=====================================================================
  UI / UPDATER              ("Update now" dabane par)
  Kaam: chhota progress window, update download aur check, phir app
  khud band ho kar naye version ke saath dobara khulti hai.
  Download runs on a thread so the window never freezes. If the
  release has no small code pack, its page opens in the browser.
=====================================================================
"""
from __future__ import annotations

import threading

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtWidgets import QApplication, QProgressDialog

from app.ui.context import open_path
from app.ui.pages.common import warn


class _Bridge(QObject):
    progress = Signal(float)
    done = Signal(object, str)        # staged path or None, error text


def run_update(window, rel: dict) -> None:
    if not rel.get("code_url"):
        open_path(rel.get("page") or rel.get("url", ""))
        return
    box = QProgressDialog(f"Downloading update {rel['version']}...", "", 0, 100, window)
    box.setWindowTitle("SEA CLIPS update")
    box.setCancelButton(None)
    box.setWindowModality(Qt.WindowModal)
    box.setMinimumDuration(0)
    box.setValue(0)
    bridge = _Bridge(window)
    bridge.progress.connect(lambda v: box.setValue(int(v * 100)))

    def work() -> None:
        from app.core import updater
        try:
            zp = updater.download(rel, bridge.progress.emit)
            staged = updater.stage(zp)
            bridge.done.emit(staged, "")
        except Exception as exc:  # noqa: BLE001 - shown to the user
            bridge.done.emit(None, str(exc))

    def finished(staged, error: str) -> None:
        box.close()
        if staged is None:
            warn(window, f"The update could not be installed.\n\n{error}\n\nThe tool keeps working as it is.")
            return
        from app.core import updater
        window.ctx.queue.shutdown()              # chalti video mehfooz rukti hai, update ke baad wahin se
        updater.apply_and_restart(staged)
        window._closing_ok = True
        QApplication.instance().quit()

    bridge.done.connect(finished)
    threading.Thread(target=work, daemon=True).start()
