"""
=====================================================================
  UI / PACKAGE UPDATE        (app ke andar "Update" window)
  Kaam: app khulte hi missing hisse dikhe to yahan khud install hon:
  progress bar, ek line ki khabar, aur aakhir mein "ho gaya". Kuch bhi
  na chale (internet nahi) to app phir bhi chalti hai, agli dafa
  khulne par phir koshish.
=====================================================================
"""
from __future__ import annotations

import importlib
import logging

from PySide6.QtCore import QProcess, Qt, QTimer
from PySide6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from app.core import packages
from app.core.i18n import t
from app.ui.widgets import GoldProgress

log = logging.getLogger("aimers.packages")


class PackageUpdateDialog(QDialog):
    def __init__(self, groups, parent=None):
        super().__init__(parent)
        self.setWindowTitle(t("pkg.title"))
        self.setModal(True)
        self.setMinimumWidth(460)
        self.setWindowFlag(Qt.WindowCloseButtonHint, False)
        self._cmds = packages.pip_commands(groups)
        self._total = len(self._cmds)
        self._done = 0
        self._value = 0.0
        self.ok = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 22, 24, 20)
        lay.setSpacing(12)
        self.head = QLabel(t("pkg.working"))
        self.head.setWordWrap(True)
        self.bar = GoldProgress()
        self.status = QLabel("")
        self.status.setStyleSheet("color: #9A9282; font-size: 9pt;")
        self.status.setWordWrap(True)
        lay.addWidget(self.head)
        lay.addWidget(self.bar)
        lay.addWidget(self.status)
        row = QHBoxLayout()
        row.addStretch(1)
        self.close_btn = QPushButton(t("pkg.close"))
        self.close_btn.clicked.connect(self.accept)
        self.close_btn.hide()
        row.addWidget(self.close_btn)
        lay.addLayout(row)
        self._creep = QTimer(self)
        self._creep.timeout.connect(self._tick)
        self._proc: QProcess | None = None
        self._quiet = 0
        QTimer.singleShot(200, self._next)

    # ---- chalna -----------------------------------------------------------
    def _tick(self) -> None:
        # pip apni raftaar nahi batata: har qadam ke andar dheere dheere aage, kabhi poora nahi
        lo = self._done / self._total
        hi = (self._done + 0.92) / self._total
        self._value = min(hi, self._value + (hi - self._value) * 0.04)
        self.bar.setValue(max(lo, self._value))
        self._quiet += 1
        if self._quiet == 60:                          # 15 sec se pip chup: dheema internet, kaam jaari
            self.status.setText(self.status.text() + "   " + t("pkg.slow"))

    def _next(self) -> None:
        if self._done >= self._total:
            self._finish(True)
            return
        self._proc = QProcess(self)
        self._proc.setProcessChannelMode(QProcess.MergedChannels)
        self._proc.readyReadStandardOutput.connect(self._read)
        self._proc.finished.connect(self._step_done)
        self._proc.errorOccurred.connect(lambda _e: self._finish(False, self._proc.errorString()))
        self._creep.start(250)
        log.info("Installing missing packages: %s", " ".join(self._cmds[self._done]))
        self._proc.start(packages.python_exe(), self._cmds[self._done])

    def _read(self) -> None:
        text = bytes(self._proc.readAllStandardOutput()).decode("utf-8", "ignore")
        for line in text.splitlines():
            line = line.strip()
            if line:
                self._quiet = 0
                log.info("pip: %s", line[:200])
                if line.startswith(("Collecting", "Downloading", "Installing", "Successfully")):
                    self.status.setText(line[:90])

    def _step_done(self, code: int, _status) -> None:
        if code != 0:
            self._finish(False, f"pip exit code {code}")
            return
        self._done += 1
        self._value = self._done / self._total
        self.bar.setValue(self._value)
        self._next()

    def _finish(self, ok: bool, why: str = "") -> None:
        if self.close_btn.isVisible():
            return                                    # pehle hi khatam
        self._creep.stop()
        self.ok = ok
        importlib.invalidate_caches()                 # naye packages isi chalti app mein mil jayein
        if ok:
            self.bar.setValue(1.0)
            self.head.setText(t("pkg.done"))
            self.status.setText("")
            log.info("Missing packages installed")
            QTimer.singleShot(1800, self.accept)
        else:
            log.warning("Package update failed: %s", why)
            self.head.setText(t("pkg.failed"))
            self.status.setText(why[:120])
        self.close_btn.show()


def check_and_update(parent) -> None:
    """App khulne ke baad: kuch missing ho to Update window (warna kuch nahi dikhta)."""
    import os
    if os.environ.get("AIMERS_NO_BACKGROUND"):          # tests: koi install nahi
        return
    try:
        groups = packages.missing()
    except Exception as exc:  # noqa: BLE001 - check hi na ho sake to app chalti rahe
        log.warning("Package check skipped: %s", exc)
        return
    if groups:
        PackageUpdateDialog(groups, parent).exec()
