"""
=====================================================================
  UI / WORKER
  Kaam: kaam peeche thread pe (window kabhi na ruke), queue aur preview.
  Runs the pipeline on a background thread so the window never
  freezes. Everything the pipeline reports comes back as Qt signals.
  Also makes a small thumbnail for each finished clip.
  Queue: several links run one after another (e.g. overnight); one
  failed link is reported and the next one still runs. Preview pack:
  the pipeline asks for OK / Cancel through `preview`, the page
  answers with answer_preview().
=====================================================================
"""
from __future__ import annotations

import threading
import traceback
from pathlib import Path

from PySide6.QtCore import QObject, QThread, Signal

from app.core.config import AppSettings
from app.core.db import Database
from app.core.logging_setup import get_logger
from app.core.paths import temp_dir
from app.media.download import DownloadError
from app.media.ffmpeg_tools import ffmpeg_bin, run
from app.pipeline.runner import Events, JobRequest, Pipeline, PipelineError, PreviewGate, RunSummary

log = get_logger("worker")


def make_thumbnail(clip: Path, out: Path, width: int = 216) -> Path | None:
    try:
        run([ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-y", "-ss", "1.0", "-i", str(clip),
             "-frames:v", "1", "-vf", f"scale={width}:-2:flags=lanczos", "-q:v", "3", str(out)], timeout=60)
        return out if out.exists() else None
    except Exception as exc:  # noqa: BLE001 - thumbnail is cosmetic
        log.debug("thumbnail failed: %s", exc)
        return None


class PipelineWorker(QObject):
    stage = Signal(str)
    progress = Signal(float, str)
    clipDone = Signal(int, int, dict)
    warning = Signal(str, dict)
    logMessage = Signal(str)
    preview = Signal(list)                    # pehle 10 clips: OK / Cancel
    queueStep = Signal(int, int, str)         # (link number, total links, link)
    finished = Signal(object)                 # RunSummary (poori queue ka jor)
    failed = Signal(str, str, str)            # key, detail, traceback

    def __init__(self, settings: AppSettings, request):
        super().__init__()
        self.settings = settings
        self.requests: list[JobRequest] = list(request) if isinstance(request, (list, tuple)) else [request]
        self.request = self.requests[0]
        self.cancel_event = threading.Event()
        self.pause_event = threading.Event()
        self.gate = PreviewGate()
        self.link_errors: list[str] = []
        self._thumbs = temp_dir() / "thumbs"
        self._thumbs.mkdir(parents=True, exist_ok=True)

    def answer_preview(self, answer: str) -> None:
        self.gate.reply(answer)

    def _clip_done(self, done: int, total: int, info: dict) -> None:
        if info.get("file"):
            thumb = make_thumbnail(Path(info["file"]), self._thumbs / f"{info['label']}.jpg")
            info = dict(info, thumb=str(thumb) if thumb else "")
        self.clipDone.emit(done, total, info)

    # --- queue ke saare nateeje jama ----------------------------------
    @staticmethod
    def _add(total: RunSummary, one: RunSummary) -> None:
        total.requested += one.requested
        total.made += one.made
        for k, v in one.counts.items():
            total.counts[k] = total.counts.get(k, 0) + v
        total.repaired += one.repaired
        total.failed += one.failed
        total.max_good += one.max_good
        total.moments += one.moments
        total.folder = one.folder or total.folder
        total.seconds += one.seconds
        total.cancelled = total.cancelled or one.cancelled

    def run(self) -> None:
        events = Events(stage=self.stage.emit, progress=self.progress.emit, clip_done=self._clip_done,
                        warning=self.warning.emit, log=self.logMessage.emit, preview=self.preview.emit)
        total = RunSummary()
        last_error: tuple[str, str, str] | None = None
        try:
            db = Database()      # own connection on this thread
        except Exception as exc:  # noqa: BLE001
            self.failed.emit("msg.error", str(exc), traceback.format_exc())
            return
        n = len(self.requests)
        for i, req in enumerate(self.requests):
            if self.cancel_event.is_set():
                total.cancelled = True
                break
            self.request = req
            self.queueStep.emit(i + 1, n, req.source)
            try:
                one = Pipeline(self.settings, db, req, events, self.cancel_event, self.pause_event,
                               preview_gate=self.gate).run()
                self._add(total, one)
                if one.cancelled:
                    break
                continue
            except PipelineError as exc:
                log.warning("Pipeline stopped: %s %s", exc.key, exc.detail)
                last_error = (exc.key, exc.detail, "")
            except DownloadError as exc:
                last_error = ("msg.download_failed", str(exc), "")
            except Exception as exc:  # noqa: BLE001 - shown to the user, full trace in log
                log.exception("Unexpected error")
                last_error = ("msg.error", str(exc), traceback.format_exc())
            if n == 1:
                self.failed.emit(*last_error)
                return
            self.link_errors.append(f"{req.source}: {last_error[1] or last_error[0]}"[:300])
            self.logMessage.emit(f"Link {i + 1} of {n} could not be made: {last_error[1] or last_error[0]}")
        if n > 1 and total.made == 0 and last_error is not None and not total.cancelled:
            self.failed.emit(*last_error)
            return
        self.finished.emit(total)


def start_worker(worker: PipelineWorker) -> QThread:
    thread = QThread()
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    worker.finished.connect(thread.quit)
    worker.failed.connect(thread.quit)
    thread.start()
    return thread
