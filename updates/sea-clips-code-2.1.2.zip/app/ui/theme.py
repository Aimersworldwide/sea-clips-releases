"""
=====================================================================
  UI / THEME  ("Black Velvet")
  Kaam: app ka rang roop (Black Velvet).
  Deep black velvet background, warm gold foil accents, white text.
  All colours live here; widgets never hard-code a colour.
  Fonts: Montserrat (bundled), so text looks the same on every PC.
=====================================================================
"""
from __future__ import annotations

from PySide6.QtCore import QPointF
from PySide6.QtGui import QColor, QFont, QFontDatabase, QLinearGradient

from app.core.paths import resource

# --- colours -----------------------------------------------------------
BG_CENTER = "#1A140A"
BG_EDGE = "#0A0907"
SIDEBAR = "#0C0B08"
PANEL_TOP = "#14110B"
PANEL_BOTTOM = "#0F0D09"
INNER = "#0B0A07"
INNER_HOVER = "#17130B"
TEXT = "#ECE5D3"
MUTE = "#A99D82"
FAINT = "#8F846B"
GOLD = "#F3D993"
GOLD_DEEP = "#C4902F"
GOLD_LIGHT = "#F6E3A9"
GOLD_LINE = "#30291B"
GOLD_LINE_STRONG = "#6B5630"
DARK_ON_GOLD = "#1A1206"
OK_GREEN = "#5BD08A"
WARN = "#F2B84B"
ERROR = "#F07167"

# Foil stops copied from the approved mockup.
FOIL_STOPS = ((0.00, "#FFF6D8"), (0.22, "#F6DB98"), (0.48, "#D9AE58"),
              (0.56, "#B9862F"), (0.78, "#E9C779"), (1.00, "#FFF0C4"))
TITLE_STOPS = ((0.0, "#FFF3CF"), (0.45, "#E9C46A"), (0.62, "#C4923A"), (1.0, "#F3D58C"))
BORDER_STOPS = ((0.0, QColor(255, 240, 200, 190)), (0.30, QColor(185, 134, 47, 115)),
                (0.60, QColor(120, 85, 30, 46)), (1.0, QColor(230, 192, 114, 140)))

# --- fonts -------------------------------------------------------------
UI_FONT = "Manrope Medium"
UI_SEMI = "Manrope SemiBold"
UI_BOLD = "Manrope Bold"
UI_EXTRA = "Manrope ExtraBold"
SERIF = "Cormorant Garamond Bold"     # bade headings (SEA CLIPS 2.0 design)
LINE = "#2B2417"                    # panels ke kinare
PANEL = "#14110B"
_FONT_FILES = ("MontserratMedium.ttf", "MontserratSemiBold.ttf", "MontserratBold.ttf",
               "MontserratExtraBold.ttf", "ManropeMedium.ttf", "ManropeSemiBold.ttf", "ManropeBold.ttf",
               "ManropeExtraBold.ttf", "CormorantGaramondBold.ttf")


def load_fonts() -> None:
    for name in _FONT_FILES:
        QFontDatabase.addApplicationFont(str(resource("assets", "fonts", name)))


def font(size: float, family: str = UI_FONT, spacing: float = 0.0) -> QFont:
    f = QFont(family)
    f.setPointSizeF(size)
    f.setHintingPreference(QFont.PreferNoHinting)
    f.setStyleStrategy(QFont.PreferAntialias)
    if spacing:
        f.setLetterSpacing(QFont.AbsoluteSpacing, spacing)
    return f


def vertical_gradient(top: float, bottom: float, stops=FOIL_STOPS) -> QLinearGradient:
    g = QLinearGradient(QPointF(0, top), QPointF(0, bottom))
    for pos, col in stops:
        g.setColorAt(pos, QColor(col) if isinstance(col, str) else col)
    return g


# --- stylesheet for standard widgets -----------------------------------
_UP = resource("assets", "ui", "chevron_up.png").as_posix()
_DOWN = resource("assets", "ui", "chevron_down.png").as_posix()

QSS = f"""
* {{ font-family: "{UI_FONT}"; color: {TEXT}; }}
QWidget#content {{ background: transparent; }}
QLabel {{ background: transparent; }}
QLabel[role="muted"] {{ color: {MUTE}; }}
QLabel[role="faint"] {{ color: {FAINT}; }}
QLabel[role="section"] {{ color: {GOLD}; font-family: "{UI_BOLD}"; letter-spacing: 2.6px; font-size: 9pt; }}
QLabel[role="field"] {{ color: {MUTE}; font-size: 9pt; }}

QLineEdit, QSpinBox, QComboBox, QPlainTextEdit, QTextEdit {{
    background: {INNER}; border: 1px solid {GOLD_LINE}; border-radius: 9px;
    padding: 8px 12px; font-size: 10.5pt; selection-background-color: {GOLD_DEEP};
}}
QLineEdit:focus, QSpinBox:focus, QComboBox:focus, QPlainTextEdit:focus, QTextEdit:focus {{
    border: 1px solid {GOLD_LINE_STRONG};
}}
QLineEdit:disabled, QSpinBox:disabled, QComboBox:disabled {{ color: {FAINT}; }}
QLineEdit[placeholderText] {{ color: {TEXT}; }}
QSpinBox::up-button, QSpinBox::down-button {{ width: 18px; border: none; background: transparent; }}
QSpinBox::up-arrow {{ image: url({_UP}); width: 12px; height: 8px; }}
QSpinBox::down-arrow {{ image: url({_DOWN}); width: 12px; height: 8px; }}
QComboBox::drop-down {{ border: none; width: 26px; }}
QComboBox::down-arrow {{ image: url({_DOWN}); width: 12px; height: 8px; margin-right: 8px; }}
QComboBox QAbstractItemView {{
    background: #121212; border: 1px solid {GOLD_LINE}; selection-background-color: #2A2318;
    selection-color: {GOLD_LIGHT}; outline: 0; padding: 4px;
}}

QTableWidget {{
    background: {INNER}; border: 1px solid {GOLD_LINE}; border-radius: 10px;
    gridline-color: rgba(230,192,114,0.08); font-size: 10pt; alternate-background-color: #191816;
}}
QTableWidget::item {{ padding: 6px; }}
QTableWidget::item:selected {{ background: #2A2318; color: {GOLD_LIGHT}; }}
QHeaderView::section {{
    background: #100F0D; color: {GOLD}; border: none; border-bottom: 1px solid {GOLD_LINE};
    padding: 8px; font-family: "{UI_BOLD}"; font-size: 9pt;
}}
QTableCornerButton::section {{ background: #100F0D; border: none; }}

QListWidget {{ background: transparent; border: none; outline: 0; font-size: 10.5pt; }}
QListWidget::item {{ padding: 10px 12px; border-radius: 8px; color: {MUTE}; }}
QListWidget::item:hover {{ background: {INNER_HOVER}; }}
QListWidget::item:selected {{ background: #2A2318; color: {GOLD_LIGHT}; }}

QScrollArea {{ background: transparent; border: none; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 4px 2px; }}
QScrollBar::handle:vertical {{ background: rgba(230,192,114,0.30); border-radius: 3px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: rgba(230,192,114,0.55); }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px 4px; }}
QScrollBar::handle:horizontal {{ background: rgba(230,192,114,0.30); border-radius: 3px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line, QScrollBar::add-page, QScrollBar::sub-page {{
    background: none; border: none; height: 0; width: 0; }}

QPushButton[role="gold"] {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #F6DC8E, stop:1 #C4902F); border: none;
    border-radius: 12px; padding: 10px 18px; font-family: "{UI_BOLD}"; font-size: 10.5pt; color: #18120A;
}}
QPushButton[role="gold"]:hover {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #FFE7A6, stop:1 #D49E3A); }}
QPushButton[role="gold"]:disabled {{ background: #3A3121; color: #8F846B; }}
QPushButton[role="tab"] {{
    background: transparent; border: none; border-radius: 17px; padding: 8px 18px;
    font-family: "{UI_SEMI}"; font-size: 10.5pt; color: {MUTE};
}}
QPushButton[role="tab"]:hover {{ color: {GOLD_LIGHT}; }}
QPushButton[role="tab"]:checked {{ background: rgba(243,217,147,0.08); color: {GOLD}; border: 1px solid #5C4A26; }}
QPushButton[role="seg"] {{
    background: transparent; border: none; padding: 6px 14px; font-size: 10pt; color: {MUTE}; border-radius: 0;
}}
QPushButton[role="seg"]:checked {{ background: #D4A84B; color: #18120A; font-family: "{UI_BOLD}"; }}
QPushButton[role="chip"] {{
    background: #1A160C; border: 1px solid #3A3121; border-radius: 12px; padding: 4px 10px;
    font-size: 9pt; color: #E9CF88;
}}
QPushButton[role="chip"]:hover {{ border: 1px solid #6B5630; }}
QFrame[role="panel"] {{ background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #14110B, stop:1 #0F0D09);
    border: 1px solid #2B2417; border-radius: 18px; }}
QFrame[role="fieldbox"] {{ background: #0B0A07; border: 1px solid #30291B; border-radius: 12px; }}
QPushButton[role="ghost"] {{
    background: {INNER}; border: 1px solid {GOLD_LINE}; border-radius: 9px; padding: 9px 16px;
    font-family: "{UI_SEMI}"; font-size: 10pt; color: {GOLD_LIGHT};
}}
QPushButton[role="ghost"]:hover {{ background: {INNER_HOVER}; border: 1px solid {GOLD_LINE_STRONG}; }}
QPushButton[role="ghost"]:disabled {{ color: {FAINT}; border: 1px solid rgba(230,192,114,0.12); }}
QPushButton[role="danger"] {{
    background: transparent; border: 1px solid rgba(240,113,103,0.45); border-radius: 9px;
    padding: 9px 16px; font-family: "{UI_SEMI}"; color: {ERROR};
}}
QPushButton[role="danger"]:hover {{ background: rgba(240,113,103,0.08); }}

QToolTip {{ background: #141414; color: {TEXT}; border: 1px solid {GOLD_LINE}; padding: 6px; }}
QMessageBox {{ background: #0E0E0E; }}
QMessageBox QLabel {{ font-size: 10.5pt; }}
QMessageBox QPushButton {{
    background: {INNER}; border: 1px solid {GOLD_LINE}; border-radius: 8px; padding: 7px 18px;
    color: {GOLD_LIGHT}; min-width: 70px;
}}
QDialog {{ background: #0E0C08; }}
QTabWidget::pane {{ border: 1px solid #2B2417; border-radius: 12px; top: -1px; background: transparent; }}
QTabWidget > QWidget {{ background: transparent; }}
QTabBar::tab {{
    background: #0E0C08; color: {MUTE}; border: 1px solid #2B2417; padding: 8px 18px; margin-right: 4px;
    border-top-left-radius: 10px; border-top-right-radius: 10px; font-family: "{UI_SEMI}";
}}
QTabBar::tab:selected {{ background: #1C150A; color: {GOLD}; border: 1px solid #6B5630; }}
QMenu {{ background: #14110B; border: 1px solid #3A3121; padding: 6px; }}
QMenu::item {{ padding: 7px 18px; border-radius: 6px; color: {TEXT}; }}
QMenu::item:selected {{ background: #2A2213; color: {GOLD_LIGHT}; }}
QProgressDialog {{ background: #0E0C08; }}
"""
