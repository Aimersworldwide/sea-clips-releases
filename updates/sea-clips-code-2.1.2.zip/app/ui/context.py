"""
=====================================================================
  UI / CONTEXT
  Kaam: saare pages ki saanjhi cheezen (settings, database, signals).
  One object shared by every page: settings, database, and signals
  so pages refresh when something changes elsewhere.
=====================================================================
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QObject, Signal

from app.core.config import AppSettings
from app.core.db import Database


class AppContext(QObject):
    campaignsChanged = Signal()
    clipsChanged = Signal()
    busyChanged = Signal(bool)

    def __init__(self, settings: AppSettings, db: Database, has_gpu: bool):
        super().__init__()
        self.settings = settings
        self.db = db
        self.has_gpu = has_gpu
        self.busy = False

    def set_busy(self, busy: bool) -> None:
        self.busy = busy
        self.busyChanged.emit(busy)

    def save_settings(self) -> None:
        self.settings = AppSettings.validate(self.settings)
        self.settings.save()


def open_path(path: Path | str) -> None:
    """Open a file or folder with the system's default app."""
    path = str(path)
    if sys.platform == "win32":
        os.startfile(path)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


def show_in_folder(path: Path | str) -> None:
    path = Path(path)
    if sys.platform == "win32" and path.exists():
        subprocess.Popen(["explorer", "/select,", str(path)])
    else:
        open_path(path.parent if path.is_file() else path)
