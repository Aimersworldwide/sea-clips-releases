"""
=====================================================================
  UI / MAIN WINDOW
  Kaam: main window: sidebar, pages, bell.
  Sidebar (brand, 5 pages, bell, "POWERED BY RAYYAN") + page stack.
  Closing during a run asks first, then stops cleanly.
  Bell: notifications (naye videos, naya update). Peeche ek halka sa
  checker: app khulne ke 20 s baad, phir har 2 ghante.
=====================================================================
"""
from __future__ import annotations

from PySide6.QtCore import QObject, QRectF, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QColor, QIcon, QLinearGradient, QPainter
from PySide6.QtWidgets import (QButtonGroup, QDialog, QHBoxLayout, QLabel, QListWidget, QMainWindow,
                               QPushButton, QStackedWidget, QVBoxLayout, QWidget)

from app.core.i18n import t
from app.core.paths import resource
from app.version import APP_NAME, VERSION
from app.ui import theme as T
from app.ui.pages.campaigns_page import CampaignsPage
from app.ui.pages.common import confirm
from app.ui.pages.studio_page import StudioPage
from app.ui.pages.delivery_page import DeliveryPage
from app.ui.pages.library_page import LibraryPage
from app.ui.pages.settings_page import SettingsPage
from app.ui.widgets import VelvetBackground


class Gem(QWidget):
    """Gold diamond with the R monogram (SEA CLIPS mark)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(46, 46)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.translate(23, 23)
        p.rotate(45)
        g = QLinearGradient(-16, -16, 16, 16)
        g.setColorAt(0, QColor("#F6DC8E"))
        g.setColorAt(1, QColor("#A8781F"))
        p.setPen(Qt.NoPen)
        p.setBrush(g)
        p.drawRoundedRect(QRectF(-16, -16, 32, 32), 7, 7)
        p.rotate(-45)
        p.setPen(QColor("#18120A"))
        p.setFont(T.font(15, T.SERIF))
        p.drawText(QRectF(-16, -17, 32, 32), Qt.AlignCenter, "R")


class TopBar(QWidget):
    """Gem | SEA CLIPS / AUTO CLIPPER · BY AIMERS WORLDWIDE | tabs | chips, bell, settings."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(66)

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(12, 11, 8, 215))
        p.fillRect(QRectF(0, self.height() - 1, self.width(), 1), QColor("#2B2417"))


class UpdateBar(QWidget):
    """Thin gold bar under the top bar when an update is ready."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 7, 12, 7)
        lay.setSpacing(14)
        self.text = QLabel()
        self.text.setFont(T.font(9.5, T.UI_SEMI))
        self.text.setStyleSheet(f"font-family:'{T.UI_SEMI}'; color:#F3D993;")
        lay.addWidget(self.text, 1)
        self.now = QPushButton("Update now")
        self.now.setProperty("role", "gold")
        self.now.setStyleSheet("padding:5px 14px;")
        self.now.setCursor(Qt.PointingHandCursor)
        self.later = QPushButton("Later")
        self.later.setProperty("role", "ghost")
        self.later.setStyleSheet("padding:5px 12px; border:none; background:transparent; color:#8F846B;")
        self.later.setCursor(Qt.PointingHandCursor)
        lay.addWidget(self.now)
        lay.addWidget(self.later)
        self.later.clicked.connect(self.hide)
        self.hide()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        g = QLinearGradient(0, 0, self.width(), 0)
        g.setColorAt(0, QColor("#21190B"))
        g.setColorAt(1, QColor("#0E0C08"))
        p.setBrush(g)
        p.setPen(QColor("#4A3C20"))
        p.drawRoundedRect(r, 12, 12)


class ActivityPage(QWidget):
    """Notifications and the line's finished videos, newest first."""

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 22, 28, 12)
        head = QLabel("Activity")
        head.setFont(T.font(24, T.SERIF))
        head.setStyleSheet(f"font-family:'{T.SERIF}'; color:#F6E3A9;")
        lay.addWidget(head)
        sub = QLabel("Finished and skipped videos from the line, and messages from the tool.")
        sub.setProperty("role", "muted")
        lay.addWidget(sub)
        self.view = QListWidget()
        lay.addWidget(self.view, 1)
        row = QHBoxLayout()
        clear = QPushButton("Clear finished videos")
        clear.setProperty("role", "ghost")
        clear.clicked.connect(self._clear)
        row.addWidget(clear)
        row.addStretch(1)
        lay.addLayout(row)

    def showEvent(self, e):
        super().showEvent(e)
        self.refresh()

    def refresh(self) -> None:
        from app.core.notify import mark_all_read, notifications
        self.view.clear()
        rows = []
        for item in self.ctx.queue.store.items(include_finished=60):
            if item.status in ("done", "failed"):
                when = (item.finished_at or item.added_at).replace("T", " ")
                if item.status == "done":
                    text = f"{when}   {item.campaign_name}: {item.made} clips from {item.title or item.source}"
                else:
                    text = f"{when}   Skipped {item.title or item.source}: {item.error[:120]}"
                rows.append((when, text))
        for n in notifications():
            rows.append((n.get("time", "").replace("T", " "), f"{n.get('time', '').replace('T', ' ')}   {n.get('text', '')}"))
        for _when, text in sorted(rows, reverse=True)[:200]:
            self.view.addItem(text)
        if not rows:
            self.view.addItem("Nothing yet.")
        mark_all_read()

    def _clear(self) -> None:
        self.ctx.queue.store.clear_finished()
        self.ctx.queue.lineChanged.emit()
        self.refresh()


# ---------------------------------------------------------------------
#  Peeche ka checker: naye videos + naya update (UI kabhi nahi rukta)
# ---------------------------------------------------------------------
class BackgroundChecker(QObject):
    done = Signal(object)          # {"update": release or None}

    def __init__(self, db_path, settings):
        super().__init__()
        self.db_path, self.settings = db_path, settings

    def run(self) -> None:
        result = {"update": None}
        try:
            from app.core.db import Database
            from app.core.notify import check_new_videos, check_update
            from app.version import UPDATE_REPO
            db = Database(self.db_path)
            camps = []
            for cid, name in db.list_campaigns():
                p = db.get_campaign(cid)
                if p is not None and p.source_links:
                    camps.append((cid, name, list(p.source_links)))
            if camps:
                check_new_videos(camps)
            if getattr(self.settings, "check_updates", True):
                result["update"] = check_update(VERSION, UPDATE_REPO)
        except Exception:  # noqa: BLE001 - checker kabhi app na roke
            pass
        self.done.emit(result)


class NotificationsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        from app.core.notify import mark_all_read, notifications
        self.setWindowTitle(t("bell.title"))
        self.resize(520, 420)
        lay = QVBoxLayout(self)
        view = QListWidget()
        items = notifications()
        for i in items:
            view.addItem(f"{'' if i.get('read') else '•  '}{i.get('time', '').replace('T', ' ')}   {i.get('text', '')}")
        if not items:
            view.addItem(t("bell.empty"))
        lay.addWidget(view, 1)
        ok = QPushButton(t("common.ok"))
        ok.clicked.connect(self.accept)
        lay.addWidget(ok)
        mark_all_read()


class MainWindow(QMainWindow):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(QIcon(str(resource("assets", "brand", "app_icon.png"))))
        self.resize(1440, 900)
        self.setMinimumSize(1180, 700)
        from app.queue.controller import QueueController
        ctx.queue = QueueController(parent=self)
        from app.ui.drive_sync import DriveSync
        ctx.drive = DriveSync(ctx, parent=self)           # (18 Nov) Drive Clip Pool upload
        from app.ui.link_target import LinkTarget
        ctx.links = LinkTarget(ctx, parent=self)          # (18 Nov) channel sheet + aaj ka target

        root = VelvetBackground()
        self.setCentralWidget(root)
        lay = QVBoxLayout(root)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # ---- top bar ---------------------------------------------------
        bar = TopBar()
        b = QHBoxLayout(bar)
        b.setContentsMargins(26, 0, 22, 0)
        b.setSpacing(12)
        b.addWidget(Gem())
        wm = QVBoxLayout()
        wm.setSpacing(0)
        name = QLabel("SEA CLIPS")
        name.setFont(T.font(16, T.SERIF, 3.0))
        name.setStyleSheet(f"font-family:'{T.SERIF}'; color:#F3D993;")
        tag = QLabel("AUTO CLIPPER · BY AIMERS WORLDWIDE")
        tag.setFont(T.font(7, T.UI_SEMI, 2.2))
        tag.setStyleSheet(f"font-family:'{T.UI_SEMI}'; color:#8E7D58;")
        wm.addStretch(1)
        wm.addWidget(name)
        wm.addWidget(tag)
        wm.addStretch(1)
        b.addLayout(wm)
        b.addSpacing(36)
        self.stack = QStackedWidget()
        self.pages = {
            "studio": StudioPage(ctx),
            "library": LibraryPage(ctx),
            "campaigns": CampaignsPage(ctx),
            "delivery": DeliveryPage(ctx),
            "activity": ActivityPage(ctx),
            "settings": SettingsPage(ctx),
        }
        titles = {"studio": "Studio", "library": "Library", "campaigns": "Campaigns", "delivery": "Delivery",
                  "activity": "Activity"}
        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        self.nav: dict[str, QPushButton] = {}
        for i, key in enumerate(self.pages):
            self.stack.addWidget(self.pages[key])
            if key not in titles:
                continue
            btn = QPushButton(titles[key])
            btn.setProperty("role", "tab")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, k=key: self.show_page(k))
            self.group.addButton(btn, i)
            self.nav[key] = btn
            b.addWidget(btn)
        b.addStretch(1)
        gpu = QLabel("● GPU ready" if ctx.has_gpu else "● CPU mode")
        gpu.setFont(T.font(8.5, T.UI_SEMI))
        gpu.setStyleSheet("color:#A6E0AD; background:#0F160F; border:1px solid #33402F; border-radius:13px;"
                          "padding:5px 12px;" if ctx.has_gpu else
                          "color:#E9CF88; background:#17130B; border:1px solid #4A3C20; border-radius:13px;"
                          "padding:5px 12px;")
        gpu.setFixedHeight(28)
        b.addWidget(gpu, 0, Qt.AlignVCenter)
        self.bell = QPushButton()
        self.bell.setProperty("role", "ghost")
        self.bell.setCursor(Qt.PointingHandCursor)
        self.bell.setStyleSheet("padding:6px 12px;")
        self.bell.clicked.connect(lambda: self.show_page("activity"))
        b.addWidget(self.bell)
        gear = QPushButton("⚙")
        gear.setProperty("role", "ghost")
        gear.setCheckable(True)
        gear.setToolTip("Settings")
        gear.setCursor(Qt.PointingHandCursor)
        gear.setStyleSheet("padding:6px 11px; font-size:12pt;")
        gear.clicked.connect(lambda: self.show_page("settings"))
        self.group.addButton(gear, len(self.pages))
        self.nav["settings"] = gear
        b.addWidget(gear)
        lay.addWidget(bar)
        self._update_bell()

        self.update_bar = UpdateBar()
        ub = QHBoxLayout()
        ub.setContentsMargins(28, 12, 28, 0)
        ub.addWidget(self.update_bar)
        lay.addLayout(ub)
        self.update_bar.now.clicked.connect(self._update_now)
        lay.addWidget(self.stack, 1)

        foot = QWidget()
        foot.setFixedHeight(32)
        f = QHBoxLayout(foot)
        f.setContentsMargins(28, 0, 28, 0)
        left = QLabel("SEA CLIPS AUTO CLIPPER · BY AIMERS WORLDWIDE")
        left.setFont(T.font(7.5, T.UI_SEMI, 1.2))
        left.setStyleSheet(f"font-family:'{T.UI_SEMI}'; color:#6F6450;")
        right = QLabel(f"<span style='color:#6F6450'>Powered by</span> "
                       f"<span style='color:#C9A457; font-family:\"{T.UI_BOLD}\"'>Rayyan</span>"
                       f"<span style='color:#6F6450'> · v{VERSION}</span>")
        right.setFont(T.font(8, T.UI_FONT, 0.8))
        f.addWidget(left)
        f.addStretch(1)
        f.addWidget(right)
        foot.setStyleSheet("border-top:1px solid #1F1B12;")
        lay.addWidget(foot)

        self.pages["studio"].goToCampaigns.connect(lambda: self.show_page("campaigns"))
        # bell ki ginti har minute, checker 20 s baad phir har 2 ghante
        self._bell_timer = QTimer(self)
        self._bell_timer.timeout.connect(self._update_bell)
        self._bell_timer.start(60_000)
        self._check_timer = QTimer(self)
        self._check_timer.timeout.connect(self._run_checker)
        self._check_timer.start(2 * 3600 * 1000)
        QTimer.singleShot(20_000, self._run_checker)
        QTimer.singleShot(3_000, self._resume_line)        # laptop / app band hua tha: line wahin se
        QTimer.singleShot(400, self._welcome)
        self._checker_thread: QThread | None = None
        self._release = None
        self.show_page("studio")
        self._closing_ok = False

    def _welcome(self) -> None:
        """Naya install (koi campaign nahi): clips folder aur pehla campaign."""
        import os
        s = self.ctx.settings
        if getattr(s, "welcomed", False) or os.environ.get("AIMERS_NO_BACKGROUND"):
            return
        if self.ctx.db.list_campaigns():
            s.welcomed = True                     # purana laptop: kabhi nahi dikhega
            self.ctx.save_settings()
            return
        from app.ui.welcome import WelcomeDialog
        dlg = WelcomeDialog(s.output_dir, self)
        dlg.exec()
        folder = dlg.folder.text().strip()
        if folder:
            s.output_dir = folder
        s.welcomed = True
        self.ctx.save_settings()
        self.show_page("campaigns")
        self.pages["campaigns"]._new()

    def _resume_line(self) -> None:
        import os
        if os.environ.get("AIMERS_NO_BACKGROUND"):
            return
        if not self.ctx.queue.running and self.ctx.queue.store.next_waiting() is not None:
            self.ctx.queue.resume_line()

    # ---- bell / notifications --------------------------------------------
    def _update_bell(self) -> None:
        from app.core.notify import unread_count
        n = unread_count()
        self.bell.setText("🔔" + (f"  {n}" if n else ""))

    def _open_bell(self) -> None:
        NotificationsDialog(self).exec()
        self._update_bell()

    def _run_checker(self) -> None:
        import os
        if os.environ.get("AIMERS_NO_BACKGROUND"):          # tests: koi network nahi
            return
        if self._checker_thread is not None and self._checker_thread.isRunning():
            return
        self._checker = BackgroundChecker(self.ctx.db.path, self.ctx.settings)
        self._checker_thread = QThread()
        self._checker.moveToThread(self._checker_thread)
        self._checker_thread.started.connect(self._checker.run)
        self._checker.done.connect(self._checked)
        self._checker.done.connect(self._checker_thread.quit)
        self._checker_thread.start()

    def _checked(self, result: dict) -> None:
        self._update_bell()
        self.ctx.campaignsChanged.emit()
        rel = result.get("update") if isinstance(result, dict) else None
        if rel:
            self.pages["settings"].show_update(rel)
            self.show_update(rel)

    def show_update(self, rel: dict) -> None:
        """Upar sunehri patti: naya update, size aur ek line ki khabar."""
        self._release = rel
        size = rel.get("size_mb")
        note = (rel.get("notes") or "").strip().splitlines()[0][:90] if rel.get("notes") else ""
        bits = [f"Update {rel['version']} is ready"] + ([f"{size} MB"] if size else []) + ([note] if note else [])
        self.update_bar.text.setText("✦  " + " · ".join(bits))
        self.update_bar.show()

    def _update_now(self) -> None:
        if not self._release:
            return
        if self.ctx.queue.running:
            if not confirm(self, "Clips are being made. Update now? The current video stops safely and "
                                 "continues after the update."):
                return
        from app.ui.updater import run_update
        run_update(self, self._release)

    def show_page(self, key: str) -> None:
        self.nav[key].setChecked(True)
        self.stack.setCurrentWidget(self.pages[key])

    def closeEvent(self, e):
        q = self.ctx.queue
        if q.running and not self._closing_ok:
            if not confirm(self, "Clips are being made. Close anyway? Clips already made are kept and this "
                                 "video continues from here the next time you open the tool."):
                e.ignore()
                return
        th = getattr(self, "_checker_thread", None)
        if th is not None and th.isRunning():
            th.quit()
            th.wait(3000)
        q.shutdown()
        try:
            self.ctx.links.shutdown()                  # sheet wala target: band window ke baad kuch na kare
        except Exception:  # noqa: BLE001
            pass
        try:
            self.ctx.drive.shutdown()
        except Exception:  # noqa: BLE001
            pass
        e.accept()
