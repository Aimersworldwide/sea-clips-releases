"""
=====================================================================
  UI / WELCOME              (naye laptop par pehli dafa)
  Kaam: clips ka folder chuno, phir "Pehla campaign banao". Bas.
  Shown once on a fresh install (no campaigns yet). Never shown on a
  laptop that already has campaigns.
=====================================================================
"""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout

from app.ui import theme as T


class WelcomeDialog(QDialog):
    def __init__(self, folder: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Welcome to SEA CLIPS")
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(30, 26, 30, 24)
        lay.setSpacing(12)
        head = QLabel("Welcome to SEA CLIPS")
        head.setStyleSheet(f"font-family:'{T.SERIF}'; font-size:24pt; color:#F6E3A9;")
        lay.addWidget(head)
        sub = QLabel("Auto Clipper by AIMERS WORLDWIDE. Two quick steps and you are ready.")
        sub.setStyleSheet(f"font-family:'{T.UI_FONT}'; color:#A99D82;")
        sub.setWordWrap(True)
        lay.addWidget(sub)
        lay.addSpacing(8)
        cap = QLabel("1.  WHERE SHOULD YOUR CLIPS GO?")
        cap.setStyleSheet(f"font-family:'{T.UI_BOLD}'; color:#8E7D58; letter-spacing:1.5px;")
        lay.addWidget(cap)
        row = QHBoxLayout()
        self.folder = QLineEdit(folder)
        browse = QPushButton("Browse")
        browse.setProperty("role", "ghost")
        browse.clicked.connect(self._browse)
        row.addWidget(self.folder, 1)
        row.addWidget(browse)
        lay.addLayout(row)
        lay.addSpacing(6)
        cap2 = QLabel("2.  MAKE YOUR FIRST CAMPAIGN")
        cap2.setStyleSheet(f"font-family:'{T.UI_BOLD}'; color:#8E7D58; letter-spacing:1.5px;")
        lay.addWidget(cap2)
        txt = QLabel("Give it a name, paste the campaign brief and pick a look. Then paste a video link in "
                     "Studio and press Add.")
        txt.setWordWrap(True)
        txt.setStyleSheet(f"font-family:'{T.UI_FONT}'; color:#ECE5D3;")
        lay.addWidget(txt)
        lay.addSpacing(10)
        go = QPushButton("Make my first campaign")
        go.setProperty("role", "gold")
        go.setCursor(Qt.PointingHandCursor)
        go.clicked.connect(self.accept)
        lay.addWidget(go, 0, Qt.AlignRight)

    def _browse(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Clips folder", self.folder.text())
        if path:
            self.folder.setText(path)
