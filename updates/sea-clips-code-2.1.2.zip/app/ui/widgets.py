"""
=====================================================================
  UI / WIDGETS  (custom painted, so gold looks like real foil)
  Kaam: app ke khaas buttons aur hisse.
    VelvetBackground  - window background (radial black + faint weave)
    Card              - panel with a thin gold gradient border
    GoldTitle         - big title painted with a gold gradient
    GoldLine          - 1 px gold rule that fades at both ends
    FoilButton        - main action button (foil + soft shine)
    NavButton         - sidebar item (foil when active)
    Toggle            - on/off switch (gold when on)
    GoldProgress      - progress bar with foil fill
    StatTile          - small box: label + value
    DropZone          - drag & drop / click to choose a video
=====================================================================
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QEasingCurve, QPointF, QPropertyAnimation, QRectF, Qt, Property, Signal
from PySide6.QtGui import (QBrush, QColor, QFontMetricsF, QLinearGradient, QPainter, QPainterPath, QPen,
                           QRadialGradient)
from PySide6.QtWidgets import (QAbstractButton, QFileDialog, QFrame, QGraphicsDropShadowEffect, QLabel,
                               QPushButton, QSizePolicy, QVBoxLayout, QWidget)

from app.ui import theme as T

VIDEO_FILTER = "Videos (*.mp4 *.mov *.mkv *.webm *.avi *.m4v *.flv *.wmv *.ts *.mts)"
VIDEO_EXT = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v", ".flv", ".wmv", ".ts", ".mts"}


def _border_gradient(rect: QRectF) -> QLinearGradient:
    g = QLinearGradient(rect.topLeft(), rect.bottomRight())
    for pos, col in T.BORDER_STOPS:
        g.setColorAt(pos, col)
    return g


# ---------------------------------------------------------------------
class VelvetBackground(QWidget):
    """Paints the whole window background."""

    def paintEvent(self, _):
        p = QPainter(self)
        r = self.rect()
        p.fillRect(r, QColor(T.BG_EDGE))
        # upar daayen se halki sunehri roshni (SEA CLIPS 2.0 design)
        g = QRadialGradient(QPointF(r.width() * 0.70, -r.height() * 0.10), max(r.width(), r.height()) * 0.75)
        g.setColorAt(0.0, QColor(42, 32, 16, 255))
        g.setColorAt(0.55, QColor(10, 9, 7, 0))
        p.fillRect(r, g)


# ---------------------------------------------------------------------
class Card(QFrame):
    """Rounded dark panel with a gold gradient hairline border."""

    def __init__(self, parent=None, radius: float = 18, padding: int = 22, inner: bool = False):
        super().__init__(parent)
        self.radius, self.inner = radius, inner
        self.setAttribute(Qt.WA_StyledBackground, False)
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(padding, padding, padding, padding)
        self.body.setSpacing(12)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        if self.inner:
            p.setBrush(QColor(T.INNER))
            p.setPen(QPen(QColor("#30291B"), 1.0))
        else:
            p.setBrush(T.vertical_gradient(0, r.height(), ((0, QColor(20, 17, 11, 245)), (1, QColor(15, 13, 9, 245)))))
            p.setPen(QPen(QColor(T.LINE), 1.0))
        p.drawRoundedRect(r, self.radius, self.radius)


# ---------------------------------------------------------------------
class GoldTitle(QWidget):
    """Large heading filled with a gold gradient (like the logo)."""

    def __init__(self, text: str, size: float = 25, parent=None):
        super().__init__(parent)
        self._text = text
        self._font = T.font(size * 1.15, T.SERIF, 0.2)
        fm = QFontMetricsF(self._font)
        self.setMinimumHeight(int(fm.height() + 6))
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def setText(self, text: str) -> None:
        self._text = text
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        fm = QFontMetricsF(self._font)
        path = QPainterPath()
        path.setFillRule(Qt.WindingFill)      # overlapping letters must not cut holes
        path.addText(QPointF(0, fm.ascent() + 2), self._font, self._text)
        top = 2
        p.fillPath(path, QBrush(T.vertical_gradient(top, top + fm.height(), T.TITLE_STOPS)))


class GoldLine(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(1)

    def paintEvent(self, _):
        p = QPainter(self)
        g = QLinearGradient(0, 0, self.width(), 0)
        g.setColorAt(0.0, QColor(185, 134, 47, 0))
        g.setColorAt(0.15, QColor(185, 134, 47, 150))
        g.setColorAt(0.5, QColor(255, 240, 196, 170))
        g.setColorAt(0.85, QColor(185, 134, 47, 150))
        g.setColorAt(1.0, QColor(185, 134, 47, 0))
        p.fillRect(self.rect(), g)


# ---------------------------------------------------------------------
class FoilButton(QPushButton):
    """The gold call-to-action button."""

    def __init__(self, text: str, parent=None, height: int = 54):
        super().__init__(text, parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(height)
        self.setFont(T.font(12, T.UI_BOLD, 2.0))
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(28)
        shadow.setOffset(0, 8)
        shadow.setColor(QColor(230, 180, 80, 70))
        self.setGraphicsEffect(shadow)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        enabled = self.isEnabled()
        if enabled:
            p.setBrush(T.vertical_gradient(r.top(), r.bottom()))
        else:
            p.setBrush(QColor("#3A342A"))
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(r, 11, 11)
        if enabled:
            # inner highlight + soft shine stripe
            p.setPen(QPen(QColor(255, 255, 255, 150 if not self.underMouse() else 200), 1))
            p.drawLine(QPointF(r.left() + 10, r.top() + 1), QPointF(r.right() - 10, r.top() + 1))
            shine = QLinearGradient(r.left() + r.width() * 0.1, 0, r.left() + r.width() * 0.32, 0)
            shine.setColorAt(0, QColor(255, 255, 255, 0))
            shine.setColorAt(0.5, QColor(255, 255, 255, 70 if self.underMouse() else 45))
            shine.setColorAt(1, QColor(255, 255, 255, 0))
            path = QPainterPath()
            path.addRoundedRect(r, 11, 11)
            p.setClipPath(path)
            p.fillRect(r, shine)
            p.setClipping(False)
        p.setPen(QColor(T.DARK_ON_GOLD) if enabled else QColor(T.FAINT))
        p.setFont(self.font())
        p.drawText(r, Qt.AlignCenter, self.text())

    def enterEvent(self, e):
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self.update()
        super().leaveEvent(e)


# ---------------------------------------------------------------------
_ICONS = {
    # simple line icons drawn with QPainterPath (no image files needed)
    "create": [("poly", [(7, 4), (19, 12), (7, 20)], True)],
    "campaigns": [("rect", (3.5, 5, 17, 14, 2)), ("line", (3.5, 9.5, 20.5, 9.5))],
    "library": [("rect", (4, 4, 7, 7, 1)), ("rect", (13, 4, 7, 7, 1)), ("rect", (4, 13, 7, 7, 1)),
                ("rect", (13, 13, 7, 7, 1))],
    "delivery": [("rect", (2.5, 7, 11, 9, 1)), ("poly", [(13.5, 10), (18, 10), (21.5, 13.5), (21.5, 16), (13.5, 16)], True),
                 ("circle", (7, 17.5, 1.8)), ("circle", (17.5, 17.5, 1.8))],
    "settings": [("circle", (12, 12, 3.2)), ("ray", (12, 12, 6.0, 9.0, 8))],
}


def draw_icon(p: QPainter, name: str, rect: QRectF, color: QColor) -> None:
    import math
    s = rect.width() / 24.0
    p.save()
    p.translate(rect.topLeft())
    p.scale(s, s)
    p.setPen(QPen(color, 1.7, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))   # in 24-unit icon space
    p.setBrush(Qt.NoBrush)
    for item in _ICONS.get(name, []):
        kind = item[0]
        if kind == "rect":
            x, y, w, h, rad = item[1]
            p.drawRoundedRect(QRectF(x, y, w, h), rad, rad)
        elif kind == "line":
            x1, y1, x2, y2 = item[1]
            p.drawLine(QPointF(x1, y1), QPointF(x2, y2))
        elif kind == "circle":
            cx, cy, rad = item[1]
            p.drawEllipse(QPointF(cx, cy), rad, rad)
        elif kind == "poly":
            path = QPainterPath(QPointF(*item[1][0]))
            for pt in item[1][1:]:
                path.lineTo(QPointF(*pt))
            if item[2]:
                path.closeSubpath()
            p.drawPath(path)
        elif kind == "ray":
            cx, cy, r1, r2, n = item[1]
            for k in range(n):
                a = 2 * math.pi * k / n
                p.drawLine(QPointF(cx + r1 * math.cos(a), cy + r1 * math.sin(a)),
                           QPointF(cx + r2 * math.cos(a), cy + r2 * math.sin(a)))
    p.restore()


class NavButton(QAbstractButton):
    def __init__(self, icon: str, text: str, parent=None):
        super().__init__(parent)
        self.icon_name = icon
        self.setText(text)
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(48)
        self.setFont(T.font(11.5, T.UI_SEMI))

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 2, -1, -2)
        on = self.isChecked()
        if on:
            p.setPen(Qt.NoPen)
            p.setBrush(T.vertical_gradient(r.top(), r.bottom()))
            p.drawRoundedRect(r, 10, 10)
            p.setPen(QPen(QColor(255, 255, 255, 170), 1))
            p.drawLine(QPointF(r.left() + 8, r.top() + 1), QPointF(r.right() - 8, r.top() + 1))
        elif self.underMouse():
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 10))
            p.drawRoundedRect(r, 10, 10)
        color = QColor(T.DARK_ON_GOLD) if on else QColor("#C9A04F")
        draw_icon(p, self.icon_name, QRectF(r.left() + 16, r.center().y() - 10, 20, 20), color)
        p.setPen(QColor(T.DARK_ON_GOLD) if on else QColor(T.MUTE))
        p.setFont(self.font())
        p.drawText(r.adjusted(50, 0, 0, 0), Qt.AlignVCenter | Qt.AlignLeft, self.text())

    def enterEvent(self, e):
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self.update()
        super().leaveEvent(e)


# ---------------------------------------------------------------------
class Toggle(QAbstractButton):
    """iOS-like switch, gold when on. Use .isChecked() / .setChecked()."""

    def __init__(self, checked: bool = False, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(checked)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedSize(46, 26)
        self._pos = 1.0 if checked else 0.0
        self._anim = QPropertyAnimation(self, b"knob", self)
        self._anim.setDuration(140)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self.toggled.connect(self._animate)

    def _animate(self, on: bool) -> None:
        self._anim.stop()
        self._anim.setStartValue(self._pos)
        self._anim.setEndValue(1.0 if on else 0.0)
        self._anim.start()

    def _get(self) -> float:
        return self._pos

    def _set(self, v: float) -> None:
        self._pos = v
        self.update()

    knob = Property(float, _get, _set)

    def setChecked(self, on: bool) -> None:  # noqa: N802 - Qt naming
        super().setChecked(on)
        self._pos = 1.0 if on else 0.0
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        if self.isChecked():
            p.setBrush(T.vertical_gradient(r.top(), r.bottom()))
            p.setPen(Qt.NoPen)
        else:
            p.setBrush(QColor("#1E1D1B"))
            p.setPen(QPen(QColor(230, 192, 114, 70), 1))
        if not self.isEnabled():
            p.setOpacity(0.4)
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        d = r.height() - 6
        x = r.left() + 3 + (r.width() - d - 6) * self._pos
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(T.DARK_ON_GOLD) if self.isChecked() else QColor("#8E877B"))
        p.drawEllipse(QRectF(x, r.top() + 3, d, d))

    def sizeHint(self):
        return self.size()


# ---------------------------------------------------------------------
class GoldProgress(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._value = 0.0
        self.setFixedHeight(10)

    def setValue(self, v: float) -> None:  # noqa: N802
        self._value = max(0.0, min(1.0, v))
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setPen(QPen(QColor(230, 192, 114, 60), 1))
        p.setBrush(QColor("#151412"))
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        if self._value > 0:
            fill = QRectF(r.left(), r.top(), max(r.height(), r.width() * self._value), r.height())
            g = QLinearGradient(fill.left(), 0, fill.right(), 0)
            g.setColorAt(0, QColor("#8A6422"))
            g.setColorAt(0.75, QColor("#E6C072"))
            g.setColorAt(1, QColor("#FFF0C4"))
            p.setPen(Qt.NoPen)
            p.setBrush(g)
            p.drawRoundedRect(fill, r.height() / 2, r.height() / 2)


# ---------------------------------------------------------------------
class StatTile(Card):
    def __init__(self, label: str, value: str = "-", center: bool = False, big: bool = False, parent=None):
        super().__init__(parent, radius=10, padding=8 if big else 14, inner=True)
        self.body.setSpacing(2)
        if big:
            self.body.setContentsMargins(4, 10, 4, 10)
        self.label = QLabel(label)
        self.value = QLabel(value)
        if big:   # count style: big number on top, label under it
            self.value.setFont(T.font(20, T.UI_BOLD))
            self.label.setFont(T.font(9))
            self.label.setProperty("role", "muted")
            for w in (self.value, self.label):
                w.setAlignment(Qt.AlignCenter)
            self.body.addWidget(self.value)
            self.body.addWidget(self.label)
        else:
            self.label.setFont(T.font(9))
            self.label.setProperty("role", "muted")
            self.value.setFont(T.font(13.5, T.UI_BOLD))
            if center:
                self.label.setAlignment(Qt.AlignCenter)
                self.value.setAlignment(Qt.AlignCenter)
            self.body.addWidget(self.label)
            self.body.addWidget(self.value)

    def set(self, value: str) -> None:
        self.value.setText(value)


# ---------------------------------------------------------------------
class DropZone(QWidget):
    """Drag a video here, or click to browse. Kai videos ek saath bhi (31 Oct): sab ek ke baad ek banti hain."""
    fileChosen = Signal(str)
    filesChosen = Signal(list)              # kai videos (line mein: pehli ki clips poori, phir agli)

    def __init__(self, title: str, hint: str, parent=None):
        super().__init__(parent)
        self.title, self.hint, self.chosen = title, hint, ""
        self.setAcceptDrops(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(170)
        self._hover = False

    def set_texts(self, title: str, hint: str) -> None:
        self.title, self.hint = title, hint
        self.update()

    def set_chosen(self, text: str) -> None:
        self.chosen = text
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            paths, _ = QFileDialog.getOpenFileNames(self, self.title, "", VIDEO_FILTER)
            self._emit([p for p in paths if p])

    def dragEnterEvent(self, e):
        urls = e.mimeData().urls()
        if urls and any(Path(u.toLocalFile()).suffix.lower() in VIDEO_EXT for u in urls):
            self._hover = True
            self.update()
            e.acceptProposedAction()

    def dragLeaveEvent(self, _):
        self._hover = False
        self.update()

    def dropEvent(self, e):
        self._hover = False
        self.update()
        self._emit([u.toLocalFile() for u in e.mimeData().urls()])

    def _emit(self, paths: list) -> None:
        """Sirf video files, ek dafa, chunne ki tarteeb mein; ek ho to fileChosen, kai hon to filesChosen."""
        videos = list(dict.fromkeys(p for p in paths if p and Path(p).suffix.lower() in VIDEO_EXT))
        if len(videos) == 1:
            self.fileChosen.emit(videos[0])
        elif videos:
            self.filesChosen.emit(videos)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(QColor(T.INNER))
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(r, 12, 12)
        glow = QRadialGradient(r.center(), r.width() * 0.32)
        glow.setColorAt(0, QColor(240, 200, 120, 40 if self._hover else 24))
        glow.setColorAt(1, QColor(240, 200, 120, 0))
        p.setBrush(glow)
        p.drawRoundedRect(r, 12, 12)
        pen = QPen(QColor(230, 192, 114, 170 if self._hover else 110), 1.4, Qt.CustomDashLine)
        pen.setDashPattern([4, 4])
        p.setPen(pen)
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(r, 12, 12)

        # upload arrow
        cx, cy = r.center().x(), r.center().y() - 34
        p.setPen(QPen(QColor(T.GOLD), 1.8, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.drawLine(QPointF(cx, cy - 14), QPointF(cx, cy + 8))
        p.drawLine(QPointF(cx - 8, cy - 6), QPointF(cx, cy - 14))
        p.drawLine(QPointF(cx + 8, cy - 6), QPointF(cx, cy - 14))
        p.drawPolyline([QPointF(cx - 15, cy + 6), QPointF(cx - 15, cy + 14), QPointF(cx + 15, cy + 14),
                        QPointF(cx + 15, cy + 6)])

        p.setPen(QColor(T.TEXT))
        p.setFont(T.font(13, T.UI_BOLD))
        p.drawText(QRectF(r.left(), cy + 26, r.width(), 30), Qt.AlignCenter, self.title)
        p.setPen(QColor(T.GOLD_LIGHT if self.chosen else T.MUTE))
        p.setFont(T.font(10.5))
        text = self.chosen or self.hint
        text = p.fontMetrics().elidedText(text, Qt.ElideMiddle, int(r.width() - 40))
        p.drawText(QRectF(r.left(), cy + 56, r.width(), 26), Qt.AlignCenter, text)


def section(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setProperty("role", "section")
    lbl.setFont(T.font(9, T.UI_BOLD, 2.6))
    return lbl


def field_label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setProperty("role", "field")
    lbl.setFont(T.font(9))
    lbl.setWordWrap(True)
    return lbl


def ghost_button(text: str, danger: bool = False) -> QPushButton:
    b = QPushButton(text)
    b.setProperty("role", "danger" if danger else "ghost")
    b.setCursor(Qt.PointingHandCursor)
    return b
