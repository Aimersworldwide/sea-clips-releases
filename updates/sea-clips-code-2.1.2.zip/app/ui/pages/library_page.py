"""
=====================================================================
  UI / PAGES / HISTORY  (pehle "Library")
  Kaam: har clip ki history, do tabs mein:
    * On laptop : jo clips abhi laptop pe hain (score, rating, kis ko
                  diya). Bohot saare ek saath chun kar delete (Select
                  all, Shift / Ctrl, poori campaign, ek "given to").
    * Deleted   : jo clips laptop se hat gaye (app se ya haath se);
                  sirf history, taake wahi clip dobara na bane.
  Upar overview: har campaign ke laptop pe maujood clips, folders se
  gin kar (haath se delete kiye clips khud hi nikal jate hain).
  Page khulte hi folder sync: ghayab files "Deleted" mein chali jati hain.
=====================================================================
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QHBoxLayout, QHeaderView, QLabel, QTableWidget,
                               QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from app.core.i18n import t
from app.output.organizer import RATING_FOLDERS, campaign_root
from app.ui import theme as T
from app.ui.context import open_path, show_in_folder
from app.ui.pages.common import PageHeader, confirm, page_layout, warn
from app.ui.widgets import ghost_button

RATING_COLOR = {"recommended": T.GOLD, "medium": "#D9D2C5", "below": T.FAINT, "check": T.WARN}


# ---------------------------------------------------------------------
#  Folder se ginti: campaign folder mein abhi kitne clips hain
# ---------------------------------------------------------------------
def folder_counts(root: Path) -> dict[str, int]:
    out = {"total": 0, "given": 0, **{k: 0 for k in RATING_FOLDERS}}
    names = {v: k for k, v in RATING_FOLDERS.items()}
    if not root.exists():
        return out
    for f in root.rglob("*.mp4"):
        if f.name.startswith("_saving_"):
            continue
        out["total"] += 1
        parts = f.relative_to(root).parts
        if parts and parts[0] == "Delivered":
            out["given"] += 1
        elif f.parent.name in names:
            out[names[f.parent.name]] += 1
    return out


def delete_clip_files(db, clips) -> tuple[int, list[str]]:
    """Chune hue clips ki files hatao aur unhe Deleted history mein daalo."""
    done, failed = [], []
    for c in clips:
        p = Path(c.file_path)
        try:
            if p.exists():
                p.unlink()
            done.append(c.id)
        except OSError as exc:
            failed.append(f"{c.label} ({exc.strerror or exc})")
    db.mark_deleted(done)
    return len(done), failed


class LibraryPage(QWidget):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        lay = page_layout(self)
        lay.addWidget(PageHeader(t("lib.title"), t("lib.subtitle")))

        # ---- overview: har campaign ke laptop pe clips (folders se) ----
        self.overview = QLabel("")
        self.overview.setWordWrap(True)
        self.overview.setTextFormat(Qt.RichText)
        lay.addWidget(self.overview)
        lay.addSpacing(10)

        # ---- filters ---------------------------------------------------
        bar = QHBoxLayout()
        bar.setSpacing(12)
        self.campaign = QComboBox()
        self.campaign.setMinimumWidth(220)
        self.campaign.currentIndexChanged.connect(self.refresh)
        self.rating = QComboBox()
        self.rating.addItem(t("lib.all"), "")
        for key in ("recommended", "medium", "below", "check"):
            self.rating.addItem(t(f"rating.{key}"), key)
        self.rating.currentIndexChanged.connect(self.refresh)
        self.given = QComboBox()
        self.given.setMinimumWidth(160)
        self.given.currentIndexChanged.connect(self._fill)
        self.summary = QLabel("")
        self.summary.setProperty("role", "muted")
        bar.addWidget(self.campaign)
        bar.addWidget(self.rating)
        bar.addWidget(self.given)
        bar.addWidget(self.summary, 1)
        lay.addLayout(bar)
        lay.addSpacing(8)

        # ---- do tabs ---------------------------------------------------
        self.tabs = QTabWidget()
        self.table = self._make_table(multi=True)
        self.table.doubleClicked.connect(lambda _: self._play())
        self.deleted_table = self._make_table(multi=False)
        on_box = QWidget()
        ol = QVBoxLayout(on_box)
        ol.setContentsMargins(0, 8, 0, 0)
        actions = QHBoxLayout()
        play = ghost_button(t("lib.open"))
        play.clicked.connect(self._play)
        show = ghost_button(t("lib.show"))
        show.clicked.connect(self._show)
        copy_title = ghost_button(t("lib.copy_title"))
        copy_title.clicked.connect(lambda: self._copy("title"))
        copy_tags = ghost_button(t("lib.copy_tags"))
        copy_tags.clicked.connect(lambda: self._copy("hashtags"))
        copy_both = ghost_button(t("lib.copy_both"))
        copy_both.clicked.connect(lambda: self._copy("both"))
        sel_all = ghost_button(t("lib.select_all"))
        sel_all.clicked.connect(self.table.selectAll)
        self.del_btn = ghost_button(t("lib.delete"), danger=True)
        self.del_btn.clicked.connect(self._delete_selected)
        actions.addWidget(play)
        actions.addWidget(show)
        actions.addWidget(copy_title)
        actions.addWidget(copy_tags)
        actions.addWidget(copy_both)
        actions.addStretch(1)
        actions.addWidget(sel_all)
        actions.addWidget(self.del_btn)
        ol.addLayout(actions)
        ol.addWidget(self.table, 1)
        self.tabs.addTab(on_box, t("lib.tab_present"))
        self.tabs.addTab(self.deleted_table, t("lib.tab_deleted"))
        lay.addWidget(self.tabs, 1)
        self.empty = QLabel(t("lib.empty"))
        self.empty.setProperty("role", "muted")
        self.empty.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.empty)
        # tab badalne pe list taaza (sab widgets banne ke baad jorna: warna khali library pe error)
        self.tabs.currentChanged.connect(self.refresh)

        self._clips = []
        ctx.campaignsChanged.connect(self._campaigns)
        ctx.clipsChanged.connect(self._maybe_refresh)
        self._campaigns()

    def _make_table(self, multi: bool) -> QTableWidget:
        cols = [t("lib.col.clip"), t("lib.col.campaign"), t("lib.col.title"), t("lib.col.hashtags"),
                t("lib.col.score"), t("lib.col.rating"), t("lib.col.length"), t("lib.col.why"), t("lib.col.given")]
        table = QTableWidget(0, len(cols))
        table.setHorizontalHeaderLabels(cols)
        table.verticalHeader().setVisible(False)
        table.setAlternatingRowColors(True)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setSelectionMode(QAbstractItemView.ExtendedSelection if multi else QAbstractItemView.SingleSelection)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setShowGrid(False)
        head = table.horizontalHeader()
        head.setSectionResizeMode(QHeaderView.ResizeToContents)
        head.setSectionResizeMode(7, QHeaderView.Stretch)
        return table

    # ---- campaigns list (pehla option: sab campaigns) ------------------
    def _campaigns(self) -> None:
        keep = self.campaign.currentData()
        self.campaign.blockSignals(True)
        self.campaign.clear()
        self.campaign.addItem(t("lib.all_campaigns"), None)
        for cid, name in self.ctx.db.list_campaigns():
            self.campaign.addItem(name, cid)
        idx = self.campaign.findData(keep)
        self.campaign.setCurrentIndex(idx if idx >= 0 else (1 if self.campaign.count() > 1 else 0))
        self.campaign.blockSignals(False)
        self.refresh()

    def _maybe_refresh(self) -> None:
        if self.isVisible():
            self.refresh()

    def showEvent(self, e):
        try:
            if self.ctx.db.sync_missing_files():             # haath se delete hue clips: Deleted mein
                self.ctx.clipsChanged.emit()
        except Exception:  # noqa: BLE001 - sync kabhi page na roke
            pass
        self.refresh()
        super().showEvent(e)

    # ---- data ------------------------------------------------------------
    def refresh(self, *_) -> None:
        cid = self.campaign.currentData()
        deleted = self.tabs.currentIndex() == 1
        self._clips = self.ctx.db.clips_for_campaign(cid, self.rating.currentData() or None,
                                                     state="deleted" if deleted else "present")
        names = sorted({c.delivered_to for c in self._clips if c.delivered_to})
        keep = self.given.currentData()
        self.given.blockSignals(True)
        self.given.clear()
        self.given.addItem(t("lib.given_any"), None)
        self.given.addItem(t("lib.given_none"), "")
        for n in names:
            self.given.addItem(n, n)
        idx = self.given.findData(keep)
        self.given.setCurrentIndex(idx if idx >= 0 else 0)
        self.given.blockSignals(False)
        self._fill()
        self._overview()

    def _shown(self):
        want = self.given.currentData()
        if want is None:
            return self._clips
        return [c for c in self._clips if c.delivered_to == want]

    def _fill(self, *_) -> None:
        deleted = self.tabs.currentIndex() == 1
        table = self.deleted_table if deleted else self.table
        clips = self._shown()
        names = self.ctx.db.campaign_names()
        table.setRowCount(len(clips))
        for row, c in enumerate(clips):
            when = c.deleted_at.replace("T", " ") if deleted else c.delivered_to
            if deleted and getattr(c, "drive_id", ""):
                when = f"In Drive Clip Pool · {when}"          # (18 Nov) upload ke baad laptop se hata
            extra = c.extra
            values = (c.label, names.get(c.campaign_id, ""), extra.get("title", ""), extra.get("hashtags", ""),
                      str(c.score), t(f"rating.{c.rating}"), f"{c.duration:.1f}s", c.score_reasons, when)
            for col, val in enumerate(values):
                item = QTableWidgetItem(val)
                if col == 0:
                    item.setData(Qt.UserRole, c.id)
                if col in (4, 6):
                    item.setTextAlignment(Qt.AlignCenter)
                if col == 5:
                    item.setForeground(QColor(RATING_COLOR.get(c.rating, T.TEXT)))
                table.setItem(row, col, item)
        header = t("lib.col.deleted") if deleted else t("lib.col.given")
        table.setHorizontalHeaderItem(8, QTableWidgetItem(header))
        self.empty.setVisible(not clips)
        self.summary.setText(t("lib.count", n=len(clips)))

    def _overview(self) -> None:
        parts = []
        for cid, name in self.ctx.db.list_campaigns():
            profile = self.ctx.db.get_campaign(cid)
            if profile is None:
                continue
            n = folder_counts(campaign_root(Path(self.ctx.settings.output_dir), profile))
            if not n["total"]:
                continue
            parts.append(f"<b>{name}</b>: {n['total']} &nbsp;<span style='color:{T.FAINT}'>("
                         f"{t('rating.recommended')} {n['recommended']}, {t('rating.medium')} {n['medium']}, "
                         f"{t('rating.below')} {n['below']}, {t('rating.check')} {n['check']}, "
                         f"{t('lib.given')} {n['given']})</span>")
        self.overview.setText(t("lib.overview") + "<br>" + ("<br>".join(parts) if parts else t("lib.overview_empty")))

    # ---- actions ---------------------------------------------------------
    def _selected(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        ids = {self.table.item(r, 0).data(Qt.UserRole) for r in rows if self.table.item(r, 0)}
        return [c for c in self._clips if c.id in ids]

    def _selected_file(self) -> str:
        chosen = self._selected()
        return chosen[0].file_path if chosen else ""

    def _copy(self, what: str) -> None:
        """Chune hue clip(s) ka title / hashtags clipboard pe (upload ke waqt paste)."""
        from PySide6.QtWidgets import QApplication
        chosen = self._selected()
        if not chosen:
            warn(self, t("lib.nothing_selected"))
            return
        lines = []
        for c in chosen:
            title, tags = c.extra.get("title", ""), c.extra.get("hashtags", "")
            lines.append(title if what == "title" else tags if what == "hashtags" else f"{title}\n{tags}".strip())
        QApplication.clipboard().setText("\n\n".join(x for x in lines if x))
        self.summary.setText(t("lib.copied", n=len(chosen)))

    def _play(self) -> None:
        path = self._selected_file()
        if path and Path(path).exists():
            open_path(path)

    def _show(self) -> None:
        path = self._selected_file()
        if path:
            show_in_folder(path)

    def _delete_selected(self) -> None:
        chosen = self._selected()
        if not chosen:
            warn(self, t("lib.nothing_selected"))
            return
        if self.ctx.busy:
            warn(self, t("msg.busy"))
            return
        if not confirm(self, t("lib.confirm_delete", n=len(chosen))):
            return
        done, failed = delete_clip_files(self.ctx.db, chosen)
        if failed:
            warn(self, t("lib.delete_failed") + "\n" + "\n".join(failed[:10]))
        self.ctx.clipsChanged.emit()
        self.refresh()
