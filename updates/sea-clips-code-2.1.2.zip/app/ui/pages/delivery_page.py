"""
=====================================================================
  UI / PAGES / DELIVERY
  Kaam: clips logon ko dene ka page.
  "Give the next N clips to <name>". Files move to
  <Campaign>/Delivered/<name> <date>/ and are never given twice.
=====================================================================
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QGridLayout, QHBoxLayout, QHeaderView, QLabel,
                               QLineEdit, QSpinBox, QTableWidget, QTableWidgetItem, QWidget)

from app.core.i18n import t
from app.output.delivery import available, deliver_next
from app.output.organizer import campaign_root
from app.ui import theme as T
from app.ui.context import open_path
from app.ui.pages.common import PageHeader, fill_campaigns, page_layout, warn
from app.ui.widgets import Card, FoilButton, Toggle, field_label, ghost_button, section


class DeliveryPage(QWidget):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.last_folder = ""
        lay = page_layout(self)
        lay.addWidget(PageHeader(t("del.title"), t("del.subtitle")))

        row = QHBoxLayout()
        row.setSpacing(24)

        give = Card(padding=24)
        give.setFixedWidth(430)
        self.campaign = QComboBox()
        self.campaign.currentIndexChanged.connect(self.refresh)
        self.available = QLabel("")
        self.available.setFont(T.font(12, T.UI_BOLD))
        self.available.setStyleSheet(f"color: {T.GOLD_LIGHT};")
        self.receiver = QLineEdit()
        self.receiver.setPlaceholderText("e.g. Ali")
        self.count = QSpinBox()
        self.count.setRange(1, 5000)
        self.count.setValue(50)
        self.include_below = Toggle(False)
        self.include_below.toggled.connect(self.refresh)
        g = QGridLayout()
        g.setVerticalSpacing(8)
        g.setHorizontalSpacing(14)
        g.addWidget(field_label(t("create.campaign")), 0, 0, 1, 2)
        g.addWidget(self.campaign, 1, 0, 1, 2)
        g.addWidget(field_label(t("del.receiver")), 2, 0)
        g.addWidget(field_label(t("del.count")), 2, 1)
        g.addWidget(self.receiver, 3, 0)
        g.addWidget(self.count, 3, 1)
        g.setColumnStretch(0, 3)
        g.setColumnStretch(1, 2)
        give.body.addLayout(g)
        trow = QHBoxLayout()
        lbl = QLabel(t("del.include_below"))
        lbl.setFont(T.font(10.5))
        trow.addWidget(lbl, 1)
        trow.addWidget(self.include_below)
        give.body.addLayout(trow)
        give.body.addWidget(self.available)
        self.give_btn = FoilButton(t("del.give"))
        self.give_btn.clicked.connect(self._give)
        give.body.addWidget(self.give_btn)
        self.result = QLabel("")
        self.result.setWordWrap(True)
        self.result.setFont(T.font(10))
        give.body.addWidget(self.result)
        self.open_btn = ghost_button(t("common.open_folder"))
        self.open_btn.clicked.connect(lambda: self.last_folder and open_path(self.last_folder))
        self.open_btn.setVisible(False)
        give.body.addWidget(self.open_btn)
        give.body.addStretch(1)
        row.addWidget(give, 0, Qt.AlignTop)

        hist = Card(padding=20)
        hist.body.addWidget(section(t("del.history")))
        cols = [t("del.col.date"), t("del.col.to"), t("del.col.count"), t("del.col.range")]
        self.table = QTableWidget(0, len(cols))
        self.table.setHorizontalHeaderLabels(cols)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(True)
        head = self.table.horizontalHeader()
        head.setSectionResizeMode(QHeaderView.ResizeToContents)
        head.setSectionResizeMode(3, QHeaderView.Stretch)
        hist.body.addWidget(self.table, 1)
        row.addWidget(hist, 1)
        lay.addLayout(row, 1)

        ctx.campaignsChanged.connect(self._campaigns)
        ctx.clipsChanged.connect(self._maybe_refresh)
        ctx.busyChanged.connect(lambda busy: self.give_btn.setEnabled(not busy))
        self._campaigns()

    def _campaigns(self) -> None:
        fill_campaigns(self.campaign, self.ctx)
        self.refresh()

    def _maybe_refresh(self) -> None:
        if self.isVisible():
            self.refresh()

    def showEvent(self, e):
        self.refresh()
        super().showEvent(e)

    def refresh(self, *_) -> None:
        cid = self.campaign.currentData()
        if not cid:
            self.available.setText(t("del.available", n=0))
            self.table.setRowCount(0)
            return
        self.ctx.db.sync_missing_files(cid)              # haath se delete hue clips kabhi "file missing" na banein
        n = len(available(self.ctx.db, cid, self.include_below.isChecked()))
        self.available.setText(t("del.available", n=n))
        self.give_btn.setEnabled(n > 0 and not self.ctx.busy)
        history = self.ctx.db.delivery_history(cid)
        self.table.setRowCount(len(history))
        for r, d in enumerate(history):
            vals = (d["created_at"].replace("T", "  "), d["receiver"], str(d["clip_count"]),
                    f"{d['first_label']}   to   {d['last_label']}")
            for c, v in enumerate(vals):
                item = QTableWidgetItem(v)
                if c == 2:
                    item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(r, c, item)

    def _give(self) -> None:
        cid = self.campaign.currentData()
        if not cid:
            return
        if not self.receiver.text().strip():
            warn(self, t("del.receiver"))
            return
        profile = self.ctx.db.get_campaign(cid)
        root = campaign_root(Path(self.ctx.settings.output_dir), profile)
        self.ctx.db.sync_missing_files(cid)
        try:
            res = deliver_next(self.ctx.db, cid, root, self.receiver.text(), self.count.value(),
                               include_below=self.include_below.isChecked())
        except (ValueError, OSError) as exc:
            warn(self, str(exc))
            return
        text = t("del.done", n=res.count, folder=str(res.folder))
        if res.missing:
            text += "\n" + t("del.missing", n=len(res.missing))
        if res.locked:
            text += "\n" + t("del.locked", n=len(res.locked))
        self.result.setText(text)
        self.last_folder = str(res.folder)
        self.open_btn.setVisible(True)
        self.ctx.clipsChanged.emit()
        self.refresh()
