"""
=====================================================================
  UI / PAGES / COMMON
  Kaam: pages ke saanjhe chhote hisse.
  Page header (gold title, subtitle, GPU status pill) and helpers
  shared by every page.
=====================================================================
"""
from __future__ import annotations

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (QComboBox, QHBoxLayout, QLabel, QMessageBox, QScrollArea, QVBoxLayout,
                               QWidget)

from app.core.i18n import t
from app.ui import theme as T
from app.ui.widgets import GoldLine, GoldTitle


class StatusPill(QWidget):
    """'NVIDIA GPU active' / 'CPU mode' pill in the header."""

    def __init__(self, text: str, ok: bool, parent=None):
        super().__init__(parent)
        self.text, self.ok = text, ok
        self.setFont(T.font(10, T.UI_SEMI))
        w = self.fontMetrics().horizontalAdvance(text) + 52
        self.setFixedSize(w, 38)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setPen(QPen(QColor(230, 192, 114, 120), 1))
        p.setBrush(QColor(20, 18, 14, 230))
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        dot = QColor(T.OK_GREEN if self.ok else T.WARN)
        glow = QColor(dot)
        glow.setAlpha(70)
        p.setPen(Qt.NoPen)
        p.setBrush(glow)
        p.drawEllipse(QRectF(r.left() + 13, r.center().y() - 6, 12, 12))
        p.setBrush(dot)
        p.drawEllipse(QRectF(r.left() + 16, r.center().y() - 3, 6, 6))
        p.setPen(QColor("#F6E3B4"))
        p.setFont(self.font())
        p.drawText(r.adjusted(32, 0, -10, 0), Qt.AlignVCenter | Qt.AlignLeft, self.text)


class PageHeader(QWidget):
    def __init__(self, title: str, subtitle: str, ctx=None, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        row = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(4)
        self.title = GoldTitle(title, 25)
        self.subtitle = QLabel(subtitle)
        self.subtitle.setProperty("role", "muted")
        self.subtitle.setFont(T.font(10.5))
        col.addWidget(self.title)
        col.addWidget(self.subtitle)
        row.addLayout(col, 1)
        if ctx is not None:
            pill = StatusPill(t("settings.gpu") if ctx.has_gpu else t("settings.cpu"), ctx.has_gpu)
            row.addWidget(pill, 0, Qt.AlignTop)
        lay.addLayout(row)
        lay.addSpacing(20)
        lay.addWidget(GoldLine())
        lay.addSpacing(22)


def page_layout(widget: QWidget) -> QVBoxLayout:
    lay = QVBoxLayout(widget)
    lay.setContentsMargins(40, 32, 40, 28)
    lay.setSpacing(0)
    return lay


def scroll_wrap(inner: QWidget) -> QScrollArea:
    area = QScrollArea()
    area.setWidgetResizable(True)
    area.setFrameShape(QScrollArea.NoFrame)
    area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    inner.setObjectName("content")
    area.setWidget(inner)
    area.viewport().setAutoFillBackground(False)
    inner.setAutoFillBackground(False)
    return area


def fill_campaigns(combo: QComboBox, ctx, keep_id: int | None = None) -> None:
    """Fill a combo with campaigns (data = id), keeping the selection."""
    current = keep_id if keep_id is not None else combo.currentData()
    combo.blockSignals(True)
    combo.clear()
    for cid, name in ctx.db.list_campaigns():
        combo.addItem(name, cid)
    idx = combo.findData(current)
    if idx < 0 and combo.count():
        idx = combo.findText(ctx.settings.default_campaign)
    combo.setCurrentIndex(max(0, idx))
    combo.blockSignals(False)


def info(parent, text: str, title: str = "") -> None:
    QMessageBox.information(parent, title or " ", text)


def warn(parent, text: str, title: str = "") -> None:
    QMessageBox.warning(parent, title or " ", text)


def confirm(parent, text: str) -> bool:
    box = QMessageBox(QMessageBox.Question, " ", text, parent=parent)
    yes = box.addButton(t("common.yes"), QMessageBox.YesRole)
    box.addButton(t("common.no"), QMessageBox.NoRole)
    box.exec()
    return box.clickedButton() is yes


def split_list(text: str) -> list[str]:
    return [x.strip() for x in text.replace("\n", ",").split(",") if x.strip()]
