"""
=====================================================================
  UI / STUDIO PAGE            (SEA CLIPS 2.0 main screen)
  Kaam: ek link daalo, "Add" dabao. Line khali ho to foran shuru,
  warna line mein lag jati hai aur apni baari par khud shuru hoti hai.
  Left : link box (link ya video file), campaign, clips, length,
         preview, Add. Neeche "Now creating": chalti video, steps,
         ginti aur waqt.
  Right: The Line: har video apne campaign, clips aur length ke saath,
         waqt ka andaza, upar / neeche, pause, hatao, badlo.
  The work runs in its own process (app.queue), so this page and every
  other page stay smooth while clips are being made.
=====================================================================
"""
from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QFrame,
                               QHBoxLayout, QLabel, QLineEdit, QMenu, QPushButton, QScrollArea,
                               QSpinBox, QVBoxLayout, QWidget)

from app.core.i18n import t
from app.media.download import is_url
from app.queue import eta
from app.queue.store import DONE, FAILED, PAUSED, RUNNING, STOPPED, WAITING, QueueItem
from app.ui import theme as T
from app.ui.context import open_path
from app.ui.pages.common import fill_campaigns, warn
from app.ui.widgets import Card, Toggle

VIDEO_EXT = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}
STEPS = (("download", "Download"), ("transcribe", "Listen"), ("plan", "Find moments"),
         ("render", "Edit & render"), ("check", "Check"))
STAGE_STEP = {"download": 0, "prepare": 1, "transcribe": 1, "plan": 2, "render": 3}


def _label(text: str, size: float = 10, family: str = "", color: str = "", spacing: float = 0.0) -> QLabel:
    lab = QLabel(text)
    fam = family or T.UI_FONT
    lab.setFont(T.font(size, fam, spacing))
    # QSS ka "* { font-family }" setFont ko dabata hai, is liye family stylesheet mein bhi
    lab.setStyleSheet(f"font-family:'{fam}';" + (f"color:{color};" if color else ""))
    return lab


def _head(text: str) -> QLabel:
    return _label(text.upper(), 8.5, T.UI_BOLD, "#8E7D58", 2.0)


def _short_source(src: str) -> str:
    if is_url(src):
        s = src.split("://", 1)[-1]
        return s if len(s) < 48 else s[:45] + "..."
    return Path(src).name


# ---------------------------------------------------------------------
#  Ye link pehle aa chuka? (15 Nov) kis campaign mein kitne clips bane, line mein hai ya nahi
# ---------------------------------------------------------------------
def video_key(src: str) -> str:
    import re
    m = re.search(r"(?:youtu\.be/|[?&]v=|/shorts/|/live/|/embed/)([A-Za-z0-9_-]{11})", src)
    return m.group(1) if m else ""


def link_history(db, store, src: str) -> str:
    key = video_key(src)
    if not key:
        return ""
    lines = []
    with db._conn() as c:
        rows = c.execute("SELECT c.name, COUNT(*), MAX(k.created_at) FROM clips k JOIN campaigns c ON c.id = k.campaign_id"
                         " WHERE k.source_path LIKE ? GROUP BY c.name", (f"%[{key}]%",)).fetchall()
    for name, n, last in rows:
        lines.append(f"• {name}: {n} clips made (last {str(last)[:10]})")
    for item in store.items(0):
        if video_key(item.source) == key:
            lines.append(f"• In the line now: {item.campaign_name}, {item.made} of {item.clip_count} clips")
    return "\n".join(lines)


# ---------------------------------------------------------------------
#  Link box: link likho / paste karo, ya video file chhor do
# ---------------------------------------------------------------------
class LinkBox(QLineEdit):
    fileDropped = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setPlaceholderText("https://youtu.be/...   or drop a video file here")
        self.setMinimumHeight(46)

    def dragEnterEvent(self, e):
        md = e.mimeData()
        if md.hasUrls() or md.hasText():
            e.acceptProposedAction()

    def dropEvent(self, e):
        md = e.mimeData()
        for u in md.urls():
            if u.isLocalFile() and Path(u.toLocalFile()).suffix.lower() in VIDEO_EXT:
                self.setText(u.toLocalFile())
                self.fileDropped.emit(u.toLocalFile())
                return
            if u.scheme().startswith("http"):
                self.setText(u.toString())
                return
        if md.hasText():
            self.setText(md.text().strip().splitlines()[0] if md.text().strip() else "")


class Field(QFrame):
    """Small labelled box (CAMPAIGN / CLIPS / LENGTH / PREVIEW)."""

    def __init__(self, label: str, editor: QWidget, parent=None):
        super().__init__(parent)
        self.setProperty("role", "fieldbox")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 7, 12, 7)
        lay.setSpacing(1)
        lay.addWidget(_label(label.upper(), 7.5, T.UI_SEMI, "#8E7D58", 1.0))
        editor.setStyleSheet("background:transparent; border:none; padding:0; font-size:11pt;"
                             f"font-family:'{T.UI_BOLD}'; color:#F0E4C3;")
        lay.addWidget(editor)


class Ring(QWidget):
    """Dashed gold circle with a plus (click = choose a video file)."""
    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(84, 84)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Choose a video file from this laptop")

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.clicked.emit()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        pen = QPen(QColor("#6B5630"), 1.5, Qt.DashLine)
        p.setPen(pen)
        p.drawEllipse(QRectF(2, 2, 80, 80))
        p.setPen(QPen(QColor("#E9CF88"), 2.2))
        p.drawLine(42, 30, 42, 54)
        p.drawLine(30, 42, 54, 42)


class Phone(QWidget):
    """9:16 preview frame showing the latest clip's picture."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(176, 312)
        self.pix: QPixmap | None = None
        self.file = ""
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Latest clip (click to play)")

    def set_clip(self, thumb: str, file: str) -> None:
        self.file = file
        self.pix = QPixmap(thumb) if thumb and Path(thumb).exists() else None
        self.update()

    def mousePressEvent(self, e):
        if self.file and Path(self.file).exists():
            open_path(self.file)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath()
        path.addRoundedRect(r, 20, 20)
        p.setClipPath(path)
        p.fillRect(r, QColor("#1B160D"))
        if self.pix and not self.pix.isNull():
            pm = self.pix.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            p.drawPixmap(int((self.width() - pm.width()) / 2), int((self.height() - pm.height()) / 2), pm)
        else:
            p.setPen(QColor("#6B5630"))
            p.setFont(T.font(9))
            p.drawText(r, Qt.AlignCenter, "Clips appear here")
        p.setClipping(False)
        p.setPen(QPen(QColor("#4A3C20"), 1))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(r, 20, 20)


class Stepper(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(54)
        self.current = -1
        self.done_all = False

    def set_step(self, k: int, done_all: bool = False) -> None:
        self.current, self.done_all = k, done_all
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        n = len(STEPS)
        w = self.width() / n
        for i in range(n - 1):
            x0, x1 = w * (i + 0.5) + 16, w * (i + 1.5) - 16
            ok = self.done_all or i < self.current
            p.setPen(QPen(QColor("#D4A84B" if ok else "#3A3121"), 1.5))
            p.drawLine(int(x0), 14, int(x1), 14)
        for i, (_key, name) in enumerate(STEPS):
            cx = w * (i + 0.5)
            ok = self.done_all or i < self.current
            go = (i == self.current) and not self.done_all
            rect = QRectF(cx - 13, 1, 26, 26)
            if ok:
                p.setPen(Qt.NoPen)
                p.setBrush(QColor("#D4A84B"))
            elif go:
                p.setPen(QPen(QColor("#F3D993"), 1.5))
                p.setBrush(QColor("#0F0D09"))
            else:
                p.setPen(QPen(QColor("#3A3121"), 1.5))
                p.setBrush(QColor("#0F0D09"))
            p.drawEllipse(rect)
            p.setPen(QColor("#18120A") if ok else QColor("#F3D993" if go else "#7D7158"))
            p.setFont(T.font(8.5, T.UI_BOLD))
            p.drawText(rect, Qt.AlignCenter, "✓" if ok else str(i + 1))
            p.setPen(QColor("#F3D993" if go else ("#CDB98A" if ok else "#7D7158")))
            p.setFont(T.font(8.5, T.UI_BOLD if go else T.UI_FONT))
            p.drawText(QRectF(cx - w / 2, 32, w, 20), Qt.AlignCenter, name)


class Kpi(QFrame):
    def __init__(self, small: str, parent=None):
        super().__init__(parent)
        self.setProperty("role", "fieldbox")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 9, 12, 9)
        lay.setSpacing(0)
        self.big = _label("-", 19, T.SERIF, "#F3D993")
        lay.addWidget(self.big)
        lay.addWidget(_label(small, 8.5, T.UI_FONT, "#8E7D58"))

    def set(self, text: str) -> None:
        self.big.setText(text)


# ---------------------------------------------------------------------
#  Line ki ek video
# ---------------------------------------------------------------------
class LineRow(QFrame):
    action = Signal(int, str)          # item id, action

    def __init__(self, n: int, item: QueueItem, eta_text: str, parent=None):
        super().__init__(parent)
        self.item = item
        self.setObjectName("lineRow")
        self.setStyleSheet("QFrame#lineRow{border:none; border-bottom:1px solid #221D13;}")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(4, 10, 4, 10)
        lay.setSpacing(12)
        mark = "✓" if item.status == DONE else ("!" if item.status == FAILED else str(n))
        num = _label(mark, 9.5, T.UI_BOLD, "#CDB98A")
        num.setAlignment(Qt.AlignCenter)
        num.setFixedSize(26, 26)
        num.setStyleSheet(f"font-family:'{T.UI_BOLD}'; color:#CDB98A; background:#1B170E; border:1px solid #3A3121; border-radius:8px;")
        lay.addWidget(num)
        col = QVBoxLayout()
        col.setSpacing(2)
        title = item.title or _short_source(item.source)
        tt = _label(title if len(title) < 46 else title[:43] + "...", 10.5, T.UI_SEMI, "#EFE3C2")
        tt.setToolTip(f"{item.title}\n{item.source}" if item.title else item.source)
        col.addWidget(tt)
        bits = [item.campaign_name]
        if item.status in (RUNNING, PAUSED, STOPPED) or (item.made and item.status != DONE):
            bits.append(f"{item.made} of {item.clip_count}")
        elif item.status == DONE:
            bits.append(f"{item.made} made")
        else:
            bits.append(f"{item.clip_count} clips")
        bits.append(f"{item.min_len} to {item.max_len} s")
        if item.preview and item.status != DONE:
            bits.append("preview on")
        mm = _label(" · ".join(bits), 8.8, T.UI_FONT, "#8F846B")
        col.addWidget(mm)
        if item.status == FAILED and item.error:
            err = _label(item.error[:90] + ("..." if len(item.error) > 90 else ""), 8.3, T.UI_FONT, T.ERROR)
            err.setToolTip(item.error)
            err.setWordWrap(True)
            col.addWidget(err)
        lay.addLayout(col, 1)
        tag_text, fg, bg = {
            RUNNING: (eta_text + " left", "#F3D993", "rgba(212,168,75,0.14)"),
            WAITING: ("≈ " + eta_text, "#A99D82", "#1D1A14"),
            PAUSED: ("Paused", "#E9CF88", "#2A2213"),
            STOPPED: ("Stopped", "#E9CF88", "#2A2213"),
            DONE: ("Done", "#8FE39C", "#13261A"),
            FAILED: ("Skipped", "#F0A090", "#2A1512"),
        }.get(item.status, ("", "#A99D82", "#1D1A14"))
        tag = _label(tag_text, 8.5, T.UI_SEMI, fg)
        tag.setStyleSheet(f"font-family:'{T.UI_SEMI}'; color:{fg}; background:{bg}; border-radius:9px; padding:3px 9px;")
        lay.addWidget(tag, 0, Qt.AlignVCenter)
        more = QPushButton("•••")
        more.setProperty("role", "ghost")
        more.setFixedSize(30, 26)
        more.setStyleSheet("padding:0; font-size:7pt; color:#CDB98A;")
        more.setCursor(Qt.PointingHandCursor)
        more.clicked.connect(self._menu)
        lay.addWidget(more, 0, Qt.AlignVCenter)
        self._more = more

    def _menu(self) -> None:
        m = QMenu(self)
        st = self.item.status
        acts = []
        if st in (WAITING, PAUSED):
            acts += [("Move up", "up"), ("Move down", "down"), ("Change clips / length", "edit")]
        if st == WAITING:
            acts.append(("Hold (skip for now)", "hold"))
        if st in (PAUSED, STOPPED):
            acts.append(("Continue", "resume"))
        if st == FAILED:
            acts.append(("Try again", "resume"))
        if st != RUNNING:
            acts.append(("Remove from line", "remove"))
        if st in (DONE, RUNNING, STOPPED, PAUSED) and self.item.made:
            acts.append(("Open clips folder", "folder"))
        for text, key in acts:
            m.addAction(text, lambda k=key: self.action.emit(self.item.id, k))
        if acts:
            m.exec(self._more.mapToGlobal(self._more.rect().bottomLeft()))


class EditItemDialog(QDialog):
    """Line mein padi video ki apni clips / length / preview."""

    def __init__(self, item: QueueItem, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Change this video")
        lay = QFormLayout(self)
        self.count = QSpinBox()
        self.count.setRange(max(1, item.made + 1), 2000)
        self.count.setValue(max(item.clip_count, item.made + 1))
        self.lo, self.hi = QSpinBox(), QSpinBox()
        for sp, v in ((self.lo, item.min_len), (self.hi, item.max_len)):
            sp.setRange(5, 600)
            sp.setSuffix(" s")
            sp.setValue(v)
        self.preview = Toggle(bool(item.preview))
        lay.addRow("Clips from this video", self.count)
        lay.addRow("Shortest", self.lo)
        lay.addRow("Longest", self.hi)
        lay.addRow("Preview first 10", self.preview)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addRow(bb)


# ---------------------------------------------------------------------
class StudioPage(QWidget):
    goToCampaigns = Signal()

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.ctl = ctx.queue
        self.counts = {"recommended": 0, "medium": 0, "below": 0, "check": 0}
        self._last_item = None

        outer = QHBoxLayout(self)
        outer.setContentsMargins(28, 16, 28, 12)
        outer.setSpacing(20)
        left = QVBoxLayout()
        left.setSpacing(18)
        left.addWidget(self._build_input())
        left.addWidget(self._build_now(), 1)
        outer.addLayout(left, 1)
        outer.addWidget(self._build_line())

        self.ctl.lineChanged.connect(self.refresh_line)
        self.ctl.itemStarted.connect(self._on_started)
        self.ctl.stage.connect(self._on_stage)
        self.ctl.progress.connect(self._on_progress)
        self.ctl.clipDone.connect(self._on_clip)
        self.ctl.warning.connect(self._on_warning)
        self.ctl.preview.connect(self._on_preview)
        self.ctl.itemFinished.connect(self._on_item_finished)
        self.ctl.itemFailed.connect(self._on_item_failed)
        self.ctl.idle.connect(self._on_idle)
        ctx.campaignsChanged.connect(self.refresh_campaigns)
        self._tick = QTimer(self)
        self._tick.timeout.connect(self._update_times)
        self._tick.start(5000)
        self.refresh_campaigns()
        self.refresh_line()
        self._show_idle()

    # (18 Nov) Google Sheet se aaj ka target: campaign + kitni clips, sheet ke Pending se khud links
    def _build_target(self) -> QHBoxLayout:
        row = QHBoxLayout()
        row.setSpacing(10)
        row.addWidget(_label("TODAY FROM SHEET", 7.5, T.UI_SEMI, "#8E7D58", 1.0))
        self.t_campaign = QComboBox()
        self.t_campaign.setMinimumWidth(170)
        self.t_goal = QSpinBox()
        self.t_goal.setRange(1, 5000)
        self.t_goal.setValue(300)
        self.t_goal.setSuffix(" clips")
        self.t_goal.setButtonSymbols(QSpinBox.NoButtons)
        self.t_btn = QPushButton("Start")
        self.t_btn.setProperty("role", "gold")
        self.t_btn.setMinimumWidth(90)
        self.t_btn.setCursor(Qt.PointingHandCursor)
        self.t_btn.clicked.connect(self._target_clicked)
        self.t_text = _label("", 8.5, T.UI_FONT, "#8F846B")
        for w in (self.t_campaign, self.t_goal, self.t_btn):
            row.addWidget(w)
        row.addWidget(self.t_text, 1)
        links = getattr(self.ctx, "links", None)
        if links is not None:
            links.status.connect(lambda _t: self._target_fill())
        self.t_campaign.currentIndexChanged.connect(lambda *_: self._target_refresh())
        QTimer.singleShot(0, self._target_fill)
        return row

    def _target_fill(self) -> None:
        from app.campaign.link_sheets import load_sources
        keep = self.t_campaign.currentData()
        self.t_campaign.blockSignals(True)
        self.t_campaign.clear()
        for src in load_sources():
            if src.get("sheet_id"):
                self.t_campaign.addItem(src["campaign"], src["campaign"])
        if self.t_campaign.count() == 0:
            self.t_campaign.addItem("No channel sheet yet", "")
        i = self.t_campaign.findData(keep)
        self.t_campaign.setCurrentIndex(max(0, i))
        self.t_campaign.blockSignals(False)
        self._target_refresh()

    def _target_refresh(self) -> None:
        links = getattr(self.ctx, "links", None)
        camp = self.t_campaign.currentData() or ""
        if links is None or not camp:
            self.t_btn.setEnabled(False)
            self.t_text.setText("Add a channel in Settings, Channel sheets" if links is not None else "")
            return
        self.t_btn.setEnabled(True)
        t = links.target(camp)
        if t.get("active"):
            made, goal = links.progress(camp)
            self.t_btn.setText("Stop")
            self.t_goal.setValue(goal or self.t_goal.value())
            self.t_text.setText(f"{made} of {goal} clips today" + (f" · {links.text}" if links.text and camp not in links.text else ""))
        else:
            self.t_btn.setText("Start")
            self.t_text.setText(links.text if camp in (links.text or "") else "")

    def _target_clicked(self) -> None:
        links = getattr(self.ctx, "links", None)
        camp = self.t_campaign.currentData() or ""
        if links is None or not camp:
            return
        if links.target(camp).get("active"):
            links.stop(camp)
        else:
            links.start(camp, self.t_goal.value())
        self._target_refresh()

    def _drive_toggled(self, on: bool) -> None:
        drive = getattr(self.ctx, "drive", None)
        if drive is None:
            return
        if on and not drive.auth.connected:
            self.drive.blockSignals(True)
            self.drive.setChecked(False)
            self.drive.blockSignals(False)
            warn(self, "Connect Google Drive first: Settings, Google Drive, Connect.")
            return
        drive.set_enabled(on)

    # ------------------------------------------------------------ build
    def _build_input(self) -> Card:
        card = Card(padding=24)
        row = QHBoxLayout()
        row.setSpacing(22)
        ring = Ring()
        ring.clicked.connect(self._choose_file)
        row.addWidget(ring, 0, Qt.AlignVCenter)
        col = QVBoxLayout()
        col.setSpacing(8)
        col.addWidget(_label("Paste a video link", 19, T.SERIF, "#F6E3A9"))
        col.addWidget(_label("One link at a time. If the line is empty it starts right away, otherwise it "
                             "joins the line and starts by itself when its turn comes.", 9.5, T.UI_FONT, "#8F846B"))
        self.link = LinkBox()
        self.link.returnPressed.connect(self._add)
        col.addWidget(self.link)
        opts = QHBoxLayout()
        opts.setSpacing(10)
        self.campaign = QComboBox()
        self.campaign.currentIndexChanged.connect(self._campaign_picked)
        self.count = QSpinBox()
        self.count.setRange(1, 2000)
        self.count.setValue(int(getattr(self.ctx.settings, "clip_count", 30) or 30))
        self.count.setButtonSymbols(QSpinBox.NoButtons)
        len_box = QWidget()
        lb = QHBoxLayout(len_box)
        lb.setContentsMargins(0, 0, 0, 0)
        lb.setSpacing(4)
        self.min_len, self.max_len = QSpinBox(), QSpinBox()
        for sp in (self.min_len, self.max_len):
            sp.setRange(5, 600)
            sp.setButtonSymbols(QSpinBox.NoButtons)
            sp.setFixedWidth(44)
            sp.setStyleSheet("background:transparent; border:none; padding:0; font-size:11pt;"
                             f"font-family:'{T.UI_BOLD}'; color:#F0E4C3;")
        lb.addWidget(self.min_len)
        lb.addWidget(_label("to", 10, T.UI_FONT, "#8F846B"))
        lb.addWidget(self.max_len)
        lb.addWidget(_label("s", 10, T.UI_FONT, "#8F846B"))
        lb.addStretch(1)
        self.preview = Toggle(False)
        self.preview.setToolTip("Stop after the first 10 clips so you can check them (it goes on by itself "
                                "after the campaign's wait time)")
        pv = QWidget()
        pl = QHBoxLayout(pv)
        pl.setContentsMargins(0, 2, 0, 0)
        pl.addWidget(self.preview)
        pl.addStretch(1)
        opts.addWidget(Field("Campaign", self.campaign), 3)
        opts.addWidget(Field("Clips from this video", self.count), 2)
        opts.addWidget(Field("Length", len_box), 2)
        f = Field("Preview first 10", pv)
        opts.addWidget(f, 2)
        # (18 Nov) Drive upload: on = 50 nayi clips (ya video khatam) ek saath Clip Pool mein, phir laptop se delete
        self.drive = Toggle(bool(getattr(self.ctx.settings, "drive_upload", False)))
        self.drive.setToolTip("On: new clips go to this campaign's Clip Pool folder on Google Drive, 50 at a time "
                              "(or all of them when a video ends), and are deleted from this laptop only after "
                              "Drive has a checked copy. Off: clips stay on the laptop; they go later when you "
                              "turn it on.")
        self.drive_text = _label("", 7.5, T.UI_FONT, "#8F846B")
        dv = QWidget()
        dl = QVBoxLayout(dv)
        dl.setContentsMargins(0, 2, 0, 0)
        dl.setSpacing(1)
        dl.addWidget(self.drive)
        dl.addWidget(self.drive_text)
        opts.addWidget(Field("Drive upload", dv), 2)
        self.drive_text.setStyleSheet(f"font-family:'{T.UI_FONT}'; font-size:7.5pt; color:#8F846B;")
        self.drive.toggled.connect(self._drive_toggled)
        drive = getattr(self.ctx, "drive", None)
        if drive is not None:
            def show(text: str) -> None:
                self.drive_text.setText(text)
                self.drive_text.setToolTip(drive.detail)
                self.drive.setToolTip(drive.detail)
            drive.status.connect(show)
            show(drive.text)
        self.add_btn = QPushButton("＋  Add")
        self.add_btn.setProperty("role", "gold")
        self.add_btn.setCursor(Qt.PointingHandCursor)
        self.add_btn.setMinimumHeight(46)
        self.add_btn.clicked.connect(self._add)
        opts.addWidget(self.add_btn, 0, Qt.AlignVCenter)
        col.addLayout(opts)
        col.addLayout(self._build_target())
        row.addLayout(col, 1)
        card.body.addLayout(row)
        return card

    def _build_now(self) -> Card:
        card = Card(padding=22)
        row = QHBoxLayout()
        row.setSpacing(22)
        self.phone = Phone()
        row.addWidget(self.phone, 0, Qt.AlignTop)
        col = QVBoxLayout()
        col.setSpacing(6)
        self.now_head = _head("Now creating")
        col.addWidget(self.now_head)
        self.now_title = _label("", 20, T.SERIF, "#F6E3A9")
        self.now_title.setWordWrap(True)
        col.addWidget(self.now_title)
        self.now_meta = _label("", 9.5, T.UI_FONT, "#8F846B")
        col.addWidget(self.now_meta)
        col.addSpacing(10)
        self.stepper = Stepper()
        col.addWidget(self.stepper)
        self.now_text = _label("", 9.5, T.UI_FONT, "#A99D82")
        self.now_text.setWordWrap(True)
        col.addWidget(self.now_text)
        col.addSpacing(6)
        kp = QHBoxLayout()
        kp.setSpacing(10)
        self.k_made, self.k_rec = Kpi("clips made"), Kpi("Recommended")
        self.k_left, self.k_done = Kpi("left on this video"), Kpi("whole line done")
        for k in (self.k_made, self.k_rec, self.k_left, self.k_done):
            kp.addWidget(k)
        col.addLayout(kp)
        col.addStretch(1)
        row.addLayout(col, 1)
        card.body.addLayout(row)
        return card

    def _build_line(self) -> Card:
        card = Card(padding=20)
        card.setFixedWidth(440)
        self.line_head = _head("The line")
        card.body.addWidget(self.line_head)
        self.rows_host = QWidget()
        self.rows = QVBoxLayout(self.rows_host)
        self.rows.setContentsMargins(0, 0, 0, 0)
        self.rows.setSpacing(0)
        self.rows.addStretch(1)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.rows_host.setObjectName("rowsHost")
        self.rows_host.setStyleSheet("QWidget#rowsHost{background:transparent;}")
        scroll.setWidget(self.rows_host)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea{background:transparent;} QScrollArea > QWidget > QWidget{background:transparent;}")
        scroll.viewport().setAutoFillBackground(False)
        card.body.addWidget(scroll, 1)
        note = _label("Each video keeps its own campaign, clips and length. The line is saved, so after a "
                      "restart it carries on.", 8.8, T.UI_FONT, "#8F846B")
        note.setWordWrap(True)
        card.body.addWidget(note)
        ctl = QHBoxLayout()
        ctl.setSpacing(8)
        self.pause_btn = QPushButton("Pause line")
        self.finish_btn = QPushButton("Finish current")
        self.stop_btn = QPushButton("Stop safely")
        for b in (self.pause_btn, self.finish_btn):
            b.setProperty("role", "ghost")
        self.stop_btn.setProperty("role", "danger")
        for b in (self.pause_btn, self.finish_btn, self.stop_btn):
            b.setCursor(Qt.PointingHandCursor)
            ctl.addWidget(b)
        self.pause_btn.clicked.connect(self._pause_clicked)
        self.finish_btn.clicked.connect(self._finish_clicked)
        self.stop_btn.clicked.connect(self._stop_clicked)
        card.body.addLayout(ctl)
        self.finish_btn.setToolTip("Let this video finish, then hold the line")
        self.stop_btn.setToolTip("Stop now. Clips already made are kept; this video continues later from here")
        return card

    # ------------------------------------------------------------ campaigns
    def refresh_campaigns(self) -> None:
        keep = self.campaign.currentData()
        self.campaign.blockSignals(True)
        fill_campaigns(self.campaign, self.ctx, keep)
        self.campaign.blockSignals(False)
        self._campaign_picked()

    def _campaign_picked(self, *_):
        cid = self.campaign.currentData()
        p = self.ctx.db.get_campaign(cid) if cid and cid != -1 else None
        lo, hi = p.length_range(self.ctx.settings) if p else (self.ctx.settings.min_length,
                                                              self.ctx.settings.max_length)
        self.min_len.setValue(int(lo))
        self.max_len.setValue(int(hi))

    def _choose_file(self) -> None:
        exts = " ".join(f"*{e}" for e in sorted(VIDEO_EXT))
        path, _ = QFileDialog.getOpenFileName(self, "Choose a video", "", f"Videos ({exts})")
        if path:
            self.link.setText(path)

    # ------------------------------------------------------------ add
    def _add(self) -> None:
        src = self.link.text().strip().strip('"')
        if not src:
            warn(self, "Paste a video link first (or drop a video file).")
            return
        if not is_url(src) and not Path(src).is_file():
            warn(self, "That is not a link or a video file on this laptop.")
            return
        cid = self.campaign.currentData()
        if not cid or cid == -1:
            warn(self, "Make a campaign first (Campaigns tab), then add videos to it.")
            self.goToCampaigns.emit()
            return
        p = self.ctx.db.get_campaign(cid)
        if p is None:
            return
        seen = link_history(self.ctx.db, self.ctl.store, src)
        if seen:
            from app.ui.pages.common import confirm
            if not confirm(self, "This link was given before:\n\n" + seen +
                           "\n\nAdd it again? New clips will be new moments or new edits, never the same clip."):
                return
        lo, hi = self.min_len.value(), self.max_len.value()
        if hi <= lo:
            hi = lo + 1
        item = QueueItem(source=src, title="" if is_url(src) else Path(src).stem.replace("_", " "),
                         campaign_id=int(cid), campaign_name=p.name, profile=p.to_dict(),
                         clip_count=self.count.value(), min_len=lo, max_len=hi,
                         preview=self.preview.isChecked())
        self.ctl.add(item)
        self.link.clear()
        self.preview.setChecked(False)

    # ------------------------------------------------------------ line
    def refresh_line(self) -> None:
        while self.rows.count() > 1:
            w = self.rows.takeAt(0).widget()
            if w:
                w.hide()
                w.setParent(None)
                w.deleteLater()
        items = self.ctl.store.items(include_finished=6)
        n = 0
        waiting = 0
        for item in items:
            if item.is_open:
                n += 1
            if item.status == WAITING:
                waiting += 1
            text = eta.fmt_duration(self.ctl.item_eta(item)) if item.status in (WAITING, RUNNING) else ""
            row = LineRow(n, item, text)
            row.action.connect(self._row_action)
            self.rows.insertWidget(self.rows.count() - 1, row)
        if not items:
            empty = _label("No videos in the line yet. Paste a link and press Add.", 9.5, T.UI_FONT, "#8F846B")
            empty.setWordWrap(True)
            self.rows.insertWidget(0, empty)
        total = self.ctl.line_eta()
        head = f"The line · {waiting} waiting"
        if total > 0 and (self.ctl.running or waiting):
            head += f" · finishes about {eta.fmt_clock(time.time() + total)}"
        self.line_head.setText(head.upper())
        self._update_buttons()
        self._update_times(refresh=False)

    def _update_buttons(self) -> None:
        running = self.ctl.running
        has_waiting = self.ctl.store.next_waiting() is not None
        if running and self.ctl.paused:
            self.pause_btn.setText("Resume")
        elif not running and has_waiting:
            self.pause_btn.setText("Start line")
        else:
            self.pause_btn.setText("Pause line")
        self.pause_btn.setEnabled(running or has_waiting)
        self.finish_btn.setEnabled(running and not self.ctl.hold)
        self.stop_btn.setEnabled(running)
        self.ctx.set_busy(running)

    def _pause_clicked(self) -> None:
        if self.ctl.running:
            if self.ctl.paused:
                self.ctl.unpause()
            else:
                self.ctl.pause()
                self.now_text.setText("Paused. Press Resume to carry on.")
        else:
            self.ctl.resume_line()
        self._update_buttons()

    def _finish_clicked(self) -> None:
        self.ctl.finish_current()
        self.now_text.setText("This video will finish, then the line holds.")

    def _stop_clicked(self) -> None:
        from app.ui.pages.common import confirm
        if confirm(self, "Stop now? Clips already made are kept, and this video continues from here later."):
            self.ctl.stop_current()
            self.now_text.setText("Stopping safely...")

    def _row_action(self, item_id: int, action: str) -> None:
        if action == "up":
            self.ctl.move(item_id, True)
        elif action == "down":
            self.ctl.move(item_id, False)
        elif action == "hold":
            self.ctl.set_paused(item_id, True)
        elif action == "resume":
            self.ctl.set_paused(item_id, False)
        elif action == "remove":
            self.ctl.remove(item_id)
        elif action == "edit":
            item = self.ctl.store.get(item_id)
            if item:
                dlg = EditItemDialog(item, self)
                if dlg.exec() == QDialog.Accepted:
                    lo, hi = dlg.lo.value(), max(dlg.hi.value(), dlg.lo.value() + 1)
                    self.ctl.change(item_id, clip_count=dlg.count.value(), min_len=lo, max_len=hi,
                                    preview=dlg.preview.isChecked())
        elif action == "folder":
            item = self.ctl.store.get(item_id)
            if item:
                from app.core.config import CampaignProfile
                from app.output.organizer import campaign_root
                try:
                    root = campaign_root(Path(self.ctx.settings.output_dir), CampaignProfile.from_dict(item.profile))
                    open_path(root)
                except Exception:  # noqa: BLE001
                    pass

    # ------------------------------------------------------------ run signals
    def _show_idle(self) -> None:
        self.now_head.setText("NOW CREATING")
        self.now_title.setText("Nothing running")
        self.now_meta.setText("Paste a link above and press Add. Videos run one after another by themselves.")
        self.stepper.set_step(-1)
        self.now_text.setText("")
        for k in (self.k_made, self.k_rec, self.k_left, self.k_done):
            k.set("-")

    def _on_started(self, item_id: int) -> None:
        item = self.ctl.store.get(item_id)
        if not item:
            return
        self._last_item = item
        self.counts = {"recommended": 0, "medium": 0, "below": 0, "check": 0}
        for k, v in (item.counts or {}).items():
            self.counts[k] = self.counts.get(k, 0) + int(v)
        self.now_head.setText("NOW CREATING")
        self.now_title.setText(item.title or _short_source(item.source))
        p = item.profile or {}
        style = p.get("ratio") or "9:16"
        plat = (p.get("platform") or "").title()
        self.now_meta.setText(" · ".join(x for x in (item.campaign_name, plat, style,
                                                      f"{item.min_len} to {item.max_len} s") if x))
        self.stepper.set_step(0)
        self.now_text.setText("Starting...")
        self.k_made.set(f"{item.made}/{item.clip_count}")
        self.k_rec.set(str(self.counts.get("recommended", 0)))
        self._update_times()

    def _on_stage(self, name: str) -> None:
        if name in STAGE_STEP:
            self.stepper.set_step(STAGE_STEP[name])
        try:
            self.now_text.setText(t(f"stage.{name}"))
        except Exception:  # noqa: BLE001
            pass

    def _on_progress(self, value: float, text: str) -> None:
        if text:
            self.now_text.setText(text)

    def _on_clip(self, done: int, total: int, info: dict) -> None:
        item = self.ctl.current
        if not item:
            return
        rating = info.get("rating", "")
        if rating:
            self.counts[rating] = self.counts.get(rating, 0) + 1
        self.k_made.set(f"{item.made}/{item.clip_count}")
        self.k_rec.set(str(self.counts.get("recommended", 0)))
        if info.get("thumb") or info.get("file"):
            self.phone.set_clip(info.get("thumb", ""), info.get("file", ""))
        if info.get("title"):
            self.now_text.setText(f"Last clip: {info.get('title')}")
        self._update_times()
        self.refresh_line()
        self.ctx.clipsChanged.emit()

    def _on_warning(self, key: str, data: dict) -> None:
        try:
            text = t(key, **data)
        except Exception:  # noqa: BLE001
            text = key
        self.now_text.setText(f"<span style='color:{T.WARN}'>{text}</span>")

    def _on_preview(self, infos: list) -> None:
        from app.pipeline.runner import preview_wait
        from app.ui.pages.create_page import PREVIEW_SECONDS, PreviewDialog
        item = self.ctl.current
        profile = None
        if item and item.profile:
            from app.core.config import CampaignProfile
            profile = CampaignProfile.from_dict(item.profile)
        dlg = PreviewDialog(infos, self, seconds=int(preview_wait(profile)) if profile else PREVIEW_SECONDS)
        answer = "ok" if dlg.exec() == QDialog.Accepted else "cancel"
        self.ctl.answer_preview(answer)

    def _on_item_finished(self, item_id: int, summary: dict) -> None:
        self.stepper.set_step(len(STEPS), done_all=not summary.get("cancelled"))
        made = summary.get("made", 0)
        c = summary.get("counts") or {}
        if summary.get("cancelled"):
            self.now_text.setText(f"Stopped. {made} clips made; it continues from here later.")
        else:
            extra = f", {c.get('check')} in Check" if c.get("check") else ""
            self.now_text.setText(f"Done: {made} clips ({c.get('recommended', 0)} Recommended, "
                                  f"{c.get('medium', 0)} Medium, {c.get('below', 0)} Below{extra}).")
        self.ctx.clipsChanged.emit()

    def _on_item_failed(self, item_id: int, key: str, detail: str, trace: str) -> None:
        try:
            text = t(key)
        except Exception:  # noqa: BLE001
            text = key
        self.now_text.setText(f"<span style='color:{T.ERROR}'>Skipped: {text} {detail[:160]}</span>")
        self.ctx.clipsChanged.emit()

    def _on_idle(self) -> None:
        self._update_buttons()
        if not self.ctl.running:
            if self._last_item is None:
                self._show_idle()
            else:
                self.now_head.setText("LAST VIDEO")
            self.k_left.set("-")
            self.k_done.set("-")

    def _update_times(self, refresh: bool = True) -> None:
        item = self.ctl.current
        if item:
            self.k_left.set(eta.fmt_duration(self.ctl.item_eta(item)))
        total = self.ctl.line_eta()
        if total > 0 and (self.ctl.running or self.ctl.store.next_waiting()):
            self.k_done.set(eta.fmt_clock(time.time() + total))

    # ------------------------------------------------------------ window
    def request_stop(self) -> bool:
        return self.ctl.running
