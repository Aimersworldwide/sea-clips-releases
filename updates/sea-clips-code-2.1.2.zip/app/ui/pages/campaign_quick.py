"""
=====================================================================
  UI / CAMPAIGN QUICK        (SEA CLIPS 2.0 campaign screen ka upar wala hissa)
  Kaam: editing style ke 6 cards, background (Blur / Black / White /
  Mix) aur tasveer ka size, brief ke "samjhe hue" tags.
  A style card is a named preset: clicking it sets the few layout
  switches that make that look. Every other setting stays as it is
  and is still reachable under "Advanced".
=====================================================================
"""
from __future__ import annotations

from PySide6.QtCore import QRectF, Qt, Signal
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import (QButtonGroup, QFrame, QHBoxLayout, QLabel, QLayout, QPushButton, QSlider, QWidget,
                               QWidgetItem)

from app.ui import theme as T

# key, title, subtitle, preset (profile fields)
LOOKS = (
    ("solo_focus", "Solo Focus", "One speaker",
     dict(fill_screen=False, stack_layout=False, whole_picture=False, captions_enabled=True)),
    ("dual_split", "Dual Split", "Speaker + listener",
     dict(fill_screen=True, stack_layout=True, whole_picture=False, captions_enabled=True)),
    ("street_talk", "Street Talk", "Host and guest",       # (15 Nov) screen bhari (koi patti nahi), halka zoom, bolne wale par
     dict(fill_screen=True, stack_layout=False, whole_picture=False, captions_enabled=True, level_voices=True,
          complete_point=True)),
    ("full_frame", "Full Frame", "Whole picture",
     dict(fill_screen=False, stack_layout=False, whole_picture=True, captions_enabled=True)),
    ("clean_fill", "Clean Fill", "Never black bars",
     dict(fill_screen=True, stack_layout=False, whole_picture=False, captions_enabled=True)),
    ("cinematic", "Cinematic", "No speech",
     dict(fill_screen=False, stack_layout=False, whole_picture=False, captions_enabled=False)),
)
LOOK_KEYS = [k for k, *_ in LOOKS]
BG_LOOKS = ("full_frame",)                       # upar neeche khali jagah sirf yahan: background selector
ZOOM_LOOKS = ("full_frame", "dual_split", "street_talk", "clean_fill")    # zoom / picture size slider
LOOK_ZOOM = {"street_talk": 1.3, "clean_fill": 1.5, "dual_split": 1.5, "full_frame": 1.5}
SIZES = ((1.0, "No zoom"), (1.3, "Light zoom"), (1.5, "Medium"), (1.7, "Strong"))


def detect_look(p) -> str:
    """Purani campaign (look khaali): switches se andaaza."""
    if getattr(p, "look", "") in LOOK_KEYS:
        return p.look
    if getattr(p, "whole_picture", False):
        return "full_frame"
    if not getattr(p, "captions_enabled", True):
        return "cinematic"
    if getattr(p, "fill_screen", False):
        if getattr(p, "stack_layout", True):
            return "dual_split"
        return "street_talk" if getattr(p, "level_voices", False) and getattr(p, "complete_point", False) \
            else "clean_fill"
    return "solo_focus"


def size_index(zoom: float) -> int:
    z = float(zoom or 0) or 1.7
    return min(range(len(SIZES)), key=lambda i: abs(SIZES[i][0] - z))


class StyleCard(QWidget):
    clicked = Signal(str)

    def __init__(self, key: str, title: str, sub: str, parent=None):
        super().__init__(parent)
        self.key, self.title, self.sub = key, title, sub
        self.on = False
        self.bg = "black"
        self.setFixedHeight(150)
        self.setMinimumWidth(110)
        self.setCursor(Qt.PointingHandCursor)

    def set_on(self, on: bool) -> None:
        self.on = on
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.clicked.emit(self.key)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setPen(QPen(QColor("#F3D993" if self.on else "#2B2417"), 1.4 if self.on else 1))
        p.setBrush(QColor("#0E0C08"))
        p.drawRoundedRect(r, 14, 14)
        m = QRectF(r.left() + 10, r.top() + 10, r.width() - 20, 92)
        bgc = {"white": "#E9E4D8", "black": "#000000"}.get(self.bg, "#2A2213") if self.key == "full_frame" else "#1C170E"
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(bgc))
        p.drawRoundedRect(m, 9, 9)

        def box(x0, y0, x1, y1, alpha=1.0):
            g = QLinearGradient(m.left() + x0 * m.width(), m.top() + y0 * m.height(),
                                m.left() + x1 * m.width(), m.top() + y1 * m.height())
            c1, c2 = QColor("#5C4A26"), QColor("#2A2213")
            c1.setAlphaF(alpha)
            c2.setAlphaF(alpha)
            g.setColorAt(0, c1)
            g.setColorAt(1, c2)
            p.setBrush(g)
            p.drawRoundedRect(QRectF(m.left() + x0 * m.width(), m.top() + y0 * m.height(),
                                     (x1 - x0) * m.width(), (y1 - y0) * m.height()), 4, 4)
        k = self.key
        if k == "solo_focus":
            box(.12, .12, .88, .88)
        elif k == "dual_split":
            box(.08, .07, .92, .49)
            box(.08, .51, .92, .93, .6)
        elif k == "street_talk":
            box(.07, .09, .72, .91)
            box(.75, .36, .93, .66, .6)
        elif k == "full_frame":
            box(.04, .33, .96, .67)
        elif k == "clean_fill":
            box(0, 0, 1, 1)
        else:
            box(.05, .06, .95, .94, .8)
        p.setPen(QColor("#F0E4C3"))
        p.setFont(T.font(9.5, T.UI_BOLD))
        p.drawText(QRectF(r.left(), m.bottom() + 6, r.width(), 18), Qt.AlignCenter, self.title)
        p.setPen(QColor("#8F846B"))
        p.setFont(T.font(8))
        p.drawText(QRectF(r.left(), m.bottom() + 23, r.width(), 16), Qt.AlignCenter, self.sub)


class BackgroundBar(QFrame):
    """BACKGROUND [Blur|Black|White|Mix]   PICTURE SIZE ----o---- Medium"""
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("bgbar")
        self.setStyleSheet("QFrame#bgbar{background:#120F09; border:1px solid #4A3C20; border-radius:12px;}")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 8, 14, 8)
        lay.setSpacing(10)
        self.bg_cap = _cap("BACKGROUND")
        lay.addWidget(self.bg_cap)
        seg = QFrame()
        self.seg = seg
        seg.setObjectName("seg")
        seg.setStyleSheet("QFrame#seg{border:1px solid #3A3121; border-radius:10px;}")
        sl = QHBoxLayout(seg)
        sl.setContentsMargins(0, 0, 0, 0)
        sl.setSpacing(0)
        self.group = QButtonGroup(self)
        self.buttons = {}
        for key, text in (("blur", "Blur"), ("black", "Black"), ("mix", "Mix")):   # (19 Nov) White mana
            b = QPushButton(text)
            b.setProperty("role", "seg")
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip("Mix: a different background in each clip" if key == "mix" else "")
            self.group.addButton(b)
            self.buttons[key] = b
            sl.addWidget(b)
            b.clicked.connect(self.changed.emit)
        lay.addWidget(seg)
        self.gap = lay.addSpacing(18)
        self.size_cap = _cap("PICTURE SIZE")
        lay.addWidget(self.size_cap)
        self.size = QSlider(Qt.Horizontal)
        self.size.setRange(0, len(SIZES) - 1)
        self.size.setPageStep(1)
        self.size.setFixedWidth(150)
        self.size.setStyleSheet(
            "QSlider::groove:horizontal{height:4px; background:#3A3121; border-radius:2px;}"
            "QSlider::sub-page:horizontal{background:#D4A84B; border-radius:2px;}"
            "QSlider::handle:horizontal{background:#F3D993; width:14px; height:14px; margin:-5px 0;"
            "border-radius:7px;}")
        self.size_text = QLabel()
        self.size_text.setStyleSheet(f"font-family:'{T.UI_FONT}'; color:#8F846B;")
        self.size.valueChanged.connect(self._size_moved)
        lay.addWidget(self.size)
        lay.addWidget(self.size_text)
        lay.addStretch(1)
        self.hint = QLabel("")
        self.hint.setStyleSheet(f"font-family:'{T.UI_FONT}'; color:#6F6450;")
        lay.addWidget(self.hint)

    def set_mode(self, look: str) -> None:
        """Full Frame: background + size. Screen bharne wale styles: sirf zoom (koi patti nahi)."""
        bg = look in BG_LOOKS
        self.bg_cap.setVisible(bg)
        self.seg.setVisible(bg)
        self.size_cap.setText("PICTURE SIZE" if bg else "ZOOM")
        self.hint.setText("Space above and below the picture" if bg else
                          "Screen always full, no bars. Less zoom keeps whole faces in frame")
        self.setVisible(look in ZOOM_LOOKS)

    def _size_moved(self, i: int) -> None:
        self.size_text.setText(SIZES[i][1])
        self.changed.emit()

    def set_values(self, bg: str, zoom: float) -> None:
        self.buttons.get(bg if bg in self.buttons else "black").setChecked(True)
        self.size.blockSignals(True)
        self.size.setValue(size_index(zoom))
        self.size.blockSignals(False)
        self.size_text.setText(SIZES[self.size.value()][1])

    def background(self) -> str:
        return next((k for k, b in self.buttons.items() if b.isChecked()), "black")

    def zoom(self) -> float:
        return SIZES[self.size.value()][0]


def _cap(text: str) -> QLabel:
    lab = QLabel(text)
    lab.setFont(T.font(8, T.UI_BOLD, 1.6))
    lab.setStyleSheet(f"font-family:'{T.UI_BOLD}'; color:#8E7D58;")
    return lab


# ---------------------------------------------------------------------
#  Tags ki line (wrap hone wali)
# ---------------------------------------------------------------------
class FlowLayout(QLayout):
    def __init__(self, parent=None, spacing: int = 8):
        super().__init__(parent)
        self._items: list = []
        self._sp = spacing

    def addItem(self, item):
        self._items.append(item)

    def addWidget(self, w):
        super().addWidget(w)

    def count(self):
        return len(self._items)

    def itemAt(self, i):
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i):
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, w):
        return self._do(QRectF(0, 0, w, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do(QRectF(rect), False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        from PySide6.QtCore import QSize
        s = QSize()
        for it in self._items:
            s = s.expandedTo(it.minimumSize())
        return s + QSize(4, 4)

    def _do(self, rect: QRectF, test: bool) -> int:
        x, y, line_h = rect.x(), rect.y(), 0
        for it in self._items:
            hint = it.sizeHint()
            nx = x + hint.width() + self._sp
            if nx - self._sp > rect.right() and line_h > 0:
                x, y = rect.x(), y + line_h + self._sp
                nx = x + hint.width() + self._sp
                line_h = 0
            if not test:
                from PySide6.QtCore import QPoint, QRect
                it.setGeometry(QRect(QPoint(int(x), int(y)), hint))
            x = nx
            line_h = max(line_h, hint.height())
        return int(y + line_h - rect.y())


class TagRow(QWidget):
    tagClicked = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.flow = FlowLayout(self)
        self.flow.setContentsMargins(0, 0, 0, 0)

    def set_tags(self, tags: list[tuple[str, str]]) -> None:
        while self.flow.count():
            it = self.flow.takeAt(0)
            w = it.widget() if isinstance(it, QWidgetItem) or hasattr(it, "widget") else None
            if w:
                w.hide()
                w.setParent(None)
                w.deleteLater()
        if tags:
            head = _cap("THE TOOL UNDERSTOOD")
            self.flow.addWidget(head)
        for text, key in tags:
            b = QPushButton("✓ " + text)
            b.setProperty("role", "chip")
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip("Click to change this setting")
            b.clicked.connect(lambda _=False, k=key: self.tagClicked.emit(k))
            self.flow.addWidget(b)
        if tags:
            fix = QPushButton("✎ click any tag to fix")
            fix.setProperty("role", "chip")
            fix.setStyleSheet("border-style:dashed; color:#A99D82;")
            fix.setEnabled(False)
            self.flow.addWidget(fix)
        self.updateGeometry()
