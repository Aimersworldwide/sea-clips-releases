"""
=====================================================================
  UI / PAGES / CREATE CLIPS  (the main screen)
  Kaam: main screen: link / queue, settings, progress, preview.
  Left : drop zone, link box (one link, or several = queue, one per
         line; they are made one after another), quick settings,
         GENERATE button
  Right: live progress (percent, clips x / y, elapsed, remaining,
         current step, counts per rating, pause / cancel)
  Below: latest clips as thumbnails with their score
=====================================================================
"""
from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import (QBoxLayout, QComboBox, QDialog, QGridLayout, QHBoxLayout, QLabel, QListWidget,
                               QListWidgetItem, QMessageBox, QPlainTextEdit, QSizePolicy, QSpinBox, QVBoxLayout,
                               QWidget)

from app.core.i18n import t
from app.media.download import is_url
from app.pipeline.runner import JobRequest, RunSummary
from app.ui import theme as T
from app.ui.context import open_path
from app.ui.pages.common import PageHeader, confirm, fill_campaigns, page_layout, scroll_wrap, warn
from app.ui.widgets import Card, DropZone, FoilButton, GoldProgress, GoldTitle, StatTile, Toggle, ghost_button, section
from app.ui.worker import PipelineWorker, start_worker

MAX_THUMBS = 8
PREVIEW_SECONDS = 20 * 60


# ---------------------------------------------------------------------
#  Links box: har line / space se alag link ya file. None = koi ghalat
# ---------------------------------------------------------------------
def parse_links(text: str) -> list[str] | None:
    out: list[str] = []
    for raw in text.replace("\r", "\n").split("\n"):
        raw = raw.strip()
        if not raw:
            continue
        parts = [raw] if Path(raw.strip('"')).exists() else raw.split()
        for part in parts:
            part = part.strip().strip('"')
            if not part:
                continue
            if not is_url(part) and not Path(part).exists():
                return None
            if part not in out:
                out.append(part)
    return out


# ---------------------------------------------------------------------
#  Preview dialog: 10 best clips, OK / Cancel, ulti ginti 20:00
# ---------------------------------------------------------------------
class PreviewDialog(QDialog):
    def __init__(self, infos: list, parent=None, seconds: int = PREVIEW_SECONDS):
        super().__init__(parent)
        self.setWindowTitle(t("preview.title"))
        self.resize(560, 460)
        self.left = seconds
        lay = QVBoxLayout(self)
        intro = QLabel(t("preview.text"))
        intro.setWordWrap(True)
        lay.addWidget(intro)
        self.list = QListWidget()
        for info in infos:
            item = QListWidgetItem(f"{info.get('label', '')}   {info.get('rating', '')} {info.get('score', '')}"
                                   f"   {Path(info.get('file', '')).name}")
            item.setData(Qt.UserRole, info.get("file", ""))
            self.list.addItem(item)
        self.list.itemDoubleClicked.connect(lambda it: open_path(it.data(Qt.UserRole)) if it.data(Qt.UserRole) else None)
        lay.addWidget(self.list, 1)
        self.clock = QLabel()
        lay.addWidget(self.clock)
        row = QHBoxLayout()
        folder = ghost_button(t("common.open_folder"))
        first = next((i.get("file") for i in infos if i.get("file")), "")
        folder.clicked.connect(lambda: open_path(str(Path(first).parent)) if first else None)
        row.addWidget(folder)
        row.addStretch(1)
        cancel = ghost_button(t("preview.cancel"), danger=True)
        cancel.clicked.connect(self.reject)
        ok = FoilButton(t("preview.ok"))
        ok.clicked.connect(self.accept)
        row.addWidget(cancel)
        row.addWidget(ok)
        lay.addLayout(row)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(1000)
        self._show()

    def _show(self) -> None:
        m, sec = divmod(max(0, self.left), 60)
        self.clock.setText(t("preview.clock", time=f"{m:02d}:{sec:02d}"))

    def _tick(self) -> None:
        self.left -= 1
        self._show()
        if self.left <= 0:
            self.timer.stop()
            self.accept()                       # 20 minute: khud aage


def _fmt_time(sec: float) -> str:
    sec = int(max(0, sec))
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


class QuickField(Card):
    """Small box in QUICK SETTINGS: label on top, editor below."""

    def __init__(self, label: str, editor: QWidget):
        super().__init__(radius=10, padding=12, inner=True)
        self.body.setSpacing(4)
        lbl = QLabel(label)
        lbl.setProperty("role", "muted")
        lbl.setFont(T.font(9))
        self.body.addWidget(lbl)
        self.body.addWidget(editor)


def _bare(widget: QWidget) -> QWidget:
    """Editors inside quick fields: no box, bold value, like the mockup."""
    if isinstance(widget, QComboBox):     # never grow to the longest item
        widget.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        widget.setMinimumContentsLength(6)
    widget.setStyleSheet("QComboBox, QSpinBox { background: transparent; border: none; padding: 0px;"
                         f" font-family: '{T.UI_BOLD}'; font-size: 12.5pt; }}")
    return widget


class ClipThumb(QWidget):
    def __init__(self, info: dict, parent=None):
        super().__init__(parent)
        self.info = info
        self.pix = QPixmap(info.get("thumb", "")) if info.get("thumb") else QPixmap()
        self.setFixedSize(104, 185)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(Path(info.get("file", "")).name)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and self.info.get("file"):
            open_path(self.info["file"])

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        path = QPainterPath()
        path.addRoundedRect(r, 10, 10)
        p.setClipPath(path)
        p.fillRect(r, QColor("#1A1916"))
        if not self.pix.isNull():
            scaled = self.pix.scaled(r.size().toSize(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            p.drawPixmap(int(r.left() + (r.width() - scaled.width()) / 2),
                         int(r.top() + (r.height() - scaled.height()) / 2), scaled)
        p.setClipping(False)
        p.setPen(QColor(230, 192, 114, 90))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(r, 10, 10)
        # score badge
        score = str(self.info.get("score", ""))
        badge = QRectF(r.right() - 38, r.top() + 8, 30, 20)
        p.setPen(Qt.NoPen)
        p.setBrush(T.vertical_gradient(badge.top(), badge.bottom()))
        p.drawRoundedRect(badge, 6, 6)
        p.setPen(QColor(T.DARK_ON_GOLD))
        p.setFont(T.font(8.5, T.UI_BOLD))
        p.drawText(badge, Qt.AlignCenter, score)
        # label
        lab = QRectF(r.left() + 6, r.bottom() - 30, r.width() - 12, 22)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(0, 0, 0, 170))
        p.drawRoundedRect(lab, 6, 6)
        p.setPen(QColor(T.TEXT))
        p.setFont(T.font(8, T.UI_SEMI))
        p.drawText(lab, Qt.AlignCenter, p.fontMetrics().elidedText(self.info.get("label", ""), Qt.ElideRight, int(lab.width() - 6)))


class CreatePage(QWidget):
    goToCampaigns = Signal()

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.chosen_file = ""
        self.chosen_files: list[str] = []          # kai videos ek saath (line mein)
        self.worker: PipelineWorker | None = None
        self.thread = None
        self.started_at = 0.0
        self.last_progress = 0.0
        self.counts = {"recommended": 0, "medium": 0, "below": 0, "check": 0}
        self.thumbs: list[ClipThumb] = []
        self.closing = False

        lay = page_layout(self)
        lay.addWidget(PageHeader("AIMERS Auto Clipping Tool", t("create.subtitle"), ctx))

        # Everything below the header scrolls on small screens (1366x768).
        content = QWidget()
        c = QVBoxLayout(content)
        c.setContentsMargins(0, 0, 8, 0)
        c.setSpacing(0)
        self.top = QBoxLayout(QBoxLayout.LeftToRight)
        self.top.setSpacing(24)
        self.top.addWidget(self._build_input_card(), 1)
        self.progress_card = self._build_progress_card()
        self.top.addWidget(self.progress_card, 0, Qt.AlignTop)
        self._wide = None
        self._apply_width(True)
        c.addLayout(self.top)
        c.addSpacing(22)
        c.addWidget(section(t("create.latest")))
        c.addSpacing(12)
        self.thumb_row = QHBoxLayout()
        self.thumb_row.setSpacing(14)
        self.no_thumbs = QLabel(t("lib.empty"))
        self.no_thumbs.setProperty("role", "faint")
        self.thumb_row.addWidget(self.no_thumbs)
        self.thumb_row.addStretch(1)
        c.addLayout(self.thumb_row)
        c.addStretch(1)
        lay.addWidget(scroll_wrap(content), 1)

        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self._tick)
        ctx.campaignsChanged.connect(self.refresh_campaigns)
        self.refresh_campaigns()
        self._set_running(False)

    # ------------------------------------------------------------ layout
    WIDE_MIN = 1080      # page width needed for side-by-side cards

    def _apply_width(self, wide: bool) -> None:
        """Side by side on wide windows, progress below on small screens."""
        panel = 400 if self.width() >= 1250 else 352
        if wide == self._wide and (not wide or self.progress_card.width() == panel):
            return
        self._wide = wide
        if wide:
            self.top.setDirection(QBoxLayout.LeftToRight)
            self.progress_card.setFixedWidth(panel)
        else:
            self.top.setDirection(QBoxLayout.TopToBottom)
            self.progress_card.setMinimumWidth(0)
            self.progress_card.setMaximumWidth(16777215)

    def resizeEvent(self, e):
        self._apply_width(self.width() >= self.WIDE_MIN)
        super().resizeEvent(e)

    # ------------------------------------------------------------ build
    def _build_input_card(self) -> Card:
        card = Card(padding=24)
        self.drop = DropZone(t("create.drop"), t("create.browse"))
        self.drop.fileChosen.connect(self._file_chosen)
        self.drop.filesChosen.connect(self._files_chosen)
        card.body.addWidget(self.drop)
        # ek ya kai links (har line pe ek): kai hon to queue ban jati hai
        self.link = QPlainTextEdit()
        self.link.setPlaceholderText(t("create.link") + "\n" + t("create.queue_hint"))
        self.link.setFixedHeight(76)
        card.body.addWidget(self.link)
        card.body.addSpacing(4)
        card.body.addWidget(section(t("create.quick")))

        s = self.ctx.settings
        self.campaign = _bare(QComboBox())
        self.campaign.activated.connect(self._campaign_picked)
        self.min_len, self.max_len = _bare(QSpinBox()), _bare(QSpinBox())
        for box, val in ((self.min_len, s.min_length), (self.max_len, s.max_length)):
            box.setRange(5, 600)
            box.setValue(val)
            box.setSuffix(" s")
        self.min_len.valueChanged.connect(lambda v: self.max_len.setValue(max(self.max_len.value(), v + 1)))
        length = QWidget()
        lrow = QHBoxLayout(length)
        lrow.setContentsMargins(0, 0, 0, 0)
        lrow.setSpacing(4)
        lrow.addWidget(self.min_len)
        to = QLabel("to")
        to.setProperty("role", "muted")
        lrow.addWidget(to)
        lrow.addWidget(self.max_len)
        lrow.addStretch(1)
        self.ratio = _bare(QComboBox())
        self.ratio.addItem("Shorts 9:16", "9:16")
        self.ratio.addItem("Landscape 16:9", "16:9")
        self.ratio.setCurrentIndex(max(0, self.ratio.findData(s.ratio)))
        self.count = _bare(QSpinBox())
        self.count.setRange(1, 5000)
        self.count.setValue(s.clip_count)
        # Phase: video ke har minute ke 100 clips = ek phase (5 phase), ya apni ginti
        self.phase = _bare(QComboBox())
        self.phase.addItem(t("phase.manual"), 0)
        self.phase.addItem(t("phase.next"), -1)
        for k in range(1, 6):
            self.phase.addItem(t("phase.n", n=k), k)
        self.phase.currentIndexChanged.connect(lambda *_: self.count.setEnabled(self.phase.currentData() == 0))

        grid = QGridLayout()
        grid.setSpacing(12)
        grid.addWidget(QuickField(t("create.campaign"), self.campaign), 0, 0)
        grid.addWidget(QuickField(t("create.length"), length), 0, 1)
        grid.addWidget(QuickField(t("create.ratio"), self.ratio), 0, 2)
        grid.addWidget(QuickField(t("create.clips"), self.count), 0, 3)
        grid.addWidget(QuickField(t("phase.title"), self.phase), 0, 4)
        for c in range(5):
            grid.setColumnStretch(c, 1)
        card.body.addLayout(grid)
        card.body.addSpacing(6)
        self.generate = FoilButton(t("create.generate"))
        self.generate.clicked.connect(self._start)
        # Generate ke saath: preview timer On / Off (pehli 10 clips ke baad rukna ya nahi)
        gen_row = QHBoxLayout()
        gen_row.setSpacing(12)
        gen_row.addWidget(self.generate, 1)
        self.preview_on = Toggle(bool(s.preview_pack))
        self.preview_on.setToolTip(t("create.preview_tip"))
        self.preview_on.toggled.connect(self._preview_toggled)
        self.preview_label = QLabel(t("create.preview_label"))
        self.preview_label.setProperty("role", "muted")
        self.preview_label.setFont(T.font(9.5))
        self.preview_label.setToolTip(t("create.preview_tip"))
        gen_row.addWidget(self.preview_label, 0, Qt.AlignVCenter)
        gen_row.addWidget(self.preview_on, 0, Qt.AlignVCenter)
        card.body.addLayout(gen_row)
        return card

    def _preview_toggled(self, on: bool) -> None:
        """Preview timer On / Off: app ki setting mein hi save (Settings wala switch bhi yahi)."""
        s = self.ctx.settings
        if s.preview_pack == bool(on):
            return
        s.preview_pack = bool(on)
        try:
            s.save()
        except OSError:
            pass

    def showEvent(self, e):
        self.preview_on.blockSignals(True)
        self.preview_on.setChecked(bool(self.ctx.settings.preview_pack))
        self.preview_on.blockSignals(False)
        super().showEvent(e)

    def _build_progress_card(self) -> Card:
        card = Card(padding=24)
        card.body.addWidget(section(t("progress.title")))
        row = QHBoxLayout()
        self.pct = GoldTitle("0%", 40)
        self.pct.setMinimumWidth(170)
        row.addWidget(self.pct, 0, Qt.AlignVCenter)
        self.source_label = QLabel(t("progress.idle"))
        self.source_label.setProperty("role", "muted")
        self.source_label.setFont(T.font(10.5))
        self.source_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.source_label.setMinimumWidth(1)
        self.source_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        row.addWidget(self.source_label, 1)
        card.body.addLayout(row)
        self.bar = GoldProgress()
        card.body.addWidget(self.bar)
        card.body.addSpacing(6)

        tiles = QHBoxLayout()
        tiles.setSpacing(10)
        self.tile_clips = StatTile(t("progress.clips"), "0 / 0")
        self.tile_elapsed = StatTile(t("progress.elapsed"), "00:00")
        self.tile_remaining = StatTile(t("progress.remaining"), "-")
        for w in (self.tile_clips, self.tile_elapsed, self.tile_remaining):
            tiles.addWidget(w)
        card.body.addLayout(tiles)

        self.now_label = QLabel("")
        self.now_label.setFont(T.font(10.5))
        self.now_label.setWordWrap(True)
        card.body.addWidget(self.now_label)

        counts = QHBoxLayout()
        counts.setSpacing(10)
        self.tile_rec = StatTile(t("rating.recommended"), "0", big=True)
        self.tile_med = StatTile(t("rating.medium"), "0", big=True)
        self.tile_low = StatTile(t("rating.below"), "0", big=True)
        for w in (self.tile_rec, self.tile_med, self.tile_low):
            counts.addWidget(w)
        card.body.addLayout(counts)

        buttons = QHBoxLayout()
        self.pause_btn = ghost_button(t("create.pause"))
        self.pause_btn.clicked.connect(self._toggle_pause)
        self.cancel_btn = ghost_button(t("create.cancel"), danger=True)
        self.cancel_btn.clicked.connect(self._cancel)
        buttons.addWidget(self.pause_btn)
        buttons.addWidget(self.cancel_btn)
        card.body.addLayout(buttons)
        return card

    # ------------------------------------------------------------ inputs
    def refresh_campaigns(self) -> None:
        fill_campaigns(self.campaign, self.ctx)
        self.campaign.addItem("+ " + t("create.new_campaign"), -1)
        self._campaign_picked(refresh=True)

    def _campaign_picked(self, *_, refresh: bool = False):
        cid = self.campaign.currentData()
        if cid == -1:
            self.campaign.setCurrentIndex(0)
            self.goToCampaigns.emit()
            return
        profile = self.ctx.db.get_campaign(cid) if cid else None
        if profile:
            lo, hi = profile.length_range(self.ctx.settings)
            applied = (cid, lo, hi, profile.ratio)
            if refresh and getattr(self, "_applied", None) == applied:
                return              # campaign wohi, us ki settings wohi: user ki likhi lambai na badlo
            self._applied = applied
            self.min_len.setValue(lo)
            self.max_len.setValue(hi)
            self.ratio.setCurrentIndex(max(0, self.ratio.findData(profile.ratio)))

    def _file_chosen(self, path: str) -> None:
        self.chosen_file = path
        self.chosen_files = []
        self.link.clear()
        self.drop.set_chosen(t("create.file_chosen", name=Path(path).name))

    def _files_chosen(self, paths: list) -> None:
        """Kai videos: line mein lagti hain (pehli ki saari clips, phir agli), har ek ki utni hi clips."""
        self.chosen_files = list(paths)
        self.chosen_file = paths[0] if paths else ""
        self.link.clear()
        self.drop.set_chosen(t("create.files_chosen", n=len(paths), name=Path(paths[0]).name))

    # ------------------------------------------------------------ run
    def _start(self) -> None:
        if self.ctx.busy:
            warn(self, t("msg.busy"))
            return
        links = parse_links(self.link.toPlainText())
        if links is None:
            warn(self, t("msg.no_input"))
            return
        files = list(getattr(self, "chosen_files", []) or [])
        sources = links or files or ([self.chosen_file] if self.chosen_file else [])
        if not sources:
            warn(self, t("msg.no_input"))
            return
        link = sources[0] if links else ""
        source = sources[0]
        cid = self.campaign.currentData()
        if not cid or cid == -1:
            cid = self.ctx.db.ensure_campaign(self.ctx.settings.default_campaign)
            self.ctx.campaignsChanged.emit()
        requests = [JobRequest(source=src, campaign_id=cid, clip_count=self.count.value(),
                               min_len=self.min_len.value(), max_len=self.max_len.value(),
                               ratio=self.ratio.currentData(), phase=int(self.phase.currentData() or 0))
                    for src in sources]
        self._run_campaign = cid
        self._reset_progress(Path(source).name if not link else link)
        self.worker = PipelineWorker(self.ctx.settings, requests)
        self.worker.preview.connect(self._on_preview)
        self.worker.queueStep.connect(self._on_queue_step)
        self.worker.stage.connect(self._on_stage)
        self.worker.progress.connect(self._on_progress)
        self.worker.clipDone.connect(self._on_clip)
        self.worker.warning.connect(self._on_warning)
        self.worker.finished.connect(self._on_finished)
        self.worker.failed.connect(self._on_failed)
        self.thread = start_worker(self.worker)
        self._set_running(True)

    def _reset_progress(self, source_name: str) -> None:
        self.counts = {"recommended": 0, "medium": 0, "below": 0, "check": 0}
        self.started_at = time.time()
        self.last_progress = 0.0
        self.pct.setText("0%")
        self.bar.setValue(0)
        name = self.campaign.currentText()
        full = f"{name}  |  {source_name}"
        self.source_label.setToolTip(full)
        self.source_label.setText(self.source_label.fontMetrics().elidedText(full, Qt.ElideMiddle, 200))
        self.tile_clips.set(f"0 / {self.count.value()}")
        self.tile_elapsed.set("00:00")
        self.tile_remaining.set(t("progress.calc"))
        for tile in (self.tile_rec, self.tile_med, self.tile_low):
            tile.set("0")
        self.now_label.setText("")
        self.timer.start()

    def _set_running(self, running: bool) -> None:
        self.ctx.set_busy(running)
        self.generate.setEnabled(not running)
        self.pause_btn.setEnabled(running)
        self.cancel_btn.setEnabled(running)
        self.pause_btn.setText(t("create.pause"))
        for w in (self.drop, self.link, self.campaign, self.min_len, self.max_len, self.ratio, self.count):
            w.setEnabled(not running)

    def _toggle_pause(self) -> None:
        if not self.worker:
            return
        if self.worker.pause_event.is_set():
            self.worker.pause_event.clear()
            self.pause_btn.setText(t("create.pause"))
        else:
            self.worker.pause_event.set()
            self.pause_btn.setText(t("create.resume"))
            self.now_label.setText(f"{t('progress.now')}: <b>{t('stage.paused')}</b>")

    def _cancel(self) -> None:
        if self.worker and confirm(self, t("msg.confirm_cancel")):
            self.worker.pause_event.clear()
            self.worker.cancel_event.set()
            self.cancel_btn.setEnabled(False)

    def request_stop(self) -> bool:
        """Ask a running job to stop (window closing). True if one is running."""
        if not (self.worker and self.thread and self.thread.isRunning()):
            return False
        self.closing = True                       # no result dialogs while closing
        self.worker.pause_event.clear()
        self.worker.cancel_event.set()
        return True

    # ------------------------------------------------------------ signals
    def _tick(self) -> None:
        elapsed = time.time() - self.started_at
        self.tile_elapsed.set(_fmt_time(elapsed))
        p = self.last_progress
        if p > 0.04:
            self.tile_remaining.set("~" + _fmt_time(elapsed * (1 - p) / p))

    def _on_stage(self, name: str) -> None:
        self.now_label.setText(f"{t('progress.now')}: <b>{t('stage.' + name)}</b>")

    def _on_progress(self, value: float, text: str) -> None:
        self.last_progress = value
        self.pct.setText(f"{int(value * 100)}%")
        self.bar.setValue(value)
        if text.startswith("Clip "):
            n = text.split()[1]
            self.now_label.setText(f"{t('progress.now')}: <b>{t('stage.render')}  |  {t('progress.clips')} {n}</b>")

    def _on_clip(self, done: int, total: int, info: dict) -> None:
        self.tile_clips.set(f"{done} / {total}")
        rating = info.get("rating")
        if rating in self.counts:
            self.counts[rating] += 1
            self.tile_rec.set(str(self.counts["recommended"]))
            self.tile_med.set(str(self.counts["medium"]))
            self.tile_low.set(str(self.counts["below"]))
        if info.get("file"):
            self.no_thumbs.hide()
            thumb = ClipThumb(info)
            self.thumbs.insert(0, thumb)
            self.thumb_row.insertWidget(0, thumb)
            while len(self.thumbs) > MAX_THUMBS:
                old = self.thumbs.pop()
                self.thumb_row.removeWidget(old)
                old.deleteLater()
        self.ctx.clipsChanged.emit()

    def _on_warning(self, key: str, data: dict) -> None:
        self.now_label.setText(f"<span style='color:{T.WARN}'>{t(key, **data)}</span>")

    # ---- queue: kaunsi link chal rahi hai ---------------------------------
    def _on_queue_step(self, i: int, n: int, source: str) -> None:
        if n <= 1:
            return
        name = source if is_url(source) else Path(source).name
        full = f"{self.campaign.currentText()}  |  {t('create.queue_step', i=i, n=n)}  |  {name}"
        self.source_label.setToolTip(full)
        self.source_label.setText(self.source_label.fontMetrics().elidedText(full, Qt.ElideMiddle, 260))

    # ---- preview pack: pehle 10 clips, OK / Cancel, 20 min baad khud OK ------
    def _on_preview(self, infos: list) -> None:
        worker = self.worker
        if worker is None:
            return
        if self.closing:
            worker.answer_preview("cancel")
            return
        from app.pipeline.runner import preview_wait
        cid = getattr(self, "_run_campaign", None)
        profile = self.ctx.db.get_campaign(cid) if cid else None
        dlg = PreviewDialog(infos, self, seconds=int(preview_wait(profile)) if profile else PREVIEW_SECONDS)
        answer = "ok" if dlg.exec() == QDialog.Accepted else "cancel"
        if self.worker is worker:
            worker.answer_preview(answer)

    def _on_finished(self, summary: RunSummary) -> None:
        self.timer.stop()
        self._set_running(False)
        if self.closing:
            return
        self.ctx.clipsChanged.emit()
        c = summary.counts
        lines = [t("msg.summary", r=c["recommended"], m=c["medium"], b=c["below"])]
        if summary.cancelled:
            lines.insert(0, t("msg.cancelled", n=summary.made))
        if summary.repaired:
            lines.append(t("msg.repaired", n=summary.repaired))
        if summary.failed:
            lines.append(t("msg.failed", n=len(summary.failed)))
        if not summary.cancelled and summary.made < summary.requested:
            lines.append(t("msg.max_good", n=summary.max_good))
        if summary.counts.get("check"):
            lines.append(t("msg.check_folder", n=summary.counts["check"]))
        errors = getattr(self.worker, "link_errors", []) if self.worker else []
        if errors:
            lines.append(t("msg.queue_errors", n=len(errors)) + "\n" + "\n".join(errors[:5]))
        if not summary.cancelled:
            self.pct.setText("100%")
            self.bar.setValue(1.0)
            self.tile_remaining.set("00:00")
            self.now_label.setText(f"{t('progress.now')}: <b>{t('step.done')}</b>")
        box = QMessageBox(QMessageBox.Information, t("msg.done_title"), "\n".join(lines), parent=self)
        open_btn = box.addButton(t("common.open_folder"), QMessageBox.AcceptRole) if summary.folder else None
        box.addButton(t("common.ok"), QMessageBox.RejectRole)
        box.exec()
        if open_btn is not None and box.clickedButton() is open_btn:
            open_path(summary.folder)
        self.worker = None

    def _on_failed(self, key: str, detail: str, trace: str) -> None:
        self.timer.stop()
        self._set_running(False)
        if self.closing:
            return
        self.ctx.clipsChanged.emit()
        try:
            text = t(key, detail=detail)
        except (KeyError, IndexError):
            text = t(key)
        if key == "msg.error" or trace:
            text = f"{t('msg.error')}:\n{detail}\n\n{t('msg.error_hint')}"
        elif detail and "{detail}" not in (t(key) or "") and key not in ("msg.no_clips",):
            text = f"{text}\n\n{detail}"
        self.now_label.setText(f"<span style='color:{T.ERROR}'>{t(key) if not trace else t('msg.error')}</span>")
        warn(self, text)
        self.worker = None
