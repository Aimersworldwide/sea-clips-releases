"""
=====================================================================
  UI / PAGES / CAMPAIGNS
  Kaam: campaigns ka page (rules, main people, protection, template).
  Left : list of campaigns (+ New, Delete)
  Right: the campaign's rules, saved once and used on every run.
  Empty fields mean "use the app default from Settings".
=====================================================================
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QFrame, QListWidget, QListWidgetItem, QPlainTextEdit, QPushButton, QSpinBox,
                               QVBoxLayout, QWidget)

from app.captions.styles import ALL_PICKABLE, STYLES
from app.core.config import CampaignProfile
from app.core.i18n import t
from app.output.organizer import campaign_root
from app.ui import theme as T
from app.ui.pages.common import confirm, info, page_layout, scroll_wrap, split_list, warn
from app.ui.widgets import Card, FoilButton, Toggle, field_label, ghost_button, section


class BriefWorker(QThread):
    """Reads a brief in the background (AI and research can take a few seconds)."""
    done = Signal(object)

    def __init__(self, text: str, settings, parent=None):
        super().__init__(parent)
        self.text, self.settings = text, settings

    def run(self) -> None:
        try:
            from app.campaign.research import read_and_research
            self.done.emit(read_and_research(self.text, self.settings))
        except Exception as exc:  # noqa: BLE001 - shown to the user, never a crash
            self.done.emit(exc)


class PhotoWorker(QThread):
    """YouTube se mazeed photos (internet), window kabhi nahi rukti."""
    done = Signal(object, list)            # (campaign id, naam, photos) wapas, taake sahi shakhs ko mile

    def __init__(self, name: str, photos: list[str], who: tuple, parent=None):
        super().__init__(parent)
        self.name, self.photos, self.who = name, photos, who

    def run(self) -> None:
        try:
            import hashlib

            from app.core.paths import sub_dir
            from app.render.photo_finder import find_online
            folder = sub_dir("people") / ("auto_" + hashlib.sha1(self.name.lower().encode()).hexdigest()[:10])
            got = [str(p) for p in find_online(self.name, self.photos, folder)]
        except Exception:  # noqa: BLE001 - user ko "nahi mili" dikhega
            got = []
        self.done.emit(self.who, got)


def show_text(parent, title: str, text: str) -> None:
    dlg = QDialog(parent)
    dlg.setWindowTitle(title)
    dlg.resize(640, 520)
    lay = QVBoxLayout(dlg)
    view = QPlainTextEdit(text)
    view.setReadOnly(True)
    lay.addWidget(view)
    ok = FoilButton("OK")
    ok.clicked.connect(dlg.accept)
    lay.addWidget(ok)
    dlg.exec()


def _row(label: str, widget: QWidget) -> QWidget:
    box = QWidget()
    lay = QVBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(6)
    lay.addWidget(field_label(label))
    lay.addWidget(widget)
    return box


def _toggle_row(label: str, toggle: Toggle) -> QWidget:
    box = QWidget()
    lay = QHBoxLayout(box)
    lay.setContentsMargins(0, 4, 0, 4)
    lbl = QLabel(label)
    lbl.setFont(T.font(10.5))
    lay.addWidget(lbl, 1)
    lay.addWidget(toggle)
    return box


class CampaignsPage(QWidget):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.current_id: int | None = None
        lay = page_layout(self)
        lay.setContentsMargins(28, 16, 28, 12)

        body = QHBoxLayout()
        body.setSpacing(24)

        # ---- left: list ----------------------------------------------
        left = Card(padding=18)
        left.setFixedWidth(300)
        cap = QLabel("CAMPAIGNS")
        cap.setStyleSheet(f"font-family:'{T.UI_BOLD}'; color:#8E7D58; letter-spacing:2px; font-size:8.5pt;")
        left.body.addWidget(cap)
        self.list = QListWidget()
        self.list.setObjectName("campList")
        self.list.setSpacing(4)
        self.list.setStyleSheet(
            "QListWidget#campList::item{border:1px solid #2B2417; border-radius:14px; padding:12px 14px;"
            "background:#0E0C08; color:#F0E4C3;}"
            "QListWidget#campList::item:selected{border:1px solid #D4A84B; background:#1C150A; color:#F6E3A9;}"
            "QListWidget#campList::item:hover{border:1px solid #4A3C20;}")
        self.list.currentItemChanged.connect(self._selected)
        left.body.addWidget(self.list, 1)
        new = QPushButton("＋  New campaign")
        new.setProperty("role", "gold")
        new.setCursor(Qt.PointingHandCursor)
        new.clicked.connect(self._new)
        self.delete_btn = ghost_button(t("camp.delete"), danger=True)
        self.delete_btn.clicked.connect(self._delete)
        left.body.addWidget(new)
        body.addWidget(left)

        # ---- right: form --------------------------------------------
        form = QWidget()
        f = QVBoxLayout(form)
        f.setContentsMargins(0, 0, 12, 0)
        f.setSpacing(18)

        # ---- campaign requirements: sab se upar (paste karo, tool khud settings kare) ----
        card0 = Card()
        card0.body.addWidget(section(t("camp.req_section")))
        req_hint = QLabel(t("camp.req_hint"))
        req_hint.setWordWrap(True)
        req_hint.setStyleSheet(f"color:{T.FAINT};")
        card0.body.addWidget(req_hint)
        self.rules = QPlainTextEdit()
        self.rules.setPlaceholderText(t("camp.rules_placeholder"))
        self.rules.setFixedHeight(170)
        card0.body.addWidget(self.rules)
        self.brief_btn = FoilButton(t("camp.read_brief"), height=46)
        self.brief_btn.clicked.connect(self._read_brief)
        self.brief_status = QLabel("")
        self.brief_status.setWordWrap(True)
        self.brief_status.setStyleSheet(f"color:{T.FAINT};")
        card0.body.addWidget(self.brief_btn)
        card0.body.addWidget(self.brief_status)
        self._brief_worker = None
        f.addWidget(card0)

        card1 = Card()
        g = QGridLayout()
        g.setHorizontalSpacing(16)
        g.setVerticalSpacing(14)
        self.name = QLineEdit()
        self.folder = QLineEdit()
        self.folder.setPlaceholderText(str(Path(ctx.settings.output_dir) / "<Name>"))
        browse = ghost_button(t("common.browse"))
        browse.clicked.connect(self._browse)
        frow = QWidget()
        fl = QHBoxLayout(frow)
        fl.setContentsMargins(0, 0, 0, 0)
        fl.addWidget(self.folder, 1)
        fl.addWidget(browse)
        self.min_len, self.max_len = QSpinBox(), QSpinBox()
        for box in (self.min_len, self.max_len):
            box.setRange(0, 180)
            box.setSpecialValueText(t("common.default"))
            box.setSuffix(" s")
        self.ratio = QComboBox()
        self.ratio.addItem("Shorts 9:16", "9:16")
        self.ratio.addItem("Landscape 16:9", "16:9")
        self.versions = QSpinBox()
        self.versions.setRange(1, 8)
        g.addWidget(_row(t("camp.name"), self.name), 0, 0, 1, 2)
        g.addWidget(_row(t("camp.folder"), frow), 1, 0, 1, 2)
        g.addWidget(_row(f"{t('camp.length')}  ({t('camp.min')})", self.min_len), 2, 0)
        g.addWidget(_row(f"{t('camp.length')}  ({t('camp.max')})", self.max_len), 2, 1)
        g.addWidget(_row(t("create.ratio"), self.ratio), 3, 0)
        g.addWidget(_row(t("camp.versions"), self.versions), 3, 1)
        self.preview_min = QSpinBox()
        self.preview_min.setRange(1, 120)
        self.preview_min.setSuffix(" min")
        self.preview_min.setToolTip(t("camp.preview_min_tip"))
        g.addWidget(_row(t("camp.preview_min"), self.preview_min), 4, 0)
        card1.body.addLayout(g)
        self.counter = QLabel("")
        self.counter.setProperty("role", "muted")
        self.stats = QLabel("")
        self.stats.setProperty("role", "muted")
        reset = ghost_button(t("camp.reset"))
        reset.clicked.connect(self._reset_numbering)
        self.reset_camp_btn = ghost_button(t("camp.reset_all"), danger=True)
        self.reset_camp_btn.clicked.connect(self._reset_campaign)
        crow = QHBoxLayout()
        cl = QVBoxLayout()
        cl.addWidget(self.counter)
        cl.addWidget(self.stats)
        crow.addLayout(cl, 1)
        crow.addWidget(reset)
        crow.addWidget(self.reset_camp_btn)
        card1.body.addLayout(crow)
        f.addWidget(card1)

        card2 = Card()
        card2.body.addWidget(section(t("camp.captions").upper()))
        self.captions = Toggle(True)
        card2.body.addWidget(_toggle_row(t("camp.captions"), self.captions))
        self.style = QComboBox()
        self.style.addItem("Auto Mix (different style each clip)", "")
        for key in ALL_PICKABLE:                        # lock: har clip mein yehi style
            self.style.addItem(STYLES[key].label, key)
        card2.body.addWidget(_row(t("camp.caption_style"), self.style))
        self.captions.toggled.connect(self.style.setEnabled)
        self.word_chip = Toggle(False)                   # bolte lafz ke peeche chhota rangeen nishaan
        card2.body.addWidget(_toggle_row(t("camp.word_chip"), self.word_chip))
        self.mix_styles = Toggle(False)                  # hamare styles + rangeen dabbe wale mila kar
        card2.body.addWidget(_toggle_row(t("camp.mix_styles"), self.mix_styles))
        self.titles_on = Toggle(True)                    # clip ka title (file naam / title card)
        card2.body.addWidget(_toggle_row(t("camp.titles"), self.titles_on))
        self.profanity = QComboBox()
        self.profanity.addItem(t("common.default"), "")
        for lvl in ("strict", "standard", "off"):
            self.profanity.addItem(t(f"prof.{lvl}"), lvl)
        card2.body.addWidget(_row(t("camp.profanity"), self.profanity))
        self.banned = QLineEdit()
        card2.body.addWidget(_row(t("camp.banned"), self.banned))
        self.avoid = QLineEdit()
        card2.body.addWidget(_row(t("camp.avoid"), self.avoid))
        # campaign ke video sources: naye uploads ki ginti (halka sa alert)
        self.sources_edit = QPlainTextEdit()
        self.sources_edit.setPlaceholderText(t("camp.sources_hint"))
        self.sources_edit.setFixedHeight(64)
        card2.body.addWidget(_row(t("camp.sources"), self.sources_edit))
        srow = QHBoxLayout()
        self.new_videos = QLabel("")
        self.new_videos.setStyleSheet(f"color:{T.GOLD};")
        self.seen_btn = ghost_button(t("camp.seen"))
        self.seen_btn.clicked.connect(self._mark_seen)
        srow.addWidget(self.new_videos, 1)
        srow.addWidget(self.seen_btn)
        card2.body.addLayout(srow)
        # naamon ki sahi spelling (rules paste karne se khud bharta hai)
        self.names_edit = QLineEdit()
        self.names_edit.setPlaceholderText(t("camp.names_hint"))
        card2.body.addWidget(_row(t("camp.names"), self.names_edit))
        f.addWidget(card2)

        card3 = Card()
        card3.body.addWidget(section("POSTING"))
        self.title = QLineEdit()
        self.hashtags = QLineEdit()
        self.hashtags.setPlaceholderText("#topic #show")
        self.note = QPlainTextEdit()
        self.note.setFixedHeight(80)
        self.disclosure = Toggle(False)
        self.disclosure_text = QLineEdit()
        self.disclosure.toggled.connect(self.disclosure_text.setEnabled)
        card3.body.addWidget(_row(t("camp.title_base"), self.title))
        card3.body.addWidget(_row(t("camp.hashtags"), self.hashtags))
        card3.body.addWidget(_row(t("camp.note"), self.note))
        card3.body.addWidget(_toggle_row(t("camp.disclosure"), self.disclosure))
        card3.body.addWidget(self.disclosure_text)
        self.cut_ads = Toggle(True)                       # default On: sponsor / ad wale hisse kaato
        card3.body.addWidget(_toggle_row(t("camp.cut_ads"), self.cut_ads))
        self.background = QComboBox()
        for key in ("black", "blur"):
            self.background.addItem(t(f"camp.background.{key}"), key)
        card3.body.addWidget(_row(t("camp.background"), self.background))
        self.fit_bars = QComboBox()                      # kaali pattiyan poori ya aadhi (video thori zoom)
        for key in ("full", "half"):
            self.fit_bars.addItem(t(f"camp.fit_bars.{key}"), key)
        card3.body.addWidget(_row(t("camp.fit_bars"), self.fit_bars))
        self.fill_screen = Toggle(False)                 # kabhi kaala hissa nahi: door ka banda zoom
        card3.body.addWidget(_toggle_row(t("camp.fill_screen"), self.fill_screen))
        self.stack_layout = Toggle(True)                 # Off: speaker akela full screen (upar neeche nahi)
        card3.body.addWidget(_toggle_row(t("camp.stack_layout"), self.stack_layout))
        self.whole_picture = Toggle(False)              # On: poori video beech mein, upar neeche blur
        card3.body.addWidget(_toggle_row(t("camp.whole_picture"), self.whole_picture))
        self.name_super = Toggle(False)                 # On: shuru mein title (zaroori naam ke saath) screen par
        card3.body.addWidget(_toggle_row(t("camp.name_super"), self.name_super))
        self.strict_edits = Toggle(False)               # On: beech se kuch na kaato, sirf beep
        card3.body.addWidget(_toggle_row(t("camp.strict_edits"), self.strict_edits))
        self.level_voices = Toggle(False)                # sawal karne wale aur main speaker ki aawaz barabar
        card3.body.addWidget(_toggle_row(t("camp.level_voices"), self.level_voices))
        self.disc_place = QComboBox()
        for key in ("below_video", "top", "bottom"):
            self.disc_place.addItem(t(f"camp.disc_place.{key}"), key)
        card3.body.addWidget(_row(t("camp.disc_place"), self.disc_place))
        self.keep_old_disc = Toggle(False)                # Off: hamari patti purana disclosure dhak de
        card3.body.addWidget(_toggle_row(t("camp.keep_old_disc"), self.keep_old_disc))
        self.hide_ticker = Toggle(False)
        card3.body.addWidget(_toggle_row(t("camp.hide_ticker"), self.hide_ticker))
        # ---- topic protection guard: campaign ke topic ke khilaf baat wala lamha clip nahi ----
        self.topic_guard = Toggle(False)
        card3.body.addWidget(_toggle_row(t("camp.topic_guard"), self.topic_guard))
        self.topic_terms = QLineEdit()
        self.topic_terms.setPlaceholderText(t("camp.topic_terms_hint"))
        card3.body.addWidget(_row(t("camp.topic_terms"), self.topic_terms))
        self.topic_bad = QLineEdit()
        self.topic_bad.setPlaceholderText(t("camp.topic_bad_hint"))
        card3.body.addWidget(_row(t("camp.topic_bad"), self.topic_bad))
        self.topic_guard.toggled.connect(self.topic_terms.setEnabled)
        self.topic_guard.toggled.connect(self.topic_bad.setEnabled)
        # ---- cold open / hook text: auto = clean titles mein band ----
        self.cold_open_mode = QComboBox()
        self.hook_mode = QComboBox()
        for box in (self.cold_open_mode, self.hook_mode):
            for key in ("auto", "on", "off"):
                box.addItem(t(f"camp.extra_mode.{key}"), key)
        card3.body.addWidget(_row(t("camp.cold_open_mode"), self.cold_open_mode))
        card3.body.addWidget(_row(t("camp.hook_mode"), self.hook_mode))
        self.complete_point = Toggle(False)              # clip nayi baat se shuru, natije par khatam
        card3.body.addWidget(_toggle_row(t("camp.complete_point"), self.complete_point))
        # ---- title rules: har campaign ke apne (requirements box khud bharta hai) ----
        card3.body.addWidget(section(t("camp.title_rules")))
        hint = QLabel(t("camp.title_rules_hint"))
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{T.FAINT};")
        card3.body.addWidget(hint)
        self.title_style = QComboBox()
        for key in ("viral", "clean"):
            self.title_style.addItem(t(f"camp.title_style.{key}"), key)
        card3.body.addWidget(_row(t("camp.title_style"), self.title_style))
        self.political = Toggle(True)
        card3.body.addWidget(_toggle_row(t("camp.political_words"), self.political))
        self.title_emoji = QComboBox()
        for key in ("auto", "on", "off"):
            self.title_emoji.addItem(t(f"camp.title_emoji.{key}"), key)
        card3.body.addWidget(_row(t("camp.title_emoji"), self.title_emoji))
        self.title_must = QLineEdit()
        self.title_must.setPlaceholderText(t("camp.title_must_hint"))
        card3.body.addWidget(_row(t("camp.title_must"), self.title_must))
        self.super_link = QLineEdit()
        self.super_link.setPlaceholderText(t("camp.super_link_hint"))
        card3.body.addWidget(_row(t("camp.super_link"), self.super_link))
        self.title_suffix = QLineEdit()                  # post title ke aakhir mein (jaise "Vote Yes on 42")
        self.title_suffix.setPlaceholderText(t("camp.title_suffix_hint"))
        card3.body.addWidget(_row(t("camp.title_suffix"), self.title_suffix))
        self.file_name = QComboBox()                     # clip file ka naam: number + title | sirf title
        for key in ("label", "title"):
            self.file_name.addItem(t(f"camp.file_name.{key}"), key)
        card3.body.addWidget(_row(t("camp.file_name"), self.file_name))
        self.platform = QComboBox()                      # TikTok: captions buttons / username se door
        for key in ("shorts", "tiktok"):
            self.platform.addItem(t(f"camp.platform.{key}"), key)
        card3.body.addWidget(_row(t("camp.platform"), self.platform))
        self.max_tags = QSpinBox()
        self.max_tags.setRange(0, 10)
        self.max_tags.setSpecialValueText(t("common.default"))
        card3.body.addWidget(_row(t("camp.max_hashtags"), self.max_tags))
        abuse = QLabel(t("camp.no_abuse"))
        abuse.setWordWrap(True)
        abuse.setStyleSheet(f"color:{T.FAINT};")
        card3.body.addWidget(abuse)
        # template: ek click mein aam settings (Debate / Interview / Podcast / Main person)
        trow = QHBoxLayout()
        self.template = QComboBox()
        for key in ("debate", "interview", "podcast", "main_person"):
            self.template.addItem(t(f"tpl.{key}"), key)
        tpl_btn = ghost_button(t("tpl.apply"))
        tpl_btn.clicked.connect(self._apply_template)
        trow.addWidget(self.template, 1)
        trow.addWidget(tpl_btn)
        box = QWidget()
        box.setLayout(trow)
        card3.body.addWidget(_row(t("tpl.label"), box))
        f.addWidget(card3)

        card4 = Card()
        card4.body.addWidget(section(t("camp.logo_section")))
        self.source_logo = QComboBox()
        for mode in ("keep", "blur", "replace"):
            self.source_logo.addItem(t(f"logo.{mode}"), mode)
        card4.body.addWidget(_row(t("camp.source_logo"), self.source_logo))
        hint = QLabel(t("camp.source_logo_hint"))
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{T.FAINT};")
        card4.body.addWidget(hint)
        self.brand_on = Toggle(False)
        card4.body.addWidget(_toggle_row(t("camp.brand_logo"), self.brand_on))
        self.brand_path = QLineEdit()
        brand_browse = ghost_button(t("common.browse"))
        brand_browse.clicked.connect(self._browse_brand)
        brow = QWidget()
        bl = QHBoxLayout(brow)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.addWidget(self.brand_path, 1)
        bl.addWidget(brand_browse)
        card4.body.addWidget(_row(t("camp.brand_file"), brow))
        self.brand_pos = QComboBox()
        for pos in ("top_left", "top_right", "bottom_left", "bottom_right"):
            self.brand_pos.addItem(t(f"pos.{pos}"), pos)
        self.brand_size = QSpinBox()
        self.brand_size.setRange(6, 35)
        self.brand_size.setSuffix(" %")
        prow = QWidget()
        pl = QHBoxLayout(prow)
        pl.setContentsMargins(0, 0, 0, 0)
        pl.addWidget(_row(t("camp.brand_pos"), self.brand_pos), 1)
        pl.addWidget(_row(t("camp.brand_size"), self.brand_size), 1)
        card4.body.addWidget(prow)
        for w in (self.brand_path, brand_browse, self.brand_pos, self.brand_size):
            self.brand_on.toggled.connect(w.setEnabled)
        f.addWidget(card4)

        # ---- main people (campaign ek ya kai logon ke baare mein) ----
        # Upar logon ki list (+ Add person / Remove person). List mein jo
        # chuna ho us ka naam aur photos neeche wale form mein badalte hain.
        card5 = Card()
        card5.body.addWidget(section(t("camp.person_section")))
        hint5 = QLabel(t("camp.person_hint"))
        hint5.setWordWrap(True)
        hint5.setStyleSheet(f"color:{T.FAINT};")
        card5.body.addWidget(hint5)
        self._people: list[dict] = [{"name": "", "photos": []}]
        self._person_idx = 0
        self.people_list = QListWidget()
        self.people_list.setFixedHeight(84)
        self.people_list.currentRowChanged.connect(self._pick_person)
        card5.body.addWidget(_row(t("camp.people"), self.people_list))
        prow0 = QHBoxLayout()
        add_person = ghost_button("+ " + t("camp.person_new"))
        add_person.clicked.connect(self._add_person)
        self.del_person = ghost_button(t("camp.person_delete"), danger=True)
        self.del_person.clicked.connect(self._delete_person)
        prow0.addWidget(add_person)
        prow0.addWidget(self.del_person)
        prow0.addStretch(1)
        card5.body.addLayout(prow0)
        self.person_name = QLineEdit()
        self.person_name.setPlaceholderText(t("camp.person_placeholder"))
        self.person_name.textEdited.connect(self._person_renamed)
        card5.body.addWidget(_row(t("camp.person_name"), self.person_name))
        self.person_list = QListWidget()
        self.person_list.setFixedHeight(130)
        card5.body.addWidget(_row(t("camp.person_photos"), self.person_list))
        prow5 = QHBoxLayout()
        add_photo = ghost_button("+ " + t("camp.person_add"))
        add_photo.clicked.connect(self._add_person_photos)
        del_photo = ghost_button(t("camp.person_remove"), danger=True)
        del_photo.clicked.connect(self._remove_person_photo)
        prow5.addWidget(add_photo)
        prow5.addWidget(del_photo)
        self.find_btn = ghost_button(t("camp.find_photos"))
        self.find_btn.clicked.connect(self._find_photos)
        prow5.addWidget(self.find_btn)
        self._finder = None
        prow5.addStretch(1)
        card5.body.addLayout(prow5)
        self.people_mode = QComboBox()
        self.people_mode.addItem(t("camp.people_any"), "any")
        self.people_mode.addItem(t("camp.people_all"), "all")
        card5.body.addWidget(_row(t("camp.people_mode"), self.people_mode))
        self.protect = Toggle(True)
        card5.body.addWidget(_toggle_row(t("camp.protect"), self.protect))
        self.auto_speaker = Toggle(False)                # naam na ho to sab se zyada bolne wala = main person
        card5.body.addWidget(_toggle_row(t("camp.auto_speaker"), self.auto_speaker))
        hint6 = QLabel(t("camp.protect_hint"))
        hint6.setWordWrap(True)
        hint6.setStyleSheet(f"color:{T.FAINT};")
        card5.body.addWidget(hint6)
        self.person_screen, self.person_talk = QSpinBox(), QSpinBox()
        for box in (self.person_screen, self.person_talk):
            box.setRange(30, 100)
            box.setSuffix(" %")
        mrow = QWidget()
        ml = QHBoxLayout(mrow)
        ml.setContentsMargins(0, 0, 0, 0)
        ml.addWidget(_row(t("camp.person_screen"), self.person_screen), 1)
        ml.addWidget(_row(t("camp.person_talk"), self.person_talk), 1)
        card5.body.addWidget(mrow)
        f.addWidget(card5)

        self._build_quick(f, [card0, card1, card2, card3, card4, card5])
        body.addWidget(scroll_wrap(form), 1)
        lay.addLayout(body, 1)

        ctx.campaignsChanged.connect(self.refresh)
        ctx.clipsChanged.connect(self._update_counter)
        self.refresh()


    # ------------------------------------------------------------ SEA CLIPS 2.0 top part
    def _build_quick(self, f, cards) -> None:
        """Upar: naam, Save; style cards; background; 3 aham cheezen; 3 switches; brief + tags; neeche Advanced."""
        from app.ui.pages.campaign_quick import LOOKS, BackgroundBar, StyleCard, TagRow
        for c in cards:
            f.removeWidget(c)
        name_row = self.name.parentWidget()
        quick = Card(padding=24)
        q = quick.body
        q.setSpacing(14)
        head = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(2)
        cap = QLabel("CAMPAIGN")
        cap.setStyleSheet(f"font-family:'{T.UI_BOLD}'; color:#8E7D58; letter-spacing:2px; font-size:8.5pt;")
        col.addWidget(cap)
        self.name.setPlaceholderText("Campaign name")
        self.name.setStyleSheet(f"font-family:'{T.SERIF}'; font-size:24pt; color:#F6E3A9; background:transparent;"
                                "border:none; padding:0;")
        col.addWidget(self.name)
        sub = QLabel("Pick a look. The tool sets layout, zoom, cuts and safety for you.")
        sub.setStyleSheet(f"font-family:'{T.UI_FONT}'; color:#8F846B;")
        col.addWidget(sub)
        head.addLayout(col, 1)
        dup = ghost_button("Duplicate")
        dup.clicked.connect(self._duplicate)
        self.save_btn = QPushButton("Save")
        self.save_btn.setProperty("role", "gold")
        self.save_btn.setCursor(Qt.PointingHandCursor)
        self.save_btn.clicked.connect(self._save)
        head.addWidget(self.delete_btn, 0, Qt.AlignBottom)
        head.addWidget(dup, 0, Qt.AlignBottom)
        head.addWidget(self.save_btn, 0, Qt.AlignBottom)
        q.addLayout(head)
        if name_row is not None:
            name_row.hide()

        styles = QHBoxLayout()
        styles.setSpacing(12)
        self.look_cards = {}
        for key, title, subt, _preset in LOOKS:
            card = StyleCard(key, title, subt)
            card.clicked.connect(self._pick_look)
            self.look_cards[key] = card
            styles.addWidget(card)
        q.addLayout(styles)
        self.bgbar = BackgroundBar()
        self.bgbar.changed.connect(self._bg_changed)
        q.addWidget(self.bgbar)

        row = QHBoxLayout()
        row.setSpacing(14)
        self.q_person = ghost_button("")
        self.q_person.setStyleSheet("text-align:left; padding:10px 14px;")
        self.q_person.setToolTip("Main person and photos (opens the people settings below)")
        self.q_person.clicked.connect(lambda: self._open_advanced(self.person_name))
        self.q_platform = QComboBox()
        self.q_platform.addItem("TikTok", "tiktok")
        self.q_platform.addItem("YouTube Shorts", "shorts")
        self.q_platform.currentIndexChanged.connect(
            lambda: self.platform.setCurrentIndex(max(0, self.platform.findData(self.q_platform.currentData()))))
        lenw = QWidget()
        ll = QHBoxLayout(lenw)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.addWidget(self.q_platform, 1)
        self.q_lo, self.q_hi = QSpinBox(), QSpinBox()
        for sp, real in ((self.q_lo, self.min_len), (self.q_hi, self.max_len)):
            sp.setRange(0, 180)
            sp.setSpecialValueText("auto")
            sp.setSuffix(" s")
            sp.valueChanged.connect(real.setValue)
            real.valueChanged.connect(sp.setValue)
            ll.addWidget(sp)
        self.q_caps = QComboBox()
        for i in range(self.style.count()):
            self.q_caps.addItem(self.style.itemText(i), self.style.itemData(i))
        self.q_caps.currentIndexChanged.connect(lambda i: self.style.setCurrentIndex(i))
        self.style.currentIndexChanged.connect(lambda i: self.q_caps.setCurrentIndex(i))
        row.addWidget(_row("MAIN PERSON", self.q_person), 5)
        row.addWidget(_row("PLATFORM · LENGTH", lenw), 4)
        row.addWidget(_row("CAPTIONS", self.q_caps), 4)
        q.addLayout(row)

        sw = QHBoxLayout()
        sw.setSpacing(14)
        self.q_titles, self.q_protect, self.q_line = Toggle(True), Toggle(True), Toggle(True)
        self.q_titles.toggled.connect(self.titles_on.setChecked)
        self.titles_on.toggled.connect(self.q_titles.setChecked)
        self.q_protect.toggled.connect(self.protect.setChecked)
        self.protect.toggled.connect(self.q_protect.setChecked)
        for text, tg, tip in (("Smart titles from the clip", self.q_titles,
                               "Titles come from what is said in each clip and follow the campaign rules"),
                              ("Protect main person", self.q_protect,
                               "Insults or attacks on the main person are beeped or the clip is skipped"),
                              ("Campaign line on screen", self.q_line,
                               "The campaign's required line (or name) on screen, with a different look in "
                               "each clip")):
            box = QFrame()
            box.setProperty("role", "fieldbox")
            bl = QHBoxLayout(box)
            bl.setContentsMargins(14, 10, 14, 10)
            lab = QLabel(text)
            lab.setStyleSheet(f"font-family:'{T.UI_SEMI}'; color:#EFE3C2;")
            lab.setToolTip(tip)
            bl.addWidget(lab, 1)
            bl.addWidget(tg)
            sw.addWidget(box)
        q.addLayout(sw)

        bcap = QLabel("CAMPAIGN BRIEF")
        bcap.setStyleSheet(f"font-family:'{T.UI_BOLD}'; color:#8E7D58; letter-spacing:2px; font-size:8.5pt;")
        q.addWidget(bcap)
        self.rules.setFixedHeight(120)
        self.rules.setPlaceholderText("Paste the campaign's requirements here. The tool reads them and sets "
                                      "length, main person, required line, hashtags, words to avoid and more.")
        q.addWidget(self.rules)
        brow = QHBoxLayout()
        self.brief_btn.hide()
        self.brief_btn = QPushButton("Read brief and set everything")
        self.brief_btn.setProperty("role", "gold")
        self.brief_btn.setCursor(Qt.PointingHandCursor)
        self.brief_btn.clicked.connect(self._read_brief)
        brow.addWidget(self.brief_status, 1)
        brow.addWidget(self.brief_btn)
        q.addLayout(brow)
        self.tags = TagRow()
        self.tags.tagClicked.connect(self._tag_clicked)
        q.addWidget(self.tags)
        f.addWidget(quick)

        self.adv_btn = ghost_button("▸  Advanced: every setting (folder, captions, titles, logo, people, protection)")
        self.adv_btn.setStyleSheet("text-align:left; padding:10px 14px;")
        self.adv_btn.clicked.connect(lambda: self._open_advanced(None, toggle=True))
        f.addWidget(self.adv_btn)
        self.adv = QWidget()
        al = QVBoxLayout(self.adv)
        al.setContentsMargins(0, 0, 0, 0)
        al.setSpacing(18)
        for c in cards[1:]:
            al.addWidget(c)
        cards[0].hide()                           # purana brief card: ab upar wale hisse mein
        self.adv.hide()
        f.addWidget(self.adv)
        f.addStretch(1)

    def _open_advanced(self, focus=None, toggle: bool = False) -> None:
        show = not self.adv.isVisible() if toggle else True
        self.adv.setVisible(show)
        self.adv_btn.setText(("▾" if show else "▸") + self.adv_btn.text()[1:])
        if focus is not None:
            focus.setFocus()

    def _pick_look(self, key: str) -> None:
        from app.ui.pages.campaign_quick import LOOKS
        preset = next(pr for k, _t, _s, pr in LOOKS if k == key)
        widgets = {"fill_screen": self.fill_screen, "stack_layout": self.stack_layout,
                   "whole_picture": self.whole_picture, "captions_enabled": self.captions,
                   "level_voices": self.level_voices, "complete_point": self.complete_point}
        for field_name, value in preset.items():
            w = widgets.get(field_name)
            if w is not None:
                w.setChecked(bool(value))
        self._look = key
        for k, card in self.look_cards.items():
            card.set_on(k == key)
        from app.ui.pages.campaign_quick import LOOK_ZOOM, size_index
        self.bgbar.size.setValue(size_index(LOOK_ZOOM.get(key, 1.5)))
        self.bgbar.set_mode(key)

    def _bg_changed(self) -> None:
        bg = self.bgbar.background()
        idx = self.background.findData(bg)
        if idx < 0:
            self.background.addItem(bg.title(), bg)
            idx = self.background.findData(bg)
        self.background.setCurrentIndex(idx)
        self.look_cards["full_frame"].bg = bg
        self.look_cards["full_frame"].update()

    def _sync_quick(self, p: CampaignProfile) -> None:
        from app.campaign.brief import understood_tags
        from app.ui.pages.campaign_quick import detect_look
        self._look = detect_look(p)
        for k, card in self.look_cards.items():
            card.set_on(k == self._look)
        bg = getattr(p, "background", "black")
        if self.background.findData(bg) < 0:
            self.background.addItem(bg.title(), bg)
        self.bgbar.set_values(bg, getattr(p, "fit_zoom", 0.0))
        self.look_cards["full_frame"].bg = bg
        self.bgbar.set_mode(self._look)
        people = [x for x in getattr(self, "_people", []) if x.get("name") or x.get("photos")]
        if people:
            first = people[0]
            n = len(first.get("photos") or [])
            self.q_person.setText(f"{first.get('name') or 'Main person'}   ·   {n} photo{'s' if n != 1 else ''}")
        else:
            self.q_person.setText("None, any speaker")
        self.q_platform.blockSignals(True)
        self.q_platform.setCurrentIndex(max(0, self.q_platform.findData(p.platform)))
        self.q_platform.blockSignals(False)
        self.q_lo.setValue(p.min_length or 0)
        self.q_hi.setValue(p.max_length or 0)
        self.q_caps.setCurrentIndex(self.style.currentIndex())
        self.q_titles.setChecked(bool(getattr(p, "titles", True)))
        self.q_protect.setChecked(bool(p.protect_main_person))
        self.q_line.setChecked(bool(getattr(p, "line_on", True)))
        self.tags.set_tags(understood_tags(p))

    def _tag_clicked(self, key: str) -> None:
        target = {"length": self.min_len, "main_person": self.person_name, "title_must": self.title_must,
                  "screen_text": self.super_link, "hashtags": self.hashtags, "avoid": self.avoid,
                  "ratio": self.ratio, "source_logo": self.source_logo, "title_style": self.title_style,
                  "political_words": self.political, "disclosure": self.disclosure_text,
                  "post_text": self.note, "profanity": self.profanity}.get(key)
        self._open_advanced(target)

    def _duplicate(self) -> None:
        p = self._collect()
        base = f"{p.name or 'Campaign'} copy"
        name, n = base, 2
        while self.ctx.db.find_campaign(name, include_hidden=True) is not None:
            name, n = f"{base} {n}", n + 1
        p.name = name
        p.output_folder = ""
        self.current_id = self.ctx.db.create_campaign(p)
        self.ctx.campaignsChanged.emit()
        info(self, f"Made \"{name}\" with the same settings.")

    # ------------------------------------------------------------ list
    def refresh(self) -> None:
        keep = self.current_id
        self.list.blockSignals(True)
        self.list.clear()
        from app.core.notify import new_video_count
        from app.ui.pages.campaign_quick import LOOKS, detect_look
        titles = {k: tt for k, tt, *_ in LOOKS}
        for cid, name in self.ctx.db.list_campaigns():
            n = new_video_count(cid)
            prof = self.ctx.db.get_campaign(cid)
            sub = ""
            if prof is not None:
                lo, hi = prof.length_range(self.ctx.settings)
                sub = f"{titles.get(detect_look(prof), '')} · {'TikTok' if prof.platform == 'tiktok' else 'Shorts'} · {lo} to {hi} s"
            item = QListWidgetItem((f"{name}   ({n} new)" if n else name) + (f"\n{sub}" if sub else ""))
            item.setData(Qt.UserRole, cid)
            self.list.addItem(item)
        self.list.blockSignals(False)
        target = 0
        for i in range(self.list.count()):
            if self.list.item(i).data(Qt.UserRole) == keep:
                target = i
        if self.list.count():
            self.list.setCurrentRow(target)
            self._selected(self.list.currentItem(), None)
        else:
            self._load(None, CampaignProfile(name=self.ctx.settings.default_campaign))

    def _selected(self, item, _prev) -> None:
        if item is None:
            return
        cid = item.data(Qt.UserRole)
        self._load(cid, self.ctx.db.get_campaign(cid) or CampaignProfile())

    def _new(self) -> None:
        self.list.clearSelection()
        self._load(None, CampaignProfile(name="", look="clean_fill", fill_screen=True, stack_layout=False,
                                         fit_zoom=1.5, platform="tiktok"))
        self.name.setFocus()                      # pehle naam; requirements box usi ke upar nazar aata hai

    # ------------------------------------------------------------ form
    def _load(self, cid: int | None, p: CampaignProfile) -> None:
        self.current_id = cid
        self.name.setText(p.name)
        self.folder.setText(p.output_folder)
        self.min_len.setValue(p.min_length or 0)
        self.max_len.setValue(p.max_length or 0)
        self.ratio.setCurrentIndex(max(0, self.ratio.findData(p.ratio)))
        self.versions.setValue(p.versions_per_moment)
        self.captions.setChecked(p.captions_enabled)
        self.style.setEnabled(p.captions_enabled)
        self.style.setCurrentIndex(max(0, self.style.findData(p.caption_style)))
        self.profanity.setCurrentIndex(max(0, self.profanity.findData(p.profanity_level)))
        self.banned.setText(", ".join(p.banned_words))
        self.avoid.setText(", ".join(p.banned_topics))
        self.names_edit.setText(", ".join(p.names))
        self.sources_edit.setPlainText("\n".join(p.source_links))
        self._show_new_videos(cid)
        self.title.setText(p.title)
        self.hashtags.setText(p.hashtags)
        self.note.setPlainText(p.delivery_note)
        self.disclosure.setChecked(p.disclosure_enabled)
        self.disclosure_text.setText(p.disclosure_text)
        self.cut_ads.setChecked(not p.own_ads)
        self.disc_place.setCurrentIndex(max(0, self.disc_place.findData(p.disclosure_place)))
        self.background.setCurrentIndex(max(0, self.background.findData(getattr(p, "background", "black"))))
        self.fit_bars.setCurrentIndex(max(0, self.fit_bars.findData(getattr(p, "fit_bars", "full"))))
        self.keep_old_disc.setChecked(bool(p.keep_old_disclosure))
        self.hide_ticker.setChecked(bool(p.hide_ticker))
        self.topic_guard.setChecked(bool(p.topic_guard))
        self.topic_terms.setText(p.topic_terms)
        self.topic_bad.setText(p.topic_bad_words)
        self.topic_terms.setEnabled(bool(p.topic_guard))
        self.topic_bad.setEnabled(bool(p.topic_guard))
        self.cold_open_mode.setCurrentIndex(max(0, self.cold_open_mode.findData(p.cold_open_mode)))
        self.hook_mode.setCurrentIndex(max(0, self.hook_mode.findData(p.hook_mode)))
        self.title_style.setCurrentIndex(max(0, self.title_style.findData(p.title_style)))
        self.political.setChecked(bool(p.political_words))
        self.title_emoji.setCurrentIndex(max(0, self.title_emoji.findData(p.title_emoji)))
        self.title_must.setText(p.title_must)
        self.super_link.setText(getattr(p, "super_link", ""))
        self.title_suffix.setText(getattr(p, "title_suffix", ""))
        self.file_name.setCurrentIndex(max(0, self.file_name.findData(getattr(p, "file_name", "label"))))
        self.platform.setCurrentIndex(max(0, self.platform.findData(getattr(p, "platform", "shorts"))))
        self.max_tags.setValue(int(p.max_hashtags or 0))
        self.disclosure_text.setEnabled(p.disclosure_enabled)
        self.rules.setPlainText(p.raw_rules)
        self.source_logo.setCurrentIndex(max(0, self.source_logo.findData(p.source_logo)))
        self.brand_on.setChecked(p.logo.enabled)
        self.brand_path.setText(p.logo.path)
        self.brand_pos.setCurrentIndex(max(0, self.brand_pos.findData(p.logo.position)))
        self.brand_size.setValue(int(round(p.logo.size_pct if p.logo.size_pct >= 6 else 14)))
        for w in (self.brand_path, self.brand_pos, self.brand_size):
            w.setEnabled(p.logo.enabled)
        autos = [list(p.main_person_auto_photos)] + [list(x.get("auto_photos") or []) for x in p.more_people
                                                     if isinstance(x, dict) and (x.get("name") or x.get("photos"))]
        self._people = ([{"name": n, "photos": list(ph), "auto_photos": a}
                         for (n, ph), a in zip(p.main_people(), autos + [[]] * 10)]
                        or [{"name": "", "photos": [], "auto_photos": []}])
        self._person_idx = 0
        self._fill_people(0)
        self.people_mode.setCurrentIndex(max(0, self.people_mode.findData(p.people_mode)))
        self.protect.setChecked(p.protect_main_person)
        self.auto_speaker.setChecked(bool(p.auto_main_speaker))
        self.complete_point.setChecked(bool(p.complete_point))
        self.word_chip.setChecked(bool(p.word_chip))
        self.fill_screen.setChecked(bool(p.fill_screen))
        self.stack_layout.setChecked(bool(getattr(p, "stack_layout", True)))
        self.whole_picture.setChecked(bool(getattr(p, "whole_picture", False)))
        self.name_super.setChecked(bool(getattr(p, "name_super", False)))
        self.strict_edits.setChecked(bool(getattr(p, "strict_edits", False)))
        self.mix_styles.setChecked(bool(getattr(p, "mix_styles", False)))
        self.titles_on.setChecked(bool(getattr(p, "titles", True)))
        self.level_voices.setChecked(bool(getattr(p, "level_voices", False)))
        self.preview_min.setValue(int(p.preview_minutes or 20))
        self.reset_camp_btn.setEnabled(cid is not None)
        self.person_screen.setValue(p.main_person_min_screen)
        self.person_talk.setValue(p.main_person_min_speaking)
        self.delete_btn.setEnabled(cid is not None)
        self._update_counter()
        self._sync_quick(p)

    def _update_counter(self) -> None:
        if self.current_id is None:
            self.counter.setText("")
            self.stats.setText("")
            return
        n = self.ctx.db.peek_next_number(self.current_id, self.ctx.settings.device_code)
        self.counter.setText(t("camp.next", n=f"{n:03d}"))
        c = self.ctx.db.campaign_counts(self.current_id)
        self.stats.setText(t("camp.stats", made=c["made"], delivered=c["delivered"], remaining=c["remaining"]))

    def _collect(self) -> CampaignProfile:
        old = self.ctx.db.get_campaign(self.current_id) if self.current_id else None
        p = old or CampaignProfile()
        p.name = self.name.text().strip()
        p.output_folder = self.folder.text().strip()
        p.min_length = self.min_len.value() or None
        p.max_length = self.max_len.value() or None
        if p.min_length and p.max_length and p.max_length <= p.min_length:
            p.max_length = p.min_length + 1
        p.ratio = self.ratio.currentData()
        p.versions_per_moment = self.versions.value()
        p.captions_enabled = self.captions.isChecked()
        p.caption_style = self.style.currentData()
        p.profanity_level = self.profanity.currentData()
        p.banned_words = split_list(self.banned.text())
        p.banned_topics = split_list(self.avoid.text())
        p.names = split_list(self.names_edit.text())
        p.source_links = [x.strip() for x in self.sources_edit.toPlainText().split() if x.strip()]
        p.title = self.title.text().strip()
        p.hashtags = self.hashtags.text().strip()
        p.delivery_note = self.note.toPlainText().strip()
        p.disclosure_enabled = self.disclosure.isChecked()
        p.disclosure_text = self.disclosure_text.text().strip() or "Sponsored"
        p.own_ads = not self.cut_ads.isChecked()          # Off = videos khud ads hain, kuch na kaato
        p.disclosure_place = self.disc_place.currentData() or "below_video"
        p.background = self.background.currentData() or "black"
        p.fit_bars = self.fit_bars.currentData() or "full"
        p.keep_old_disclosure = self.keep_old_disc.isChecked()
        p.hide_ticker = self.hide_ticker.isChecked()
        p.topic_guard = self.topic_guard.isChecked()
        p.topic_terms = self.topic_terms.text().strip()
        p.topic_bad_words = self.topic_bad.text().strip()
        p.cold_open_mode = self.cold_open_mode.currentData() or "auto"
        p.hook_mode = self.hook_mode.currentData() or "auto"
        p.title_style = self.title_style.currentData() or "viral"
        p.political_words = self.political.isChecked()
        p.title_emoji = self.title_emoji.currentData() or "auto"
        p.title_must = self.title_must.text().strip()
        p.super_link = self.super_link.text().strip()
        p.title_suffix = self.title_suffix.text().strip()
        p.file_name = self.file_name.currentData() or "label"
        if self.platform.currentData() in ("shorts", "tiktok"):
            p.platform = self.platform.currentData()
        p.max_hashtags = self.max_tags.value()
        p.raw_rules = self.rules.toPlainText()
        p.source_logo = self.source_logo.currentData() or "keep"
        p.logo.enabled = self.brand_on.isChecked() and bool(self.brand_path.text().strip())
        p.logo.path = self.brand_path.text().strip()
        p.logo.position = self.brand_pos.currentData() or "top_right"
        p.logo.size_pct = float(self.brand_size.value())
        p.logo.opacity = 0.95
        self._store_person()
        people = [x for x in self._people if x["name"].strip() or x["photos"]]
        first = people[0] if people else {"name": "", "photos": []}
        p.main_person_name = first["name"].strip()
        p.main_person_photos = list(first["photos"])
        p.main_person_auto_photos = list(first.get("auto_photos") or [])
        p.more_people = [{"name": x["name"].strip(), "photos": list(x["photos"]),
                          "auto_photos": list(x.get("auto_photos") or [])} for x in people[1:]]
        p.people_mode = self.people_mode.currentData() or "any"
        p.protect_main_person = self.protect.isChecked()
        p.auto_main_speaker = self.auto_speaker.isChecked()
        p.complete_point = self.complete_point.isChecked()
        p.word_chip = self.word_chip.isChecked()
        p.fill_screen = self.fill_screen.isChecked()
        p.stack_layout = self.stack_layout.isChecked()
        p.whole_picture = self.whole_picture.isChecked()
        p.name_super = self.name_super.isChecked()
        p.strict_edits = self.strict_edits.isChecked()
        p.mix_styles = self.mix_styles.isChecked()
        p.titles = self.titles_on.isChecked()
        p.level_voices = self.level_voices.isChecked()
        p.preview_minutes = self.preview_min.value()
        p.main_person_min_screen = self.person_screen.value()
        p.main_person_min_speaking = self.person_talk.value()
        # SEA CLIPS 2.0: style card, background, tasveer ka size, campaign line
        p.look = getattr(self, "_look", "") or p.look
        from app.ui.pages.campaign_quick import BG_LOOKS, ZOOM_LOOKS
        if p.look in BG_LOOKS:
            p.background = self.bgbar.background()
        if p.look in ZOOM_LOOKS:
            p.fit_zoom = self.bgbar.zoom()
        p.line_on = self.q_line.isChecked()
        return p

    def _save(self) -> None:
        # (15 Nov) line chalte waqt bhi save: line ki har video ke paas campaign ki apni copy hai,
        # is liye ye badlav sirf aage daali jaane wali videos par lagta hai
        p = self._collect()
        if not p.name:
            warn(self, t("camp.name"))
            return
        existing = self.ctx.db.find_campaign(p.name)
        hidden = self.ctx.db.find_campaign(p.name, include_hidden=True)
        if hidden is not None and existing is None and self.current_id is not None and hidden != self.current_id:
            warn(self, f"\"{p.name}\" was used by a deleted campaign. Create it as a new campaign "
                       "to bring it back, or pick another name.")
            return
        if existing is not None and existing != self.current_id:
            warn(self, f"\"{p.name}\" already exists.")
            return
        if self.current_id is None:
            self.current_id = self.ctx.db.create_campaign(p)
        else:
            self.ctx.db.update_campaign(self.current_id, p)
        campaign_root(Path(self.ctx.settings.output_dir), p).mkdir(parents=True, exist_ok=True)
        self.ctx.campaignsChanged.emit()
        q = getattr(self.ctx, "queue", None)
        extra = ""
        if q is not None and any(i.campaign_id == self.current_id and i.is_open for i in q.store.items(0)):
            extra = "\n\nVideos already in the line keep the settings they were added with."
        info(self, t("msg.saved") + extra)

    def _delete(self) -> None:
        if self.current_id is None:
            return
        if self.ctx.busy:
            warn(self, t("msg.busy"))
            return
        if confirm(self, t("msg.confirm_delete", name=self.name.text())):
            self.ctx.db.delete_campaign(self.current_id)
            self.current_id = None
            self.ctx.campaignsChanged.emit()

    def _reset_campaign(self) -> None:
        """Sirf yehi campaign: history hamesha, clips aur settings chunne par. Doosri campaigns ko kuch nahi."""
        from app.tools.campaign_reset import count_campaign_videos, reset_campaign
        if self.current_id is None:
            return
        if self.ctx.busy:
            warn(self, t("msg.busy"))
            return
        cid, name = self.current_id, self.name.text().strip()
        dlg = QDialog(self)
        dlg.setWindowTitle(t("camp.reset_all"))
        dlg.setMinimumWidth(460)
        lay = QVBoxLayout(dlg)
        what = QLabel(t("camp.reset_what", name=name))
        what.setWordWrap(True)
        lay.addWidget(what)
        clips_box = QCheckBox(t("camp.reset_clips", n=count_campaign_videos(self.ctx.db, self.ctx.settings, cid)))
        clips_box.setChecked(True)
        lay.addWidget(clips_box)
        settings_box = QCheckBox(t("camp.reset_settings"))
        settings_box.setChecked(True)
        lay.addWidget(settings_box)
        lay.addWidget(QLabel(t("reset.type")))
        typed = QLineEdit()
        typed.setPlaceholderText("RESET")
        lay.addWidget(typed)
        row = QHBoxLayout()
        cancel = ghost_button(t("common.cancel"))
        cancel.clicked.connect(dlg.reject)
        go = FoilButton(t("camp.reset_go"))
        go.setEnabled(False)
        typed.textChanged.connect(lambda x: go.setEnabled(x.strip().upper() == "RESET"))
        go.clicked.connect(dlg.accept)
        row.addStretch(1)
        row.addWidget(cancel)
        row.addWidget(go)
        lay.addLayout(row)
        if dlg.exec() != QDialog.Accepted:
            return
        res = reset_campaign(self.ctx.db, self.ctx.settings, cid, clips_box.isChecked(), settings_box.isChecked())
        msg = t("camp.reset_done", name=name, r=res.records, v=res.clips_deleted)
        if res.failed:
            msg += "\n\n" + t("lib.delete_failed") + "\n" + "\n".join(res.failed[:10])
        self.ctx.campaignsChanged.emit()
        self.ctx.clipsChanged.emit()
        profile = self.ctx.db.get_campaign(cid)
        if profile is not None:
            self._load(cid, profile)
        info(self, msg)

    def _browse(self) -> None:
        path = QFileDialog.getExistingDirectory(self, t("camp.folder"), self.folder.text() or self.ctx.settings.output_dir)
        if path:
            self.folder.setText(path)

    # ---- campaign brief -> settings -------------------------------------
    def _read_brief(self) -> None:
        text = self.rules.toPlainText().strip()
        if not text:
            warn(self, t("camp.brief_empty"))
            return
        if self._brief_worker is not None and self._brief_worker.isRunning():
            return
        self.brief_btn.setEnabled(False)
        self.brief_status.setText(t("camp.reading"))
        self._brief_worker = BriefWorker(text, self.ctx.settings, self)
        self._brief_worker.done.connect(self._brief_done)
        self._brief_worker.start()

    def _brief_done(self, result) -> None:
        from app.campaign.brief import apply, summary_text
        self.brief_btn.setEnabled(True)
        if isinstance(result, Exception):
            self.brief_status.setText("")
            warn(self, f"{t('msg.error')}: {result}")
            return
        profile = self._collect()                    # what is on screen now (nothing saved yet)
        changes = apply(profile, result)
        self._load(self.current_id, profile)
        self.brief_status.setText(t("camp.brief_done"))
        show_text(self, t("camp.read_brief"), summary_text(result, changes))

    def _apply_template(self) -> None:
        from app.campaign.templates import apply_template
        profile = self._collect()                    # jo screen pe hai (abhi save nahi)
        changed = apply_template(profile, self.template.currentData())
        self._load(self.current_id, profile)
        self.brief_status.setText(t("tpl.done", name=self.template.currentText(), n=len(changed)))

    def _browse_brand(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, t("camp.brand_file"), self.brand_path.text(),
                                              "Images (*.png *.jpg *.jpeg *.webp)")
        if path:
            self.brand_path.setText(path)

    # ---- naye videos ka alert (campaign ke source links) --------------------
    def _show_new_videos(self, cid) -> None:
        from app.core.notify import new_video_count
        n = new_video_count(cid) if cid is not None else 0
        self.new_videos.setText(t("camp.new_videos", n=n) if n else "")
        self.seen_btn.setVisible(bool(n))

    def _mark_seen(self) -> None:
        from app.core.notify import mark_videos_seen
        if self.current_id is not None:
            mark_videos_seen(self.current_id)
            self._show_new_videos(self.current_id)
            self.refresh()

    # ---- main people: list, chunna, naya, hatana ---------------------------
    def _person_label(self, x: dict) -> str:
        extra = len(x.get("auto_photos") or [])
        found = f" + {extra} {t('camp.found_online')}" if extra else ""
        return f"{x['name'].strip() or t('camp.person_unnamed')}  ({len(x['photos'])} photos{found})"

    def _fill_people(self, select: int) -> None:
        self.people_list.blockSignals(True)
        self.people_list.clear()
        for x in self._people:
            self.people_list.addItem(self._person_label(x))
        self.people_list.setCurrentRow(select)
        self.people_list.blockSignals(False)
        self._person_idx = select
        cur = self._people[select]
        self.person_name.setText(cur["name"])
        self._show_person_photos(cur["photos"])
        self.del_person.setEnabled(len(self._people) > 1)

    def _store_person(self) -> None:
        """Form (naam + photos) ko chune hue shakhs mein likh do."""
        if not (0 <= self._person_idx < len(self._people)):
            return
        old = self._people[self._person_idx]
        photos = [self.person_list.item(i).data(Qt.UserRole) for i in range(self.person_list.count())]
        same = photos == old.get("photos") and self.person_name.text().strip() == old.get("name", "")
        self._people[self._person_idx] = {
            "name": self.person_name.text().strip(), "photos": photos,
            # apni photos ya naam badle to purani dhoondi photos hata do (agle run pe nayi)
            "auto_photos": list(old.get("auto_photos") or []) if same else []}
        item = self.people_list.item(self._person_idx)
        if item is not None:
            item.setText(self._person_label(self._people[self._person_idx]))

    # ---- mazeed photos internet (YouTube) se, peeche thread pe ---------------
    def _find_photos(self) -> None:
        self._store_person()
        cur = self._people[self._person_idx]
        if not cur["name"].strip() or not cur["photos"]:
            warn(self, t("camp.find_need"))
            return
        self.find_btn.setEnabled(False)
        self.find_btn.setText(t("camp.finding"))
        who = (self.current_id, cur["name"].strip(), tuple(cur["photos"]))
        self._finder = PhotoWorker(cur["name"], list(cur["photos"]), who, self)
        self._finder.done.connect(self._photos_found)
        self._finder.start()

    def _photos_found(self, who, paths: list) -> None:
        self.find_btn.setEnabled(True)
        self.find_btn.setText(t("camp.find_photos"))
        cid, name, photos = who
        idx = next((i for i, x in enumerate(self._people)
                    if x["name"].strip() == name and tuple(x["photos"]) == photos), -1)
        if cid != self.current_id or idx < 0:
            return                       # campaign / shakhs badal gaya: nateeja kisi aur ko nahi
        self._people[idx]["auto_photos"] = list(paths)
        item = self.people_list.item(idx)
        if item is not None:
            item.setText(self._person_label(self._people[idx]))
        info(self, t("camp.found_n", n=len(paths)) if paths else t("camp.found_none"))

    def _pick_person(self, row: int) -> None:
        if row < 0 or row == self._person_idx:
            return
        self._store_person()
        self._fill_people(row)

    def _add_person(self) -> None:
        self._store_person()
        if len(self._people) >= 6:
            return
        self._people.append({"name": "", "photos": [], "auto_photos": []})
        self._fill_people(len(self._people) - 1)
        self.person_name.setFocus()

    def _delete_person(self) -> None:
        if len(self._people) <= 1:
            return
        self._people.pop(self._person_idx)
        self._fill_people(max(0, self._person_idx - 1))

    def _person_renamed(self, _text: str) -> None:
        self._store_person()

    # ---- main person photos ---------------------------------------------
    def _show_person_photos(self, paths: list[str]) -> None:
        from app.render.person import check_photos
        self.person_list.clear()
        checks = check_photos(paths) if paths else []
        for path, chk in zip(paths, checks):
            mark = "OK" if chk.ok else "NOT USED"
            item = QListWidgetItem(f"{mark}  {Path(path).name}  ({chk.message})")
            item.setData(Qt.UserRole, path)
            if not chk.ok:
                item.setForeground(Qt.red)
            self.person_list.addItem(item)

    def _add_person_photos(self) -> None:
        import hashlib
        import shutil

        from app.core.paths import sub_dir
        files, _ = QFileDialog.getOpenFileNames(self, t("camp.person_add"), "",
                                                "Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        if not files:
            return
        current = [self.person_list.item(i).data(Qt.UserRole) for i in range(self.person_list.count())]
        store = sub_dir("people")
        for src in files:
            if len(current) >= 8:
                break
            try:
                digest = hashlib.sha1(Path(src).read_bytes()).hexdigest()[:16]
                dst = store / f"{digest}{Path(src).suffix.lower()}"
                if not dst.exists():
                    shutil.copy2(src, dst)          # keep a copy: the original may be moved later
            except OSError as exc:
                warn(self, f"{Path(src).name}: {exc}")
                continue
            if str(dst) not in current:
                current.append(str(dst))
        self._show_person_photos(current)
        self._store_person()

    def _remove_person_photo(self) -> None:
        row = self.person_list.currentRow()
        if row < 0:
            return
        paths = [self.person_list.item(i).data(Qt.UserRole) for i in range(self.person_list.count())]
        paths.pop(row)
        self._show_person_photos(paths)
        self._store_person()

    def _reset_numbering(self) -> None:
        if self.current_id is None:
            return
        if self.ctx.busy:
            warn(self, t("msg.busy"))
            return
        if confirm(self, t("msg.confirm_reset")):
            batch = self.ctx.db.reset_numbering(self.current_id, self.ctx.settings.device_code)
            self._update_counter()
            info(self, f"{t('camp.next', n='001')}\n{batch}")
