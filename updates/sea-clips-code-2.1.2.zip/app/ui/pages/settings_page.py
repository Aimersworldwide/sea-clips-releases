"""
=====================================================================
  UI / PAGES / SETTINGS
  Kaam: settings page (quality, GPU, clear clips, updates).
  Only switches that do something in this version are shown (no
  dead options). Export / Import moves the same setup to another
  laptop; Export diagnostics zips the logs for support.
=====================================================================
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog, QGridLayout, QHBoxLayout, QLabel,
                               QLineEdit, QPlainTextEdit, QSpinBox, QVBoxLayout, QWidget)

from app.captions.styles import ROTATION_STYLES, STYLES
from app.core.config import AppSettings
from app.core.i18n import set_language, t
from app.core.logging_setup import export_diagnostics
from app.core.paths import settings_path
from app.ui import theme as T
from app.ui.context import show_in_folder
from app.ui.pages.common import PageHeader, info, page_layout, scroll_wrap, split_list, warn
from app.ui.widgets import Card, FoilButton, Toggle, field_label, ghost_button, section


def _field(label: str, widget: QWidget) -> QWidget:
    box = QWidget()
    lay = QVBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(6)
    lay.addWidget(field_label(label))
    lay.addWidget(widget)
    return box


def _switch(label: str, toggle: Toggle) -> QWidget:
    box = QWidget()
    lay = QHBoxLayout(box)
    lay.setContentsMargins(0, 2, 0, 2)
    lbl = QLabel(label)
    lbl.setFont(T.font(10.5))
    lbl.setWordWrap(True)
    lay.addWidget(lbl, 1)
    lay.addWidget(toggle, 0, Qt.AlignRight)
    return box


# ---------------------------------------------------------------------
#  Switch + chhota (i) button: dabane pe faide aur nuqsan likhe aate hain
# ---------------------------------------------------------------------
def _switch_info(label: str, toggle: Toggle, info_text: str, note: str = "") -> QWidget:
    from PySide6.QtWidgets import QToolButton
    box = QWidget()
    lay = QHBoxLayout(box)
    lay.setContentsMargins(0, 2, 0, 2)
    text = QLabel(label + (f"   <span style='color:{T.FAINT}'>{note}</span>" if note else ""))
    text.setFont(T.font(10.5))
    text.setWordWrap(True)
    btn = QToolButton()
    btn.setText("i")
    btn.setToolTip(info_text)
    btn.setFixedSize(22, 22)
    btn.setStyleSheet(f"QToolButton{{border:1px solid {T.FAINT}; border-radius:11px; font-weight:bold;}}")
    btn.clicked.connect(lambda: info(box, info_text, label))
    lay.addWidget(text, 1)
    lay.addWidget(btn, 0, Qt.AlignRight)
    lay.addWidget(toggle, 0, Qt.AlignRight)
    return box


def _combo(items: list[tuple[str, str]]) -> QComboBox:
    c = QComboBox()
    for label, data in items:
        c.addItem(label, data)
    return c


def _select(combo: QComboBox, data) -> None:
    combo.setCurrentIndex(max(0, combo.findData(data)))


class SettingsPage(QWidget):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        lay = page_layout(self)
        lay.addWidget(PageHeader(t("settings.title"), t("settings.subtitle")))

        form = QWidget()
        f = QVBoxLayout(form)
        f.setContentsMargins(0, 0, 12, 0)
        f.setSpacing(18)

        # ---- general ---------------------------------------------------
        c = Card()
        c.body.addWidget(section(t("settings.general")))
        g = QGridLayout()
        g.setHorizontalSpacing(16)
        g.setVerticalSpacing(14)
        self.device = _combo([(x, x) for x in "ABCDEFGH"])
        self.output = QLineEdit()
        out_btn = ghost_button(t("common.browse"))
        out_btn.clicked.connect(lambda: self._browse(self.output))
        self.models = QLineEdit()
        mod_btn = ghost_button(t("common.browse"))
        mod_btn.clicked.connect(lambda: self._browse(self.models))
        g.addWidget(_field(t("settings.device"), self.device), 0, 0)       # app sirf English mein
        g.addWidget(_field(t("settings.output"), self._with_button(self.output, out_btn)), 1, 0, 1, 2)
        g.addWidget(_field(t("settings.models"), self._with_button(self.models, mod_btn)), 2, 0, 1, 2)
        c.body.addLayout(g)
        f.addWidget(c)

        # ---- clips -------------------------------------------------------
        c = Card()
        c.body.addWidget(section(t("settings.clips")))
        g = QGridLayout()
        g.setHorizontalSpacing(16)
        g.setVerticalSpacing(14)
        self.min_len, self.max_len, self.count, self.block = QSpinBox(), QSpinBox(), QSpinBox(), QSpinBox()
        for box, lo, hi in ((self.min_len, 5, 600), (self.max_len, 6, 600), (self.count, 1, 5000), (self.block, 5, 500)):
            box.setRange(lo, hi)
        self.min_len.setSuffix(" s")
        self.max_len.setSuffix(" s")
        self.ratio = _combo([("Shorts 9:16", "9:16"), ("Landscape 16:9", "16:9")])
        g.addWidget(_field(f"{t('settings.default_length')}  ({t('camp.min')})", self.min_len), 0, 0)
        g.addWidget(_field(f"{t('settings.default_length')}  ({t('camp.max')})", self.max_len), 0, 1)
        g.addWidget(_field(t("settings.clip_count"), self.count), 1, 0)
        g.addWidget(_field(t("settings.ratio"), self.ratio), 1, 1)
        g.addWidget(_field(t("settings.block"), self.block), 2, 0)
        self.per_minute = QSpinBox()
        self.per_minute.setRange(5, 500)
        g.addWidget(_field(t("settings.per_minute"), self.per_minute), 2, 1)
        c.body.addLayout(g)
        f.addWidget(c)

        # ---- AI helper (campaign briefs) -------------------------------
        c = Card()
        c.body.addWidget(section(t("settings.ai")))
        self.research = Toggle()
        c.body.addWidget(_switch(t("settings.research"), self.research))
        ai_note = QLabel(t("settings.ai_note"))
        ai_note.setWordWrap(True)
        ai_note.setStyleSheet(f"color:{T.FAINT};")
        c.body.addWidget(ai_note)
        f.addWidget(c)

        # ---- editing -------------------------------------------------
        c = Card()
        c.body.addWidget(section(t("settings.editing")))
        self.captions = Toggle()
        self.rotate = Toggle()
        self.style = _combo([(STYLES[key].label, key) for key in ROTATION_STYLES])     # sirf pasand kiye styles
        self.silence = _combo([(t(f"silence.{k}"), k) for k in ("light", "medium", "strong")])   # khamoshi hamesha kat ti
        self.looks = Toggle()
        self.hook_titles = Toggle()
        self.zoom_effects = Toggle()
        self.reaction_shots = Toggle()
        self.better_moments = Toggle()
        self.sound_effects = Toggle()
        self.sharpen = Toggle()
        self.captions.toggled.connect(self.style.setEnabled)
        self.captions.toggled.connect(self.rotate.setEnabled)
        c.body.addWidget(_switch(t("settings.captions"), self.captions))
        c.body.addWidget(_field(t("settings.caption_style"), self.style))
        c.body.addWidget(_switch(t("settings.rotate"), self.rotate))
        c.body.addWidget(_field(t("settings.silence"), self.silence))
        c.body.addWidget(_switch(t("settings.looks"), self.looks))
        c.body.addWidget(_switch(t("settings.hook_titles"), self.hook_titles))
        c.body.addWidget(_switch(t("settings.zoom_effects"), self.zoom_effects))
        c.body.addWidget(_switch(t("settings.reaction_shots"), self.reaction_shots))
        c.body.addWidget(_switch(t("settings.better_moments"), self.better_moments))
        c.body.addWidget(_switch(t("settings.sound_effects"), self.sound_effects))
        c.body.addWidget(_switch(t("settings.sharpen"), self.sharpen))
        f.addWidget(c)

        # ---- quality aur speed: YouTube HQ + GPU Fast encoding --------
        from app.core.gpu import has_gpu
        c = Card()
        c.body.addWidget(section(t("settings.quality")))
        self.cold_open = Toggle()
        c.body.addWidget(_switch_info(t("settings.cold_open"), self.cold_open, t("settings.cold_open_info")))
        self.name_card = Toggle()
        c.body.addWidget(_switch_info(t("settings.name_card"), self.name_card, t("settings.name_card_info")))
        self.titles_enabled = Toggle()
        c.body.addWidget(_switch(t("settings.titles_enabled"), self.titles_enabled))
        self.hashtags_enabled = Toggle()
        c.body.addWidget(_switch(t("settings.hashtags_enabled"), self.hashtags_enabled))
        self.upload_names = Toggle()
        c.body.addWidget(_switch(t("settings.upload_names"), self.upload_names))
        self.title_cards = _combo([(t(f"title_cards.{k}"), k) for k in ("auto", "always", "off")])
        c.body.addWidget(_field(t("settings.title_cards"), self.title_cards))
        self.title_cards.setToolTip(t("settings.title_cards_info"))
        self.show_channel_name = Toggle()
        c.body.addWidget(_switch(t("settings.show_channel_name"), self.show_channel_name))
        self.channel_name = QLineEdit()
        self.channel_name.setMaxLength(40)
        c.body.addWidget(_field(t("settings.channel_name"), self.channel_name))
        self.show_channel_name.toggled.connect(self.channel_name.setEnabled)
        self.preview_pack = Toggle()
        c.body.addWidget(_switch_info(t("settings.preview_pack"), self.preview_pack, t("settings.preview_pack_info")))
        self.youtube_hq = Toggle()
        self.gpu_encode = Toggle()
        self._gpu = has_gpu()
        c.body.addWidget(_switch_info(t("settings.youtube_hq"), self.youtube_hq, t("settings.youtube_hq_info")))
        c.body.addWidget(_switch_info(t("settings.gpu_encode"), self.gpu_encode, t("settings.gpu_encode_info"),
                                      note=t("settings.gpu_found") if self._gpu else t("settings.no_gpu")))
        self.gpu_encode.setEnabled(self._gpu)          # GPU nahi = switch grey, on nahi ho sakta
        f.addWidget(c)

        # ---- audio and words -----------------------------------------
        c = Card()
        c.body.addWidget(section(t("settings.audio")))
        self.loudness = Toggle()
        self.beep = _combo([(t(f"beep.{k}"), k) for k in ("beep", "mute", "cut")])
        self.max_beeps = QSpinBox()
        self.max_beeps.setRange(0, 20)
        self.profanity = _combo([(t(f"prof.{k}"), k) for k in ("strict", "standard", "off")])
        self.banned = QLineEdit()
        self.vips = QLineEdit()
        self.names = QPlainTextEdit()
        self.names.setFixedHeight(100)
        self.names.setPlaceholderText("trump = Trump\nkamala = Kamala")
        c.body.addWidget(_switch(t("settings.loudness"), self.loudness))
        g = QGridLayout()
        g.setHorizontalSpacing(16)
        g.setVerticalSpacing(14)
        g.addWidget(_field(t("settings.beep_mode"), self.beep), 0, 0)
        g.addWidget(_field(t("settings.profanity"), self.profanity), 0, 1)
        g.addWidget(_field(t("settings.max_beeps"), self.max_beeps), 1, 0, 1, 2)
        c.body.addLayout(g)
        c.body.addWidget(_field(t("settings.banned"), self.banned))
        c.body.addWidget(_field(t("settings.vips"), self.vips))
        c.body.addWidget(_field(t("settings.names"), self.names))
        f.addWidget(c)

        # ---- system --------------------------------------------------
        c = Card()
        c.body.addWidget(section(t("settings.system")))
        self.auto_delete = Toggle()
        c.body.addWidget(_switch(t("settings.auto_delete"), self.auto_delete))
        self.cookies = QLineEdit()
        self.cookies.setPlaceholderText("cookies.txt")
        ck_btn = ghost_button(t("common.browse"))
        ck_btn.clicked.connect(self._browse_cookies)
        c.body.addWidget(_field(t("settings.cookies"), self._with_button(self.cookies, ck_btn)))
        brow = QHBoxLayout()
        for key, slot in (("settings.export", self._export), ("settings.import", self._import),
                          ("settings.diagnostics", self._diagnostics)):
            b = ghost_button(t(key))
            b.clicked.connect(slot)
            brow.addWidget(b)
        c.body.addLayout(brow)
        f.addWidget(c)

        # ---- clips saaf karna (kabhi khud nahi; campaign chun kar) --------
        c = Card()
        c.body.addWidget(section(t("clear.section")))
        hint = QLabel(t("clear.hint"))
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{T.FAINT};")
        c.body.addWidget(hint)
        clear_btn = ghost_button(t("clear.button"), danger=True)
        clear_btn.clicked.connect(self._clear_clips)
        c.body.addWidget(clear_btn, 0, Qt.AlignLeft)
        f.addWidget(c)

        # ---- tool reset: ek button mein sab naya (history, campaigns, settings) ----
        c = Card()
        c.body.addWidget(section(t("reset.section")))
        hint = QLabel(t("reset.hint"))
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{T.FAINT};")
        c.body.addWidget(hint)
        reset_btn = ghost_button(t("reset.button"), danger=True)
        reset_btn.clicked.connect(self._reset_tool)
        c.body.addWidget(reset_btn, 0, Qt.AlignLeft)
        f.addWidget(c)

        # ---- updates (GitHub se; kabhi zabardasti nahi) ----------------
        from app.version import VERSION
        c = Card()
        c.body.addWidget(section(t("upd.section")))
        self.upd_label = QLabel(t("upd.current", v=VERSION))
        self.upd_label.setWordWrap(True)
        c.body.addWidget(self.upd_label)
        self.upd_notes = QPlainTextEdit()
        self.upd_notes.setReadOnly(True)
        self.upd_notes.setFixedHeight(90)
        self.upd_notes.hide()
        c.body.addWidget(self.upd_notes)
        urow = QHBoxLayout()
        check = ghost_button(t("upd.check"))
        check.clicked.connect(self._check_update)
        self.upd_now = FoilButton(t("upd.now"))
        self.upd_now.clicked.connect(self._update_now)
        self.upd_now.hide()
        urow.addWidget(check)
        urow.addWidget(self.upd_now)
        urow.addStretch(1)
        c.body.addLayout(urow)
        self._release: dict | None = None
        f.addWidget(c)

        # (15 Nov, SEA CLIPS 2.0) saamne sirf zaroori: General, Clips, Updates. Baaki "Advanced" mein band.
        cards = [f.itemAt(i).widget() for i in range(f.count()) if f.itemAt(i).widget() is not None]
        keep = {0, 1, len(cards) - 1}
        adv = QWidget()
        al = QVBoxLayout(adv)
        al.setContentsMargins(0, 0, 0, 0)
        al.setSpacing(18)
        for i, card in enumerate(cards):
            if i not in keep:
                f.removeWidget(card)
                al.addWidget(card)
        adv_btn = ghost_button("▸  Advanced: editing, quality, audio, research, cleanup and reset")
        adv_btn.setStyleSheet("text-align:left; padding:10px 14px;")

        def flip() -> None:
            adv.setVisible(not adv.isVisible())
            adv_btn.setText(("▾" if adv.isVisible() else "▸") + adv_btn.text()[1:])
        adv_btn.clicked.connect(flip)
        adv.hide()
        f.addWidget(adv_btn)
        f.addWidget(adv)
        if getattr(ctx, "drive", None) is not None:          # (18 Nov) Google Drive Clip Pool
            from app.ui.pages.drive_card import ChannelCard, DriveCard
            f.insertWidget(2, DriveCard(ctx))
            if getattr(ctx, "links", None) is not None:
                f.insertWidget(3, ChannelCard(ctx))          # (18 Nov) channel ki Google Sheet
        from PySide6.QtWidgets import QPushButton
        self.save_btn = QPushButton(t("settings.save"))
        self.save_btn.setProperty("role", "gold")
        self.save_btn.setCursor(Qt.PointingHandCursor)
        self.save_btn.clicked.connect(self._save)
        f.addWidget(self.save_btn, 0, Qt.AlignLeft)
        f.addStretch(1)
        lay.addWidget(scroll_wrap(form), 1)
        self.load(ctx.settings)

    # ------------------------------------------------------------ helpers
    @staticmethod
    def _with_button(edit: QLineEdit, button) -> QWidget:
        w = QWidget()
        lay = QHBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(edit, 1)
        lay.addWidget(button)
        return w

    def _browse_cookies(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, t("settings.cookies"), str(Path.home() / "Downloads"),
                                              "Cookies (*.txt)")
        if path:
            self.cookies.setText(path)

    def _browse(self, edit: QLineEdit) -> None:
        path = QFileDialog.getExistingDirectory(self, " ", edit.text() or str(Path.home()))
        if path:
            edit.setText(path)

    def showEvent(self, e):
        # Create page wala preview switch bhi yahi setting badalta hai: dikhate waqt taaza
        self.preview_pack.setChecked(bool(self.ctx.settings.preview_pack))
        super().showEvent(e)

    # ------------------------------------------------------------ load / collect
    def load(self, s: AppSettings) -> None:
        _select(self.device, s.device_code)
        self.output.setText(s.output_dir)
        self.models.setText(s.models_dir)
        self.min_len.setValue(s.min_length)
        self.max_len.setValue(s.max_length)
        self.count.setValue(s.clip_count)
        _select(self.ratio, s.ratio)
        self.block.setValue(s.block_size)
        self.per_minute.setValue(s.clips_per_minute)
        self.captions.setChecked(s.captions_enabled)
        _select(self.style, s.default_caption_style)
        self.rotate.setChecked(s.rotate_caption_styles)
        self.style.setEnabled(s.captions_enabled)
        self.rotate.setEnabled(s.captions_enabled)
        _select(self.silence, s.silence_level)
        self.looks.setChecked(s.color_looks_enabled)
        self.hook_titles.setChecked(s.hook_titles)
        self.zoom_effects.setChecked(s.zoom_effects)
        self.reaction_shots.setChecked(s.reaction_shots)
        self.better_moments.setChecked(s.better_moments)
        self.sound_effects.setChecked(s.sound_effects)
        self.sharpen.setChecked(s.sharpen)
        self.youtube_hq.setChecked(s.youtube_hq)
        self.preview_pack.setChecked(s.preview_pack)
        self.cold_open.setChecked(s.cold_open)
        self.name_card.setChecked(s.name_card)
        _select(self.title_cards, s.title_cards)
        self.titles_enabled.setChecked(s.titles_enabled)
        self.hashtags_enabled.setChecked(s.hashtags_enabled)
        self.upload_names.setChecked(s.upload_names)
        self.show_channel_name.setChecked(s.show_channel_name)
        self.channel_name.setText(s.channel_name)
        self.channel_name.setEnabled(s.show_channel_name)
        self.gpu_encode.setChecked(s.gpu_encode and self._gpu)
        self.loudness.setChecked(s.loudness_normalize)
        _select(self.beep, s.beep_mode)
        self.max_beeps.setValue(s.max_beeps_per_clip)
        _select(self.profanity, s.profanity_level)
        self.banned.setText(", ".join(s.general_banned_words))
        self.vips.setText(", ".join(s.vip_names))
        self.names.setPlainText("\n".join(f"{k} = {v}" for k, v in s.names_dictionary.items()))
        self.auto_delete.setChecked(s.auto_delete_source)
        self.cookies.setText(s.youtube_cookies)
        self.research.setChecked(s.research_online)

    def collect(self) -> AppSettings:
        """Read the form into a COPY (the live settings change only on Save)."""
        s = copy.deepcopy(self.ctx.settings)
        s.language = "en"
        s.device_code = self.device.currentData()
        s.output_dir = self.output.text().strip() or s.output_dir
        s.models_dir = self.models.text().strip()
        s.min_length = self.min_len.value()
        s.max_length = max(self.max_len.value(), s.min_length + 1)
        s.clip_count = self.count.value()
        s.ratio = self.ratio.currentData()
        s.block_size = self.block.value()
        s.clips_per_minute = self.per_minute.value()
        s.captions_enabled = self.captions.isChecked()
        s.default_caption_style = self.style.currentData()
        s.rotate_caption_styles = self.rotate.isChecked()
        s.silence_level = self.silence.currentData()
        s.color_looks_enabled = self.looks.isChecked()
        s.hook_titles = self.hook_titles.isChecked()
        s.zoom_effects = self.zoom_effects.isChecked()
        s.reaction_shots = self.reaction_shots.isChecked()
        s.better_moments = self.better_moments.isChecked()
        s.sound_effects = self.sound_effects.isChecked()
        s.sharpen = self.sharpen.isChecked()
        s.youtube_hq = self.youtube_hq.isChecked()
        s.preview_pack = self.preview_pack.isChecked()
        s.cold_open = self.cold_open.isChecked()
        s.name_card = self.name_card.isChecked()
        s.title_cards = self.title_cards.currentData() or "auto"
        s.titles_enabled = self.titles_enabled.isChecked()
        s.hashtags_enabled = self.hashtags_enabled.isChecked()
        s.upload_names = self.upload_names.isChecked()
        s.show_channel_name = self.show_channel_name.isChecked()
        s.channel_name = self.channel_name.text().strip()
        s.gpu_encode = self.gpu_encode.isChecked() and self._gpu
        s.loudness_normalize = self.loudness.isChecked()
        s.beep_mode = self.beep.currentData()
        s.max_beeps_per_clip = self.max_beeps.value()
        s.profanity_level = self.profanity.currentData()
        s.general_banned_words = split_list(self.banned.text())
        s.vip_names = split_list(self.vips.text())
        names = {}
        for line in self.names.toPlainText().splitlines():
            if "=" in line:
                wrong, right = (x.strip() for x in line.split("=", 1))
                if wrong and right:
                    names[wrong] = right
        s.names_dictionary = names
        s.auto_delete_source = self.auto_delete.isChecked()
        s.youtube_cookies = self.cookies.text().strip()
        s.gemini_api_key = ""                     # Gemini band
        s.research_online = self.research.isChecked()
        return s

    # ------------------------------------------------------------ actions
    def _save(self) -> None:
        if self.ctx.busy:
            warn(self, t("msg.busy"))
            return
        old_lang = self.ctx.settings.language
        self.ctx.settings = self.collect()
        self.ctx.save_settings()
        self.load(self.ctx.settings)
        msg = t("msg.saved")
        if self.ctx.settings.language != old_lang:
            set_language(self.ctx.settings.language)
            msg += "\n" + t("settings.restart")
        self.ctx.campaignsChanged.emit()
        info(self, msg)

    def _export(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, t("settings.export"),
                                              str(Path.home() / "AIMERS settings.json"), "Settings (*.json)")
        if path:
            s = self.collect()
            s.gemini_api_key = ""            # keys and sign-ins never leave this laptop
            s.youtube_cookies = ""
            AppSettings.validate(s).save(Path(path))
            info(self, t("msg.saved"))

    def _import(self) -> None:
        if self.ctx.busy:
            warn(self, t("msg.busy"))
            return
        path, _ = QFileDialog.getOpenFileName(self, t("settings.import"), str(Path.home()), "Settings (*.json)")
        if not path:
            return
        try:
            imported = AppSettings.from_data(json.loads(Path(path).read_text(encoding="utf-8")))
        except (OSError, ValueError, UnicodeDecodeError) as exc:      # JSONDecodeError is a ValueError
            warn(self, f"{t('settings.import_bad')}\n\n{exc}")
            return
        # Laptop-specific values stay as they are on this PC.
        imported.device_code = self.ctx.settings.device_code
        imported.output_dir = self.ctx.settings.output_dir
        imported.models_dir = self.ctx.settings.models_dir
        imported.gemini_api_key = self.ctx.settings.gemini_api_key
        imported.youtube_cookies = self.ctx.settings.youtube_cookies
        self.ctx.settings = AppSettings.validate(imported)
        self.ctx.settings.save(settings_path())
        self.load(self.ctx.settings)
        info(self, t("msg.saved"))

    def _diagnostics(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, t("settings.diagnostics"), str(Path.home() / "Desktop"))
        if folder:
            zip_path = export_diagnostics(Path(folder))
            show_in_folder(zip_path)

    # ---- Clear clips: campaigns chuno, sirf videos delete (folders baaki) ----
    def _clear_clips(self) -> None:
        from app.output.organizer import campaign_root
        if self.ctx.busy:
            warn(self, t("msg.busy"))
            return
        camps = self.ctx.db.list_campaigns()
        if not camps:
            info(self, t("clear.none"))
            return
        dlg = QDialog(self)
        dlg.setWindowTitle(t("clear.button"))
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel(t("clear.pick")))
        boxes = []
        all_box = QCheckBox(t("lib.select_all"))
        lay.addWidget(all_box)
        for cid, name in camps:
            b = QCheckBox(name)
            b.setProperty("cid", cid)
            boxes.append(b)
            lay.addWidget(b)
        all_box.toggled.connect(lambda on: [b.setChecked(on) for b in boxes])
        row = QHBoxLayout()
        cancel = ghost_button(t("common.cancel"))
        cancel.clicked.connect(dlg.reject)
        go = FoilButton(t("clear.go"))
        go.clicked.connect(dlg.accept)
        row.addStretch(1)
        row.addWidget(cancel)
        row.addWidget(go)
        lay.addLayout(row)
        if dlg.exec() != QDialog.Accepted:
            return
        chosen = [b.property("cid") for b in boxes if b.isChecked()]
        if not chosen:
            return
        from app.ui.pages.common import confirm
        if not confirm(self, t("clear.confirm", n=len(chosen))):
            return
        removed, failed = clear_campaign_videos(self.ctx.db, Path(self.ctx.settings.output_dir), chosen,
                                                campaign_root)
        msg = t("clear.done", n=removed)
        if failed:
            msg += "\n" + t("lib.delete_failed") + "\n" + "\n".join(failed[:10])
        info(self, msg)
        self.ctx.clipsChanged.emit()

    def _reset_tool(self) -> None:
        """Poora tool naya: history, campaigns, cache, settings (+ chuna ho to clip videos). Phir app band."""
        from app.tools.app_reset import count_videos, reset_everything
        if self.ctx.busy:
            warn(self, t("msg.busy"))
            return
        out = Path(self.ctx.settings.output_dir)
        dlg = QDialog(self)
        dlg.setWindowTitle(t("reset.button"))
        dlg.setMinimumWidth(480)
        lay = QVBoxLayout(dlg)
        what = QLabel(t("reset.what", folder=str(out)))
        what.setWordWrap(True)
        lay.addWidget(what)
        clips_box = QCheckBox(t("reset.with_clips", n=count_videos(out)))
        clips_box.setChecked(True)
        lay.addWidget(clips_box)
        lay.addWidget(QLabel(t("reset.type")))
        typed = QLineEdit()
        typed.setPlaceholderText("RESET")
        lay.addWidget(typed)
        row = QHBoxLayout()
        cancel = ghost_button(t("common.cancel"))
        cancel.clicked.connect(dlg.reject)
        go = FoilButton(t("reset.go"))
        go.setEnabled(False)
        typed.textChanged.connect(lambda x: go.setEnabled(x.strip().upper() == "RESET"))
        go.clicked.connect(dlg.accept)
        row.addStretch(1)
        row.addWidget(cancel)
        row.addWidget(go)
        lay.addLayout(row)
        if dlg.exec() != QDialog.Accepted:
            return
        res = reset_everything(self.ctx.db, self.ctx.settings, clips_box.isChecked())
        msg = t("reset.done", c=res.campaigns, r=res.records, v=res.clips_deleted)
        if res.failed:
            msg += "\n\n" + t("lib.delete_failed") + "\n" + "\n".join(res.failed[:10])
        info(self, msg)
        from PySide6.QtWidgets import QApplication
        win = self.window()
        if hasattr(win, "_closing_ok"):
            win._closing_ok = True                      # band karte waqt dobara na poochhe
        QApplication.instance().quit()                   # app band: agli dafa bilkul naya khulega

    # ---- Updates -------------------------------------------------------------
    def show_update(self, rel: dict) -> None:
        from app.version import VERSION
        self._release = rel
        self.upd_label.setText(t("upd.available", v=rel["version"], cur=VERSION))
        self.upd_notes.setPlainText(rel.get("notes") or "")
        self.upd_notes.setVisible(bool(rel.get("notes")))
        self.upd_now.setVisible(bool(rel.get("url") or rel.get("page")))

    def _check_update(self) -> None:
        from app.core.notify import check_update
        from app.version import UPDATE_REPO, VERSION
        rel = check_update(VERSION, UPDATE_REPO)
        if rel:
            self.show_update(rel)
        else:
            info(self, t("upd.none", v=VERSION))

    def _update_now(self) -> None:
        """
        Naya version: GitHub release ka page browser mein khulta hai. Installer kai hisson
        (Setup.exe + .bin) mein hota hai, is liye wahan se sab files ek folder mein le kar
        Setup.exe chalayein. App kabhi atakti nahi (koi bara download app ke andar nahi).
        """
        rel = self._release
        if not rel:
            return
        win = self.window()
        if hasattr(win, "show_update"):
            win.show_update(rel)
            win._update_now()
            return
        from app.ui.context import open_path
        open_path(rel.get("page") or rel.get("url", ""))


# ---------------------------------------------------------------------
#  Helpers (page ke bahar, test ho sakein)
# ---------------------------------------------------------------------
def clear_campaign_videos(db, output_dir: Path, campaign_ids: list[int], root_of) -> tuple[int, list[str]]:
    """Chuni hui campaigns ke folders mein sirf .mp4 videos delete; folders aur history baaki."""
    removed, failed = 0, []
    for cid in campaign_ids:
        profile = db.get_campaign(cid)
        if profile is None:
            continue
        root = root_of(output_dir, profile)
        if not root.exists() or root.resolve() == output_dir.resolve():
            continue                         # Clips folder khud kabhi nahi
        for f in root.rglob("*.mp4"):
            try:
                f.unlink()
                removed += 1
            except OSError as exc:
                failed.append(f"{f.name} ({exc.strerror or exc})")
        db.sync_missing_files(cid)
    return removed, failed


def download_installer(url: str, version: str) -> Path:
    """Naya installer temp folder mein (sirf github.com se)."""
    import urllib.request
    from urllib.parse import urlparse

    from app.core.paths import temp_dir
    host = urlparse(url).hostname or ""
    if not (host == "github.com" or host.endswith(".githubusercontent.com")):
        raise ValueError("update link is not on GitHub")
    out = temp_dir() / f"AIMERS Setup {version}.exe"
    req = urllib.request.Request(url, headers={"User-Agent": "AIMERS-Auto-Clipping-Tool"})
    with urllib.request.urlopen(req, timeout=120) as r, open(out, "wb") as fh:   # noqa: S310
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            fh.write(chunk)
    return out
