"""
=====================================================================
  OUTPUT / DELIVERY TRACKER
  Kaam: clips logon ko dena (har clip sirf ek dafa).
  "Give the next 200 clips to Ali":
    * picks undelivered clips in number order (Recommended first,
      then Medium; Below 50 only if asked)
    * moves them to  <Campaign>/Delivered/<Ali> <date>/
    * marks EACH clip as given the moment its file is moved, so a
      problem half way (file open in a player) can never cause the
      same clip to be given to someone else later
    * clips whose file is missing are NOT counted as delivered
    * rebuilds Clips List.xlsx
  A clip is never given twice.
=====================================================================
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path

from app.core.db import ClipRecord, Database
from app.core.logging_setup import get_logger
from app.core.paths import move_with_retry, safe_filename
from app.output.organizer import unique_path

log = get_logger("delivery")


@dataclass
class DeliveryResult:
    folder: Path
    clips: list[ClipRecord]     # actually given
    missing: list[str]          # labels whose file was not found on disk (not given)
    locked: list[str]           # labels whose file could not be moved (not given)
    error: str = ""             # why the delivery stopped early, if it did

    @property
    def count(self) -> int:
        return len(self.clips)


def available(db: Database, campaign_id: int, include_below: bool = False) -> list[ClipRecord]:
    order = ["recommended", "medium"] + (["below"] if include_below else [])
    pool = db.clips_for_campaign(campaign_id, undelivered_only=True)
    return sorted((c for c in pool if c.rating in order), key=lambda c: (order.index(c.rating), c.number))


def deliver_next(db: Database, campaign_id: int, root: Path, receiver: str, count: int,
                 include_below: bool = False, move_files: bool = True) -> DeliveryResult:
    receiver = receiver.strip()
    if not receiver:
        raise ValueError("Receiver name is required")
    if count <= 0:
        raise ValueError("Count must be at least 1")
    picked = available(db, campaign_id, include_below)[:count]
    if not picked:
        raise ValueError("No clips left to deliver")

    folder = root / "Delivered" / safe_filename(f"{receiver} {date.today().isoformat()}", 80)
    folder.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().isoformat(timespec="seconds")
    given: list[ClipRecord] = []
    missing: list[str] = []
    locked: list[str] = []
    error = ""
    for clip in picked:
        src = Path(clip.file_path)
        if move_files:
            if not src.exists():
                missing.append(clip.label)
                continue
            dst = unique_path(folder, src.name)
            try:
                move_with_retry(src, dst, attempts=5, wait=0.4)
            except OSError as exc:
                # e.g. the clip is open in a player: stop here, nothing is lost
                locked = [c.label for c in picked[picked.index(clip):] if c.label not in missing]
                error = str(exc)
                log.warning("Delivery stopped at %s: %s", clip.label, exc)
                break
            db.update_clip(clip.id, file_path=str(dst), delivered_to=receiver, delivered_at=stamp)
        else:
            db.update_clip(clip.id, delivered_to=receiver, delivered_at=stamp)
        given.append(clip)

    if given:
        db.record_delivery(campaign_id, receiver, [c.id for c in given])
    # (Clips List.xlsx ab nahi banti: data sirf tool ke andar)
    log.info("Delivered %d clips to %s (%d missing, %d locked)", len(given), receiver, len(missing), len(locked))
    if not given and not missing and error:
        raise OSError(f"Could not move the clips: {error}")
    return DeliveryResult(folder, given, missing, locked, error)
