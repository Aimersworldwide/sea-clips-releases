"""
=====================================================================
  OUTPUT / ORGANIZER
  Kaam: clip folders, naam aur titles.
  Folder layout (no app branding anywhere):
      <output>/<Campaign>/[<batch>/]Recommended/
                                    Medium/
                                    Below 50/
                         Delivered/<receiver> <date>/
                         Clips List.xlsx
                         Delivery Note.txt
  File name:
      Debate_A_001 - <Title> #tag1 #tag2.mp4
      * no title set     -> "Debate_A_001.mp4"
      * title varies a little per clip (hook from the clip itself)
      * the part after the label is kept within 100 characters
        (YouTube title limit). Hashtags that do not fit are left out
        of the name; they are always in Delivery Note.txt.
=====================================================================
"""
from __future__ import annotations

import re
from pathlib import Path

from app.core.config import CampaignProfile
from app.core.paths import safe_filename

RATING_FOLDERS = {"recommended": "Recommended", "medium": "Medium", "below": "Below 50", "check": "Check"}
TITLE_LIMIT = 100
HOOK_WORDS = 6

# Only characters Windows allows in file names (no : | ?).
_TITLE_FORMATS = (
    "{base} - {hook}",
    "{hook} - {base}",
    "{base}, {hook}",
    "{base}",
)
_FILLER_START = re.compile(r"^(so|and|but|well|look|okay|ok|um|uh|you know|i mean)[,\s]+", re.I)


# ---------------------------------------------------------------------
#  Folders
# ---------------------------------------------------------------------
def campaign_root(output_dir: Path, profile: CampaignProfile) -> Path:
    if profile.output_folder:
        return Path(profile.output_folder)
    return Path(output_dir) / safe_filename(profile.name or "Campaign", 60)


def rating_folder(root: Path, rating: str, batch: str = "") -> Path:
    base = root / safe_filename(batch, 40) if batch else root
    folder = base / RATING_FOLDERS.get(rating, "Below 50")
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def clip_label(campaign: str, device: str, number: int) -> str:
    """Debate_A_001 (4 digits once past 999)."""
    name = re.sub(r"[^A-Za-z0-9]+", "_", campaign).strip("_") or "Clip"
    return f"{name}_{device}_{number:03d}"


# ---------------------------------------------------------------------
#  Titles
# ---------------------------------------------------------------------
def hook_from_text(first_sentence: str, max_words: int = HOOK_WORDS) -> str:
    text = _FILLER_START.sub("", first_sentence.strip())
    words = text.split()
    if not words:
        return ""
    hook = " ".join(words[:max_words]).rstrip(",;:-")
    if len(words) > max_words:
        hook = hook.rstrip(".!?") + "..."
    return hook[0].upper() + hook[1:]


def clip_title(base: str, hook: str, number: int) -> str:
    """Small, honest variation: same base title, different hook per clip."""
    base = base.strip()
    if not base:
        return ""
    fmt = _TITLE_FORMATS[number % len(_TITLE_FORMATS)] if hook else "{base}"
    return fmt.format(base=base, hook=hook)


def _tags(hashtags: str) -> list[str]:
    out = []
    for tag in hashtags.replace(",", " ").split():
        tag = "#" + tag.lstrip("#")
        if len(tag) > 1 and tag not in out:
            out.append(tag)
    return out


def clip_filename(label: str, title: str, hashtags: str) -> str:
    """Build the final file name (without folder)."""
    title = safe_filename(title, TITLE_LIMIT)
    tail = title
    for tag in _tags(hashtags):
        candidate = f"{tail} {tag}".strip()
        if len(safe_filename(candidate, 999)) > TITLE_LIMIT:
            break
        tail = candidate
    name = f"{label} - {tail}" if tail else label
    return safe_filename(name, len(label) + 3 + TITLE_LIMIT) + ".mp4"


def unique_path(folder: Path, filename: str) -> Path:
    path = folder / filename
    n = 2
    while path.exists():
        path = folder / f"{Path(filename).stem} ({n}).mp4"
        n += 1
    return path


# ---------------------------------------------------------------------
#  Delivery note
# ---------------------------------------------------------------------
def write_delivery_note(root: Path, profile: CampaignProfile) -> Path | None:
    """Text the clipper pastes when posting. Only written if there is something to say."""
    lines = []
    if profile.delivery_note.strip():
        lines += ["POST TEXT", profile.delivery_note.strip(), ""]
    tags = _tags(profile.hashtags)
    if tags:
        lines += ["HASHTAGS", " ".join(tags), ""]
    if profile.disclosure_enabled and profile.disclosure_text.strip():
        lines += ["DISCLOSURE", profile.disclosure_text.strip(), ""]
    path = root / "Delivery Note.txt"
    if not lines:
        if path.exists():
            path.unlink()
        return None
    root.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    return path
