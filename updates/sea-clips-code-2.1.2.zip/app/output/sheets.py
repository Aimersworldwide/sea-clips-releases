"""
=====================================================================
  OUTPUT / SHEETS  ("Clips List.xlsx" in each campaign folder)
  Kaam: har campaign ki "Clips List.xlsx" banana.
  One workbook, one tab per folder so it is easy to read:
      All | Recommended | Medium | Below 50 | Deliveries
  Rebuilt from the database after every run and every delivery, so
  it is always correct (never edited by hand by the app).
  If the file is open in Excel, a copy is saved next to it instead.
=====================================================================
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from app.core.db import Database
from app.core.logging_setup import get_logger
from app.output.organizer import RATING_FOLDERS

log = get_logger("sheets")

SHEET_NAME = "Clips List.xlsx"
HEAD_FILL = PatternFill("solid", fgColor="1A1712")
HEAD_FONT = Font(bold=True, color="E9C46A")
CLIP_COLUMNS = ("Clip", "Moment / cut / edit", "Title", "Hashtags", "Length (s)", "Score", "Rating", "Why", "Rules checked",
                "Beeps", "Repaired", "Delivered to", "Delivered on", "File")
RATING_TEXT = {"recommended": "Recommended", "medium": "Medium", "below": "Below 50", "check": "Check"}


def _title_from_file(label: str, file_path: str) -> str:
    """'Debate_A_001 M001-C1-E1 - Title' -> 'Title' (tag ho ya na ho)."""
    stem = Path(file_path).stem
    if not stem.startswith(label):
        return ""
    rest = stem[len(label):]
    if rest.startswith(" ") and " - " in rest:
        return rest.split(" - ", 1)[1]
    return ""


def _write_table(ws, headers, rows, widths) -> None:
    ws.append(list(headers))
    for cell in ws[1]:
        cell.fill, cell.font = HEAD_FILL, HEAD_FONT
        cell.alignment = Alignment(vertical="center")
    for row in rows:
        ws.append(list(row))
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    if rows:
        ws.auto_filter.ref = ws.dimensions


def write_campaign_sheet(db: Database, campaign_id: int, root: Path) -> Path:
    clips = db.clips_for_campaign(campaign_id)
    wb = Workbook()
    wb.remove(wb.active)
    widths = (16, 16, 52, 40, 10, 8, 13, 34, 48, 7, 9, 16, 18, 60)

    def rows_for(rating: str | None):
        for c in clips:
            if rating and c.rating != rating:
                continue
            extra = c.extra
            yield (c.label, extra.get("tag", ""), extra.get("title") or _title_from_file(c.label, c.file_path),
                   extra.get("hashtags", ""), round(c.duration or (c.end_sec - c.start_sec), 1),
                   c.score, RATING_TEXT.get(c.rating, c.rating), c.score_reasons, extra.get("rules", ""), c.beeps,
                   "Yes" if c.repaired else "", c.delivered_to, c.delivered_at.replace("T", " "),
                   c.file_path)

    _write_table(wb.create_sheet("All"), CLIP_COLUMNS, list(rows_for(None)), widths)
    for rating, folder in RATING_FOLDERS.items():
        _write_table(wb.create_sheet(folder), CLIP_COLUMNS, list(rows_for(rating)), widths)

    deliveries = [(d["created_at"].replace("T", " "), d["receiver"], d["clip_count"],
                   d["first_label"], d["last_label"]) for d in db.delivery_history(campaign_id)]
    _write_table(wb.create_sheet("Deliveries"), ("Date", "Given to", "Clips", "From", "To"),
                 deliveries, (18, 22, 8, 16, 16))

    root.mkdir(parents=True, exist_ok=True)
    target = root / SHEET_NAME
    try:
        wb.save(target)
    except PermissionError:   # open in Excel
        target = root / f"Clips List ({datetime.now():%Y-%m-%d %H%M}).xlsx"
        wb.save(target)
        log.warning("Clips List.xlsx was open; saved %s instead", target.name)
    return target
