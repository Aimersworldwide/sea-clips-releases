"""
=====================================================================
  SELECT / AI JUDGE  (part of "Better moments", free options only)
  Kaam: AI se moments ko number (optional), aur protection AI judge.
  The rule score cannot tell whether a moment is actually interesting.
  When a free AI is available, the best ~30 moments (their words only,
  no video) are sent once per video and rated 0 to 10 like a short
  video editor would: does it start strong, make sense on its own,
  and land a point people would watch to the end and share?
    gemini : the user's own free Gemini key (same as the brief reader)
    ollama : a local model on this laptop, fully offline
  No AI available, no internet, a limit reached or a strange answer:
  nothing changes, the rule score is used. The key is sent in a
  header only and never logged.
=====================================================================
"""
from __future__ import annotations

import json

from app.campaign.ai import AIUnavailable, gemini_text, ollama_model, ollama_text
from app.core.logging_setup import get_logger

log = get_logger("ai_rank")

PROMPT = """You are a senior short-form video editor choosing clips from a long video for TikTok, Reels and Shorts.
Rate each numbered moment from 0 to 10:
10 = starts strong in the first seconds, makes complete sense without the rest of the video,
     and lands a clear, interesting point, story, strong opinion, emotion or surprise people would share.
5  = fine but ordinary.
0  = boring, confusing without context, or cut off.
Be strict and use the whole scale. Judge only the words.
Return ONLY JSON: {"ratings": [{"id": 0, "score": 7, "why": "max 8 words"}, ...]} with one entry per moment.

MOMENTS:
"""


def parse(text: str, count: int) -> dict[int, tuple[float, str]]:
    """Strict JSON answer -> {index: (score, reason)}; anything odd is dropped."""
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end <= start:
        return {}
    try:
        data = json.loads(text[start:end + 1])
    except ValueError:
        return {}
    out: dict[int, tuple[float, str]] = {}
    for item in data.get("ratings") or []:
        if not isinstance(item, dict):
            continue
        idx, score = item.get("id"), item.get("score")
        if (isinstance(idx, int) and not isinstance(idx, bool) and 0 <= idx < count
                and isinstance(score, (int, float)) and not isinstance(score, bool) and 0 <= score <= 10):
            out[idx] = (float(score), str(item.get("why") or "")[:60])
    # a judge that rated almost nothing (or everything the same) tells us nothing
    if len(out) < 0.6 * count or len({v[0] for v in out.values()}) < 2:
        return {}
    return out


def make_judge(gemini_key: str = "", gemini_model: str = ""):
    """A rerank(texts) function for the planner, or None when no AI is available."""
    local = "" if gemini_key else ollama_model()
    if not gemini_key and not local:
        return None

    def judge(texts: list[str]) -> dict[int, tuple[float, str]]:
        prompt = PROMPT + "\n".join(f"[{i}] {t}" for i, t in enumerate(texts))
        try:
            if gemini_key:
                answer, _ = gemini_text(prompt, gemini_key, gemini_model, json_mode=True)
                engine = "Gemini"
            else:
                answer, engine = ollama_text(prompt, local), f"local AI ({local})"
        except AIUnavailable as exc:
            log.warning("AI moment judge not used: %s", exc)
            return {}
        result = parse(answer, len(texts))
        log.info("AI moment judge (%s): rated %d of %d moments", engine, len(result), len(texts))
        return result
    return judge


# ---------------------------------------------------------------------
#  AI guard judge: "kya ye moment main person ko bura dikhata hai?"
#  Kaam: protection guard ka optional hissa. Sirf alfaaz jaate hain.
#  Jawab mein jo moment "risky" hon un ke number wapas aate hain.
#  AI na ho / ghalat jawab = khali (sirf qaide chalte hain).
# ---------------------------------------------------------------------
GUARD_PROMPT = """You check short video clips for a fan campaign about {names}.
For each numbered moment answer: does this moment show {names} in a negative light
(being insulted, mocked, proven wrong, losing the argument, embarrassed)?
Normal disagreement where {names} answers well is NOT negative.
Return ONLY JSON: {{"risky": [ids of negative moments]}}.

MOMENTS:
"""


def parse_guard(text: str, count: int) -> list[int]:
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end <= start:
        return []
    try:
        data = json.loads(text[start:end + 1])
    except ValueError:
        return []
    ids = data.get("risky") if isinstance(data, dict) else None
    if not isinstance(ids, list):
        return []
    out = [i for i in ids if isinstance(i, int) and not isinstance(i, bool) and 0 <= i < count]
    return sorted(set(out)) if len(out) <= 0.8 * count else []      # "sab risky" = ghalat jawab


def make_guard_judge(names: list[str], gemini_key: str = "", gemini_model: str = ""):
    """judge(texts) -> [risky indexes], or None when no AI is available."""
    names = [n for n in names if n.strip()]
    local = "" if gemini_key else ollama_model()
    if not names or (not gemini_key and not local):
        return None
    who = " or ".join(names)

    def judge(texts: list[str]) -> list[int]:
        prompt = GUARD_PROMPT.format(names=who) + "\n".join(f"[{i}] {t}" for i, t in enumerate(texts))
        try:
            if gemini_key:
                answer, _ = gemini_text(prompt, gemini_key, gemini_model, json_mode=True)
            else:
                answer = ollama_text(prompt, local)
        except AIUnavailable as exc:
            log.warning("AI protection judge not used: %s", exc)
            return []
        risky = parse_guard(answer, len(texts))
        log.info("AI protection judge: %d of %d moments risky", len(risky), len(texts))
        return risky
    return judge
