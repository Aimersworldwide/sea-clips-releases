"""
=====================================================================
  SELECT / SCORING
  Kaam: har moment ka score 0-100 (hook, mukammal baat, payoff).
  Every candidate clip gets a score from 0 to 100, built from four
  parts (25 points each) so the reason is always explainable:
    hook      - does the first line grab attention?
    complete  - is it one complete thought with a clean ending?
    payoff    - does it land a point / conclusion?
    delivery  - good speaking pace, clear audio, no dead air
  Phase 3 adds two signals:
    * voice energy (from the audio): a lively, expressive voice scores
      higher than a flat one (delivery, up to +6)
    * question and answer inside the clip (payoff +3): debates live on it
  Better moments (setting, on by default) adds stricter checks:
    * an answer whose question is just before the clip (no context): -6
    * a clip that ends on an open question (no answer): -5
    * a slow, very long first sentence: -3
    * a point that lands at the very end: +3, a short story: +3,
      tension (but / actually / the problem): +2
  Ratings:  75+ Recommended | 50-74 Medium | below 50 -> "Below 50"
  An optional local AI model (llama-server) can refine the score
  later; this rule-based score always works offline with no model.
=====================================================================
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.transcribe.models import Word

HOOK_PHRASES = (
    "the truth is", "here's the thing", "here is the thing", "let me tell you", "the problem is",
    "the reality is", "nobody", "no one", "everyone", "everybody", "never", "always", "what if",
    "most people", "the biggest", "the worst", "the best", "the secret", "the real reason",
    "you have to", "you need to", "think about", "imagine", "listen", "look,", "i'll tell you",
    "do you know", "did you know", "why do", "why does", "why is", "how do", "how is", "wrong",
    "lie", "lying", "crazy", "insane", "ridiculous", "unbelievable", "shocking",
)
PAYOFF_PHRASES = (
    "that's why", "that is why", "the point is", "which means", "bottom line", "in the end",
    "at the end of the day", "and that's", "so the answer", "that's the problem", "that's it",
    "that's what", "period", "end of story", "simple as that", "that's the truth", "and that matters",
)
CONNECTIVE_START = {"and", "but", "so", "because", "which", "then", "or", "also", "plus", "cause", "like"}
VAGUE_START = {"he", "she", "they", "it", "this", "that", "these", "those", "him", "her", "them"}
FILLERS = {"um", "uh", "erm", "hmm", "mm", "uhh", "umm"}
EMPHASIS = {"absolutely", "completely", "totally", "never", "always", "every", "nothing", "everything",
            "million", "billion", "trillion", "huge", "massive", "biggest", "worst", "best", "must"}
NUMBER_RE = re.compile(r"\d")
STORY_PHRASES = ("i remember", "one time", "when i was", "true story", "so i was", "the day i", "years ago",
                 "my dad", "my mom", "my father", "my mother", "i was like", "this guy")
TENSION_WORDS = {"but", "however", "actually", "although", "except", "instead"}
# Tanz / mazaq / punchline ke ishare (commentary shows ke viral hisse)
WIT_PHRASES = (
    "calm down", "oh boy", "i'll admit", "technically", "apparently", "come on", "give me a break",
    "you can't make this up", "what an amazing", "worth watching", "the slowest", "in the history of",
    "why is she", "why is he", "why would", "who cares", "good luck", "shocker", "spoiler", "turns out",
    "it gets weirder", "wait for it", "let's be honest", "that's not how", "has come to", "nobody asked",
    "congratulations", "genius", "brilliant", "with all due respect", "are you serious", "you have to laugh",
)


@dataclass
class Score:
    total: int
    hook: int
    complete: int
    payoff: int
    delivery: int
    reasons: list[str] = field(default_factory=list)

    @property
    def rating(self) -> str:
        return rating_for(self.total)


def rating_for(total: int) -> str:
    if total >= 75:
        return "recommended"
    if total >= 50:
        return "medium"
    return "below"


def _has(text: str, phrases: tuple[str, ...]) -> bool:
    return any(p in text for p in phrases)


def liveliness(envelope, rate: float, start: float, end: float) -> float | None:
    """
    0..1: how expressive the voice is between start and end. `envelope`
    is the loudness (RMS) of the speech audio, `rate` values per second.
    Uses the spread of loudness while talking (a flat voice barely
    changes) and how often it rises clearly above its own average.
    """
    import numpy as np
    if envelope is None:
        return None
    a, b = int(start * rate), int(end * rate)
    seg = envelope[a:b]
    if len(seg) < rate * 3:
        return None
    talk = seg[seg > max(1e-4, 0.2 * np.percentile(seg, 90))]    # drop pauses (near silence) only
    if len(talk) < rate:
        return None
    spread = float(np.std(talk) / (np.mean(talk) + 1e-9))       # about 0.3 flat .. 0.9 lively
    peaks = float(np.mean(talk > 1.6 * np.median(talk)))         # share of clearly louder moments
    return max(0.0, min(1.0, (spread - 0.3) / 0.6 * 0.7 + min(peaks / 0.25, 1.0) * 0.3))


def speech_envelope(samples, sample_rate: int = 16000, rate: int = 20):
    """Loudness (RMS) of the speech audio, `rate` values per second."""
    import numpy as np
    hop = sample_rate // rate
    n = len(samples) // hop
    if n == 0:
        return None
    frames = samples[: n * hop].reshape(n, hop)
    return np.sqrt((frames ** 2).mean(axis=1))


def quiet_spans(env, rate: int = 20, min_len: float = 0.4, drop_db: float = 30.0) -> list[tuple[float, float]]:
    """
    Awaaz se khamoshi ke hisse (source seconds): aawaz bohot dheemi
    (aam baat cheet se drop_db kam) aur kam az kam min_len lambi. Ye wo
    khamoshi bhi pakadta hai jo speech model ne kisi lafz ke andar gin li.
    """
    import numpy as np
    if env is None or len(env) == 0:
        return []
    db = 20 * np.log10(np.asarray(env, dtype=float) + 1e-6)
    quiet = db < np.percentile(db, 90) - drop_db
    out, start = [], None
    for k, q in enumerate(list(quiet) + [False]):
        if q and start is None:
            start = k
        elif not q and start is not None:
            if (k - start) / rate >= min_len:
                out.append((round(start / rate, 3), round(k / rate, 3)))
            start = None
    return out


# ---------------------------------------------------------------------
#  Hook ke number (0..25): pehli line kitni pakadti hai
#  Kaam: alag function taake cold open (teaser line) ko bhi isi tarah
#  jaancha ja sake.
# ---------------------------------------------------------------------
def hook_points(first: str, lead: str, reasons: list[str] | None = None) -> int:
    reasons = reasons if reasons is not None else []
    first = first.lower()
    hook = 8
    if "?" in first:
        hook += 6
        reasons.append("opens with a question")
    if _has(first, HOOK_PHRASES):
        hook += 8
        reasons.append("strong opening line")
    if NUMBER_RE.search(first):
        hook += 3
    n_first = len(first.split())
    if 4 <= n_first <= 18:
        hook += 4
    if lead in CONNECTIVE_START:
        hook -= 10
        reasons.append("starts with a linking word")
    elif lead in VAGUE_START:
        hook -= 5
    return max(0, min(25, hook))


def score_window(words: list[Word], sentence_texts: list[str], beeps: int = 0,
                 energy: float | None = None, before: str = "", better: bool = False) -> Score:
    """Score one candidate clip (words + its sentences). `before` = the sentence just before it."""
    reasons: list[str] = []
    first = sentence_texts[0].lower() if sentence_texts else ""
    last = sentence_texts[-1].lower() if sentence_texts else ""
    full = " ".join(sentence_texts).lower()
    first_words = [w.clean for w in words[:3]]
    lead = first_words[0] if first_words else ""

    # --- hook (0..25) ------------------------------------------------
    hook = hook_points(first, lead, reasons)

    # --- complete (0..25) --------------------------------------------
    complete = 8
    if last.rstrip().endswith((".", "!", "?")):
        complete += 9
    else:
        complete += 3
    last_word = words[-1].clean if words else ""
    if last_word not in CONNECTIVE_START and last_word not in {"the", "a", "an", "to", "of", "and"}:
        complete += 4
    if len(last.split()) >= 3:
        complete += 4
    complete = max(0, min(25, complete))

    # --- payoff (0..25) ----------------------------------------------
    payoff = 8
    if _has(full, PAYOFF_PHRASES):
        payoff += 9
        reasons.append("clear payoff")
    if last.rstrip().endswith("!"):
        payoff += 3
    emphasis = sum(1 for w in words if w.clean in EMPHASIS)
    payoff += min(5, emphasis * 2)
    if any(t.rstrip().endswith("?") for t in sentence_texts[:-1]) and not last.rstrip().endswith("?"):
        payoff += 3
        reasons.append("question and answer")
    # punchline: chhota, saaf aakhri jumla, pichle lambe jumle ke baad ("Calm down." "Who cares?")
    if len(sentence_texts) >= 2 and 1 <= len(last.split()) <= 7 and len(sentence_texts[-2].split()) >= 6 \
            and last.rstrip().endswith((".", "!", "?")):
        payoff += 4
        reasons.append("punchline ending")
    wit = sum(1 for ph in WIT_PHRASES if ph in full)
    if wit:
        payoff += min(6, 3 * wit)
        reasons.append("wit / sarcasm")
    payoff = max(0, min(25, payoff))

    # --- delivery (0..25) --------------------------------------------
    delivery = 6
    if words:
        span = max(0.1, words[-1].end - words[0].start)
        wps = len(words) / span
        if 2.2 <= wps <= 3.9:
            delivery += 8
        elif 1.7 <= wps < 2.2 or 3.9 < wps <= 4.5:
            delivery += 4
        avg_prob = sum(w.prob for w in words) / len(words)
        if avg_prob >= 0.85:
            delivery += 5
        elif avg_prob >= 0.7:
            delivery += 2
        gaps = [b.start - a.end for a, b in zip(words, words[1:])]
        if not any(g > 1.2 for g in gaps):
            delivery += 4
        fillers = sum(1 for w in words if w.clean in FILLERS)
        if fillers / len(words) < 0.03:
            delivery += 2
        else:
            reasons.append("many filler words")
    if energy is not None:
        if energy >= 0.55:
            delivery += 6
            reasons.append("lively voice")
        elif energy >= 0.35:
            delivery += 3
        elif energy < 0.15:
            delivery -= 2
            reasons.append("flat voice")
    delivery = max(0, min(25, delivery))

    if better:
        b_hook, b_complete, b_payoff = _better(words, sentence_texts, before, reasons)
        hook = max(0, min(25, hook + b_hook))
        complete = max(0, min(25, complete + b_complete))
        payoff = max(0, min(25, payoff + b_payoff))

    total = hook + complete + payoff + delivery - 3 * beeps
    total = max(0, min(100, total))
    return Score(total=total, hook=hook, complete=complete, payoff=payoff, delivery=delivery, reasons=reasons)


def _better(words: list[Word], sentence_texts: list[str], before: str, reasons: list[str]) -> tuple[int, int, int]:
    """Extra (hook, complete, payoff) points of the stricter moment check."""
    hook = complete = payoff = 0
    first = sentence_texts[0] if sentence_texts else ""
    last = sentence_texts[-1].lower().rstrip() if sentence_texts else ""
    if before.rstrip().endswith("?"):
        hook -= 6
        reasons.append("answer without its question")
    if last.endswith("?") and len(sentence_texts) > 1:
        complete -= 5
        reasons.append("ends on an open question")
    if len(first.split()) > 25:
        hook -= 3
        reasons.append("slow start")
    if _has(last, PAYOFF_PHRASES) or last.endswith("!"):
        payoff += 3
        reasons.append("lands at the end")
    full = " ".join(sentence_texts).lower()
    if _has(full, STORY_PHRASES):
        payoff += 3
        reasons.append("short story")
    middle = [w.clean for w in words[3:-3]]
    if any(w in TENSION_WORDS for w in middle):
        payoff += 2
    return hook, complete, payoff
