"""
=====================================================================
  SELECT / SMART CUTS AUR COLD OPEN
  Kaam: clip ka cut behtar banana, taake score (aur views) barhein.

  1. Smart cut (sirf un moments ke liye jin ka score 50 se kam hai):
     * shuru ke "and / so / but / um" jaise kamzor lafz kaat do, taake
       clip seedha baat se shuru ho
     * beech ke khali jumle ("You know." "Right." "Okay.") kaat do
     * khamoshi thori zyada kaato (pace "medium")
     Phir naye (edited) lafzon pe dobara score. Behtar ho to hi rakho.
     Baat ka matlab kabhi nahi badalta: sirf bharti ke lafz jaate hain.
     Clip kabhi campaign ki minimum length se chhota nahi hota.

  2. Cold open (Settings, default on): clip ki sab se pakadne wali line
     (1 se 3 second) shuru mein ek dafa dikhao, phir clip apni tarteeb
     se. Sirf tab jab wo line pehli line se waqai zyada mazboot ho, saaf
     ho (koi beep / gaali / bura lafz nahi) aur clip max length ke andar
     rahe.
=====================================================================
"""
from __future__ import annotations

from dataclasses import replace

from app.select.scoring import CONNECTIVE_START, FILLERS, hook_points, score_window
from app.transcribe.models import Word

LEAD_TRIM = CONNECTIVE_START | FILLERS | {"well", "okay", "ok", "yeah", "look", "now", "right"}
# jo pehle lafz kaate ja sakte hain (bina matlab badle): "because / which / look / then" jumle ka hissa hain
SAFE_LEAD = FILLERS | {"so", "and", "well", "okay", "ok", "yeah"}
# sirf khali bharti; "yes / no / sure / right / okay" jawab ho sakte hain, wo kabhi nahi kat te
FILLER_SENTENCES = {"you know", "um", "uh", "so", "well", "i mean", "anyway", "mm", "hmm", "uh huh", "you see"}
TEASER_MIN, TEASER_MAX = 1.0, 3.0          # cold open line ki lambai (second)
TEASER_GAIN = 4                            # pehli line se kam az kam itne hook points zyada ho
TEASER_MIN_POINTS = 16                     # aur khud bhi itni mazboot ho
TEASER_AHEAD = 5.0                         # line clip mein kam az kam itne second baad aati ho (warna dohrana bekaar)
PACE_GAP = (0.60, 0.25)                    # "medium" pace: 0.6 s se lambi khamoshi 0.25 s


def _sentence_text(words: list[Word]) -> str:
    return " ".join(w.text for w in words)


def _compressed(words: list[Word]) -> list[Word]:
    """Lafz "medium" pace ke baad ki timing pe (delivery ka score sahi aaye)."""
    out, shift = [], 0.0
    for i, w in enumerate(words):
        if i:
            gap = w.start - words[i - 1].end
            if gap > PACE_GAP[0]:
                shift += gap - PACE_GAP[1]
        out.append(Word(w.text, round(w.start - shift, 3), round(w.end - shift, 3), w.prob, w.speaker, w.doubt))
    return out


# ---------------------------------------------------------------------
#  Smart cut: kamzor clip ko behtar cut
# ---------------------------------------------------------------------
def rescue(win, words: list[Word], sentences, min_len: float, before: str = "", better: bool = False):
    """
    win: planner ki Window. words: poori transcript ke lafz. sentences:
    poori transcript ke jumle. Behtar Window wapas, warna None.
    """
    first, last = win.w_first, win.w_last
    cut: set[int] = set(win.cut_words)
    # asal (bina naye cut) ka qaida-score; is aur window ke total ka farq (AI judge, awaaz ki energy)
    # naye score mein bhi rehta hai, taake AI ka rad kiya moment smart cut se "achha" na ban jaye
    old_kept = [w for i, w in enumerate(words[first:last + 1], start=first) if i not in cut]
    old_texts = []
    for s in sentences[win.s_first: win.s_last + 1]:
        part = [words[i] for i in range(s.first, s.last + 1) if i not in cut]
        if part:
            old_texts.append(_sentence_text(part))
    # shuru ke kamzor lafz (zyada se zyada 2)
    k = first
    while k <= min(first + 1, last) and words[k].clean in SAFE_LEAD:     # sirf bharti, jumle ka hissa nahi
        cut.add(k)
        k += 1
    # beech ke khali jumle (shuru / aakhir wale nahi, wo clip ki baat hain)
    for j in range(win.s_first + 1, win.s_last):
        s = sentences[j]
        text = " ".join(w.clean for w in words[s.first:s.last + 1]).strip()
        prev_q = words[sentences[j - 1].last].text.rstrip().endswith("?")
        if text in FILLER_SENTENCES and not prev_q:          # sawal ke foran baad wala jumla jawab hai
            cut.update(range(s.first, s.last + 1))
    kept = [w for i, w in enumerate(words[first:last + 1], start=first) if i not in cut]
    if not kept or len(kept) < 6:
        return None
    # naye cut ke jumle
    texts = []
    for s in sentences[win.s_first: win.s_last + 1]:
        part = [words[i] for i in range(s.first, s.last + 1) if i not in cut]
        if part:
            texts.append(_sentence_text(part))
    paced = _compressed(kept)
    lost = sum(words[i].end - words[i].start for i in cut if first <= i <= last)
    squeeze = (kept[-1].end - kept[0].start) - (paced[-1].end - paced[0].start)
    if win.length - lost - max(0.0, squeeze - (win.duration - win.length)) < min_len:
        return None                                   # minimum length se chhota: nahi
    beeps = len(win.beep_words)
    if not old_kept:
        return None
    rule_old = score_window(old_kept, old_texts, beeps, before=before, better=better).total
    extra = win.score.total - rule_old                    # AI judge / energy ka hissa
    new = score_window(paced, texts, beeps, before=before, better=better)
    total = max(0, min(100, new.total + extra))
    if total <= win.score.total:
        return None
    keep = [r for r in win.score.reasons if r not in new.reasons]
    new = replace(new, total=total, reasons=new.reasons + keep + ["smart cut"])
    return replace(win, score=new, cut_words=sorted(cut), pace="medium")


# ---------------------------------------------------------------------
#  Shuru ki tamheed kaatna (har clip, professional editor ki tarah):
#  "So, um, well ..." jaise 1-2 kamzor pehle lafz hata do taake clip
#  seedha baat se shuru ho. Sirf tab jab lambai minimum se kam na ho.
#  Matlab kabhi nahi badalta (ye lafz koi maana nahi rakhte).
# ---------------------------------------------------------------------
LEAD_ONLY = {"so", "um", "uh", "erm", "well", "okay", "ok", "and", "like", "you", "know"}


def trim_lead(win, words: list[Word], min_len: float):
    first, last = win.w_first, win.w_last
    cut = set(win.cut_words)
    k = first
    while k <= min(first + 1, last - 6) and words[k].clean in LEAD_ONLY:
        if words[k].clean == "you" and not (k + 1 <= last and words[k + 1].clean == "know"):
            break
        cut.add(k)
        if words[k].clean == "you":
            cut.add(k + 1)
            k += 1
        k += 1
    new = cut - set(win.cut_words)
    if not new:
        return None
    lost = (words[max(new)].end - words[min(new)].start) + (words[max(new) + 1].start - words[max(new)].end)
    if win.length - lost < min_len:
        return None
    sc = win.score
    reasons = [r for r in sc.reasons if r != "starts with a linking word"]
    bonus = 3 if len(reasons) < len(sc.reasons) else 1
    return replace(win, cut_words=sorted(cut), lead_cut=sorted(new),
                   score=replace(sc, total=min(100, sc.total + bonus), reasons=reasons + ["tight start"]))


# ---------------------------------------------------------------------
#  Cold open: sab se mazboot line shuru mein
# ---------------------------------------------------------------------
def choose_teaser(win, words: list[Word], sentences, max_len: float, blocked: set[int] | None = None,
                  clean=None, speaker_ok=None):
    """(first, last) lafz index of the teaser line, aur naya score; warna None."""
    blocked = set(blocked or ()) | set(win.beep_words) | set(win.cut_words)
    first_s = sentences[win.s_first]
    opening = [words[i] for i in range(first_s.first, first_s.last + 1) if i not in set(win.cut_words)]
    if not opening:
        return None
    first_text = _sentence_text(opening)                  # smart cut ke baad asal pehli line
    base = hook_points(first_text, opening[0].clean)
    best = None
    punctuated = any(w.ends_sentence for w in words[win.w_first:win.w_last + 1])
    for s in sentences[win.s_first + 1: win.s_last + 1]:
        if punctuated and not s.hard_end:
            continue                                      # poora jumla hi, adhoora khayal kabhi nahi
        if speaker_ok is not None and not speaker_ok(words[s.first].start, words[s.last].end):
            continue                                      # line main person ki ho (screen pe wohi)
        dur = words[s.last].end - words[s.first].start
        if not (TEASER_MIN <= dur <= TEASER_MAX) or not (5 <= s.last - s.first + 1 <= 14):
            continue
        if words[s.first].start - win.start < TEASER_AHEAD or words[s.first].clean in LEAD_TRIM:
            continue
        if any(i in blocked for i in range(s.first, s.last + 1)):
            continue
        text = _sentence_text(words[s.first:s.last + 1])
        if clean is not None and not clean(text):
            continue
        pts = hook_points(text, words[s.first].clean)
        if pts >= max(base + TEASER_GAIN, TEASER_MIN_POINTS) and (best is None or pts > best[0]):
            best = (pts, s.first, s.last, dur)
    if best is None:
        return None
    pts, a, b, dur = best
    if win.length + dur + 0.3 > max_len:
        return None                                   # max length se bahar: nahi
    sc = win.score
    gain = pts - sc.hook
    new = replace(sc, total=max(0, min(100, sc.total + max(0, gain))), hook=max(sc.hook, pts),
                  reasons=sc.reasons + ["cold open"])
    return (a, b), new
