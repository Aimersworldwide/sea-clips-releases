"""
=====================================================================
  SELECT / PLANNER
  Kaam: transcript se clips ki list: moments, cuts, best first tarteeb.
  Turns a transcript into an ordered list of clips to render.
    1. candidate windows  : start at a sentence start, end at a
                            sentence end, length inside the range
    2. filter             : threats / long abuse / too many beeps /
                            sponsor reads and ads -> window dropped
    3. score              : 0..100 (see scoring.py)
    4. moments            : best non-overlapping windows
    5. versions           : same moment, start shifted by >= 3 s
    6. blocks of 50       : a moment appears at most once per block
    7. duplicate check    : skip what was already made from this file
    8. re-edits           : if the video has fewer different moments
                            than asked for, the count is filled with
                            re-edits of the best moments (the edit
                            engine gives each one a new look), so the
                            user always gets the number they asked for
=====================================================================
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace

from app.filters.profanity import analyze
from app.select.scoring import Score, score_window
from app.select.sentences import Sentence, is_punctuated, split_sentences
from app.transcribe.models import Transcript

LEAD_IN = 0.08          # seconds before the first word
TAIL_MAX = 0.6          # let the last line land (reaction beat)
MIN_START_GAP = 3.0     # versions of a moment must start >= 3 s apart
MOMENT_OVERLAP = 0.5    # two different moments may overlap at most 50 %
DUPLICATE_OVERLAP = 0.85
SIMILAR_SHARE = 0.72    # do naye cuts itne (lambe span ka 72 %) mil jayein to ek jaise hain: sirf ek banta hai


@dataclass
class Window:
    s_first: int            # first sentence index
    s_last: int             # last sentence index
    w_first: int            # first word index
    w_last: int             # last word index
    start: float
    end: float
    score: Score
    beep_words: list[int] = field(default_factory=list)   # absolute word indexes
    cut_words: list[int] = field(default_factory=list)    # protection guard: these words are cut out
    check: bool = False                                    # protection guard: unsure -> "Check" folder
    attacks: list[tuple[float, float]] = field(default_factory=list)   # source seconds, no reaction shot of him
    teaser: tuple = ()                                     # cold open: (first, last) word index of the teaser line
    pace: str = ""                                         # smart cut: tighter silence removal ("medium")
    kept: float = 0.0                                      # lambai khamoshi kaatne ke baad (0 = poori)
    lead_cut: list[int] = field(default_factory=list)     # shuru ke kamzor lafz jo kate (zaroorat ho to wapas)

    @property
    def duration(self) -> float:
        return self.end - self.start

    @property
    def length(self) -> float:
        """Clip ki asal lambai (khamoshi kaatne ke baad)."""
        return self.kept or self.duration


@dataclass
class ClipPlan:
    moment_id: str
    version: int
    block: int
    window: Window
    remix: int = 0              # 0 = first edit of this window, n = n-th re-edit
    cut: int = 1                # moment ka kaunsa cut (alag start / end)

    @property
    def tag(self) -> str:
        """M012-C3-E2: moment, cut, edit (file name aur Clips List mein)."""
        return f"{self.moment_id}-C{self.cut}-E{self.remix + 1}"

    @property
    def window_key(self) -> str:
        return window_key(self.window.start, self.window.end)


def window_key(start: float, end: float) -> str:
    return f"{start:.2f}-{end:.2f}"


@dataclass
class PlanResult:
    clips: list[ClipPlan]
    moments: int
    max_good: int               # clips scoring 50+ that this video can give
    dropped: dict[str, int]
    remixed: int = 0            # clips that are re-edits of an earlier moment


def _overlap(a: tuple[float, float], b: tuple[float, float]) -> float:
    """Overlap as a share of the shorter span (0..1)."""
    inter = max(0.0, min(a[1], b[1]) - max(a[0], b[0]))
    shorter = max(1e-6, min(a[1] - a[0], b[1] - b[0]))
    return inter / shorter


def _same_share(a: tuple[float, float], b: tuple[float, float]) -> float:
    """Overlap as a share of the LONGER span: 1.0 only when two clips are nearly the same.
    (A 45 s clip that contains an old 20 s clip is a new clip, not a repeat.)"""
    inter = max(0.0, min(a[1], b[1]) - max(a[0], b[0]))
    longer = max(1e-6, max(a[1] - a[0], b[1] - b[0]))
    return inter / longer


# Sponsor reads and ads inside a video ("go to ziprecruiter.com slash ...", "use promo code").
# A clip of an ad is useless for a campaign and breaks "no external promotions" rules.
AD_RE = __import__("re").compile(
    r"\.com ?(?:slash|/)|(?<![a-z])(?:promo code|use (?:the )?code|coupon code|discount code|brought to you by|"
    r"sponsored by|today's sponsor|our sponsor|free trial|percent off|% off|dot com slash|"
    r"link in (?:the )?description|sign up (?:at|today)|head (?:on )?over to|go to [a-z0-9]+(?:\.| dot )com)"
)


def is_ad(text: str) -> bool:
    """Does this stretch of speech sound like a sponsor read / ad?"""
    return AD_RE.search(text.lower()) is not None


AD_BEFORE, AD_AFTER, AD_JOIN = 0.5, 4.0, 45.0      # seconds around / between ad sentences


def ad_spans(words) -> list[tuple[float, float]]:
    """
    Sponsor reads ka waqt. Jumlon ke hisaab se: jis jumle mein ad wala
    jumla (".com slash", promo code ...) ya sponsor ka naam (".com" se
    pehle wala lafz, jaise "ZipRecruiter") ho, wo ad hai. Paas paas ke ad
    jumle (45 s tak) ek ad. Pehle 30 second andha dhund kaatne se show
    ke behtareen hisse (ad se pehle / outro se pehle) zaya ho jaate the.
    """
    import re
    if not words:
        return []
    from app.select.sentences import split_sentences
    sents = split_sentences(words)
    texts = [" ".join(w.text for w in words[x.first:x.last + 1]).lower() for x in sents]
    brands: set[str] = set()
    for t in texts:
        for m in re.finditer(r"([a-z0-9]{4,})\s?\.com", t):
            brands.add(m.group(1))
    brand_re = re.compile(r"(?<![a-z0-9])(?:" + "|".join(sorted(map(re.escape, brands))) + r")(?![a-z0-9])") \
        if brands else None
    hits = [k for k, t in enumerate(texts) if AD_RE.search(t) or (brand_re is not None and brand_re.search(t))]
    # ad se pehle ke bechne wale jumle ("They help you find ...", "your company") bhi ad, 20 s tak
    pitch = re.compile(r"(?<![a-z])(?:help(?:s)? you|you need|your (?:business|company|team|home|family)|"
                       r"our company|sponsor|try (?:it|them)|for free|save \d|discount|special offer|hiring)")
    lead: list[int] = []
    for k in hits:
        j = k - 1
        while j >= 0 and pitch.search(texts[j]) and words[sents[k].first].start - words[sents[j].first].start <= 20:
            lead.append(j)
            j -= 1
    hits = sorted(set(hits) | set(lead))
    spans: list[list[float]] = []
    for k in hits:
        a, b = words[sents[k].first].start, words[sents[k].last].end
        if spans and a - spans[-1][1] <= AD_JOIN:
            spans[-1][1] = max(spans[-1][1], b)
        else:
            spans.append([a, b])
    return [(a - AD_BEFORE, b + AD_AFTER) for a, b in spans]


def topic_matcher(topics: list[str]):
    """
    One regex for every "never mention" item. A person's surname alone
    counts too ("Trump" for "Donald Trump") when it is 5+ letters, since
    speakers rarely use full names. Better to skip a clip than break a
    campaign rule.
    """
    import re
    terms: set[str] = set()
    for topic in topics:
        clean = re.sub(r"[^a-z0-9' ]+", " ", topic.lower()).split()
        if not clean:
            continue
        terms.add(" ".join(clean))
        if 2 <= len(clean) <= 3 and topic[:1].isupper() and len(clean[-1]) >= 5:
            terms.add(clean[-1])
    if not terms:
        return None
    alts = "|".join(re.escape(t).replace(r"\ ", r"\s+") for t in sorted(terms, key=len, reverse=True))
    return re.compile(rf"(?<![a-z0-9])(?:{alts})(?![a-z0-9])")


# ---------------------------------------------------------------------
#  Poori baat (campaign switch "complete_point")
#  Kaam: clip ek nayi baat se shuru ho aur baat poori ho kar khatam ho:
#    * shuru ka jumla "And / But / So / Because / That's why ..." se nahi
#      (ye pichli baat ka hissa hai, akela samajh nahi aata)
#    * aakhri jumla sawal (?) nahi, adhoora nahi ("and", "the", ":")
#    * agla jumla "But / However / Except ..." se shuru ho to baat abhi
#      chal rahi hai: wahan khatam nahi
# ---------------------------------------------------------------------
_OPEN_BAD = {"and", "but", "because", "cause", "cuz", "or", "also", "plus", "then", "which", "whereas",
             "although", "though", "therefore", "hence", "thus", "anyway", "otherwise", "meanwhile", "nor"}
_OPEN_BAD_PHRASES = ("that's why", "thats why", "which is why", "that is why", "this is why", "like i said",
                     "as i said", "as i was saying", "like i was saying", "that's the", "that means", "on top of that",
                     "in addition", "not only that", "and so", "so then", "in other words", "same thing")
_END_BAD = {"and", "but", "so", "or", "because", "the", "a", "an", "to", "of", "for", "with", "that", "is", "are",
            "was", "if", "when", "like", "my", "your", "his", "her", "their", "our", "i", "we", "you", "they"}
_CONTINUES = {"but", "however", "except", "although", "though", "yet", "secondly", "also", "plus"}


def _words_of(text: str) -> list[str]:
    import re
    return [w for w in re.split(r"[^a-z0-9']+", (text or "").lower()) if w]


def opens_point(sentence_text: str) -> bool:
    """Ye jumla nayi baat shuru kar sakta hai? (pichli baat ka jor nahi)"""
    ws = _words_of(sentence_text)
    if not ws:
        return False
    if ws[0] in _OPEN_BAD:
        return False
    head = " ".join(ws[:5])
    return not any(head.startswith(ph) for ph in _OPEN_BAD_PHRASES)


def closes_point(sentence_text: str, next_text: str = "") -> bool:
    """Is jumle pe baat poori hoti hai? (sawal / adhoora nahi, aur agla jumla isi baat ko aage na badhaye)"""
    t = (sentence_text or "").strip()
    if not t or t.endswith("?") or t.endswith(":") or t.endswith(",") or t.endswith("..."):
        return False
    ws = _words_of(t)
    if not ws or ws[-1] in _END_BAD:
        return False
    nxt = _words_of(next_text)
    return not (nxt and nxt[0] in _CONTINUES)


def candidate_windows(
    transcript: Transcript,
    min_len: float,
    max_len: float,
    profanity_level: str = "standard",
    banned_words: list[str] | None = None,
    vip_names: list[str] | None = None,
    max_beeps: int = 3,
    energy=None,
    avoid_topics: list[str] | None = None,
    better: bool = False,
    window_filter=None,
    guard=None,
    silence_level: str = "off",
    quiet: list[tuple[float, float]] | None = None,
    beep_mode: str = "beep",
    keep_ads: bool = False,
    avoid_spans: list[tuple[float, float]] | None = None,
    complete_point: bool = False,
) -> tuple[list[Window], dict[str, int]]:
    from app.render.timeline import build_segments, gap_savings, total_duration
    words = transcript.words
    saved = gap_savings(words, silence_level)        # lambai khamoshi kaatne ke baad
    avoid = topic_matcher(avoid_topics or [])
    sentences: list[Sentence] = split_sentences(words)
    out: list[Window] = []
    dropped: dict[str, int] = {}

    strict = is_punctuated(words)    # clip edges only at . ? ! when punctuated
    ads = [] if keep_ads else ad_spans(words)      # keep_ads: videos campaign ke apne ads hain (kuch na kaato)
    for i in range(len(sentences)):
        if strict and i > 0 and not sentences[i - 1].hard_end:
            continue                     # would start in the middle of a sentence
        if complete_point and not opens_point(sentences[i].text):
            dropped["not_full_point"] = dropped.get("not_full_point", 0) + 1
            continue                     # pichli baat ka hissa ("And / But / That's why ...")
        for j in range(i, len(sentences)):
            s0, s1 = sentences[i], sentences[j]
            # Lead-in never reaches back into the previous word.
            prev_end = words[s0.first - 1].end if s0.first > 0 else 0.0
            lead = min(LEAD_IN, max(0.0, (s0.start - prev_end) / 2))
            start = max(0.0, s0.start - lead)
            next_start = sentences[j + 1].start if j + 1 < len(sentences) else s1.end + TAIL_MAX
            end = min(s1.end + TAIL_MAX, max(s1.end, next_start - 0.05))
            duration = end - start - (saved[s1.last] - saved[s0.first])
            if duration > max_len:
                if not (quiet and silence_level != "off"):
                    break
                # andaza lamba hai, magar awaaz wali khamoshi kat kar shayad fit ho: pakka naapo
                exact = total_duration(build_segments(words[s0.first:s1.last + 1], start, end, silence_level,
                                                      quiet=quiet, cut_word_indexes=None))
                if exact > max_len:
                    break
            if quiet and silence_level != "off" and duration >= min_len - 0.1:
                # pakki lambai: awaaz wali khamoshi (lafz ke andar) bhi kat ti hai, wohi hisaab jo render karta hai
                duration = total_duration(build_segments(words[s0.first:s1.last + 1], start, end, silence_level,
                                                         quiet=quiet))
            if duration < min_len + LEN_MARGIN:
                continue                 # thori gunjaish: lafz ke andar ki khamoshi bhi kat ti hai
            if strict and not s1.hard_end:
                continue                 # would end in the middle of a sentence
            if complete_point and not closes_point(s1.text, sentences[j + 1].text if j + 1 < len(sentences) else ""):
                continue                 # baat abhi poori nahi (sawal, adhoora, ya agla jumla "But ...")
            seg_words = words[s0.first: s1.last + 1]
            if any(start < b and end > a for a, b in ads):
                dropped["sponsor_ad"] = dropped.get("sponsor_ad", 0) + 1
                continue
            if avoid_spans and any(start < b and end > a for a, b in avoid_spans):
                dropped["topic_negative"] = dropped.get("topic_negative", 0) + 1     # campaign ke topic ke khilaf
                continue
            if avoid is not None and avoid.search(" ".join(w.clean for w in seg_words)):
                dropped["banned_topic"] = dropped.get("banned_topic", 0) + 1
                continue
            if window_filter is not None and not window_filter(start, end, seg_words):
                dropped["main_person"] = dropped.get("main_person", 0) + 1
                continue
            verdict = analyze(seg_words, profanity_level, banned_words, vip_names, max_beeps)
            if verdict.skip:
                dropped[verdict.reason] = dropped.get(verdict.reason, 0) + 1
                continue
            # Main person protection guard: beep / cut / skip (filters/guard.py)
            g_beep: list[int] = []
            g_cut: list[int] = []
            g_check, g_attacks = False, []
            if guard is not None:
                rel = [(s.first - s0.first, s.last - s0.first) for s in sentences[i:j + 1]]
                g = guard.check(seg_words, rel)
                if g.skip:
                    dropped[g.reason] = dropped.get(g.reason, 0) + 1
                    continue
                g_beep, g_cut, g_check, g_attacks = g.beep, g.cut, g.check, g.attacks
            gone = set(g_cut) | (set(verdict.beep_indexes) if beep_mode == "cut" else set())
            if gone and silence_level != "off":
                # kate hue hamle / gaaliyon ke baad bhi clip poora lamba ho (warna khamoshi chhorni padti)
                left = total_duration(build_segments(seg_words, start, end, silence_level,
                                                     cut_word_indexes=gone, quiet=quiet))
                if left < min_len + LEN_MARGIN:
                    dropped["cut_short"] = dropped.get("cut_short", 0) + 1
                    continue
                duration = left
            score = score_window(seg_words, [s.text for s in sentences[i:j + 1]], verdict.beep_count,
                                 energy=energy(start, end) if energy else None,
                                 before=sentences[i - 1].text if i > 0 else "", better=better)
            out.append(Window(
                s_first=i, s_last=j, w_first=s0.first, w_last=s1.last,
                start=round(start, 3), end=round(end, 3), score=score, kept=round(duration, 3),
                beep_words=sorted({s0.first + k for k in verdict.beep_indexes + g_beep}),
                cut_words=[s0.first + k for k in g_cut], check=g_check, attacks=g_attacks,
            ))
    return out, dropped


# ---------------------------------------------------------------------
#  Ek moment ke kitne cuts (alag start / end): mazboot moment = zyada
#  75+ : 6 cuts, 60+ : 5, 50+ : 4, baaki : 3  (setting is se zyada ho to wo)
# ---------------------------------------------------------------------
def cuts_for(score: int, cap: int) -> int:
    n = 6 if score >= 75 else 5 if score >= 60 else 4 if score >= 50 else 3
    if cap < 3:
        return max(1, min(n, cap))          # user ne kam maange
    return cap if cap > 6 else n


def _moments_and_versions(ranked: list[Window], versions_per_moment: int,
                          dynamic: bool = False) -> tuple[dict[int, list[Window]], list[Window]]:
    # --- moments: best windows that do not overlap each other much ---
    moments: list[Window] = []
    for w in ranked:
        if all(_overlap((w.start, w.end), (m.start, m.end)) < MOMENT_OVERLAP for m in moments):
            moments.append(w)

    # --- versions of each moment -------------------------------------
    versions: dict[int, list[Window]] = {}
    every: list[Window] = list(moments)          # saare moments ke saare cuts (do moments ka ek jaisa cut nahi)
    for idx, m in enumerate(moments):
        chosen = [m]
        limit = cuts_for(m.score.total, versions_per_moment) if dynamic else max(1, versions_per_moment)
        for w in ranked:
            if len(chosen) >= limit:
                break
            if w is m or _overlap((w.start, w.end), (m.start, m.end)) < 0.5:
                continue
            # Versions must belong to THIS moment more than to any other.
            owner = max(range(len(moments)), key=lambda k: _overlap((w.start, w.end), (moments[k].start, moments[k].end)))
            if owner != idx:
                continue
            if all(abs(w.start - c.start) >= MIN_START_GAP for c in chosen) and \
                    all((abs(w.start - c.start) >= MIN_START_GAP or abs(w.end - c.end) >= MIN_START_GAP)
                        and _same_share((w.start, w.end), (c.start, c.end)) < SIMILAR_SHARE for c in every):
                chosen.append(w)
                every.append(w)
        versions[idx] = chosen
    return versions, moments


LEN_MARGIN = 0.3         # clip finder: minimum se thora lamba (render ke hisaab ki chhoti ghalti ki gunjaish)
RERANK_TOP = 30          # best moments shown to the AI judge
RERANK_WEIGHT = 3        # points per step away from 5 on its 0..10 scale (max +/- 15)


def apply_viral(windows: list[Window], transcript: Transcript, make_scorer) -> list[Window]:
    """
    Viral se seekhna: har moment ko main person ki asal viral shorts ki
    baat se milao (research/match.py). Jo baat asal mein viral hui thi us
    jaisa moment +8 tak. Koi masla ho to score wahi rehta hai.
    """
    from dataclasses import replace
    try:
        scorer = make_scorer([s.text for s in split_sentences(transcript.words)])
        if not getattr(scorer, "ok", False):
            return windows
        out = []
        for w in windows:
            pts, why = scorer.bonus(w.s_first, w.s_last)
            if pts:
                sc = replace(w.score, total=max(0, min(100, w.score.total + pts)),
                             reasons=w.score.reasons + [f"{why} +{pts}"])
                w = replace(w, score=sc)
            out.append(w)
        return out
    except Exception:  # noqa: BLE001 - bonus hai, zaroorat nahi
        return windows


def apply_rerank(windows: list[Window], transcript: Transcript, rerank) -> list[Window]:
    """
    Better moments, optional AI step: the best moments (text only) go to
    `rerank(texts) -> {index: (0..10, reason)}`. Each window takes the
    verdict of the moment it belongs to. Any failure keeps the rule score.
    """
    from dataclasses import replace
    ranked = sorted(windows, key=lambda w: (-w.score.total, w.start))
    _, moments = _moments_and_versions(ranked, 1)
    moments = moments[:RERANK_TOP]
    words = transcript.words
    texts = [" ".join(w.text for w in words[m.w_first:m.w_last + 1])[:1200] for m in moments]
    try:
        verdict = rerank(texts) or {}
    except Exception:  # noqa: BLE001 - the AI step is a bonus, never a requirement
        return windows
    if not verdict:
        return windows
    out = []
    for w in windows:
        owner = max(range(len(moments)), key=lambda k: _overlap((w.start, w.end), (moments[k].start, moments[k].end)))
        if owner in verdict and _overlap((w.start, w.end), (moments[owner].start, moments[owner].end)) >= 0.5:
            value, why = verdict[owner]
            delta = int(round((max(0.0, min(10.0, value)) - 5) * RERANK_WEIGHT))
            sc = replace(w.score, total=max(0, min(100, w.score.total + delta)),
                         reasons=w.score.reasons + [f"AI {value:g}/10" + (f": {why}" if why else "")])
            w = replace(w, score=sc)
        out.append(w)
    return out


# ---------------------------------------------------------------------
#  AI guard judge (optional, Gemini): "kya ye moment main person ko
#  bura dikhata hai?" Haan = us moment ki saari windows hata do.
#  Koi bhi ghalti (internet nahi) = sirf qaide chalte hain.
# ---------------------------------------------------------------------
def apply_guard_judge(windows: list[Window], transcript: Transcript, judge, dropped: dict[str, int]) -> list[Window]:
    ranked = sorted(windows, key=lambda w: (-w.score.total, w.start))
    _, moments = _moments_and_versions(ranked, 1)
    moments = moments[:RERANK_TOP]
    words = transcript.words
    texts = [" ".join(w.text for w in words[m.w_first:m.w_last + 1])[:1200] for m in moments]
    try:
        risky = set(judge(texts) or [])
    except Exception:  # noqa: BLE001 - bonus step only
        return windows
    if not risky:
        return windows
    out = []
    for w in windows:
        owner = max(range(len(moments)), key=lambda k: _overlap((w.start, w.end), (moments[k].start, moments[k].end)))
        if owner in risky and _overlap((w.start, w.end), (moments[owner].start, moments[owner].end)) >= 0.5:
            dropped["guard_ai"] = dropped.get("guard_ai", 0) + 1
            continue
        out.append(w)
    return out


# ---------------------------------------------------------------------
#  Cuts behtar karo: kamzor (<50) ko smart cut, phir cold open line
# ---------------------------------------------------------------------
def improve_cuts(windows: list[Window], transcript: Transcript, min_len: float, max_len: float,
                 smart: bool, cold: bool, clean=None, better: bool = False, speaker_ok=None) -> list[Window]:
    from app.select.smart_cuts import choose_teaser, rescue, trim_lead
    words = transcript.words
    sentences = split_sentences(words)
    out = []
    for w in windows:
        if smart:
            w = trim_lead(w, words, min_len) or w             # har clip: shuru ki tamheed nahi
        if smart and w.score.total < 50:
            before = sentences[w.s_first - 1].text if w.s_first > 0 else ""
            w = rescue(w, words, sentences, min_len, before=before, better=better) or w
        if cold:
            got = choose_teaser(w, words, sentences, max_len, clean=clean, speaker_ok=speaker_ok)
            if got is not None:
                (a, b), sc = got
                w = replace(w, teaser=(a, b), score=sc)
        out.append(w)
    return out


def plan_clips(
    transcript: Transcript,
    min_len: float,
    max_len: float,
    clip_count: int,
    versions_per_moment: int = 4,
    block_size: int = 50,
    used_windows: list[tuple[float, float]] | None = None,
    profanity_level: str = "standard",
    banned_words: list[str] | None = None,
    vip_names: list[str] | None = None,
    max_beeps: int = 3,
    allow_remix: bool = True,
    energy=None,
    avoid_topics: list[str] | None = None,
    better: bool = False,
    rerank=None,
    window_filter=None,
    guard=None,
    guard_judge=None,
    dynamic_cuts: bool = False,
    smart_cuts: bool = True,
    cold_open: bool = False,
    teaser_clean=None,
    per_moment_cap: int = 0,
    teaser_speaker=None,
    silence_level: str = "off",
    quiet: list[tuple[float, float]] | None = None,
    beep_mode: str = "beep",
    viral=None,
    keep_ads: bool = False,
    avoid_spans: list[tuple[float, float]] | None = None,
    complete_point: bool = False,
) -> PlanResult:
    windows, dropped = candidate_windows(
        transcript, min_len, max_len, profanity_level, banned_words, vip_names, max_beeps, energy=energy,
        avoid_topics=avoid_topics, better=better, window_filter=window_filter, guard=guard,
        silence_level=silence_level, quiet=quiet, beep_mode=beep_mode, keep_ads=keep_ads, avoid_spans=avoid_spans,
        complete_point=complete_point)
    if not windows and silence_level != "off":
        # bohot kam bolne wali video (khamoshi kaat kar koi clip poora nahi banta): bina kaate dhoondo
        windows, dropped = candidate_windows(
            transcript, min_len, max_len, profanity_level, banned_words, vip_names, max_beeps, energy=energy,
            avoid_topics=avoid_topics, better=better, window_filter=window_filter, guard=guard,
            silence_level="off", keep_ads=keep_ads, avoid_spans=avoid_spans, complete_point=complete_point)
    if not windows and complete_point:
        # "poori baat" ke saath ek bhi clip nahi bana (bohot chhoti / tooti video): bina is shart ke
        windows, dropped = candidate_windows(
            transcript, min_len, max_len, profanity_level, banned_words, vip_names, max_beeps, energy=energy,
            avoid_topics=avoid_topics, better=better, window_filter=window_filter, guard=guard,
            silence_level=silence_level, quiet=quiet, beep_mode=beep_mode, keep_ads=keep_ads, avoid_spans=avoid_spans)
        dropped["full_point_relaxed"] = 1
    if guard_judge is not None and windows:
        windows = apply_guard_judge(windows, transcript, guard_judge, dropped)
    if better and rerank is not None and windows:
        windows = apply_rerank(windows, transcript, rerank)
    if viral is not None and windows:
        windows = apply_viral(windows, transcript, viral)
    # Smart cuts (sirf 50 se kam wale) aur cold open (setting) - select/smart_cuts.py
    if windows and (smart_cuts or cold_open):
        windows = improve_cuts(windows, transcript, min_len, max_len, smart_cuts, cold_open, teaser_clean, better,
                               speaker_ok=teaser_speaker)

    # Duplicate check against clips already made from this same file.
    used = used_windows or []
    # naya cut pichle bane clips se saaf alag ho (phase 2 ka cut phase 1 jaisa na ho)
    fresh = [w for w in windows if all(_same_share((w.start, w.end), u) < SIMILAR_SHARE for u in used)]
    if len(fresh) < len(windows):
        dropped["already_made"] = len(windows) - len(fresh)
    ranked = sorted(fresh, key=lambda w: (-w.score.total, w.start))

    versions, moments = _moments_and_versions(ranked, versions_per_moment, dynamic=dynamic_cuts)
    max_good = sum(1 for vs in versions.values() for w in vs if w.score.total >= 50)

    # --- tarteeb (user ka faisla, 24 Oct): ---------------------------
    #  daur 1: har moment ka pehla cut (C1), achhe score wale pehle
    #  daur 2: har moment ka doosra cut (C2), daur 3: C3 ...
    #  phir re-edits (naye edit), daur ba daur
    #  Har daur ke andar score ke hisaab se (best first).
    # moment ke number SAARI windows ki ek hi list se (naye cuts aur re-edits dono ke liye),
    # taake doosri dafa chalne pe bhi re-edit apne asal moment ka number le
    all_ranked = sorted(windows, key=lambda w: (-w.score.total, w.start))
    _, all_moments = _moments_and_versions(all_ranked, versions_per_moment)
    label: dict[int, int] = {}
    taken_ids: set[int] = set()
    for k, m in enumerate(moments):
        best = max(range(len(all_moments)), default=-1,
                   key=lambda j: _overlap((m.start, m.end), (all_moments[j].start, all_moments[j].end)))
        if best < 0 or best in taken_ids or _overlap((m.start, m.end),
                                                     (all_moments[best].start, all_moments[best].end)) <= 0:
            best = len(all_moments) + k                       # koi saaf jori nahi: apna alag number
        label[k] = best
        taken_ids.add(best)
    # pichle runs (phase 1) mein is moment ke kitne cuts ban chuke: naye cut ka number un ke baad (C3, C4...)
    prior: dict[int, int] = {}
    for a, b in {window_key(a, b): (a, b) for a, b in used}.values():
        if not all_moments:
            break
        j = max(range(len(all_moments)),
                key=lambda k: _overlap((a, b), (all_moments[k].start, all_moments[k].end)))
        if _overlap((a, b), (all_moments[j].start, all_moments[j].end)) >= 0.5:
            prior[j] = prior.get(j, 0) + 1
    fresh: list[tuple[int, int, int, float, int, int, Window]] = []
    for k, vs in versions.items():
        for n, w in enumerate(vs):
            fresh.append((n, 0, -w.score.total, w.start, label[k], prior.get(label[k], 0) + n + 1, w))
    fresh.sort(key=lambda x: x[:4])
    order: list[tuple[int, str, int, Window, int]] = []     # (tier, moment_id, version, window, remix)
    for tier, _, _, _, k, n, w in fresh:
        order.append((tier, f"M{k + 1:03d}", n, w, 0))

    if len(order) < clip_count and allow_remix:
        # re-edit ke liye windows: is run ke naye cuts, phir baaki windows jo un sab se saaf alag hon
        # (pichle phase ke clip jaisi window us clip ka re-edit banti hai, naya "ek jaisa" cut nahi)
        chosen: list[Window] = [w for vs in versions.values() for w in vs]
        for w in all_ranked:
            if all(_same_share((w.start, w.end), (c.start, c.end)) < SIMILAR_SHARE for c in chosen):
                chosen.append(w)
        good_pool, weak_pool = [], []
        for w in chosen:
            owner = max(range(len(all_moments)),
                        key=lambda k: _overlap((w.start, w.end), (all_moments[k].start, all_moments[k].end)))
            (good_pool if w.score.total >= 50 else weak_pool).append((owner, w))
        fresh_per_label: dict[int, int] = {}
        for k, vs in versions.items():
            fresh_per_label[label[k]] = fresh_per_label.get(label[k], 0) + len(vs)
        need = clip_count - len(order)
        extra: list[tuple[int, int, int, str, int, Window, int]] = []
        for tier, pool in ((100, good_pool), (200, weak_pool)):      # saare naye cuts ke baad
            rounds = 0
            while pool and len(extra) < need:
                rounds += 1
                for k, win in pool:
                    extra.append((tier, rounds, -win.score.total, f"M{k + 1:03d}", 0, win, 1))
        extra.sort(key=lambda x: x[:3])
        for tier, _, _, mid, _, win, _ in extra:
            order.append((tier, mid, 0, win, 1))
        order.sort(key=lambda x: x[0])                          # stable: andar ki tarteeb wahi
        # har window ka re-edit number, tarteeb ke mutabiq: pehle bane (pichle runs + is run) milte julte
        # clips gine jaate hain. Jo window kisi bane clip jaisi nahi, woh naya cut hai (re-edit nahi).
        run_wins: list[tuple[float, float]] = []
        new_cuts: dict[int, int] = {}
        renum = []
        for tier, mid, version, win, n in order:
            span = (win.start, win.end)
            if n:
                k2 = sum(1 for u in used if _same_share(span, u) >= SIMILAR_SHARE) + \
                    sum(1 for r in run_wins if _same_share(span, r) >= SIMILAR_SHARE)
                if k2:
                    renum.append((tier, mid, k2 + 1, win, k2))
                else:
                    lab = int(mid[1:]) - 1
                    new_cuts[lab] = new_cuts.get(lab, 0) + 1
                    v = prior.get(lab, 0) + fresh_per_label.get(lab, 0) + new_cuts[lab]
                    renum.append((tier, mid, v, win, 0))
            else:
                renum.append((tier, mid, version, win, 0))
            run_wins.append(span)
        order = renum
    if per_moment_cap > 0:
        # (16 Nov, user) ek moment ke kul clips (naye cuts + re-edits, pichle runs bhi) is had tak
        made: dict[int, int] = {}                 # pichle bane clips (har clip gina, re-edit bhi)
        for a, b in used:
            if all_moments:
                j = max(range(len(all_moments)),
                        key=lambda k: _overlap((a, b), (all_moments[k].start, all_moments[k].end)))
                if _overlap((a, b), (all_moments[j].start, all_moments[j].end)) >= 0.5:
                    made[j] = made.get(j, 0) + 1
        seen: dict[str, int] = {}
        capped = []
        for item in order:
            mid = item[1]
            base = made.get(int(mid[1:]) - 1, 0) if mid[1:].isdigit() else 0
            if base + seen.get(mid, 0) >= per_moment_cap:
                continue
            seen[mid] = seen.get(mid, 0) + 1
            capped.append(item)
        if len(capped) < len(order):
            dropped["per_moment_cap"] = len(order) - len(capped)
        order = capped
    order = order[:clip_count] if not allow_remix or len(order) > clip_count else order

    # --- blocks: har block mein ek moment ek hi dafa (agar ho sake) ---
    plans: list[ClipPlan] = []
    block, current = 1, set()
    # pehle saare naye cuts, phir re-edits: block ka qaida dono ke andar alag alag
    fresh_items = [it for it in order if not it[4]]
    reedit_items = [it for it in order if it[4]]
    for waiting in (fresh_items, reedit_items):
        while waiting and len(plans) < clip_count:
            later = []
            placed = False
            for item in waiting:
                if len(plans) >= clip_count:
                    break
                tier, mid, version, win, n = item
                if mid in current or len(current) >= block_size:
                    later.append(item)
                    continue
                plans.append(ClipPlan(moment_id=mid, version=version, block=block, window=win, remix=n))
                current.add(mid)
                placed = True
            waiting = later
            if waiting:
                block, current = block + 1, set()
            if not placed and not waiting:
                break
    # har moment ke cuts ko number do (pehli dafa nazar aane ki tarteeb mein). Pichle runs (phase 1)
    # ke cuts bhi gine jaate hain: phase 2 ka naya cut C3 kehlata hai, aur pichle cut jaisa clip
    # usi cut ka re-edit (M002-C1-E2), taake koi label dobara na aaye.
    clusters: list[list] = []          # [moment, span, cut number, kitne clips is cut ke ban chuke]
    per_moment: dict[str, int] = {}

    def best_cluster(span: tuple[float, float]):
        best, share = None, 0.0
        for c in clusters:
            sh = 1.0 if c[1] == span else _same_share(span, c[1])
            if sh >= SIMILAR_SHARE and sh > share:
                best, share = c, sh
        return best

    for a, b in used:                  # banne ki tarteeb mein (db: ORDER BY id)
        hit = best_cluster((a, b))
        if hit is not None:
            hit[3] += 1
            continue
        if not all_moments:
            continue
        j = max(range(len(all_moments)), key=lambda k: _overlap((a, b), (all_moments[k].start, all_moments[k].end)))
        if _overlap((a, b), (all_moments[j].start, all_moments[j].end)) < 0.5:
            continue
        mid = f"M{j + 1:03d}"
        per_moment[mid] = per_moment.get(mid, 0) + 1
        clusters.append([mid, (a, b), per_moment[mid], 1])
    for cp in plans:
        span = (cp.window.start, cp.window.end)
        hit = best_cluster(span) if cp.remix else next((c for c in clusters if c[1] == span), None)
        if hit is None:
            per_moment[cp.moment_id] = per_moment.get(cp.moment_id, 0) + 1
            hit = [cp.moment_id, span, per_moment[cp.moment_id], 0]
            clusters.append(hit)
        cp.moment_id, cp.cut = hit[0], hit[2]
        if cp.remix:
            cp.remix = max(1, hit[3])          # E number = is cut ke pehle bane clips + 1
        hit[3] += 1
    remixed = sum(1 for cp in plans if cp.remix)

    return PlanResult(clips=plans, moments=len(moments), max_good=max_good, dropped=dropped, remixed=remixed)
