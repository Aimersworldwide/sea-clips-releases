"""
=====================================================================
  SELECT / SENTENCES
  Kaam: lafzon ko jumlon mein todna (clip kabhi beech jumle mein na kate).
  Splits the word list into sentences. A clip may only start at a
  sentence start and end at a sentence end, which is how we guarantee
  "never cut the speaker mid-thought".
  A sentence ends at . ? ! or at a long pause (> 0.9 s).
  Only "hard" ends (. ? ! or the end of the video) may be a clip edge
  when the transcript is punctuated (Whisper English always is).
  Pause-only ends are used as clip edges only for transcripts with
  almost no punctuation.
=====================================================================
"""
from __future__ import annotations

from dataclasses import dataclass

from app.transcribe.models import Word

PAUSE_BREAK = 0.9          # seconds of silence that also ends a sentence
MAX_SENTENCE_WORDS = 45    # very long run-ons are split at the longest pause (in the middle)


@dataclass
class Sentence:
    first: int      # index of first word
    last: int       # index of last word (inclusive)
    start: float
    end: float
    text: str
    hard_end: bool = True    # ends with . ? ! (or at the end of the video)

    @property
    def duration(self) -> float:
        return self.end - self.start


def split_sentences(words: list[Word]) -> list[Sentence]:
    sentences: list[Sentence] = []
    if not words:
        return sentences
    begin = 0
    for i, w in enumerate(words):
        nxt = words[i + 1] if i + 1 < len(words) else None
        gap = (nxt.start - w.end) if nxt else 99.0
        too_long = (i - begin + 1) >= MAX_SENTENCE_WORDS
        if w.ends_sentence or gap > PAUSE_BREAK or nxt is None or too_long:
            if too_long and not w.ends_sentence and gap <= PAUSE_BREAK:
                # Lamba bina-nuqte ka hissa (speech model kabhi punctuation chhor deta hai): sab se
                # lambe waqfe pe todo, magar beech mein (dono taraf kam az kam 12 lafz), taake ek
                # ek lafz ke "jumle" na banein. Lamba waqfa (0.3 s+) asli jumle ka khatma maana jaata hai.
                lo, hi = begin + 11, i - 12
                rng = range(lo, hi + 1) if hi >= lo else range(begin, i)
                cut = max(rng, key=lambda k: words[k + 1].start - words[k].end)
                pause = words[cut + 1].start - words[cut].end
                sentences.append(_make(words, begin, cut, soft_hard=pause >= 0.45))
                begin = cut + 1
                continue
            # bina nuqte ka hissa lambe waqfe (0.9 s+) pe khatam: wo bhi jumle ka khatma
            unpunct = gap > PAUSE_BREAK and i - begin >= 5 and not any(x.ends_sentence for x in words[begin:i + 1])
            sentences.append(_make(words, begin, i, soft_hard=unpunct))
            begin = i + 1
    if begin < len(words):
        sentences.append(_make(words, begin, len(words) - 1))
    return sentences


def _make(words: list[Word], a: int, b: int, soft_hard: bool = False) -> Sentence:
    # comma pe khatam hissa kabhi clip ka kinara nahi (baat abhi jaari hai)
    soft_hard = soft_hard and not words[b].text.rstrip().endswith((",", ";", ":", "-"))
    return Sentence(first=a, last=b, start=words[a].start, end=words[b].end,
                    text=" ".join(w.text for w in words[a:b + 1]),
                    hard_end=words[b].ends_sentence or b == len(words) - 1 or soft_hard)


def is_punctuated(words: list[Word]) -> bool:
    """At least one . ? ! per 40 words on average."""
    if not words:
        return False
    ends = sum(1 for w in words if w.ends_sentence)
    return ends * 40 >= len(words)
