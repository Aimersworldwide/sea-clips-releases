"""
=====================================================================
  CAPTIONS / BUILDER  (words -> animated .ass subtitle file)
  Kaam: lafzon se chalte hue captions (.ass file) aur hook line banana.
  Rules (from research):
    * max 2 lines, line width measured in real pixels
    * captions appear 0.1 s before the word is heard (pro standard)
    * one highlighted (spoken) word at a time
    * break at sentence ends, commas and pauses; no orphan words
    * hide captions during silence (> 0.6 s)
    * stay inside the safe zone: away from the right button rail
      and the bottom title area
    * beeped words are shown masked (f***)
  Animations (all short and smooth):
    rise   - line rises 12 px and fades in over 140 ms (ease out)
    fade   - 120 ms fade in
    pop    - spoken word 96% -> 104% -> 100% over 150 ms
    tint   - spoken word colour crossfade in 70 ms
    out    - 90 ms fade out when a pause follows
=====================================================================
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from dataclasses import replace

from app.captions.fonts import em_to_ass, text_width
from app.captions.styles import SPEAKER_B_COLOR, CaptionStyle, scaled_for
from app.filters.profanity import mask_word
from app.transcribe.models import Word

LEAD = 0.10           # captions show this much before the word
GAP_HIDE = 0.60       # silence longer than this hides captions
MIN_SCREEN = 0.70     # a caption screen stays at least this long
PAUSE_BREAK = 0.35    # a pause this long starts a new caption screen


# ---------------------------------------------------------------------
#  Small helpers
# ---------------------------------------------------------------------
def ass_color(hex_rgb: str, alpha: float = 0.0) -> str:
    """'#RRGGBB' + alpha (0 solid .. 1 clear) -> ASS '&HAABBGGRR'."""
    h = hex_rgb.lstrip("#")
    r, g, b = h[0:2], h[2:4], h[4:6]
    a = f"{max(0, min(255, round(alpha * 255))):02X}"
    return f"&H{a}{b}{g}{r}".upper()


def tag_color(hex_rgb: str) -> str:
    """'#RRGGBB' -> override-tag colour '&HBBGGRR&' (alpha is set separately)."""
    h = hex_rgb.lstrip("#")
    return f"&H{h[4:6]}{h[2:4]}{h[0:2]}&".upper()


def ass_time(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def apply_case(text: str, case: str) -> str:
    if case == "upper":
        return text.upper()
    if case == "lower":
        return text.lower()
    # sentence case: speech model kabhi "i" / "i'm" chhota likh deta hai
    low = text.lower()
    if text[:1] == "i" and (low.rstrip(".,!?;:") == "i" or low.startswith(("i'm", "i'll", "i've", "i'd"))):
        return "I" + text[1:]
    return text


def rounded_rect(w: float, h: float, r: float) -> str:
    """ASS vector drawing of a rounded rectangle at (0,0)."""
    r = min(r, h / 2, w / 2)
    k = r * 0.45  # bezier handle
    return (f"m {r:.1f} 0 l {w - r:.1f} 0 b {w - k:.1f} 0 {w:.1f} {k:.1f} {w:.1f} {r:.1f} "
            f"l {w:.1f} {h - r:.1f} b {w:.1f} {h - k:.1f} {w - k:.1f} {h:.1f} {w - r:.1f} {h:.1f} "
            f"l {r:.1f} {h:.1f} b {k:.1f} {h:.1f} 0 {h - k:.1f} 0 {h - r:.1f} "
            f"l 0 {r:.1f} b 0 {k:.1f} {k:.1f} 0 {r:.1f} 0")


# ---------------------------------------------------------------------
#  Layout model
# ---------------------------------------------------------------------
@dataclass
class Token:
    word: Word
    display: str
    index: int            # index inside the clip word list


@dataclass
class Line:
    tokens: list[Token]
    width: float = 0.0
    scale: float = 1.0
    x_offsets: list[float] = field(default_factory=list)   # left edge of each token from line start
    widths: list[float] = field(default_factory=list)


@dataclass
class Screen:
    lines: list[Line]
    start: float
    end: float

    @property
    def tokens(self) -> list[Token]:
        return [t for ln in self.lines for t in ln.tokens]


@dataclass
class Frame:
    width: int
    height: int

    @property
    def vertical(self) -> bool:
        return self.height > self.width

    @property
    def safe_left(self) -> int:
        return 60 if self.vertical else 120

    @property
    def safe_right(self) -> int:
        return 150 if self.vertical else 120   # right button rail on Shorts

    @property
    def center_x(self) -> float:
        return (self.safe_left + self.width - self.safe_right) / 2

    @property
    def max_width(self) -> float:
        return self.width - self.safe_left - self.safe_right - 40


# ---------------------------------------------------------------------
#  Chunking words into caption screens
# ---------------------------------------------------------------------
def _measure(text: str, st: CaptionStyle) -> float:
    return text_width(text, st.font, st.size, st.spacing)


def _line_width(tokens: list[Token], st: CaptionStyle) -> float:
    return _measure(" ".join(t.display for t in tokens), st)


def build_screens(words: list[Word], st: CaptionStyle, frame: Frame, masked: set[int]) -> list[Screen]:
    tokens = [Token(w, apply_case(mask_word(w.text) if i in masked else w.text, st.case), i)
              for i, w in enumerate(words) if w.text.strip()]
    groups: list[list[Token]] = []
    current: list[Token] = []
    limit = frame.max_width * st.max_lines * 0.95

    for k, tok in enumerate(tokens):
        if current:
            prev = current[-1]
            gap = tok.word.start - prev.word.end
            breaks = (
                len(current) >= st.max_words
                or prev.word.ends_sentence
                or gap > PAUSE_BREAK
                or (prev.word.text.endswith((",", ";", ":")) and len(current) >= 2)
                or _line_width(current + [tok], st) > limit
            )
            if breaks:
                groups.append(current)
                current = []
        current.append(tok)
    if current:
        groups.append(current)

    # No orphan: a lone last word of a sentence joins the previous screen if it fits.
    merged: list[list[Token]] = []
    for g in groups:
        if (len(g) == 1 and merged and not merged[-1][-1].word.ends_sentence
                and g[0].word.start - merged[-1][-1].word.end <= PAUSE_BREAK
                and len(merged[-1]) <= st.max_words
                and _line_width(merged[-1] + g, st) <= limit):
            merged[-1] = merged[-1] + g
        else:
            merged.append(g)

    screens = [Screen(lines=_split_lines(g, st, frame), start=0.0, end=0.0) for g in merged]
    _time_screens(screens)
    return screens


def _split_lines(tokens: list[Token], st: CaptionStyle, frame: Frame) -> list[Line]:
    full = _line_width(tokens, st)
    if full <= frame.max_width or st.max_lines == 1 or len(tokens) == 1:
        lines = [Line(tokens)]
    else:
        # Choose the split that makes the widest line as narrow as possible;
        # on a tie prefer the bottom line longer (Netflix rule).
        best, best_key = None, None
        for cut in range(1, len(tokens)):
            top, bottom = tokens[:cut], tokens[cut:]
            wt, wb = _line_width(top, st), _line_width(bottom, st)
            key = (max(wt, wb), 0 if wb >= wt else 1)
            if best_key is None or key < best_key:
                best, best_key = (top, bottom), key
        lines = [Line(best[0]), Line(best[1])]
    space = _measure(" ", st)
    for ln in lines:
        ln.widths = [_measure(t.display, st) for t in ln.tokens]
        ln.width = sum(ln.widths) + space * (len(ln.tokens) - 1)
        ln.scale = min(1.0, frame.max_width / ln.width) if ln.width else 1.0
        x, offs = 0.0, []
        for wdt in ln.widths:
            offs.append(x)
            x += wdt + space
        ln.x_offsets = offs
    return lines


def _time_screens(screens: list[Screen]) -> None:
    for i, sc in enumerate(screens):
        toks = sc.tokens
        sc.start = max(0.0, toks[0].word.start - LEAD)
        sc.end = toks[-1].word.end + 0.15
        if i > 0:
            sc.start = max(sc.start, screens[i - 1].end)
    for i, sc in enumerate(screens):
        nxt = screens[i + 1] if i + 1 < len(screens) else None
        wanted = max(sc.end, sc.start + MIN_SCREEN)
        if nxt is not None:
            gap = nxt.start - sc.tokens[-1].word.end
            wanted = nxt.start if gap <= GAP_HIDE else min(wanted + 0.15, nxt.start)
        sc.end = max(sc.start + 0.05, wanted)


# ---------------------------------------------------------------------
#  ASS writer
# ---------------------------------------------------------------------
def _header(st: CaptionStyle, frame: Frame) -> str:
    border_style = 3 if st.box else 1
    outline_col = ass_color(st.box_color, st.box_alpha) if st.box else ass_color(st.outline_color)
    outline = 14 if st.box else st.outline
    back = ass_color("#000000", st.shadow_alpha)
    return (
        "[Script Info]\nScriptType: v4.00+\n"
        f"PlayResX: {frame.width}\nPlayResY: {frame.height}\n"
        "WrapStyle: 2\nScaledBorderAndShadow: yes\nYCbCr Matrix: TV.709\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
        "Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Cap,{st.font},{st.size},{ass_color(st.color)},{ass_color(st.color)},{outline_col},{back},"
        f"0,0,0,0,100,100,{st.spacing},0,{border_style},{outline},{st.shadow},5,0,0,0,1\n"
        f"Style: Chip,{st.font},{st.size},{ass_color(st.highlight_color)},{ass_color(st.highlight_color)},"
        f"{ass_color('#000000', 1)},{ass_color('#000000', 0.6)},0,0,0,0,100,100,0,0,1,0,2,7,0,0,0,1\n"
        f"Style: Hook,{st.font},{st.size},{ass_color('#FFFFFF')},{ass_color('#FFFFFF')},"
        f"{ass_color('#000000', 1)},{ass_color('#000000', 0.55)},0,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1\n"
        f"Style: Title,{TITLE_FONT},{st.size},{ass_color('#111111')},{ass_color('#111111')},"
        f"{ass_color('#FFFFFF', 1)},{ass_color('#FFFFFF', 1)},0,0,0,0,100,100,0,0,1,0,0,4,0,0,0,1\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )


def _base_color(tok: Token, st: CaptionStyle, keys: set[int] | None = None, alt: bool = False) -> str:
    if st.speaker_colors and tok.word.speaker == 1:
        return SPEAKER_B_COLOR
    if st.keyword_color and keys and tok.index in keys:
        return st.keyword_color
    if alt and st.alt_color:
        return st.alt_color
    return st.color


# ---------------------------------------------------------------------
#  Har caption screen ka sab se ahem lafz (rangeen dikhne ke liye)
#  Pehle: number / zor wale lafz (never, every, biggest ...), phir naam
#  (beech jumle mein bada harf), phir lamba asli lafz (6+ harf, aam
#  lafz nahi). Har screen mein zyada se zyada ek; chhoti screens
#  (1-2 lafz) mein sirf pehli do qisam.
# ---------------------------------------------------------------------
STOP = {"the", "and", "that", "this", "with", "have", "they", "there", "their", "what", "about", "would",
        "could", "should", "because", "which", "where", "when", "were", "been", "from", "your", "you're",
        "it's", "that's", "going", "really", "something", "people", "thing", "things", "think", "know",
        "just", "like", "actually", "basically", "literally", "gonna", "wanna", "doesn't", "didn't", "isn't"}
STRONG = {"never", "always", "every", "everyone", "everybody", "nobody", "nothing", "everything", "worst",
          "best", "biggest", "dumbest", "stupid", "insane", "crazy", "ridiculous", "absolutely", "completely",
          "totally", "million", "billion", "trillion", "huge", "massive", "wrong", "truth", "lie", "lying",
          "war", "money", "free", "dead", "illegal", "racist", "fake", "real", "president", "power"}


def pick_keywords(screens: list["Screen"]) -> set[int]:
    keys: set[int] = set()
    for sc in screens:
        toks = sc.tokens
        best, rank = None, 0
        for k, t in enumerate(toks):
            w = t.word.clean if hasattr(t.word, "clean") else t.word.text.lower()
            raw = t.word.text.strip(".,!?;:\"'")
            r = 0
            if any(ch.isdigit() for ch in raw) or w in STRONG:
                r = 3
            elif raw[:1].isupper() and len(raw) > 2 and k > 0 and w not in STOP and raw.lower() != "i":
                r = 2
            elif len(toks) >= 3 and len(w) >= 6 and w not in STOP:
                r = 1
            if r > rank or (r == rank and r and len(w) > len(best.word.text)):
                best, rank = t, r
        if best is not None and rank:
            keys.add(best.index)
    return keys


def _line_text(line: Line, active_index: int | None, spoken_upto: int, st: CaptionStyle,
               keys: set[int] | None = None, alt: bool = False) -> str:
    parts: list[str] = []
    for tok in line.tokens:
        base = tag_color(_base_color(tok, st, keys, alt))
        is_active = tok.index == active_index
        prefix, suffix = f"{{\\1c{base}}}", ""
        pop = max(100, int(getattr(st, "pop_scale", 104) or 104))
        pop_tag = f"\\fscx96\\fscy96\\t(0,80,\\fscx{pop}\\fscy{pop})\\t(80,{150 if pop <= 106 else 220},\\fscx100\\fscy100)"
        if st.highlight == "color" and is_active:
            prefix = f"{{\\1c{base}\\t(0,70,\\1c{tag_color(st.highlight_color)})"
            if st.pop_on_highlight:
                prefix += pop_tag
            prefix += "}"
            suffix = "{\\fscx100\\fscy100}"
        elif st.highlight == "underline" and is_active:
            # bolta lafz rangeen aur us ke neeche line (line text ke rang ki hoti hai)
            prefix = f"{{\\1c{tag_color(st.highlight_color)}\\u1}}"
            suffix = "{\\u0}"
        elif st.highlight == "chip" and is_active:
            prefix = f"{{\\1c{tag_color(st.highlight_text_color)}\\bord0\\shad0}}"
            suffix = f"{{\\bord{st.outline}\\shad{st.shadow}}}"
        elif st.highlight == "scale" and is_active:
            prefix = f"{{\\1c{base}{pop_tag}}}"
            suffix = "{\\fscx100\\fscy100}"
        elif st.highlight == "dim":
            alpha = "&H00&" if tok.index <= spoken_upto else f"&H{round(st.dim_alpha * 255):02X}&"
            if st.fill_color and tok.index <= spoken_upto:
                base = tag_color(st.fill_color)          # karaoke: bola hua lafz rang se bhar jaata hai
            prefix = f"{{\\1c{base}\\1a{alpha}\\3a{alpha}}}"
        if st.reveal and active_index is not None and tok.index > active_index:
            prefix += "{\\1a&HFF&\\3a&HFF&\\4a&HFF&}"      # abhi bola nahi: chhupa (jagah wahi)
        parts.append(prefix + tok.display.replace("{", "(").replace("}", ")") + suffix)
    return " ".join(parts)


# ---------------------------------------------------------------------
#  Hook title: shuru ke 2-3 second, frame ke upar, ek chhoti line
#  Kaam: do tarah se banta hai -
#    box     : gol konon wala dabba (peela / safed / kala) aur us pe text
#    outline : bina dabbe ke, mota kala outline wala text
#  Kaunsa banega ye edit (EditChoice) batata hai: ~70% box, ~30% outline.
#  Chehre aur captions se door jagah renderer (hook_position) dhoondta hai.
# ---------------------------------------------------------------------
HOOK_SECONDS = 2.6
HOOK_EM = 0.62            # hook text size relative to the caption size
HOOK_COLORS = ("#FFD60A", "#FFFFFF", "#111111")     # peela, safed, kala


def _readable_on(hex_rgb: str) -> str:
    r, g, b = (int(hex_rgb.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
    return "#111111" if 0.299 * r + 0.587 * g + 0.114 * b > 150 else "#FFFFFF"


HEAD_BIG = 1.55              # (20 Nov) stream headline hook ka size (aam hook ka guna)


def hook_events(hook: str, st: CaptionStyle, frame: "Frame", seconds: float = HOOK_SECONDS,
                y_center: float | None = None, boxed: bool = True, color: str = "", big: bool = False) -> list[str]:
    """Dialogue lines for the hook: a rounded box with the text on it, or outlined text only.
    big (20 Nov, stream clips): viral stream clips jaisa bada headline, bade huroof, 2-3 linein."""
    text = hook.upper() if (st.case == "upper" or big) else hook
    words = text.replace("{", "(").replace("}", ")").split()
    if not words:
        return []
    size = st.size * HOOK_EM * (HEAD_BIG if big else 1.0)
    max_w = frame.width * (0.90 if big else 0.84)

    def width(t: str) -> float:
        return text_width(t, st.font, size, st.spacing)
    long_show = seconds > HOOK_SECONDS and len(words) > 4    # Super (lamba jumla): do linein, bara aur saaf
    if big and width(" ".join(words)) > max_w and len(words) >= 3:
        # bada headline: 2 ya 3 barabar linein, huroof chhote na hon
        best = None
        for n in (2, 3):
            if len(words) < n:
                continue
            cuts = [round(len(words) * k / n) for k in range(1, n)]
            parts = [" ".join(words[a:b]) for a, b in zip([0] + cuts, cuts + [len(words)])]
            wmax = max(width(p) for p in parts)
            if best is None or (wmax <= max_w and best[0] > max_w) or (wmax <= max_w) == (best[0] <= max_w) and wmax < best[0]:
                best = (wmax, parts)
            if wmax <= max_w:
                break
        lines = best[1]
    elif (width(" ".join(words)) * 0.8 <= max_w and not long_show) or len(words) < 3:   # one line if a small shrink is enough
        lines = [" ".join(words)]
    else:                                   # two balanced lines
        k = min(range(1, len(words)),
                key=lambda i: max(width(" ".join(words[:i])), width(" ".join(words[i:]))))
        lines = [" ".join(words[:k]), " ".join(words[k:])]
    scale = min(1.0, max_w / max(width(ln) for ln in lines))
    size *= scale
    line_h = size * 1.12
    pad_x, pad_y = size * 0.55, size * 0.32
    box_w = max(width(ln) for ln in lines) * scale * 1.06 + pad_x * 2     # thori gunjaish: lafz dabbe se bahar na hon
    box_h = line_h * len(lines) + pad_y * 2
    if y_center is None:
        y_center = 0.14 if frame.height > frame.width else 0.12
    top = frame.height * y_center - box_h / 2
    if big:
        top = max(frame.height * 0.035, top)          # bada headline upar se bahar na jaye
    left = frame.width / 2 - box_w / 2
    end = ass_time(seconds)
    colour = color or st.highlight_color
    fade = "\\fad(160,220)"
    out: list[str] = []
    if boxed:
        # gol konon wala dabba, text us ke upar parhne layak rang mein
        ink = _readable_on(colour)
        out.append(f"Dialogue: 2,{ass_time(0.05)},{end},Hook,,0,0,0,,"
                   f"{{\\an7\\move({left:.1f},{top + 14:.1f},{left:.1f},{top:.1f},0,200){fade}"
                   f"\\1c{ass_color(colour)}\\bord0\\shad3\\p1}}{rounded_rect(box_w, box_h, size * 0.38)}")
        text_tags = f"\\1c{ass_color(ink)}\\bord0\\shad0"
    else:
        # sirf text: andhere rang ka text na ho, warna outline mein gum ho jaye
        ink = colour if _readable_on(colour) == "#111111" else "#FFFFFF"
        edge = max(3.0, size * 0.09)
        text_tags = f"\\1c{ass_color(ink)}\\3c{ass_color('#000000')}\\bord{edge:.1f}\\shad2"
    for i, ln in enumerate(lines):
        y = top + pad_y + line_h * (i + 0.5)
        out.append(f"Dialogue: 3,{ass_time(0.05)},{end},Hook,,0,0,0,,"
                   f"{{\\an5\\move({frame.width / 2:.1f},{y + 14:.1f},{frame.width / 2:.1f},{y:.1f},0,200){fade}"
                   f"\\fs{size:.1f}{text_tags}}}{ln}")
    return out


# ---------------------------------------------------------------------
#  Naam patti: shuru ke ~3 second, upar baayen kone mein chhoti si patti
#  "Ben Shapiro  |  Oct 2026" (date sirf jab video ki date pata ho)
#  Kaam: research ke mutabiq political clips mein bolne wale ka naam aur
#  date ho to clip "fake / purana" keh kar nazarandaz nahi hota.
# ---------------------------------------------------------------------
NAME_SECONDS = 3.0


def name_card_events(text: str, st: CaptionStyle, frame: "Frame", y: float = 0.055, right: bool = False) -> list[str]:
    text = text.replace("{", "(").replace("}", ")").strip()
    if not text:
        return []
    size = st.size * 0.40
    w = text_width(text, st.font, size, 0) + size * 1.2
    h = size * 1.55
    left, top = frame.width * 0.045, frame.height * y
    if right:                                       # campaign logo upar baayen ho to patti daayen
        left = frame.width * 0.955 - w
    fade = "\\fad(200,250)"
    end = ass_time(NAME_SECONDS)
    return [
        f"Dialogue: 2,{ass_time(0.1)},{end},Hook,,0,0,0,,{{\\an7\\pos({left:.1f},{top:.1f}){fade}"
        f"\\1c{ass_color('#000000')}\\1a&H50&\\bord0\\shad0\\p1}}{rounded_rect(w, h, h * 0.3)}",
        f"Dialogue: 3,{ass_time(0.1)},{end},Hook,,0,0,0,,{{\\an4\\pos({left + size * 0.6:.1f},{top + h / 2:.1f})"
        f"{fade}\\fs{size:.1f}\\1c{ass_color('#FFFFFF')}\\bord0\\shad0}}{text}",
    ]


# ---------------------------------------------------------------------
#  Title card (seekha hua viral andaaz): safed pas-e-manzar, upar kala
#  title (2 line tak, aakhir mein emoji), chaho to channel ka naam.
#  Emoji tasveer ffmpeg alag se lagata hai: yahan us ki jagah nikalti hai.
# ---------------------------------------------------------------------
TITLE_FONT = "Inter SemiBold"
HEADER_FONT = "Inter Bold"


def _wrap(words: list[str], font: str, size: float, max_w: float, tail: float) -> list[str]:
    lines, cur = [], ""
    for w in words:
        test = f"{cur} {w}".strip()
        if cur and text_width(test, font, size) > max_w:
            lines.append(cur)
            cur = w
        else:
            cur = test
    if cur:
        lines.append(cur)
    if len(lines) == 2:
        # do lines barabar (aakhri line mein akela lafz nahi), emoji ki jagah samet
        best = None
        for k in range(1, len(words)):
            a, b = " ".join(words[:k]), " ".join(words[k:])
            wa, wb = text_width(a, font, size), text_width(b, font, size) + tail
            if wa <= max_w and wb <= max_w and (best is None or max(wa, wb) < best[0]):
                best = (max(wa, wb), [a, b])
        if best:
            lines = best[1]
    if lines and text_width(lines[-1], font, size) + tail > max_w and len(lines[-1].split()) > 1:
        last = lines[-1].rsplit(" ", 1)                 # emoji ki jagah: aakhri lafz agli line mein
        lines[-1:] = [last[0], last[1]]
    return lines


def title_card_events(title: str, frame: "Frame", top: float, header: str = "",
                      emoji: bool = True) -> tuple[list[str], tuple[float, float, float] | None]:
    """(ASS events, emoji ki jagah (x, y, size) ya None). `top` = video ka upar wala kinara (px)."""
    title = title.replace("{", "(").replace("}", ")").strip()
    if not title:
        return [], None
    w = frame.width
    k = w / 1080
    events: list[str] = []
    y0 = 40 * k
    if header:
        name = header.replace("{", "(").replace("}", ")").strip()
        handle = "@" + re.sub(r"[^a-z0-9_.]", "", name.lower())
        hs = em_to_ass(HEADER_FONT, 40 * k)
        events.append(f"Dialogue: 4,0:00:00.00,9:59:59.00,Title,,0,0,0,,{{\\an4\\pos({60 * k:.1f},{88 * k:.1f})"
                      f"\\fn{HEADER_FONT}\\fs{hs:.1f}}}{name.upper()}")
        events.append(f"Dialogue: 4,0:00:00.00,9:59:59.00,Title,,0,0,0,,{{\\an4\\pos({62 * k:.1f},{132 * k:.1f})"
                      f"\\fs{hs * 0.62:.1f}\\1c{ass_color('#666666')}}}{handle}")
        y0 = 165 * k
    max_w = w * 0.90
    em = 64 * k
    for em in (64 * k, 56 * k, 49 * k):
        size = em_to_ass(TITLE_FONT, em)
        tail = em * 1.25 if emoji else 0
        lines = _wrap(title.split(), TITLE_FONT, size, max_w, tail)
        if len(lines) <= 2:
            break
    lines = lines[:3]
    gap = em * 1.28
    block = gap * len(lines)
    y_first = y0 + max(0.0, (top - 22 * k - y0 - block) / 2) + gap / 2
    spot = None
    for i, line in enumerate(lines):
        lw = text_width(line, TITLE_FONT, size)
        last = i == len(lines) - 1
        extra = tail if (last and emoji) else 0
        left = (w - lw - extra) / 2
        y = y_first + i * gap
        events.append(f"Dialogue: 4,0:00:00.00,9:59:59.00,Title,,0,0,0,,{{\\an4\\pos({left:.1f},{y:.1f})"
                      f"\\fs{size:.1f}}}{line}")
        if last and emoji:
            spot = (left + lw + em * 0.22, y - em * 0.52, em * 1.04)
    return events, spot


# ---------------------------------------------------------------------
#  Classic (17 Nov, user ka reference clip): upar ki patti mein 2 line
#  ka mota title (Anton), pehla lafz rangeen. Kaali patti: safed text +
#  peela lafz. Safed patti: kaala text + laal lafz.
# ---------------------------------------------------------------------
CLASSIC_TITLE_FONT = "Anton"
CLASSIC_COLORS = {"black": ("#FFFFFF", "#FFD500"), "white": ("#141414", "#E0201B")}


def _balanced(words: list[str], n: int) -> list[str]:
    if n <= 1 or len(words) <= 1:
        return [" ".join(words)]
    if n == 2:
        best = None
        for k in range(1, len(words)):
            a, b = " ".join(words[:k]), " ".join(words[k:])
            score = abs(len(a) - len(b)) + (0 if len(a) <= len(b) + 4 else 3)
            if best is None or score < best[0]:
                best = (score, [a, b])
        return best[1]
    per = max(1, round(len(words) / n))
    out = [" ".join(words[i:i + per]) for i in range(0, len(words), per)]
    return out[:n - 1] + [" ".join(out[n - 1:])] if len(out) > n else out


KEY_STRONG = {
    "beautiful", "crazy", "insane", "evil", "stupid", "wrong", "right", "never", "always", "worst", "best",
    "destroy", "destroyed", "destroys", "love", "hate", "lie", "lies", "lying", "truth", "fake", "real", "free",
    "freedom", "illegal", "racist", "socialism", "socialist", "communist", "marxist", "god", "jesus", "america",
    "american", "abortion", "gun", "guns", "border", "taxes", "tax", "money", "rich", "poor", "kill", "killed",
    "deport", "ban", "banned", "war", "dead", "die", "fail", "failed", "disaster", "genius", "brilliant",
    "terrible", "horrible", "amazing", "perfect", "impossible", "ridiculous", "dangerous", "shocking", "huge",
    "million", "billion", "trillion", "nobody", "everyone", "everybody", "men", "women", "marriage", "family",
}
KEY_SKIP = {
    "the", "a", "an", "and", "or", "but", "to", "of", "in", "on", "at", "for", "with", "is", "are", "was", "were",
    "be", "been", "it", "its", "this", "that", "these", "those", "you", "your", "we", "our", "they", "their", "he",
    "she", "his", "her", "i", "me", "my", "so", "do", "does", "did", "not", "no", "yes", "just", "what", "why",
    "how", "who", "when", "where", "if", "than", "then", "too", "very", "can", "will", "would", "should", "could",
    "about", "from", "by", "as", "up", "out", "all", "any", "some", "more", "most", "like", "get", "got", "have",
    "has", "had", "say", "says", "said", "tell", "tells", "told", "think", "thinks", "know", "knows",
}


def key_word(title: str, spoken: str = "", skip_names: tuple = ()) -> int:
    """(18 Nov) Title ka sab se ahem lafz (index): jazbati / mazboot lafz, naam ya jagah, number; warna lamba
    asal lafz. Barabari mein baad wala (reference: "... Ottawa Toronto And Vancouver.")."""
    words = title.split()
    if not words:
        return -1
    spoken_caps = set()
    toks = re.findall(r"[A-Za-z][A-Za-z'\-]+[.,?!]?", spoken or "")
    for k, t in enumerate(toks):
        if k > 0 and t[:1].isupper() and toks[k - 1][-1:] not in ".?!":
            spoken_caps.add(t.rstrip(".,?!").lower())       # beech jumle mein bara harf = naam / jagah
    skip_names = tuple(n.lower() for n in skip_names)
    name_words = {re.sub(r"[^a-z0-9']", "", x) for n in skip_names for x in n.split()}   # (18 Nov) "Charlie" bhi
    best, best_k = -1.0, -1
    for k, w in enumerate(words):
        core = re.sub(r"[^A-Za-z0-9$%']", "", w).lower()
        if len(core) < 3 or core in KEY_SKIP:
            continue
        score = min(len(core), 10) / 10.0
        if core in KEY_STRONG:
            score += 5
        if any(ch.isdigit() for ch in core) or "$" in w or "%" in w:
            score += 4
        if core in name_words or core.removesuffix("'s") in name_words:
            score -= 1.0                                  # main shakhs ka naam rangeen nahi (sab title mein hota hai)
        elif core in spoken_caps:
            score += 3
        score += 0.02 * k
        if score >= best:
            best, best_k = score, k
    return best_k if best_k >= 0 else len(words) - 1


def classic_title_events(title: str, frame: "Frame", bg: str, video_top: float, key: str = "") -> list[str]:
    """Classic title (18 Nov, v2 = viral reference): upar wali patti ke beech, 2 lines (lamba ho to 3), chhota
    aur mota (Anton), ek AHEM lafz rangeen (key = us ka index; khali ho to pehla lafz)."""
    title = title.replace("{", "(").replace("}", ")").replace("\\", " ").strip()
    if not title:
        return []
    w = frame.width
    k = w / 1080
    text_c, key_c = CLASSIC_COLORS.get(bg, CLASSIC_COLORS["black"])
    words = title.split()
    try:
        key_i = int(key) if str(key) != "" else 0
    except ValueError:
        key_i = 0
    key_i = key_i if 0 <= key_i < len(words) else 0
    # (18 Nov) reference: harf ~62 px ooncha (fs ~110), lines ke beech 80 px (0.73 x fs), chaurai 80% tak
    max_w = w * 0.80
    lines, size = [], 110 * k
    for n in (2, 3, 4):
        lines = _balanced(words, n) if len(words) > 1 else [title]
        size = 110 * k
        while size > 80 * k and max(text_width(x, CLASSIC_TITLE_FONT, size) for x in lines) > max_w:
            size -= 2 * k
        if max(text_width(x, CLASSIC_TITLE_FONT, size) for x in lines) <= max_w:
            break
    while size > 48 * k and (max(text_width(x, CLASSIC_TITLE_FONT, size) for x in lines) > max_w
                             or size * (0.73 * (len(lines) - 1) + 0.75) > video_top * 0.88):
        size -= 2 * k
    gap = size * 0.73
    mid = video_top / 2 + 2 * k
    y_first = mid - gap * (len(lines) - 1) / 2
    glow = "#000000" if bg != "white" else "#FFFFFF"
    events, n_word = [], 0
    for i, line in enumerate(lines):
        parts = []
        for wd in line.split():
            if n_word == key_i:
                parts.append(f"{{\\1c{ass_color(key_c)}}}{wd}{{\\1c{ass_color(text_c)}}}")
            else:
                parts.append(wd)
            n_word += 1
        events.append(f"Dialogue: 4,0:00:00.00,9:59:59.00,Title,,0,0,0,,"
                      f"{{\\an5\\pos({w / 2:.1f},{y_first + i * gap:.1f})\\fn{CLASSIC_TITLE_FONT}\\fs{size:.1f}"
                      f"\\fscx100\\fscy100\\fsp0.5\\1c{ass_color(text_c)}\\3c{ass_color(glow)}\\4c{ass_color(glow)}"
                      f"\\bord{2.2 * k:.1f}\\blur{1.5 * k:.1f}\\shad{2.0 * k:.1f}\\b0\\fad(150,0)}}{' '.join(parts)}")
    return events


def classic_super_events(text: str, frame: "Frame", bg: str, top: float, bottom: float) -> list[str]:
    """(19 Nov, Diamonds) Classic ki neeche wali patti mein campaign ka Super (jaise "Natural Diamonds |
    Botswana" wala jumla), poore clip mein: title se chhota, saaf, 1 ya 2 lines, patti ke beech."""
    text = text.replace("{", "(").replace("}", ")").replace("\\", " ").strip()
    if not text:
        return []
    w = frame.width
    k = w / 1080
    text_c = "#FFFFFF" if bg != "white" else "#111111"
    glow = "#000000" if bg != "white" else "#FFFFFF"
    words = text.split()
    max_w = w * 0.86
    size = 74 * k
    lines = [text]
    for n in (1, 2, 3):
        lines = _balanced(words, n) if len(words) > 1 else [text]
        size = 74 * k
        while size > 56 * k and max(text_width(x, CLASSIC_TITLE_FONT, size) for x in lines) > max_w:
            size -= 2 * k
        if max(text_width(x, CLASSIC_TITLE_FONT, size) for x in lines) <= max_w:
            break
    gap = size * 0.9
    mid = (top + bottom) / 2
    y_first = mid - gap * (len(lines) - 1) / 2
    return [f"Dialogue: 4,0:00:00.00,9:59:59.00,Title,,0,0,0,,"
            f"{{\\an5\\pos({w / 2:.1f},{y_first + i * gap:.1f})\\fn{CLASSIC_TITLE_FONT}\\fs{size:.1f}"
            f"\\fscx100\\fscy100\\fsp0.5\\1c{ass_color(text_c)}\\3c{ass_color(glow)}\\4c{ass_color(glow)}"
            f"\\bord{1.8 * k:.1f}\\blur{1.2 * k:.1f}\\shad{1.5 * k:.1f}\\b0\\fad(150,0)}}{line}"
            for i, line in enumerate(lines)]


# ---------------------------------------------------------------------
#  Disclosure (jaise siyasi ad ka "This post was paid for by ..."):
#  NEECHE ek saaf, gehri patti (video mein pehle se likha disclosure is
#  ke neeche chhup jaata hai), us mein halke safed harf, LAFZ BA LAFZ
#  (ek harf bhi nahi badalta), poore clip mein. Patti patli rakhi hai
#  taake baqi video se dhyan na hate.
# ---------------------------------------------------------------------
DISCLOSURE_FONT = "Inter SemiBold"
DISCLOSURE_EM = 30.0          # 1080 chaurai pe harf ka size (px)
DISCLOSURE_PAD = 22.0         # patti ke upar / neeche khali jagah (px, 1080 pe)
DISCLOSURE_LINE = 1.28        # line ke beech faasla (em ka guna)
DISCLOSURE_MAX_LINES = 6
DISCLOSURE_TEXT = "#EDEDED"   # halka safed: saaf parha jaye, chamke nahi
DISCLOSURE_BG = "0x0D0D0D"    # patti ka rang (gehra, saada)


DISCLOSURE_SAFE_RIGHT = 0.15   # Shorts / Reels / TikTok: daayen buttons (like, comment, share) ki jagah
DISCLOSURE_SAFE_LEFT = 0.05


def disclosure_margins(width: int, height: int) -> tuple[float, float]:
    """Khadi (9:16) video mein disclosure daayen buttons se bacha rahe: (baayen, daayen) khali jagah px."""
    if height > width:
        return width * DISCLOSURE_SAFE_LEFT, width * DISCLOSURE_SAFE_RIGHT
    return width * 0.04, width * 0.04


def disclosure_band(text: str, width: int = 1080, height: int = 1920,
                    cover: float = 0.0) -> tuple[list[str], float, float]:
    """(lines, em px, patti ki unchai px) is frame pe. Text bilkul wahi rehta hai, sirf lines mein bata.
    cover: video ke purane disclosure ko dhakne ke liye patti kam az kam itni unchi (frame ka hissa)."""
    k = min(width, height) / 1080          # 1080x1920 = 1, HQ 1440x2560 = 1.33, 16:9 1920x1080 = 1
    words = (text or "").split()
    if not words:
        return [], 0.0, 0.0
    left, right = disclosure_margins(width, height)
    max_w = width - left - right

    def wrap(em: float) -> list[str]:
        size = em_to_ass(DISCLOSURE_FONT, em)
        lines, cur = [], ""
        for w in words:
            test = f"{cur} {w}".strip()
            if cur and text_width(test, DISCLOSURE_FONT, size) > max_w:
                lines.append(cur)
                cur = w
            else:
                cur = test
        if cur:
            lines.append(cur)
        return lines

    # normal: 30 / 27 / 24 px. cover (purane disclosure ki jagah) ho to text utni jagah mein sama jaye:
    # sab se bara size jo fit ho (22 px tak, phir bhi parhne layak), warna sab se chhota
    sizes = (DISCLOSURE_EM, 27.0, 24.0) if not cover else (DISCLOSURE_EM, 28.0, 27.0, 26.0, 25.0, 24.0, 23.0, 22.0)
    pads = (DISCLOSURE_PAD,) if not cover else (DISCLOSURE_PAD, 16.0, 12.0)
    best = None
    for e in sizes:
        em = e * k
        lines = wrap(em)
        if len(lines) > DISCLOSURE_MAX_LINES:
            continue
        for pad in pads:
            band = pad * k * 2 + em * DISCLOSURE_LINE * len(lines)
            best = (lines, em, band)
            if not cover or band <= cover * height:
                break
        if not cover or best[2] <= cover * height:
            break
    if best is None:
        em = sizes[-1] * k
        lines = wrap(em)
        best = (lines, em, DISCLOSURE_PAD * k * 2 + em * DISCLOSURE_LINE * len(lines))
    lines, em, band = best
    band = max(band, cover * height)
    return lines, em, float(int(round(band / 2)) * 2)


def disclosure_events(text: str, frame: "Frame", at_top: bool = False, cover: float = 0.0,
                      top: float | None = None, band: float | None = None) -> list[str]:
    """Patti ke andar disclosure ki lines (beech mein). Patti neeche, upar (at_top), ya kisi bhi unchai
    (top, band: px is frame pe). Patti ka rang ffmpeg lagata hai."""
    lines, em, full = disclosure_band(text, frame.width, frame.height, cover)
    band = full if band is None else band
    size = em_to_ass(DISCLOSURE_FONT, em)
    gap = em * DISCLOSURE_LINE
    pad = band - gap * len(lines)
    if top is None:
        top = 0.0 if at_top else frame.height - band
    left, right = disclosure_margins(frame.width, frame.height)
    cx = (left + frame.width - right) / 2                 # daayen buttons se bacha kar beech
    out = []
    for i, line in enumerate(lines):
        safe = line.replace("{", "(").replace("}", ")").replace("\\", "/")
        y = top + pad / 2 + gap * (i + 0.5)
        out.append(f"Dialogue: 5,0:00:00.00,9:59:59.00,Title,,0,0,0,,{{\\an5\\pos({cx:.1f},{y:.1f})"
                   f"\\fn{DISCLOSURE_FONT}\\fs{size:.1f}\\1c{ass_color(DISCLOSURE_TEXT)}\\bord0\\shad0}}{safe}")
    return out


def build_ass(
    words: list[Word],
    style: CaptionStyle,
    width: int,
    height: int,
    masked: set[int] | None = None,
    out_path: Path | None = None,
    entrance: str | None = None,
    hook: str = "",
    hook_y: float | None = None,
    y_at=None,
    hook_box: bool = True,
    hook_color: str = "",
    hook_big: bool = False,
    hook_seconds: float = 0.0,
    name_card: str = "",
    name_card_right: bool = False,
    title_card: tuple[list[str], object] | None = None,
) -> str:
    """Return (and optionally write) the full .ass text for one clip.
    `entrance` (rise/fade) overrides the style's own entrance so the
    variety engine can rotate it."""
    frame = Frame(width, height)
    st = scaled_for(style, width, height)
    st = replace(st, size=em_to_ass(st.font, st.size))
    if entrance in ("rise", "fade"):
        st = replace(st, entrance=entrance)
    screens = build_screens(words, st, frame, masked or set())
    keys = pick_keywords(screens) if st.keyword_color else set()
    gap_line = st.size * (1.08 if st.box else 0.92)
    y_center = height * st.y_pct
    events: list[str] = []

    base_y = y_center
    for s_idx, sc in enumerate(screens):
        # per shot height (e.g. below a full picture, on the stacked divider), else the style's own
        shot_y = y_at(sc.start) if y_at is not None else None
        y_center = height * shot_y if shot_y is not None else base_y
        nxt = screens[s_idx + 1] if s_idx + 1 < len(screens) else None
        fade_out = nxt is None or nxt.start - sc.end > 0.05 or (nxt.start - sc.tokens[-1].word.end) > GAP_HIDE
        toks = sc.tokens
        # One event per spoken word (active word changes); before the first word, show plain.
        cuts = [sc.start] + [max(sc.start, t.word.start - LEAD) for t in toks[1:]] + [sc.end]
        n_lines = len(sc.lines)
        for k, tok in enumerate(toks):
            t0, t1 = cuts[k], cuts[k + 1]
            if t1 - t0 < 0.02:
                continue
            first_event, last_event = k == 0, k == len(toks) - 1
            for li, line in enumerate(sc.lines):
                y = y_center + (li - (n_lines - 1) / 2) * gap_line
                x = frame.center_x
                scale_tag = f"\\fscx{line.scale * 100:.0f}\\fscy{line.scale * 100:.0f}" if line.scale < 0.999 else ""
                anim = ""
                if first_event and st.entrance == "rise":
                    anim = f"\\move({x:.0f},{y + 12:.0f},{x:.0f},{y:.0f},0,140)"
                    fade_in = 140
                else:
                    fade_in = 120 if (first_event and st.entrance == "fade") else 0
                pos = "" if anim else f"\\pos({x:.0f},{y:.0f})"
                fade = ""
                if fade_in or (last_event and fade_out):
                    fade = f"\\fad({fade_in},{90 if (last_event and fade_out) else 0})"
                glow = f"\\blur{st.glow:g}" if getattr(st, "glow", 0) else ""
                head = f"{{\\an5{pos}{anim}{fade}{scale_tag}{glow}}}"
                text = _line_text(line, tok.index, tok.index, st, keys, alt=s_idx % 2 == 1)
                events.append(f"Dialogue: 1,{ass_time(t0)},{ass_time(t1)},Cap,,0,0,0,,{head}{text}")

                # Chip behind the active word (box_highlight style).
                if st.highlight == "chip" and tok in line.tokens:
                    j = line.tokens.index(tok)
                    pad_x, pad_y = st.size * 0.16, st.size * 0.10
                    w = line.widths[j] * line.scale + pad_x * 2
                    h = st.size * 0.86 + pad_y * 2
                    left = x - line.width * line.scale / 2 + line.x_offsets[j] * line.scale - pad_x
                    top = y - h / 2 - st.size * 0.03
                    chip_fade = f"\\fad({fade_in},{90 if (last_event and fade_out) else 0})" if fade else ""
                    chip_pos = (f"\\move({left:.1f},{top + 12:.1f},{left:.1f},{top:.1f},0,140)" if anim
                                else f"\\pos({left:.1f},{top:.1f})")
                    events.append(
                        f"Dialogue: 0,{ass_time(t0)},{ass_time(t1)},Chip,,0,0,0,,"
                        f"{{\\an7{chip_pos}{chip_fade}\\p1}}{rounded_rect(w, h, st.size * 0.2)}"
                    )

    if hook:
        events.extend(hook_events(hook, st, frame, seconds=hook_seconds or HOOK_SECONDS, y_center=hook_y,
                                  boxed=hook_box, color=hook_color, big=hook_big))
    if name_card:
        events.extend(name_card_events(name_card, st, frame, right=name_card_right))
    if title_card:
        events.extend(title_card[0])
    text = _header(st, frame) + "\n".join(events) + "\n"
    if out_path is not None:
        out_path.write_text(text, encoding="utf-8")
    return text
