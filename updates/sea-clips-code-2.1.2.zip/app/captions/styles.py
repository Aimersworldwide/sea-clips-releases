"""
=====================================================================
  CAPTIONS / STYLE PRESETS  (12 premium styles)
  Kaam: captions ke tayyar styles (rang, font, size, highlight).
  All sizes are for a 1080 x 1920 (9:16) frame and are scaled for
  16:9 automatically. Colours are normal hex (#RRGGBB).
  Highlight modes:
    color   - spoken word changes colour (60-80 ms crossfade)
    chip    - spoken word sits on a rounded colour box
    dim     - unspoken words dimmed, spoken words fully lit
    scale   - spoken word pops slightly (max 4 %), no colour
    none    - no per-word highlight
=====================================================================
"""
from __future__ import annotations

from dataclasses import dataclass, replace


@dataclass(frozen=True)
class CaptionStyle:
    key: str
    label: str
    font: str
    size: int                    # type size in em px at 1080 x 1920 (like CSS)
    case: str = "upper"          # upper | sentence | lower
    color: str = "#FFFFFF"
    outline_color: str = "#000000"
    outline: float = 6.0
    shadow: float = 3.0
    shadow_alpha: float = 0.5    # 0 = solid, 1 = invisible
    highlight: str = "color"
    highlight_color: str = "#FFD60A"
    highlight_text_color: str = "#111111"   # text colour on a chip
    pop_on_highlight: bool = True
    dim_alpha: float = 0.45      # for "dim" mode (0 = solid)
    box: bool = False            # whole-line backing box (newsroom)
    box_color: str = "#000000"
    box_alpha: float = 0.28
    max_words: int = 3           # words per caption screen
    max_lines: int = 2
    y_pct: float = 0.64          # vertical centre of the caption block
    spacing: float = 0.0         # letter spacing px
    entrance: str = "rise"       # rise | fade | none
    speaker_colors: bool = False
    keyword_color: str = ""      # khaas lafz (number, naam, zor wale lafz) hamesha is rang mein; "" = nahi
    alt_color: str = ""          # har doosri caption screen is rang mein (do rang bari bari); "" = nahi
    reveal: bool = False         # lafz bolne ke saath ek ek kar ke nazar aate hain (jagah pehle se pakki)
    fill_color: str = ""         # "dim" mode: bole ja chuke lafz is rang mein bharte jaate hain (karaoke)
    pop_scale: int = 104         # bolta lafz kitna bara ho (100 = bilkul nahi, 104 = halka, 118 = uchhalta)
    glow: float = 0.0            # kinare ka halka noor (blur), 0 = nahi


STYLES: dict[str, CaptionStyle] = {s.key: s for s in [
    CaptionStyle("yellow_pop", "Yellow Pop", "Montserrat Black", 84, "upper", highlight="color",
                 highlight_color="#FFD60A", max_words=3, outline=6.5, shadow=3),
    CaptionStyle("authority", "Authority", "Montserrat ExtraBold", 74, "sentence", highlight="color",
                 highlight_color="#FFD60A", pop_on_highlight=False, max_words=5, max_lines=1, outline=5.5),
    CaptionStyle("box_highlight", "Box Highlight", "Poppins Bold", 70, "sentence", highlight="chip",
                 highlight_color="#FFD60A", max_words=4, outline=4.5, pop_on_highlight=False),
    CaptionStyle("ice_blue", "Ice Blue", "Montserrat ExtraBold", 76, "lower", highlight="color",
                 highlight_color="#3FC1FF", outline_color="#0B1F3A", max_words=4, outline=6),
    CaptionStyle("anton_impact", "Anton Impact", "Anton", 92, "upper", highlight="color",
                 highlight_color="#F7C204", max_words=3, outline=4.5, shadow=3, spacing=1.0),
    CaptionStyle("minimal_weight", "Minimal", "Montserrat Bold", 68, "lower", highlight="scale",
                 outline=2.5, shadow=3, shadow_alpha=0.35, max_words=5, max_lines=1, entrance="fade"),
    CaptionStyle("dim_to_lit", "Dim to Lit", "Inter SemiBold", 66, "sentence", highlight="dim",
                 outline=3.5, max_words=7, max_lines=2, pop_on_highlight=False, entrance="fade"),
    CaptionStyle("newsroom_box", "Newsroom Box", "Inter Bold", 60, "sentence", highlight="none",
                 outline=0, shadow=0, box=True, max_words=7, max_lines=2, y_pct=0.70, pop_on_highlight=False,
                 entrance="fade"),
    CaptionStyle("debate_duo", "Debate Duo", "Montserrat ExtraBold", 74, "sentence", highlight="color",
                 highlight_color="#FFD60A", max_words=5, max_lines=1, outline=5.5, pop_on_highlight=False,
                 speaker_colors=True),
    CaptionStyle("gold_premium", "Gold Premium", "Montserrat ExtraBold", 78, "upper", highlight="color",
                 highlight_color="#F2C85B", max_words=3, outline=5.5),
    CaptionStyle("bebas_red", "Bebas Red", "Bebas Neue", 108, "upper", highlight="color",
                 highlight_color="#FF3B30", max_words=3, outline=4.0, shadow=4, shadow_alpha=0.4, spacing=1.5),
    CaptionStyle("green_chip", "Green Chip", "Poppins Bold", 70, "sentence", highlight="chip",
                 highlight_color="#22E07A", highlight_text_color="#0A0A0A", max_words=4, outline=4.5,
                 pop_on_highlight=False),
    # --- 24 Oct 2026: user ke pasand kiye hue chhote, saaf styles (har video mein ek hi rang) ---
    CaptionStyle("clean_pop", "Clean Pop", "Montserrat ExtraBold", 64, "sentence", highlight="color",
                 outline=3.5, shadow=4, shadow_alpha=0.35, max_words=4, max_lines=1, y_pct=0.68),
    CaptionStyle("clean_caps", "Clean Caps", "Montserrat Black", 58, "upper", highlight="color",
                 outline=3.5, shadow=4, shadow_alpha=0.35, max_words=3, max_lines=1, y_pct=0.68, spacing=0.5),
    CaptionStyle("glow_karaoke", "Glow Karaoke", "Poppins Bold", 62, "sentence", highlight="dim", dim_alpha=0.45,
                 fill_color="#3DDC84", outline=3, shadow=3, shadow_alpha=0.4, max_words=5, max_lines=1,
                 pop_on_highlight=False, y_pct=0.68),
    CaptionStyle("karaoke_clean", "Karaoke Clean", "Inter Bold", 58, "sentence", highlight="dim", dim_alpha=0.45,
                 fill_color="#FFD60A", outline=3, shadow=3, shadow_alpha=0.4, max_words=5, max_lines=1,
                 pop_on_highlight=False, y_pct=0.68),
    CaptionStyle("pill_highlight", "Pill Highlight", "Montserrat Bold", 60, "sentence", highlight="chip",
                 highlight_color="#7B5CFF", highlight_text_color="#FFFFFF", outline=3, shadow=3, shadow_alpha=0.4,
                 max_words=4, max_lines=1, pop_on_highlight=False, y_pct=0.68),
    CaptionStyle("pill_round", "Pill Round", "Poppins Bold", 58, "sentence", highlight="chip",
                 highlight_color="#FF9F1C", highlight_text_color="#FFFFFF", outline=3, shadow=3, shadow_alpha=0.4,
                 max_words=4, max_lines=1, pop_on_highlight=False, y_pct=0.68),
    CaptionStyle("soft_box", "Soft Box", "Inter Bold", 54, "sentence", highlight="color", highlight_color="#4CC9F0",
                 outline=0, shadow=0, box=True, box_color="#000000", box_alpha=0.45, max_words=5, max_lines=1,
                 pop_on_highlight=False, y_pct=0.70),
    CaptionStyle("bold_two", "Bold Two Words", "Anton", 86, "upper", highlight="color", highlight_color="#FF9F1C",
                 outline=4, shadow=4, shadow_alpha=0.35, max_words=2, max_lines=1, y_pct=0.66, spacing=1.0),
    CaptionStyle("bold_two_bebas", "Bold Two Bebas", "Bebas Neue", 100, "upper", highlight="color",
                 outline=4, shadow=4, shadow_alpha=0.35, max_words=2, max_lines=1, y_pct=0.66, spacing=1.5),
    # viral political shorts jaisa: CAPS safed + kala kinara, sirf bolte lafz ke peeche chhota rangeen nishaan
    # (poori line ke peeche dabba nahi). Sirf un campaigns mein jahan "word_chip" On ho.
    CaptionStyle("word_chip", "Word Highlight", "Montserrat Black", 64, "upper", highlight="chip",
                 highlight_color="#FFD60A", highlight_text_color="#111111", outline=4.5, shadow=3,
                 shadow_alpha=0.35, max_words=3, max_lines=1, y_pct=0.68, pop_on_highlight=False, spacing=0.5),
    # Isi khandaan ke aur andaaz (Political jaisi campaigns ki variety): ek line, saaf safed lafz,
    # sirf bolta lafz rangeen dabbe par ya rangeen. Koi dhundla (dim) lafz nahi, koi bara dabba nahi.
    CaptionStyle("word_chip_purple", "Word Highlight Purple", "Poppins Bold", 60, "sentence", highlight="chip",
                 highlight_color="#7C3AED", highlight_text_color="#FFFFFF", outline=4.0, shadow=3,
                 shadow_alpha=0.35, max_words=4, max_lines=1, y_pct=0.68, pop_on_highlight=False),
    CaptionStyle("word_chip_green", "Word Highlight Green", "Montserrat Black", 60, "upper", highlight="chip",
                 highlight_color="#22C55E", highlight_text_color="#0B0B0B", outline=4.5, shadow=3,
                 shadow_alpha=0.35, max_words=3, max_lines=1, y_pct=0.68, pop_on_highlight=False, spacing=0.5),
    # (5 Nov 2026) Debate reference clips jaisa: CAPS safed + kala kinara, bolta lafz LAAL dabbe par safed
    CaptionStyle("word_chip_red", "Word Highlight Red", "Montserrat Black", 62, "upper", highlight="chip",
                 highlight_color="#E5242A", highlight_text_color="#FFFFFF", outline=4.5, shadow=3,
                 shadow_alpha=0.35, max_words=3, max_lines=1, y_pct=0.62, pop_on_highlight=False, spacing=0.5),
    CaptionStyle("word_color_yellow", "Word Color Yellow", "Montserrat ExtraBold", 60, "sentence",
                 highlight="color", highlight_color="#FFD60A", outline=4.5, shadow=3, shadow_alpha=0.35,
                 max_words=4, max_lines=1, y_pct=0.68, pop_on_highlight=False),
    # --- 15 Nov 2026 (SEA CLIPS 2.0): naye pro styles, sab bina dabbe ke ---
    CaptionStyle("bold_outline", "Bold Outline", "Montserrat Black", 66, "upper", highlight="none",
                 outline=7.5, shadow=2, shadow_alpha=0.4, max_words=3, max_lines=2, y_pct=0.66,
                 pop_on_highlight=False),
    CaptionStyle("karaoke_fill", "Karaoke Fill", "Montserrat ExtraBold", 62, "upper", highlight="dim",
                 dim_alpha=0.0, fill_color="#FFD60A", outline=4.5, shadow=3, shadow_alpha=0.35, max_words=4,
                 max_lines=1, y_pct=0.67, pop_on_highlight=False),
    CaptionStyle("pop_word", "Pop Word", "Montserrat Black", 62, "upper", highlight="color",
                 highlight_color="#2EE86B", pop_scale=118, outline=4.5, shadow=3, shadow_alpha=0.35,
                 max_words=3, max_lines=1, y_pct=0.67),
    CaptionStyle("two_tone", "Two Tone", "Poppins Bold", 60, "lower", highlight="none", keyword_color="#FFE11A",
                 outline=4.0, shadow=3, shadow_alpha=0.35, max_words=4, max_lines=1, y_pct=0.68,
                 pop_on_highlight=False),
    CaptionStyle("soft_shadow", "Soft Shadow", "Inter SemiBold", 56, "sentence", highlight="none",
                 outline=0.8, shadow=4.5, shadow_alpha=0.25, max_words=5, max_lines=1, y_pct=0.69,
                 pop_on_highlight=False, entrance="fade"),
    CaptionStyle("underline_sweep", "Underline Sweep", "Montserrat ExtraBold", 60, "upper", highlight="underline",
                 highlight_color="#FF3D8B", outline=4.5, shadow=3, shadow_alpha=0.35, max_words=3, max_lines=1,
                 y_pct=0.67, pop_on_highlight=False),
    CaptionStyle("gold_glow", "Gold Glow", "Montserrat Black", 62, "upper", highlight="none",
                 keyword_color="#F6C445", outline_color="#2A1A00", outline=4.5, glow=2.0, shadow=3,
                 shadow_alpha=0.4, max_words=3, max_lines=1, y_pct=0.67, pop_on_highlight=False),
    # (17 Nov) Classic (user ka reference): video ke andar, CAPS, 3 lafz, bolta lafz peela, koi dabba nahi
    CaptionStyle("classic_caps", "Classic Caps", "Montserrat Black", 52, "upper", highlight="color",
                 highlight_color="#FFD500", outline=5.0, shadow=2.0, shadow_alpha=0.6, max_words=3, max_lines=1,
                 y_pct=0.55, spacing=2.0, entrance="none", pop_scale=100, pop_on_highlight=False),
    # (18 Nov) Classic v2 (user ke viral reference): chhote, patle kinare, gehri parchhai, 3 lafz, bolta lafz peela
    CaptionStyle("classic_ref", "Classic Small", "Montserrat Black", 44, "upper", highlight="color",
                 highlight_color="#FFD500", outline=3.0, shadow=2.5, shadow_alpha=0.75, max_words=3, max_lines=1,
                 y_pct=0.55, spacing=1.0, entrance="none", pop_scale=100, pop_on_highlight=False),
    CaptionStyle("big_two_outline", "Big Two Words", "Anton", 104, "upper", highlight="none",
                 outline=6.5, shadow=3, shadow_alpha=0.35, max_words=2, max_lines=1, y_pct=0.64, spacing=1.0,
                 pop_on_highlight=False),
]}

# Har clip ki rotation sirf in styles mein (bade bhaari purane styles sirf "lock" karne pe)
# (28 Oct 2026: user - captions ke peeche kaala / rangeen dabba nahi, chehra chhupta hai. Dabbe wale
#  styles (pill_highlight, soft_box, pill_round) rotation se bahar; sirf lafz + kinara)
ROTATION_STYLES = ["clean_pop", "glow_karaoke", "bold_two", "clean_caps", "karaoke_clean", "bold_two_bebas"]

CHIP_STYLES = ["word_chip", "word_chip_red", "word_chip_purple", "word_chip_green", "word_color_yellow"]   # "word_chip" switch On: SIRF ye

SPEAKER_B_COLOR = "#FFE08A"


def get_style(key: str) -> CaptionStyle:
    return STYLES.get(key, STYLES["clean_pop"])


# ---------------------------------------------------------------------
#  Box wale styles: default rotation mein nahi aate
#  Kaam: jin styles mein lafzon ke peeche rangeen dabba (chip) ya poori
#  line ke peeche box hai, wo "kaghaz ki parchi" jaise lagte hain. Ye
#  sirf tab chalte hain jab user khud style lock kare, ya source video
#  mein pehle se subtitles hon (tab cover box lagta hai, neeche dekho).
# ---------------------------------------------------------------------
def is_boxed(style: CaptionStyle) -> bool:
    return style.box or style.highlight == "chip"


NEW_STYLES = ["bold_outline", "karaoke_fill", "pop_word", "two_tone", "soft_shadow", "underline_sweep",
              "gold_glow", "big_two_outline"]
# Auto Mix: purane + naye bina dabbe wale styles; dabbe wale sirf kabhi kabhi (lagbhag 5 mein se 1 clip)
PLAIN_STYLES: list[str] = list(ROTATION_STYLES) + NEW_STYLES      # variety engine isi list se chunta hai
AUTO_BOXED: list[str] = ["word_chip", "pill_highlight", "soft_box", "word_chip_green"]
BOXED_SHARE = 0.2
ALL_PICKABLE: list[str] = PLAIN_STYLES + AUTO_BOXED   # campaign mein lock karne ke liye


# ---------------------------------------------------------------------
#  Cover box: source ke apne subtitles ke upar hamare captions
#  Kaam: jab source video mein pehle se likhe hue subtitles nazar aa
#  rahe hon, hamare captions ke peeche gehra (lagbhag solid) box lagta
#  hai, taake dono text aapas mein na milein aur parhna asaan rahe.
#  Style ka font, rang aur highlight wahi rehta hai.
# ---------------------------------------------------------------------
COVER_ALPHA = 0.10            # 0 = bilkul solid, 1 = gayab


def cover_version(style: CaptionStyle) -> CaptionStyle:
    highlight = "color" if style.highlight == "chip" else style.highlight
    return replace(style, box=True, box_color="#000000", box_alpha=COVER_ALPHA, outline=0, shadow=0,
                   highlight=highlight)


# ---------------------------------------------------------------------
#  Highlight rang ki rotation
#  Kaam: jo styles default peela (#FFD60A) highlight use karte hain, un
#  ka bolta hua lafz har clip mein alag rang le sakta hai. Apne khaas
#  rang wale styles (gold, ice blue, red) apna rang hi rakhte hain.
# ---------------------------------------------------------------------
DEFAULT_ACCENT = "#FFD60A"
ACCENTS = ("#FFD60A", "#FFD60A", "#3DDC84", "#4CC9F0", "#FF9F1C")    # peela zyada, phir hara, neela, narangi


def with_accent(style: CaptionStyle, accent: str) -> CaptionStyle:
    if not accent or style.highlight_color.upper() != DEFAULT_ACCENT or style.highlight not in ("color", "chip"):
        return style
    return replace(style, highlight_color=accent)


# ---------------------------------------------------------------------
#  Rangeen captions (professional palettes)
#  Kaam: sirf safed text nahi. Har clip ko ek palette milti hai:
#    keywords : safed text, har screen ka sab se ahem lafz (number, naam,
#               zor wala lafz) pakke rang mein, bolta lafz doosre rang mein
#    two_tone : screens bari bari safed aur rangeen
#    full     : poora text rangeen (peela / hara / neela), bolta lafz safed
#    white    : saada safed (kabhi kabhi, variety ke liye)
#  Rang sirf achhe parhne wale, mota kala outline hamesha.
# ---------------------------------------------------------------------
PALETTES: dict[str, str] = {          # har clip ka EK rang; viral shorts ke chalte hue rang (tez, saaf)
    "yellow": "#FFE11A", "green": "#2EE86B", "cyan": "#22C7FF", "orange": "#FF9500",
    "purple": "#A259FF", "pink": "#FF3D8B", "red": "#FF3333",
}
PALETTE_ORDER = ("yellow", "green", "cyan", "orange", "purple", "pink", "yellow", "green", "red")


def with_palette(style: CaptionStyle, palette: str) -> CaptionStyle:
    """Clip ka ek rang: bolta lafz / karaoke bharaai / goli (pill) sab isi rang mein, baaki text safed."""
    colour = PALETTES.get(palette)
    if not colour or style.speaker_colors:
        return style
    if style.key == "gold_glow":
        return style                                   # sunehra hi rehta hai
    if style.highlight == "none":
        # bina highlight wale: two tone ka ahem lafz palette ke rang mein, baaki saada safed
        return replace(style, keyword_color=colour if style.keyword_color else "")
    if style.highlight == "dim":
        return replace(style, fill_color=colour, keyword_color="", alt_color="")
    if style.highlight == "chip":
        ink = "#111111" if palette in ("yellow", "green", "cyan", "orange") else "#FFFFFF"
        return replace(style, highlight_color=colour, highlight_text_color=ink, keyword_color="", alt_color="")
    return replace(style, highlight_color=colour, keyword_color="", alt_color="")


def scaled_for(style: CaptionStyle, width: int, height: int) -> CaptionStyle:
    """Scale a 1080x1920 style for another frame size (e.g. 1920x1080)."""
    if (width, height) == (1080, 1920):
        return style
    factor = min(width / 1080, height / 1920) if height > width else height / 1920 * 1.6
    return replace(
        style,
        size=max(28, round(style.size * factor)),
        outline=round(style.outline * factor, 1),
        shadow=round(style.shadow * factor, 1),
        y_pct=0.80 if width > height else style.y_pct,
    )
