"""
=====================================================================
  CAPTIONS / FONTS + TEXT MEASURING
  Kaam: fonts load karna aur text ki chaurai naapna (captions frame se bahar na jayein).
  Captions are drawn by libass (inside ffmpeg). To place highlight
  chips, break lines by real pixel width and keep text inside the
  safe zone, we measure text ourselves with the same font files.
  ASS font size = font "height" (winAscent + winDescent), the same
  rule libass uses, so our numbers match what is drawn.
=====================================================================
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from app.core.paths import resource

FONT_DIR = resource("assets", "fonts")

# family name (as used in ASS) -> file
FONT_FILES = {
    "Montserrat Light": "MontserratLight.ttf",
    "Montserrat Bold": "MontserratBold.ttf",
    "Montserrat ExtraBold": "MontserratExtraBold.ttf",
    "Montserrat Black": "MontserratBlack.ttf",
    "Inter SemiBold": "InterSemiBold.ttf",
    "Inter Bold": "InterBold.ttf",
    "Poppins Bold": "PoppinsBold.ttf",
    "Anton": "Anton-Regular.ttf",
    "Bebas Neue": "BebasNeue-Regular.ttf",
}

# fonts downloaded by the online style pack: family -> full path
ONLINE_FONT_FILES: dict[str, Path] = {}


def font_path(family: str) -> Path:
    if family in FONT_FILES:
        return FONT_DIR / FONT_FILES[family]
    if family in ONLINE_FONT_FILES:
        return ONLINE_FONT_FILES[family]
    raise KeyError(f"Unknown caption font: {family}")


def font_dir_for(family: str) -> Path:
    """Folder libass must search for this family."""
    return font_path(family).parent


class _Metrics:
    def __init__(self, path: Path):
        from fontTools.ttLib import TTFont  # type: ignore
        font = TTFont(str(path), lazy=True)
        self.cmap = font.getBestCmap() or {}
        self.hmtx = font["hmtx"].metrics
        os2 = font["OS/2"]
        self.units_per_em = font["head"].unitsPerEm
        self.height_units = (os2.usWinAscent + os2.usWinDescent) or self.units_per_em
        self.ascent_units = os2.usWinAscent
        missing = self.cmap.get(ord("n")) or ".notdef"
        self.default_adv = self.hmtx.get(missing, (500, 0))[0]

    def advance(self, ch: str) -> int:
        glyph = self.cmap.get(ord(ch))
        return self.hmtx[glyph][0] if glyph in self.hmtx else self.default_adv


@lru_cache(maxsize=64)
def _metrics(family: str) -> _Metrics:
    return _Metrics(font_path(family))


def text_width(text: str, family: str, size: float, spacing: float = 0.0, scale_x: float = 1.0) -> float:
    """Width in pixels of `text` drawn at ASS font size `size`."""
    m = _metrics(family)
    units = sum(m.advance(ch) for ch in text)
    return (units * size / m.height_units + spacing * len(text)) * scale_x


def em_to_ass(family: str, em_px: float) -> float:
    """
    Designers give sizes in "em" pixels (like CSS font-size). ASS sizes
    are the font's full height, which is larger. Convert so a style
    written as 84 px really looks like 84 px type.
    """
    m = _metrics(family)
    return round(em_px * m.height_units / m.units_per_em, 1)
