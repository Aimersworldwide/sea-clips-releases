"""
=====================================================================
  QC / AUTO CHECK
  Kaam: har bani hui clip ki jaanch (size, length, audio, kaali / ruki tasveer).
  Every rendered clip is checked before it is counted:
    * file opens, right size (1080x1920 or 1920x1080), H.264 + AAC
    * duration matches the plan (within 0.35 s)
    * audio present and not silent
    * no long black section (> 1.0 s) that the source did not have
    * no frozen picture (> 3 s same frame) that the source did not have
      (a stuck decoder / broken cut; a still tweet in the source is fine)
  A failed clip is rendered once more with safer settings by the
  pipeline. If it fails again it goes to "Below 50" with the reason,
  so nothing broken is ever mixed with good clips.
=====================================================================
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from app.media.ffmpeg_tools import FFmpegError, ffmpeg_bin, run
from app.media.probe import probe

DURATION_TOLERANCE = 0.35
MAX_BLACK = 1.0
SILENT_DB = -60.0
MAX_FREEZE = 3.0
FREEZE_VF = "freezedetect=n=0.001:d=3"


@dataclass
class QCResult:
    ok: bool
    problems: list[str] = field(default_factory=list)
    duration: float = 0.0

    @property
    def summary(self) -> str:
        return "OK" if self.ok else "; ".join(self.problems)


def check_clip(path: Path, expected_size: tuple[int, int], expected_duration: float,
               source_range: tuple[Path, float, float] | None = None) -> QCResult:
    """source_range lets black that is already in the source be ignored."""
    problems: list[str] = []
    if not path.exists() or path.stat().st_size < 10_000:
        return QCResult(False, ["file missing or empty"])
    try:
        info = probe(path)
    except Exception as exc:              # noqa: BLE001 - any probe failure = broken file
        return QCResult(False, [f"file cannot be read ({exc})"])

    if (info.width, info.height) != expected_size:
        problems.append(f"size {info.width}x{info.height}, expected {expected_size[0]}x{expected_size[1]}")
    if info.video_codec != "h264":
        problems.append(f"video codec {info.video_codec}")
    if not info.has_audio:
        problems.append("no audio")
    if abs(info.duration - expected_duration) > DURATION_TOLERANCE:
        problems.append(f"length {info.duration:.2f}s, expected {expected_duration:.2f}s")

    # One decode pass: black frames + loudest sample.
    try:
        proc = run([ffmpeg_bin(), "-hide_banner", "-nostdin", "-i", str(path),
                    "-vf", f"blackdetect=d=0.5:pix_th=0.08,{FREEZE_VF}", "-af", "volumedetect",
                    "-f", "null", "-"], timeout=600)
        log_text = proc.stderr
    except FFmpegError as exc:
        return QCResult(False, problems + [f"decode error: {exc.tail[-200:]}"], info.duration)

    black = sum(float(d) for d in re.findall(r"black_duration:([\d.]+)", log_text))
    if black > MAX_BLACK and source_range:
        try:
            black -= source_black_seconds(*source_range)
        except FFmpegError:
            pass
    if black > MAX_BLACK:
        problems.append(f"{black:.1f}s of black picture")
    frozen = freeze_seconds(log_text, info.duration)
    if frozen > MAX_FREEZE and source_range:
        try:
            frozen -= source_freeze_seconds(*source_range)
        except FFmpegError:
            pass
    if frozen > MAX_FREEZE:
        problems.append(f"{frozen:.1f}s of frozen picture")
    m = re.search(r"max_volume:\s*(-?[\d.]+|-inf) dB", log_text)
    if info.has_audio and (not m or m.group(1) == "-inf" or float(m.group(1)) < SILENT_DB):
        problems.append("audio is silent")

    return QCResult(not problems, problems, info.duration)


def source_black_seconds(path: Path, start: float, end: float) -> float:
    """How much black the SOURCE already has in this range (not our fault)."""
    proc = run([ffmpeg_bin(), "-hide_banner", "-nostdin", "-ss", f"{start:.3f}", "-t", f"{end - start:.3f}",
                "-i", str(path), "-an", "-vf", "blackdetect=d=0.5:pix_th=0.08", "-f", "null", "-"], timeout=600)
    return sum(float(d) for d in re.findall(r"black_duration:([\d.]+)", proc.stderr))


def source_freeze_seconds(path: Path, start: float, end: float) -> float:
    """How long the SOURCE itself stands still in this range (a still image is not our fault)."""
    proc = run([ffmpeg_bin(), "-hide_banner", "-nostdin", "-ss", f"{start:.3f}", "-t", f"{end - start:.3f}",
                "-i", str(path), "-an", "-vf", FREEZE_VF, "-f", "null", "-"], timeout=600)
    return freeze_seconds(proc.stderr, end - start)


def freeze_seconds(log_text: str, total: float) -> float:
    """Ruki hui tasveer ke second (aakhir tak ruki ho to end ki line nahi aati, wo bhi gino)."""
    starts = [float(x) for x in re.findall(r"freeze_start:\s*([\d.]+)", log_text)]
    ends = [float(x) for x in re.findall(r"freeze_end:\s*([\d.]+)", log_text)]
    out = 0.0
    for i, a in enumerate(starts):
        b = ends[i] if i < len(ends) else total
        out += max(0.0, b - a)
    return out


# ---------------------------------------------------------------------
#  Title card ki aakhri jaanch: kisi chehre ke baal safed hisse ko na chhuen
#  Kaam: bane hue clip ke kuch frames mein chehre dhoondo (wahi YuNet jo
#  framing mein hai). Kisi bare chehre ke baal video ke upar wale kinare se
#  chipke hon to False: runner us clip ko title card ke baghair dobara banata hai.
# ---------------------------------------------------------------------
HAIR_OVER_BOX = 0.28     # YuNet ka dabba maathe tak; baal us se itna upar (naapa: ~0.18, gunjaish ke sath)
CARD_MIN_GAP = 12        # px (1920 frame pe) baal aur safed hisse ke beech kam se kam


def card_head_clear(path: Path, video_top: float, video_h: float = 1350.0, samples: int = 5) -> bool:
    """True jab title card clip mein har bara chehra (baal samet) video ke andar saaf jagah ke sath ho."""
    import subprocess

    import cv2
    import numpy as np

    from app.render.layout import MODEL
    info = probe(path)
    w, h = 540, 960
    scale = h / 1920.0
    det = cv2.FaceDetectorYN.create(str(MODEL), "", (w, h), 0.6, 0.3, 50)
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    for k in range(samples):
        t = info.duration * (k + 0.5) / samples
        raw = subprocess.run([ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-ss", f"{t:.3f}", "-i", str(path),
                              "-frames:v", "1", "-vf", f"scale={w}:{h}:flags=area", "-f", "rawvideo",
                              "-pix_fmt", "bgr24", "-"], capture_output=True, creationflags=flags).stdout
        if len(raw) < w * h * 3:
            continue
        frame = np.frombuffer(raw[:w * h * 3], np.uint8).reshape(h, w, 3)
        _, faces = det.detect(frame)
        for f in [] if faces is None else faces:
            fx, fy, fw, fh = (float(v) for v in f[:4])
            if fw < w * 0.06:                          # chhote chehre (tweet ki tasveer) ginti mein nahi
                continue
            centre = fy + fh / 2
            if not video_top * scale <= centre <= (video_top + video_h) * scale:
                continue
            hair = fy - HAIR_OVER_BOX * fh
            if hair < (video_top + CARD_MIN_GAP) * scale:
                return False
    return True
