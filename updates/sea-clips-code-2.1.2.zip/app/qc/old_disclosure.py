"""
=====================================================================
  QC / OLD DISCLOSURE        (video mein pehle se likha disclosure)
  Kaam: bani hui clip ke kuch frames parh kar (offline OCR, laptop par
  hi, kuch bahar nahi jata) dekhna ke video ka apna purana disclosure
  ("paid for by ...", "FPPC ID ...") kahin nazar to nahi aa raha.
    * neeche mila ya kahin nahi: hamari patti neeche (zaroorat ho to
      itni unchi ke purana poora chhup jaye)
    * upar mila: hamari patti upar, bilkul us ke upar; pehle check ke
      kisi ka sar / baal patti ke neeche na aaye
    * beech mein, ya upar aur neeche dono, ya patti sar ko chhuye:
      clip "Check" folder mein (kabhi deliver nahi)
  Aakhri jaanch: patti badalne ke baad clip dobara parhi jaati hai.
=====================================================================
"""
from __future__ import annotations

import logging
import re
import subprocess
import threading
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger("aimers.disclosure")

SAMPLES = 5                 # clip ke itne frames parhe jaate hain
EDGE = 0.36                 # frame ka upar / neeche ka itna hissa parha jata hai (beech mein chehra / captions)
PAD = 0.012                 # purane text ke neeche / upar itni gunjaish (frame ka hissa)
MAX_COVER = 0.30            # patti is se unchi nahi (warna video ka bara hissa chhupe): Check
SMALL_TEXT = 0.03           # is se chhota text ek frame mein bhi mile to ginti (captions is se bare hote hain)
FACE_MIN_W = 0.06           # chhote chehre (tweet ki tasveer) ginti mein nahi
HAIR_OVER_BOX = 0.28        # chehre ke dabbe se baal itna upar (check.py wala hi)
HEAD_GAP = 0.01             # patti aur baalon ke beech kam az kam itna faasla

KEYWORDS = ("paidforby", "paidfor", "fppc", "sponsoredby", "advertisement", "majorfunding", "authorizedby",
            "notauthorized", "committee", "adpaidfor", "politicalad", "disclosure")

_ocr = None
_ocr_lock = threading.Lock()


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9#]", "", (text or "").lower())


def available() -> bool:
    try:
        import rapidocr_onnxruntime  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def _reader():
    global _ocr
    with _ocr_lock:
        if _ocr is None:
            from rapidocr_onnxruntime import RapidOCR
            _ocr = RapidOCR()
        return _ocr


def strong_disclosure(text: str) -> bool:
    """Pakka disclosure ka lafz ("paid for by", "FPPC", "committee" ...)? Sirf hamare disclosure se milta
    julta text (jaise logo par "Protect Retirement & Life Savings") akela disclosure nahi."""
    t = _norm(text)
    return len(t) >= 4 and any(k in t for k in KEYWORDS)


def looks_like_disclosure(text: str, own: str = "") -> bool:
    """Ye likhai kisi disclosure ka hissa hai? (OCR kabhi spaces kha jata hai, is liye bina spaces)"""
    t = _norm(text)
    if len(t) < 4:
        return False
    if any(k in t for k in KEYWORDS):
        return True
    o = _norm(own)
    return len(t) >= 12 and bool(o) and t in o


@dataclass
class Box:
    y0: float                    # frame ka hissa (0 = upar)
    y1: float
    text: str
    frame: int

    @property
    def centre(self) -> float:
        return (self.y0 + self.y1) / 2


@dataclass
class Finding:
    boxes: list[Box] = field(default_factory=list)      # hamari patti ke bahar purane disclosure ki likhai
    heads: list[float] = field(default_factory=list)    # har bare chehre ke baalon ka upar wala kinara (frame ka hissa)

    @property
    def clean(self) -> bool:
        return not self.boxes


@dataclass
class Plan:
    action: str                  # "keep" (jaisa hai theek), "bottom", "top", "check"
    cover: float = 0.0           # patti kam az kam itni unchi (frame ka hissa)
    reason: str = ""


def _frames(path: Path, samples: int = SAMPLES):
    import numpy as np

    from app.media.ffmpeg_tools import ffmpeg_bin
    from app.media.probe import probe
    info = probe(path)
    w, h = info.display_size if hasattr(info, "display_size") else (info.width, info.height)
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    for k in range(samples):
        t = info.duration * (k + 0.5) / samples
        raw = subprocess.run([ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-ss", f"{t:.3f}", "-i", str(path),
                              "-frames:v", "1", "-vf", f"scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"],
                             capture_output=True, creationflags=flags).stdout
        if len(raw) >= w * h * 3:
            yield np.frombuffer(raw[:w * h * 3], np.uint8).reshape(h, w, 3)


def _heads(frame) -> list[float]:
    import cv2

    from app.render.layout import MODEL
    h, w = frame.shape[:2]
    sw, sh = 540, max(2, int(round(540 * h / w)))
    small = cv2.resize(frame, (sw, sh), interpolation=cv2.INTER_AREA)
    det = cv2.FaceDetectorYN.create(str(MODEL), "", (sw, sh), 0.6, 0.3, 50)
    _, faces = det.detect(small)
    out = []
    for f in [] if faces is None else faces:
        fx, fy, fw, fh = (float(v) for v in f[:4])
        if fw >= sw * FACE_MIN_W:
            out.append(max(0.0, (fy - HAIR_OVER_BOX * fh) / sh))
    return out


def scan(path: Path, own_text: str, strip: tuple[float, float], samples: int = SAMPLES) -> Finding:
    """Clip parho. strip = hamari patti (y0, y1, frame ka hissa): us ke andar ki likhai hamari apni hai."""
    ocr = _reader()
    found = Finding()
    seen: list[Box] = []
    for i, frame in enumerate(_frames(path, samples)):
        h = frame.shape[0]
        found.heads += _heads(frame)
        for top in (0.0, 1.0 - EDGE):
            a, b = int(top * h), int(min(1.0, top + EDGE) * h)
            res, _ = ocr(frame[a:b])
            for box, text, _score in res or []:
                ys = [float(p[1]) for p in box]
                y0, y1 = (a + min(ys)) / h, (a + max(ys)) / h
                if strip[0] - 0.005 <= (y0 + y1) / 2 <= strip[1] + 0.005:
                    continue                            # hamari apni patti
                if looks_like_disclosure(text, own_text):
                    seen.append(Box(round(y0, 4), round(y1, 4), text, i))
    # campaign ke logo / naam ki likhai hamare disclosure jaisi ho sakti hai: wo sirf tab gini jaye jab
    # paas (12% unchai ke andar) koi pakka disclosure lafz bhi ho
    strong = [b for b in seen if strong_disclosure(b.text)]
    seen = [b for b in seen if strong_disclosure(b.text) or any(abs(o.centre - b.centre) < 0.12 for o in strong)]
    # captions bade hote hain aur badalte rehte hain: bara text tab hi gino jab do frames mein usi jagah ho
    for b in seen:
        same = sum(1 for o in seen if o.frame != b.frame and abs(o.centre - b.centre) < 0.02)
        if (b.y1 - b.y0) <= SMALL_TEXT or same:
            found.boxes.append(b)
    return found


def plan(found: Finding, band: float, band_for=None) -> Plan:
    """Pehli clip (patti jahan thi) ki jaanch se faisla: patti kahan aur kitni unchi.
    band = abhi wali patti (frame ka hissa); band_for(cover) = itni jagah dhakni ho to patti ki asal
    unchai (upar text chhota ho kar purane disclosure ki jagah mein sama jaata hai)."""
    if found.clean:
        return Plan("keep")
    top = [b for b in found.boxes if b.centre < 0.5]
    bottom = [b for b in found.boxes if b.centre >= 0.5]
    words = "; ".join(sorted({b.text for b in found.boxes}))[:120]
    if top and bottom:
        return Plan("check", reason=f"old disclosure at the top and the bottom ({words})")
    if bottom:
        cover = 1.0 - min(b.y0 for b in bottom) + PAD
        if cover > MAX_COVER:
            return Plan("check", reason=f"old disclosure too high up to cover ({words})")
        return Plan("bottom", max(cover, band), f"old disclosure above the strip, strip made taller ({words})")
    need = max(b.y1 for b in top) + PAD
    cover = band_for(need) if band_for else max(need, band)
    if cover > MAX_COVER:
        return Plan("check", reason=f"old disclosure too low down to cover ({words})")
    if any(hair < cover + HEAD_GAP for hair in found.heads):
        return Plan("check", reason=f"old disclosure at the top, but a strip there would touch a head ({words})")
    return Plan("top", cover, f"old disclosure at the top, strip moved to the top ({words})")
