"""
=====================================================================
  QC / NUMBERS        (captions ke numbers screen se milao)
  Kaam: clip mein koi number bola gaya ho (48%, $1,684, 2030) to clip
  ke frames parh kar (offline OCR) dekhna ke screen par wahi number
  likha hai ya nahi:
    * screen par wahi number: pakka (shak khatam)
    * shak wala number aur screen par us jaisa number (aik harf ka
      farq, ya dobara sunne mein wahi suna): caption screen wala kar do
    * phir bhi pakka na ho: clip "Check" mein, wajah ke saath
  Campaign rule: "Claims must stay accurate to the talking points" -
  ghalat number = ghalat daawa.
=====================================================================
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger("aimers.numbers")

NUM = re.compile(r"\$?\d[\d,]*(?:\.\d+)?%?")
SAMPLES = 6
SCREEN_BOTTOM = 0.86         # frame ke is hisse se neeche likhe numbers (ticker, ghari, mausam) nahi gine jaate
MANY_DOUBTS = 3              # itne ya zyada shak wale (aam) lafz ek clip mein: Check


def canon(text: str) -> str:
    """'$1,684.' -> '$1684', '48 %' -> '48%', '96.5%' -> '96.5%'."""
    t = text.replace(",", "").replace(" ", "")
    m = NUM.search(t)
    if not m:
        return ""
    return m.group(0).rstrip(".")


def _digits(s: str) -> str:
    return re.sub(r"[^\d.]", "", s)


def close(a: str, b: str) -> bool:
    """Ek hi qism (%, $) aur sirf ek harf ka farq: '40%' / '48%', '$1640' / '$1684' nahi (do harf)."""
    if a.endswith("%") != b.endswith("%") or a.startswith("$") != b.startswith("$"):
        return False
    x, y = _digits(a), _digits(b)
    if len(x) != len(y) or not x:
        return False
    return sum(1 for p, q in zip(x, y) if p != q) == 1


def similar(a: str, b: str) -> bool:
    """Ek hi qism aur qareeb qareeb (10% tak): '$1640' / '$1684' - shak ke liye, khud theek karne ke liye nahi."""
    if a.endswith("%") != b.endswith("%") or a.startswith("$") != b.startswith("$"):
        return False
    try:
        x, y = float(_digits(a)), float(_digits(b))
    except ValueError:
        return False
    return x > 0 and y > 0 and x != y and abs(x - y) / max(x, y) <= 0.10


def screen_numbers(path: Path, start: float, end: float, samples: int = SAMPLES) -> set[str]:
    """Video ke is hisse mein screen par likhe numbers (OCR)."""
    from app.qc.old_disclosure import _reader, available
    if not available():
        return set()
    import subprocess

    import numpy as np

    from app.media.ffmpeg_tools import ffmpeg_bin
    from app.media.probe import probe
    sw, sh = probe(path).display_size
    w = 1080 if sw >= sh else 720
    h = max(2, int(round(w * sh / sw / 2)) * 2)
    ocr = _reader()
    found: set[str] = set()
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    span = max(0.2, end - start)
    for k in range(samples):
        t = start + span * (k + 0.5) / samples
        raw = subprocess.run([ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-ss", f"{t:.3f}", "-i", str(path),
                              "-frames:v", "1", "-vf", f"scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"],
                             capture_output=True, creationflags=flags).stdout
        if len(raw) < w * h * 3:
            continue
        res, _ = ocr(np.frombuffer(raw[:w * h * 3], np.uint8).reshape(h, w, 3))
        for box, text, _score in res or []:
            ys = [float(pt[1]) for pt in box] if box is not None else [0.0]
            if sum(ys) / len(ys) > h * SCREEN_BOTTOM:
                continue                    # sab se neeche: news ticker / ghari / mausam ("99°"), clip ki baat nahi
            if "°" in text or re.search(r"\d\s*(?:am|pm)\b", text.lower()):
                continue                    # darja hararat, waqt
            for m in NUM.finditer(text.replace(" ", "")):
                c = canon(m.group(0))
                if c:
                    found.add(c)
    return found


# ---------------------------------------------------------------------
#  Lafzon wale numbers ("ninety seven", "three percent") ki ginti
#  Kaam: dobara sunne mein "97" aaya aur pehli dafa "ninety seven": dono
#  aik hi number hain, shak nahi.
# ---------------------------------------------------------------------
_UNITS = {w: i for i, w in enumerate("zero one two three four five six seven eight nine ten eleven twelve "
                                      "thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split())}
_TENS = {w: 10 * i for i, w in enumerate("_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()) if i >= 2}
_SCALES = {"hundred": 100, "thousand": 1000, "million": 1_000_000, "billion": 1_000_000_000}


def _tok(text: str) -> str:
    return re.sub(r"[^a-z0-9%$.]", "", (text or "").lower().replace("-", ""))


def word_value(tokens: list[str]) -> float | None:
    """['ninety', 'seven'] -> 97, ['three'] -> 3, ['2', 'million'] -> 2000000. Number na ho to None."""
    total, cur, seen = 0.0, 0.0, False
    for t in tokens:
        t = t.rstrip(".")
        if t in ("percent", "%", "a"):
            continue
        if t == "and":
            if cur < 100 and total == 0:
                return None                                # "three and four" do alag numbers hain
            continue
        if re.fullmatch(r"\$?\d+(?:\.\d+)?%?", t):
            cur += float(t.strip("$%"))
        elif t in _UNITS:
            cur += _UNITS[t]
        elif t in _TENS:
            cur += _TENS[t]
        elif t in _SCALES:
            cur = max(cur, 1.0) * _SCALES[t]
            if _SCALES[t] >= 1000:
                total, cur = total + cur, 0.0
        else:
            return None
        seen = True
    return total + cur if seen else None


def _number_run(words, i: int) -> list:
    """Lafz i ke aas paas lagataar number wale lafz (jumla ek hi number)."""
    from app.transcribe.recheck import is_number

    def ok(w):
        t = _tok(w.text)
        return is_number(w.text) or t in ("percent", "and") or bool(re.fullmatch(r"\$?\d[\d,.]*%?", t))
    a = b = i
    while a > 0 and ok(words[a - 1]) and i - a < 6:
        a -= 1
    while b + 1 < len(words) and ok(words[b + 1]) and b - i < 6:
        b += 1
    return words[a:b + 1]


def same_number(words, i: int) -> bool:
    """Lafz i ka shak sirf likhne ka farq hai? ('ninety' + 'seven' = '97', 'three' = '3%')"""
    alt = _tok(words[i].doubt)
    alt_v = word_value([alt]) if alt else None
    if alt_v is None:
        return False
    if word_value([_tok(words[i].text)]) == alt_v:
        return True
    run = _number_run(words, i)
    k = next(n for n, w in enumerate(run) if w is words[i])
    # sirf woh hisse jin mein YEHI lafz ho ("ninety seven" = 97); "twenty two" ka "two" kabhi 20 nahi
    for a in range(0, k + 1):
        for b in range(k + 1, len(run) + 1):
            v = word_value([_tok(w.text) for w in run[a:b]])
            if v is not None and v == alt_v:
                return True
    return False


@dataclass
class NumberCheck:
    fixed: list[tuple[str, str]] = field(default_factory=list)     # (pehle, ab)
    unsure: list[str] = field(default_factory=list)                # ab bhi pakke nahi (Check ki wajah)

    @property
    def problem(self) -> str:
        if not self.unsure:
            return ""
        return "captions: please check " + ", ".join(self.unsure[:4])


def check_words(words, screen: set[str], names: list[str] | None = None) -> NumberCheck:
    """
    words: clip ke lafz (Word, jagah par badalte hain). screen: screen par likhe numbers.
    Shak wale numbers screen se theek / pakke; baaki shak NumberCheck.unsure mein.
    """
    from app.transcribe.recheck import is_number
    out = NumberCheck()
    plain_doubts: list[str] = []
    for i, w in enumerate(words):
        if w.doubt and (is_number(w.text) or _tok(w.text) == "percent") and same_number(words, i):
            w.doubt = ""                                   # "ninety seven" aur "97" aik hi number
            continue
        num = canon(w.text)
        if num:
            if num in screen:
                w.doubt = ""                                   # screen par wahi likha: pakka
                continue
            alt = canon(w.doubt) if w.doubt else ""
            match = [s for s in screen if s == alt] or [s for s in screen if close(num, s)]
            if len(match) == 1 and (w.doubt or alt):
                new = _swap(w.text, match[0])
                out.fixed.append((w.text, new))
                w.text, w.doubt = new, ""
                continue
            near = match or [x for x in screen if similar(num, x)]
            if near and not w.doubt:
                out.unsure.append(f"'{w.text.strip('.,')}' (screen shows {near[0]})")    # suna aur likha alag
                continue
            if w.doubt:
                out.unsure.append(f"'{w.text.strip('.,')}' (also heard '{w.doubt}')")
        elif w.doubt and is_number(w.text):
            out.unsure.append(f"'{w.text.strip('.,')}' (also heard '{w.doubt}')")
        elif w.doubt:
            plain_doubts.append(f"'{w.text.strip('.,')}' (also heard '{w.doubt}')")
    # aam lafzon ka shak (28 Oct): sirf naamon ka shak Check bhejta hai; baaki aam lafz (accent) nahi
    if names:
        keys = {t.lower() for n in names for t in re.findall(r"[A-Za-z]{3,}", n)}
        # naam ka shak: likha ya dobara suna lafz naam ho ("Kurt" / "Kirk" dono soorat)
        out.unsure += [d for d in plain_doubts
                       if any(x.lower().strip(".,!?") in keys for x in re.findall(r"'([^']*)'", d))]
    return out


def _swap(text: str, number: str) -> str:
    """Lafz ka number badlo, aage peeche ka nishaan (. , ?) wahi rahe."""
    m = re.search(r"\$?\d[\d,]*(?:\.\d+)?%?", text)
    if not m:
        return number
    old = m.group(0)
    new = number
    if "," in old and "," not in new and "." not in new:
        digits = new.lstrip("$").rstrip("%")
        new = ("$" if new.startswith("$") else "") + f"{int(digits):,}" + ("%" if new.endswith("%") else "")
    return text[:m.start()] + new + text[m.end():]
