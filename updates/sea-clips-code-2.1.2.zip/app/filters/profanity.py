"""
=====================================================================
  FILTERS / PROFANITY, HATE, THREATS, VIP RESPECT
  Kaam: gaaliyan beep, dhamkiyan wala moment skip, VIP ki izzat.
  Policy (from research + owner decisions):
    slurs (any protected group) ...... beep + mask in captions
    strong profanity ................. beep + mask
    moderate profanity ............... beep (off when level = "off")
    mild words (hell, damn) .......... allowed
    abuse aimed at listed VIP names .. beep the insult word
    threats / calls for violence ..... moment is skipped (no clip)
    long abusive run (> 3 words or
      > 1.5 s) ....................... moment is skipped
    more than `max_beeps` beeps ...... moment is skipped
  Normal criticism is never touched.
=====================================================================
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.core.paths import resource
from app.transcribe.models import Word

WORDLIST_DIR = resource("app", "filters", "wordlists")


def _load_list(name: str) -> list[str]:
    path = WORDLIST_DIR / name
    if not path.exists():
        return []
    lines = [ln.strip() for ln in path.read_text(encoding="utf-8").splitlines()]
    return [ln for ln in lines if ln and not ln.startswith("#")]


def _compile(patterns: list[str]) -> re.Pattern | None:
    if not patterns:
        return None
    return re.compile(r"^(?:" + "|".join(patterns) + r")$", re.IGNORECASE)


# Patterns are regex fragments matched against one cleaned word.
STRONG = _compile(_load_list("strong.txt"))
MODERATE = _compile(_load_list("moderate.txt"))
MILD = _compile(_load_list("mild.txt"))            # strict only
SLURS = _compile(_load_list("slurs.txt"))
INSULTS = _compile(_load_list("insults.txt"))
THREATS = [re.compile(p, re.IGNORECASE) for p in _load_list("threats.txt")]

DEFAULT_VIPS = _load_list("vip_names.txt")

MAX_RUN_WORDS = 3
MAX_RUN_SECONDS = 1.5


@dataclass
class FilterResult:
    beep_indexes: list[int] = field(default_factory=list)  # word indexes to beep + mask
    skip: bool = False                                        # moment must not become a clip
    reason: str = ""

    @property
    def beep_count(self) -> int:
        """Adjacent beeped words count as one beep (one bleep sound)."""
        count, last = 0, -10
        for idx in self.beep_indexes:
            if idx != last + 1:
                count += 1
            last = idx
        return count


def _runs(indexes: list[int]) -> list[list[int]]:
    """[3,4,5,9,10] -> [[3,4,5],[9,10]]"""
    runs: list[list[int]] = []
    for idx in indexes:
        if runs and idx == runs[-1][-1] + 1:
            runs[-1].append(idx)
        else:
            runs.append([idx])
    return runs


def _norm(text: str) -> str:
    return "".join(ch for ch in text.lower() if ch.isalnum() or ch == "'").strip("'")


def _custom(words: list[str]) -> re.Pattern | None:
    """Single banned words (exact word, any case)."""
    cleaned = [re.escape(_norm(w)) for w in words if w.strip() and len(w.split()) == 1 and _norm(w)]
    return _compile(cleaned)


def _phrases(words: list[str]) -> list[list[str]]:
    """Banned phrases of 2+ words, e.g. "shut up" -> ["shut", "up"]."""
    out = []
    for w in words:
        parts = [_norm(p) for p in w.split()]
        parts = [p for p in parts if p]
        if len(parts) >= 2:
            out.append(parts)
    return out


def analyze(
    words: list[Word],
    level: str = "standard",
    banned_words: list[str] | None = None,
    vip_names: list[str] | None = None,
    max_beeps: int = 3,
) -> FilterResult:
    """Decide which words to beep, or whether the whole moment must be skipped."""
    result = FilterResult()
    custom = _custom(banned_words or [])
    vips = {name.split()[-1].strip().lower() for name in (vip_names or []) if name.strip()}
    text = " ".join(w.clean for w in words)

    # 1) Threats / calls for violence -> skip whole moment.
    for pattern in THREATS:
        if pattern.search(text):
            result.skip, result.reason = True, "threat"
            return result

    # 2) Word by word decisions.
    clean = [w.clean for w in words]
    for i, word in enumerate(clean):
        if not word:
            continue
        flagged = False
        if SLURS and SLURS.match(word):
            flagged = True
        elif STRONG and STRONG.match(word) and level != "off":
            flagged = True
        elif MODERATE and MODERATE.match(word) and level in ("standard", "strict"):
            flagged = True
        elif MILD and MILD.match(word) and level == "strict":
            flagged = True
        elif custom and custom.match(word):
            flagged = True
        elif INSULTS and INSULTS.match(word) and vips:
            # Insult within 4 words of a VIP name -> respect filter.
            window = clean[max(0, i - 4): i + 5]
            if any(v in window for v in vips):
                flagged = True
        if flagged:
            result.beep_indexes.append(i)

    # 2b) Banned phrases ("shut up"): every word of the phrase is beeped.
    for phrase in _phrases(banned_words or []):
        n = len(phrase)
        for i in range(len(clean) - n + 1):
            if clean[i:i + n] == phrase:
                result.beep_indexes.extend(range(i, i + n))
    result.beep_indexes = sorted(set(result.beep_indexes))

    # 3) Long abusive run -> skip (beeping it would wreck the clip).
    for run in _runs(result.beep_indexes):
        seconds = words[run[-1]].end - words[run[0]].start
        if len(run) > MAX_RUN_WORDS or seconds > MAX_RUN_SECONDS:
            result.skip, result.reason = True, "long_abuse"
            return result

    # 4) Too many beeps -> skip.
    if result.beep_count > max_beeps:
        result.skip, result.reason = True, "too_many_beeps"
    return result


def mask_word(text: str) -> str:
    """'fucking,' -> 'f******,' : first letter kept, punctuation kept."""
    core = text.rstrip(".,!?;:\"')")
    trail = text[len(core):]
    lead = core[:1]
    return lead + "*" * max(2, len(core) - 1) + trail
