"""
=====================================================================
  FILTERS / TOPIC GUARD        (campaign ke topic ko bura na dikhao)
  Kaam: jis jumle mein campaign ke topic (jaise "Prop 42") ke khilaf
  baat ho ("No on 42", "vote no", "oppose Prop 42", "Prop 42 is a
  scam" ...), us jumle wala koi clip na bane. Rules: "Cannot show
  PRO 42 in a negative light".
    * seedhe khilaf jumle: "no on 42", "vote no", "against Prop 42"
    * topic ka naam + bura lafz usi jumle mein: "Prop 42 is a bad idea"
    * campaign ke apne lafz (jo user likhe) bhi
  Sirf offline lafzon se: bolne wale ka andaaz (taunt) nahi samajhta,
  is liye ehtiyat zyada: shak ho to clip na banao.
=====================================================================
"""
from __future__ import annotations

import re

# topic se PEHLE ye lafz (2 lafz ke andar): "oppose Prop 42", "vote no on Prop 42", "stop Prop 42"
BEFORE = ("oppose", "opposes", "opposed", "opposing", "against", "reject", "rejects", "defeat", "stop", "kill",
          "vote no on", "no on", "don't support", "do not support", "won't support", "fight", "fighting", "repeal")
# topic ke BAAD (4 lafz ke andar) ye baat: "Prop 42 is a scam", "Prop 42 would hurt seniors"
AFTER = ("bad", "worse", "worst", "terrible", "awful", "horrible", "scam", "fraud", "lie", "lies", "misleading",
         "dangerous", "harmful", "hurts", "hurt", "risky", "reckless", "flawed", "wrong", "mistake", "disaster",
         "waste", "wasteful", "fails", "failed", "failure", "costly", "rip off", "ripoff", "con", "sham", "shady",
         "corrupt", "bad idea", "won't work", "will not work", "doesn't work", "does not work", "should not pass",
         "shouldn't pass", "a trap", "a trick", "unfair")
# topic ka naam na bhi ho, ye jumle phir bhi campaign ke khilaf hain
ALWAYS_BAD = (r"\bvote no\b", r"\bno on (?:prop(?:osition)?\.? ?)?\d+", r"\bvote against\b")


def _terms(topic: str) -> list[str]:
    """'Prop 42, Yes on 42' -> ['prop 42', 'yes on 42', 'proposition 42', 'prop. 42']."""
    out: list[str] = []
    for part in re.split(r"[,;\n]", topic or ""):
        t = part.strip().lower()
        if not t:
            continue
        out.append(t)
        m = re.search(r"\bprop(?:osition)?\.?\s*(\d+)\b", t)
        if m:
            out += [f"prop {m.group(1)}", f"proposition {m.group(1)}", f"prop. {m.group(1)}"]
    return list(dict.fromkeys(out))


def _alt(items) -> str:
    return "|".join(map(re.escape, sorted(set(items), key=len, reverse=True)))


class TopicGuard:
    def __init__(self, topic: str, extra: str = ""):
        terms = _terms(topic)
        self.always_re = re.compile("|".join(ALWAYS_BAD))
        extra_words = [w.strip().lower() for w in re.split(r"[,;\n]", extra or "") if w.strip()]
        self.extra_re = re.compile(r"(?<![a-z])(?:" + _alt(extra_words) + r")(?![a-z])") if extra_words else None
        if terms:
            topic_re = r"(?:" + _alt(terms) + r")(?![a-z0-9])"
            gap = r"(?:\s+\S+){0,2}?\s+"                       # do lafz tak beech mein
            self.before_re = re.compile(r"(?<![a-z])(?:" + _alt(BEFORE) + r")" + gap + topic_re)
            self.after_re = re.compile(topic_re + r"(?:\s+\S+){0,4}?\s+(?:" + _alt(AFTER) + r")(?![a-z])")
        else:
            self.before_re = self.after_re = None

    def negative(self, sentence: str) -> bool:
        """Ye jumla campaign ke topic ke khilaf hai?"""
        t = re.sub(r"\s+", " ", (sentence or "").lower().replace("\u2019", "'"))
        t = re.sub(r"[^a-z0-9' .]", " ", t)
        t = re.sub(r"\s+", " ", t)
        if self.always_re.search(t) or (self.extra_re is not None and self.extra_re.search(t)):
            return True
        return bool(self.before_re is not None and (self.before_re.search(t) or self.after_re.search(t)))

    def spans(self, words) -> list[tuple[float, float]]:
        """Khilaf jumlon ka waqt (sec): in ko chhoone wala koi clip nahi banta."""
        if not words:
            return []
        from app.select.sentences import split_sentences
        out = []
        for s in split_sentences(words):
            text = " ".join(w.text for w in words[s.first:s.last + 1])
            if self.negative(text):
                out.append((words[s.first].start, words[s.last].end))
        return out
