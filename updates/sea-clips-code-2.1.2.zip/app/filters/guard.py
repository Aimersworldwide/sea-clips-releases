"""
=====================================================================
  FILTERS / MAIN PERSON PROTECTION GUARD   (har campaign ke liye)
  Kaam: campaign jis shakhs (ya shakhsiyat) ke baare mein hai, us ke
  khilaaf baatein clip mein na jayein. Ye kisi ek campaign ke liye
  nahi; jo bhi naam campaign mein "main person" hain, un sab pe chalta
  hai. Clip banne se pehle (moment chunte waqt) chalta hai, isliye
  render quality pe koi asar nahi.

  Naam na ho aur "main speaker khud pehchano" On ho: main speaker video
  se (chehre) pehchana jata hai; tab "you / your" aur "he / him" jab
  koi AUR bol raha ho, hamle ka nishana gine jate hain.

  Qaide (ROADMAP section 7 + 13):
    * Hamla = bura lafz (liar, idiot, destroyed ...) us shakhs ke naam
      ke qareeb, ya "you / your" ke qareeb jab koi AUR bol raha ho.
      Us ki apni baat (wo kisi aur ko bura kahe) theek hai.
    * Chhota hamla (~2 second tak): sirf bura lafz beep + *** captions.
    * Lamba hamla: wo jumla clip se kaat diya jata hai, agar clip phir
      bhi poore jumlon ka aur minimum length ka rahe.
    * Kaatna mumkin na ho, hamla clip ka shuru / aakhri jumla ho, ya
      hamla hi clip ki asal baat ho: moment nahi banta.
    * Clip hamesha main person pe khatam hota hai (aakhri jumla us ka),
      jab video mein us ki shakal se pata chal sake.
    * Source ka title ("X Gets DESTROYED") ho to sakhti zyada: he / him
      bhi gine jate hain aur shak wale clips "Check" folder mein.
    * Hook line aur file title mein kabhi bure ya khatarnaak lafz nahi.
=====================================================================
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.filters.profanity import STRONG, SLURS, _load_list
from app.transcribe.models import Word

# ---------------------------------------------------------------------
#  Lafzon ki lists (wordlists/guard_negative.txt, hook_blocked.txt)
# ---------------------------------------------------------------------
NEGATIVE = re.compile(r"^(?:" + "|".join(_load_list("guard_negative.txt")) + r")$", re.IGNORECASE)
HOOK_BLOCKED = re.compile(r"^(?:" + "|".join(_load_list("hook_blocked.txt")) + r")$", re.IGNORECASE)

SECOND_PERSON = {"you", "your", "youre", "you're", "yours", "ya"}
THIRD_PERSON = {"he", "him", "his", "he's", "hes"}
NEGATORS = {"not", "never", "isn't", "isnt", "wasn't", "wasnt", "aren't", "arent", "no"}

NEAR = 5                  # bura lafz naam se itne lafz door tak "us pe" gina jata hai
NEAR_STRICT = 8
SHORT_ATTACK = 2.0        # is se chhota hamla beep, bara kaata jata hai
MAX_CUT_SHARE = 0.35      # clip ka itna hissa kaatna pare to moment hi chhor do
END_ON_PERSON = 0.5       # aakhri jumle ke itne lafz main person ke hon


# ---------------------------------------------------------------------
#  Nateeja (har window ke liye)
# ---------------------------------------------------------------------
@dataclass
class GuardResult:
    skip: bool = False
    reason: str = ""
    beep: list[int] = field(default_factory=list)      # window ke andar lafzon ke index
    cut: list[int] = field(default_factory=list)       # ye lafz (poore jumle) clip se kaat do
    check: bool = False                                # shak: "Check" folder
    attacks: list[tuple[float, float]] = field(default_factory=list)   # source seconds (reaction shot nahi)
    note: str = ""


# ---------------------------------------------------------------------
#  Naam ke tukre: "Ben Shapiro" -> {"ben", "shapiro", "shapiros"}
# ---------------------------------------------------------------------
def name_tokens(names: list[str]) -> set[str]:
    out: set[str] = set()
    for n in names:
        for part in re.split(r"[\s\-]+", n.lower()):
            part = "".join(ch for ch in part if ch.isalnum())
            if len(part) >= 3:
                out |= {part, part + "s"}
    return out


# ---------------------------------------------------------------------
#  Source title sakht hai? ("Gets DESTROYED", "Owned", ...)
# ---------------------------------------------------------------------
def hostile_title(title: str, names: list[str]) -> bool:
    words = [w for w in re.split(r"[^a-z']+", (title or "").lower()) if w]
    if not words or not any(NEGATIVE.match(w) for w in words):
        return False
    tokens = name_tokens(names)
    return any(w in tokens for w in words) or not tokens


# ---------------------------------------------------------------------
#  Hook / title saaf hai?
# ---------------------------------------------------------------------
def hook_is_clean(text: str, names: list[str] | None = None) -> bool:
    words = ["".join(ch for ch in w.lower() if ch.isalnum() or ch == "'").strip("'") for w in text.split()]
    words = [w for w in words if w]
    for w in words:
        if HOOK_BLOCKED.match(w) or (STRONG and STRONG.match(w)) or (SLURS and SLURS.match(w)):
            return False
    tokens = name_tokens(names or [])
    if tokens and any(w in tokens for w in words) and any(NEGATIVE.match(w) for w in words):
        return False
    return True


# ---------------------------------------------------------------------
#  Guard banao: runner har campaign ke liye ek dafa banata hai
#    names   : main people ke naam
#    his_at  : function(seconds) -> 0..1, main person us waqt screen pe
#              aur bol raha hai? (None = video se pata nahi chal sakta)
#    strict  : source title sakht hai
# ---------------------------------------------------------------------
class Guard:
    def __init__(self, names: list[str], his_at=None, strict: bool = False, min_len: float = 0.0,
                 auto: bool = False):
        self.tokens = name_tokens(names)
        self.auto = auto and his_at is not None      # naam nahi, main speaker chehre se (video se pehchana)
        self.his_at = his_at
        self.strict = strict
        self.min_len = min_len

    def _his(self, w: Word) -> bool | None:
        """True = main person bol raha (bara chehra), False = koi aur, None = pata nahi."""
        if self.his_at is None:
            return None
        v = self.his_at((w.start + w.end) / 2)
        return True if v >= 1.0 else False if v <= 0.0 else None

    def _on_screen(self, w: Word) -> bool:
        return self.his_at is not None and self.his_at((w.start + w.end) / 2) >= 0.5

    def _targets(self, clean: list[str], words: list[Word]) -> list[int]:
        out = []
        for i, c in enumerate(clean):
            if c in self.tokens:
                out.append(i)
            elif c in SECOND_PERSON and self._his(words[i]) is False:
                out.append(i)                               # koi aur us se baat kar raha hai
            elif (self.strict or self.auto) and c in THIRD_PERSON and self._his(words[i]) is False:
                out.append(i)
        return out

    def check(self, words: list[Word], sentences: list[tuple[int, int]]) -> GuardResult:
        """
        words: window ke lafz. sentences: window ke jumle (first, last)
        index, window ke andar. Faisla: beep / cut / skip / check.
        """
        res = GuardResult()
        if not words or not (self.tokens or self.auto):
            return res
        clean = [w.clean for w in words]
        targets = self._targets(clean, words)
        near = NEAR_STRICT if self.strict else NEAR
        hits: list[tuple[int, int]] = []                # (bura lafz, nishana) index
        for i, c in enumerate(clean):
            if not c or not NEGATIVE.match(c):
                continue
            if i > 0 and clean[i - 1] in NEGATORS:
                continue                                 # "you're not wrong"
            if self._his(words[i]) is True:
                continue                                 # wo khud bol raha hai (kisi aur ke baare mein)
            t = [k for k in targets if abs(k - i) <= near]
            if t:
                hits.append((i, min(t, key=lambda k: abs(k - i))))
        if hits:
            res = self._decide(words, sentences, hits)
        if not res.skip and self.his_at is not None:
            res = self._ending(words, sentences, res)
        return res

    # --- beep, cut ya skip -------------------------------------------
    def _decide(self, words, sentences, hits) -> GuardResult:
        """
        Hamla jumle ke hisaab se: jis jumle mein hamla ho, us ke saare bure
        lafz hamle ka hissa. Ek bura lafz aur ~2 s tak = beep. Zyada bure
        lafz ya lamba = poora jumla kaato (shuru / aakhri jumla = skip).
        """
        res = GuardResult()
        clean = [w.clean for w in words]
        groups: dict[int, list[tuple[int, int]]] = {}
        for i, t in hits:
            k = next((k for k, (f, l) in enumerate(sentences) if f <= i <= l), -1)
            groups.setdefault(k, []).append((i, t))
        cut: set[int] = set()
        for k, pairs in sorted(groups.items()):
            f, l = sentences[k] if k >= 0 else (min(min(p) for p in pairs), max(max(p) for p in pairs))
            negs = sorted({j for j in range(f, l + 1) if clean[j] and NEGATIVE.match(clean[j])
                           and not (j > 0 and clean[j - 1] in NEGATORS) and self._his(words[j]) is not True})
            a = min(min(p) for p in pairs)
            b = max(max(max(p) for p in pairs), negs[-1] if negs else 0)
            res.attacks.append((words[a].start, words[b].end))
            if len(negs) <= 1 and words[b].end - words[a].start <= SHORT_ATTACK:
                res.beep += [i for i, _ in pairs]
            elif k == 0 or k == len(sentences) - 1 or k < 0:
                res.skip, res.reason = True, "guard_attack"
                return res
            else:
                cut.update(range(f, l + 1))
        spans = res.attacks
        res.beep = sorted(set(res.beep))
        res.cut = sorted(cut)
        total = words[-1].end - words[0].start
        if cut:
            lost = sum(words[i].end - words[i].start for i in cut)
            gaps = sum(max(0.0, words[i + 1].start - words[i].end) for i in cut if i + 1 < len(words))
            if (lost + gaps) / max(total, 0.1) > MAX_CUT_SHARE or total - lost - gaps < self.min_len:
                res.skip, res.reason = True, "guard_attack"
                return res
        if len(spans) >= 3:
            res.skip, res.reason = True, "guard_attack"           # hamla hi clip ki baat hai
            return res
        res.check = self.strict and bool(spans)
        res.note = f"protection: {len(res.beep)} beeped, {len(cut)} words cut"
        return res

    # --- clip main person pe khatam ho -------------------------------
    def _ending(self, words, sentences, res: GuardResult) -> GuardResult:
        if not sentences:
            return res
        f, l = sentences[-1]
        last = [w for w in words[f:l + 1] if w.clean]
        if not last:
            return res
        # chehre ki timeline har second ek dafa naapi jaati hai: aas paas ka second bhi gino (camera cut ke beech)
        def near(w):
            mid = (w.start + w.end) / 2
            return self.his_at is not None and max(self.his_at(mid), self.his_at(mid - 0.6), self.his_at(mid + 0.6)) >= 0.5
        his = sum(1 for w in last if near(w)) / len(last)
        if his < END_ON_PERSON:
            res.skip, res.reason = True, "guard_ending"
        return res
