"""
=====================================================================
  APP ENTRY POINT
  Kaam: app shuru karna (window, settings, database).
  Start order: logging -> settings -> language -> database -> fonts
  -> theme -> window. Any startup crash is written to the log and
  shown in a plain message box instead of vanishing silently.
=====================================================================
"""
from __future__ import annotations

import sys
import traceback


def _show_unexpected_errors(parent) -> None:
    """
    Any error inside a button handler is logged AND shown, never silent.
    Errors on background threads arrive through the worker's signals.
    """
    import threading
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QMessageBox
    from app.core.i18n import t
    previous = sys.excepthook

    def hook(exc_type, exc, tb):
        previous(exc_type, exc, tb)                       # writes the log
        if threading.current_thread() is not threading.main_thread():
            return
        text = f"{t('msg.error')}:\n{exc}\n\n{t('msg.error_hint')}"
        QTimer.singleShot(0, lambda: QMessageBox.warning(parent, " ", text))
    sys.excepthook = hook


def main() -> int:
    from app.core.logging_setup import get_logger, setup_logging
    setup_logging()
    log = get_logger("main")

    from PySide6.QtCore import Qt
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QApplication, QMessageBox

    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    try:
        from app.core.config import AppSettings
        from app.core.db import Database
        from app.core.i18n import set_language
        from app.core.paths import resource
        from app.media.ffmpeg_tools import has_nvidia_gpu
        from app.ui import theme as T
        from app.ui.context import AppContext
        from app.ui.main_window import MainWindow
        from app.version import APP_NAME, COMPANY, VERSION

        app.setApplicationName(APP_NAME)
        app.setOrganizationName(COMPANY)
        app.setApplicationVersion(VERSION)
        app.setWindowIcon(QIcon(str(resource("assets", "brand", "app_icon.png"))))
        if sys.platform == "win32":   # own taskbar icon instead of python's
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("AIMERS.AutoClippingTool")

        # Only one copy at a time (two copies could make duplicate clips).
        from PySide6.QtCore import QLockFile
        from app.core.paths import app_data_dir
        lock = QLockFile(str(app_data_dir() / "app.lock"))
        lock.setStaleLockTime(0)
        if not lock.tryLock(100):
            QMessageBox.information(None, APP_NAME, "SEA CLIPS Auto Clipper is already open.")
            return 0

        settings = AppSettings.validate(AppSettings.load())
        set_language(settings.language)
        T.load_fonts()
        app.setFont(T.font(10))
        app.setStyleSheet(T.QSS)
        db = Database()
        try:
            gone = db.sync_missing_files()             # haath se delete hue clips: Deleted history mein
            if gone:
                log.info("%d clips were deleted outside the app; moved to the Deleted history", gone)
        except Exception as exc:  # noqa: BLE001 - start kabhi na ruke
            log.warning("folder sync skipped: %s", exc)
        ctx = AppContext(settings, db, has_nvidia_gpu())
        log.info("%s %s starting (GPU: %s)", APP_NAME, VERSION, ctx.has_gpu)
        window = MainWindow(ctx)
        window.show()
        _show_unexpected_errors(window)
        # naye zaroori hisse missing hon to app ke andar hi Update window (khud install)
        from PySide6.QtCore import QTimer
        from app.ui.package_update import check_and_update
        QTimer.singleShot(400, lambda: check_and_update(window))
        if AppSettings.RESET_NOTICE:
            from app.core.i18n import t
            QMessageBox.information(window, APP_NAME, t("msg.settings_reset"))

        # Keep the link downloader fresh (YouTube changes often). Once a day,
        # in the background, never blocks the window.
        import threading
        from app.core.paths import cache_dir
        from app.media.download import self_update
        threading.Thread(target=self_update, args=(cache_dir(),), daemon=True).start()
        return app.exec()
    except Exception:  # noqa: BLE001
        log.exception("Startup failed")
        QMessageBox.critical(None, "SEA CLIPS Auto Clipper",
                             "The app could not start.\n\n" + traceback.format_exc()[-1500:])
        return 1


if __name__ == "__main__":
    sys.exit(main())
