"""
=====================================================================
  MEDIA / DOWNLOAD FROM LINK
  Kaam: link se video download karna (YouTube, TikTok ...).
  Uses yt-dlp (YouTube, TikTok, Instagram, Facebook, X, Vimeo, Twitch
  and direct video links). Always asks for the highest quality,
  because 9:16 crops need every pixel.
  YouTube changes often, so the downloader updates itself once a day
  in the background (pip package; the packaged .exe build in Phase 5
  updates through the app updater).
  YouTube also needs a JavaScript runtime: deno.exe is placed in
  bin/ by the installer and passed to yt-dlp here.
=====================================================================
"""
from __future__ import annotations

import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Callable

from app.core.logging_setup import get_logger
from app.core.paths import resource
from app.media.ffmpeg_tools import Cancelled, ffmpeg_bin

log = get_logger("download")
_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

# The daily self-update and a download never run at the same time
# (pip replacing yt-dlp's files mid-download could break it).
_UPDATE_LOCK = threading.Lock()

URL_RE = re.compile(r"^https?://\S+$", re.IGNORECASE)

# Best video up to 4K + best audio; fall back to best single file.
FORMAT = "bv*[height<=2160]+ba/b[height<=2160]/bv*+ba/b"


class DownloadError(RuntimeError):
    pass


def is_url(text: str) -> bool:
    return bool(URL_RE.match(text.strip()))


def _bin(name: str) -> Path | None:
    exe = resource("bin", name + (".exe" if sys.platform == "win32" else ""))
    return exe if exe.exists() else None


def self_update(stamp_dir: Path, max_age_hours: float = 24) -> str:
    """
    Upgrade the yt-dlp package at most once a day (background thread).
    The new version is used from the next app start.
    """
    if getattr(sys, "frozen", False):
        return "skipped"
    stamp = stamp_dir / "ytdlp_update.stamp"
    if not _UPDATE_LOCK.acquire(blocking=False):
        return "busy"
    try:
        if stamp.exists() and time.time() - stamp.stat().st_mtime < max_age_hours * 3600:
            return "recent"
        stamp_dir.mkdir(parents=True, exist_ok=True)
        out = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-U", "yt-dlp[default]"],
                             capture_output=True, text=True, timeout=300, creationflags=_NO_WINDOW)
        stamp.touch()
        return "ok" if out.returncode == 0 else "failed"
    except (OSError, subprocess.TimeoutExpired) as exc:
        log.warning("yt-dlp update failed: %s", exc)
        return "failed"
    finally:
        _UPDATE_LOCK.release()


BROWSERS = ("chrome", "edge", "firefox", "brave")
_LOGIN_HINTS = ("sign in to confirm", "not a bot", "cookies", "login required", "age-restricted", "private video")


def needs_login(exc: BaseException) -> bool:
    text = str(exc).lower()
    return any(h in text for h in _LOGIN_HINTS)


def download(
    url: str,
    target_dir: Path,
    on_progress: Callable[[float], None] | None = None,
    cancel_event: threading.Event | None = None,
    cookies_file: str = "",
) -> Path:
    """
    Download `url` into `target_dir`. Returns the final file path.
    If the site asks for a login ("confirm you're not a bot"), the same
    download is retried with the user's own browser sign-in: first a
    cookies.txt set in Settings, then Chrome / Edge / Firefox / Brave.
    """
    target_dir.mkdir(parents=True, exist_ok=True)
    try:
        return _download_any(url, target_dir, on_progress, cancel_event, cookies_file)
    except DownloadError:
        # internet nahi / site ne mana kiya: yehi video pehle download ho chuki ho to wohi chala lo
        saved = cached_copy(url, target_dir)
        if saved is None:
            raise
        log.warning("Download failed; using the copy already saved: %s", saved.name)
        return saved


def cached_copy(url: str, target_dir: Path) -> Path | None:
    """Pehle download ki hui isi link ki file (YouTube id se), warna None."""
    m = re.search(r"(?:youtu\.be/|[?&]v=|/shorts/|/live/|/embed/)([A-Za-z0-9_-]{11})", url)
    if not m or not target_dir.is_dir():
        return None
    files = [f for f in target_dir.glob(f"*[[]{m.group(1)}[]].mp4") if f.stat().st_size > 0]
    return max(files, key=lambda f: f.stat().st_mtime) if files else None


def _download_any(url, target_dir, on_progress, cancel_event, cookies_file) -> Path:
    with _UPDATE_LOCK:          # wait (max ~5 min) if the daily update is running
        attempts: list[dict] = [{}]
        if cookies_file and Path(cookies_file).is_file():
            attempts.append({"cookiefile": cookies_file})
        attempts += [{"cookiesfrombrowser": (b,)} for b in BROWSERS]
        last: Exception | None = None
        for extra in attempts:
            try:
                if extra:
                    log.info("Retrying download with %s", next(iter(extra.values())))
                return _download(url, target_dir, on_progress, cancel_event, extra)
            except Cancelled:
                raise
            except _NeedsLogin as exc:
                last = exc
                continue
        raise DownloadError(
            "YouTube asked to sign in for this video, so it was skipped and the line moved on. "
            "You can download the video yourself and drop the file into the link box."
        ) from last


class _NeedsLogin(Exception):
    pass


def _deno_options() -> dict:
    """yt-dlp ke liye ffmpeg aur deno ka pata (doosre hisse bhi use karte hain)."""
    out: dict = {}
    ffmpeg = Path(ffmpeg_bin())
    if ffmpeg.is_absolute():
        out["ffmpeg_location"] = str(ffmpeg.parent)
    deno = _bin("deno")
    if deno:
        out["js_runtimes"] = {"deno": {"path": str(deno)}}
    return out


def _download(url, target_dir, on_progress, cancel_event, extra: dict | None = None) -> Path:
    try:
        import yt_dlp  # type: ignore
    except ImportError as exc:  # pragma: no cover
        raise DownloadError("Downloader is missing. Reinstall the app.") from exc

    result: dict[str, str] = {}

    def hook(d: dict) -> None:
        if cancel_event is not None and cancel_event.is_set():
            raise Cancelled()
        if d.get("status") == "downloading" and on_progress:
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            if total:
                on_progress(min(0.99, d.get("downloaded_bytes", 0) / total))
        elif d.get("status") == "finished":
            result["file"] = d.get("filename", "")

    options = {
        "format": FORMAT,
        "merge_output_format": "mp4",
        "outtmpl": str(target_dir / "%(title).80s [%(id)s].%(ext)s"),
        "restrictfilenames": True,       # plain ASCII names, safe for ffmpeg
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "progress_hooks": [hook],
        "retries": 5,
        "fragment_retries": 5,
        "continuedl": True,              # resume after a dropped connection
    }
    ffmpeg = Path(ffmpeg_bin())
    if ffmpeg.is_absolute():
        options["ffmpeg_location"] = str(ffmpeg.parent)
    deno = _bin("deno")
    if deno:
        options["js_runtimes"] = {"deno": {"path": str(deno)}}
    options.update(extra or {})
    try:
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(url, download=True)
            final = Path(ydl.prepare_filename(info)).with_suffix(".mp4")
    except Cancelled:
        raise
    except Exception as exc:  # yt-dlp raises many types (and wraps ours)
        if cancel_event is not None and cancel_event.is_set():
            raise Cancelled() from exc
        if extra:
            # A browser sign-in attempt failed (browser open / locked / not
            # installed / still asks): move on to the next way.
            log.warning("Sign-in attempt %s failed: %s", extra, str(exc)[:200])
            raise _NeedsLogin(str(exc)) from exc
        if needs_login(exc):
            log.warning("Site wants a login (%s): %s", extra or "no cookies", str(exc)[:200])
            raise _NeedsLogin(str(exc)) from exc
        log.error("Download failed: %s", exc)
        raise DownloadError(
            "Could not download this link, so it was skipped and the line moved on. Check the link "
            "and your internet, or download the video yourself and drop the file into the link box."
        ) from exc

    if not final.exists():
        vid = f"[{info.get('id', '')}]"
        candidates = sorted((p for p in target_dir.iterdir() if vid in p.name and p.suffix != ".part"),
                            key=lambda p: p.stat().st_mtime)
        if not candidates:
            raise DownloadError("Download finished but the file was not found.")
        final = candidates[-1]
    # chhoti si maloomat saath rakho (naam patti ki date, channel)
    try:
        import json
        meta = {k: info.get(k) for k in ("title", "upload_date", "channel", "uploader", "id")}
        final.with_name(final.stem + ".meta.json").write_text(json.dumps(meta), encoding="utf-8")
    except Exception:  # noqa: BLE001 - sirf extra maloomat
        pass
    if on_progress:
        on_progress(1.0)
    return final


def source_meta(path: Path) -> dict:
    """Download ke waqt rakhi maloomat (title, upload_date YYYYMMDD, channel); na ho to {}."""
    import json
    try:
        return json.loads(Path(path).with_name(Path(path).stem + ".meta.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
