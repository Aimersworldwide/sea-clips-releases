"""
=====================================================================
  MEDIA / PREPARE SOURCE
  Kaam: source video ko saaf master copy mein badalna.
  1. Fix "difficult" sources before anything else:
       * variable frame rate  -> constant (stops audio drift)
       * HDR                  -> tone-mapped to normal BT.709
       * phone rotation       -> applied
  2. Extract a 16 kHz mono WAV for speech recognition.
  The prepared file is cached by source hash, so it is made once.
=====================================================================
"""
from __future__ import annotations

import threading
from pathlib import Path
from typing import Callable

from app.core.logging_setup import get_logger
from app.media.ffmpeg_tools import run_ffmpeg
from app.media.probe import SourceInfo

log = get_logger("prepare")


def needs_normalizing(info: SourceInfo) -> bool:
    return info.is_vfr or info.is_hdr or info.video_codec not in ("h264", "hevc", "vp9", "av1", "mpeg4", "prores")


def normalize(info: SourceInfo, out_path: Path,
              on_progress: Callable[[float], None] | None = None,
              cancel_event: threading.Event | None = None) -> Path:
    """Make a clean, constant-frame-rate, SDR master (visually lossless)."""
    if out_path.exists() and out_path.stat().st_size > 0:
        return out_path
    fps = info.fps if 20 <= info.fps <= 61 else 30
    vf = []
    if info.is_hdr:
        vf.append("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,"
                  "tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p")
    vf.append(f"fps={fps}")
    tmp = out_path.with_suffix(".part.mp4")
    run_ffmpeg([
        "-i", str(info.path),
        "-vf", ",".join(vf),
        "-c:v", "libx264", "-preset", "fast", "-crf", "12", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "320k", "-ar", "48000",
        "-movflags", "+faststart", str(tmp),
    ], duration=info.duration, on_progress=on_progress, cancel_event=cancel_event)
    tmp.replace(out_path)
    return out_path


def extract_speech_audio(src: Path, out_wav: Path, duration: float | None = None,
                         cancel_event: threading.Event | None = None) -> Path:
    """16 kHz mono WAV - the exact format Whisper models expect."""
    if out_wav.exists() and out_wav.stat().st_size > 0:
        return out_wav
    tmp = out_wav.with_suffix(".part.wav")
    run_ffmpeg(["-i", str(src), "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(tmp)],
               duration=duration, cancel_event=cancel_event)
    tmp.replace(out_wav)
    return out_wav
