"""
=====================================================================
  MEDIA / FFMPEG TOOLS
  Kaam: ffmpeg chalana aur us ki ghaltiyan sambhalna.
  Finds ffmpeg/ffprobe (bundled first, then system PATH) and runs
  them with live progress, pause-safe cancellation and clear errors.
=====================================================================
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path
from typing import Callable

from app.core.logging_setup import get_logger
from app.core.paths import resource

log = get_logger("ffmpeg")

# Hide the black console window that would flash for every ffmpeg call on Windows.
_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


class FFmpegError(RuntimeError):
    """ffmpeg failed. `tail` holds the last lines of its output."""

    def __init__(self, message: str, tail: str = ""):
        super().__init__(message)
        self.tail = tail


class Cancelled(Exception):
    """The user pressed Cancel."""


def _find(name: str) -> str:
    exe = f"{name}.exe" if sys.platform == "win32" else name
    bundled = resource("bin", exe)
    if bundled.exists():
        return str(bundled)
    found = shutil.which(name)
    if not found:
        raise FFmpegError(f"{name} was not found. Reinstall the app or install {name}.")
    return found


def ffmpeg_bin() -> str:
    return _find("ffmpeg")


def ffprobe_bin() -> str:
    return _find("ffprobe")


def run(args: list[str], timeout: float | None = None) -> subprocess.CompletedProcess:
    """Run a short command and return its output (raises on failure)."""
    log.debug("RUN %s", " ".join(args))
    proc = subprocess.run(
        args, capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=timeout, creationflags=_NO_WINDOW,
    )
    if proc.returncode != 0:
        tail = "\n".join(proc.stderr.strip().splitlines()[-15:])
        raise FFmpegError(f"Command failed ({Path(args[0]).name})", tail)
    return proc


def run_ffmpeg(
    args: list[str],
    duration: float | None = None,
    on_progress: Callable[[float], None] | None = None,
    cancel_event: threading.Event | None = None,
    cwd: str | None = None,
) -> str:
    """
    Run ffmpeg with `-progress` so we can report 0..1 progress.
    `args` are everything after the ffmpeg executable.
    Progress only moves forward (newer ffmpeg can report a later
    timestamp first). Returns the last stderr lines (for log parsing).
    Cancel is checked on every progress line (about twice a second).
    """
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-y", "-progress", "pipe:1", "-nostats", *args]
    log.debug("FFMPEG %s", " ".join(cmd))
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8",
        errors="replace", creationflags=_NO_WINDOW, cwd=cwd,
    )
    stderr_lines: list[str] = []

    def _drain_stderr() -> None:
        assert proc.stderr is not None
        for line in proc.stderr:
            stderr_lines.append(line.rstrip())
            if len(stderr_lines) > 200:
                del stderr_lines[:100]

    reader = threading.Thread(target=_drain_stderr, daemon=True)
    reader.start()

    assert proc.stdout is not None
    best = 0.0
    for line in proc.stdout:
        if cancel_event is not None and cancel_event.is_set():
            proc.kill()
            proc.wait()
            raise Cancelled()
        if on_progress and duration and line.startswith("out_time_us="):
            try:
                seconds = int(line.split("=", 1)[1]) / 1_000_000
            except ValueError:
                continue
            frac = max(0.0, min(1.0, seconds / duration))
            if frac > best:
                best = frac
                on_progress(frac)
    proc.wait()
    reader.join(timeout=2)
    if proc.returncode != 0:
        tail = "\n".join(stderr_lines[-15:])
        # (18 Nov) asal wajah aksar aakhri 15 lines se pehle hoti hai: error wali lines alag se
        keys = ("error", "Error", "failed", "Failed", "Impossible", "Invalid", "invalid", "cuda", "CUDA",
                "No such", "not supported", "out of memory", "Cannot", "cannot")
        hits = [ln for ln in stderr_lines[:-15] if any(k in ln for k in keys)][-12:]
        if hits:
            log.error("ffmpeg error lines:\n%s", "\n".join(hits))
        log.error("ffmpeg failed:\n%s", tail)
        raise FFmpegError("Video processing failed", tail)
    if on_progress:
        on_progress(1.0)
    return "\n".join(stderr_lines)


def escape_filter_path(path: Path | str) -> str:
    """
    Quote a path for use as a filter option value, e.g.
        subtitles=filename=<this>
    Rules (ffmpeg filter syntax): forward slashes, drive colon escaped
    as \\:, whole value in single quotes, and a single quote inside the
    path closes the quote, adds an escaped quote, then reopens.
    Works for spaces, colons, commas, brackets and apostrophes
    (e.g. C:\\Users\\O'Brien\\...).
    """
    text = str(path).replace("\\", "/")
    text = text.replace(":", "\\:")
    parts = text.split("'")
    return "'" + "'\\\\\\''".join(parts) + "'"


def free_space_gb(path: Path) -> float:
    target = path if path.exists() else path.parent
    while not target.exists() and target != target.parent:
        target = target.parent
    return shutil.disk_usage(target).free / 1_000_000_000


def has_nvidia_gpu() -> bool:
    """True when an NVIDIA GPU + driver is present (nvidia-smi works)."""
    smi = shutil.which("nvidia-smi")
    if not smi and sys.platform == "win32":
        candidate = Path(os.environ.get("SystemRoot", "C:\\Windows")) / "System32" / "nvidia-smi.exe"
        smi = str(candidate) if candidate.exists() else None
    if not smi:
        return False
    try:
        out = subprocess.run([smi, "-L"], capture_output=True, text=True, timeout=10, creationflags=_NO_WINDOW)
        return out.returncode == 0 and "GPU" in out.stdout
    except (OSError, subprocess.TimeoutExpired):
        return False
