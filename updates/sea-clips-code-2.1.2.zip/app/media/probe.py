"""
=====================================================================
  MEDIA / PROBE + SOURCE CHECK
  Kaam: video ki maloomat (size, fps, audio) aur check.
  Reads video facts (size, fps, length, HDR, variable frame rate)
  and warns early when a source will give soft clips.
=====================================================================
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

from app.media.ffmpeg_tools import ffprobe_bin, run


@dataclass
class SourceInfo:
    path: Path
    width: int
    height: int
    fps: float
    duration: float
    has_audio: bool
    is_hdr: bool
    is_vfr: bool
    rotation: int
    video_codec: str
    audio_rate: int

    @property
    def display_size(self) -> tuple[int, int]:
        """Size after applying phone rotation metadata."""
        if self.rotation in (90, 270):
            return self.height, self.width
        return self.width, self.height

    @property
    def is_vertical(self) -> bool:
        w, h = self.display_size
        return h > w * 1.2

    @property
    def quality_label(self) -> int:
        """The 'p' number people know (720, 1080, 2160) based on the short side."""
        return min(self.display_size)


def _fps(text: str) -> float:
    try:
        value = float(Fraction(text))
        return value if value > 0 else 0.0
    except (ValueError, ZeroDivisionError):
        return 0.0


def probe(path: Path) -> SourceInfo:
    out = run([
        ffprobe_bin(), "-v", "error", "-print_format", "json",
        "-show_format", "-show_streams", str(path),
    ], timeout=120)
    data = json.loads(out.stdout)
    streams = data.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"), None)
    audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
    if video is None:
        raise ValueError("This file has no video stream.")

    rotation = 0
    for side in video.get("side_data_list", []) or []:
        if "rotation" in side:
            rotation = abs(int(side["rotation"])) % 360
    if "rotate" in (video.get("tags") or {}):
        rotation = abs(int(video["tags"]["rotate"])) % 360

    avg = _fps(video.get("avg_frame_rate", "0/1"))
    real = _fps(video.get("r_frame_rate", "0/1"))
    duration = float(data.get("format", {}).get("duration") or video.get("duration") or 0)
    transfer = (video.get("color_transfer") or "").lower()

    return SourceInfo(
        path=path,
        width=int(video.get("width", 0)),
        height=int(video.get("height", 0)),
        fps=round(avg or real or 30.0, 3),
        duration=duration,
        has_audio=audio is not None,
        is_hdr=transfer in ("smpte2084", "arib-std-b67"),
        is_vfr=bool(avg and real and abs(avg - real) / max(real, 1e-6) > 0.02),
        rotation=rotation,
        video_codec=video.get("codec_name", ""),
        audio_rate=int(audio.get("sample_rate", 48000)) if audio else 0,
    )


@dataclass
class SourceCheck:
    ok: bool
    low_quality: bool
    message_key: str = ""
    height: int = 0


def check_source(info: SourceInfo) -> SourceCheck:
    """9:16 crops of 1080p are only ~608 px wide; below 720p clips look soft."""
    if not info.has_audio:
        return SourceCheck(ok=False, low_quality=False, message_key="no_audio")
    if info.duration < 10:
        return SourceCheck(ok=False, low_quality=False, message_key="too_short")
    low = info.quality_label < 720
    return SourceCheck(ok=True, low_quality=low, message_key="msg.source_low" if low else "", height=info.quality_label)


def source_hash(path: Path) -> str:
    """Fast fingerprint: size + first and last 4 MB. Same file -> same hash."""
    size = path.stat().st_size
    h = hashlib.sha256(str(size).encode())
    with open(path, "rb") as f:
        h.update(f.read(4_000_000))
        if size > 8_000_000:
            f.seek(-4_000_000, 2)
            h.update(f.read(4_000_000))
    return h.hexdigest()[:24]
