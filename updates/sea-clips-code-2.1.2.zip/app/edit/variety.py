"""
=====================================================================
  EDIT / VARIETY ENGINE
  Kaam: har clip ko alag edit dena (koi do clips ek jaise nahi).
  Gives every clip its own combination of editing choices so no two
  clips look the same. Deterministic: the same clip number always
  gets the same choices (so a re-render is identical).
  Rules:
    * consecutive clips never share caption style or colour look
    * a campaign can lock the caption style (then only it is used)
    * re-edits of the same moment never repeat a combination, also
      across runs (thousands of different edits per moment)
  Rotates: caption style, caption entrance, colour look, stacked
  layout order (who is on top), progress bar, pace (silence removal),
  zoom (punch / slow push / none), the hook title (on / off, box or
  outline, colour), caption position, caption mode (phrase / 1-2
  words), caption size and the highlight colour.
  Similarity check: a re-edit of a moment must differ from every
  earlier edit of it in at least 2 of the 10 choices (< 85 % same).
  Faces, picture content and voice are never changed by any of these.
=====================================================================
"""
from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass

from app.captions.builder import HOOK_COLORS
from app.captions.styles import ACCENTS, PALETTE_ORDER, PLAIN_STYLES, STYLES
from app.edit.looks import LOOK_ORDER
from app.edit.motion import ZOOMS

ENTRANCES = ("rise", "fade")
BARS = ("", "top", "bottom")       # progress bar
PACES = ("", "medium")             # "" = the app's silence setting; "medium" = tighter
CAP_POS = ("", "high", "low")      # captions: style ki jagah / thoda upar / thoda neeche
CAP_MODE = ("", "word", "reveal")  # "" = jumle ke tukre, "word" = 1-2 lafz, "reveal" = lafz bolte hi aate hain
CAP_SIZE = (1.0, 0.92, 1.08)       # captions ka size
SIMILAR = 0.85                     # isi moment ke purane edit se itna ya zyada milta ho = nahi chalega


@dataclass
class EditChoice:
    caption_style: str
    entrance: str
    look: str
    swap: bool = False             # stacked layout: right side on top
    bar: str = ""                  # progress bar: "" | top | bottom
    pace: str = ""                 # silence removal override for this clip
    zoom: str = "punch"            # "" | punch | push   (Phase 3)
    hook: bool = True              # hook title in the first seconds (Phase 3)
    hook_box: bool = True          # hook on a rounded box (~70%) or outline text only (~30%)
    hook_color: str = ""           # hook box colour: yellow / white / black
    accent: str = ""               # spoken-word highlight colour for this clip ("" = style colour)
    cap_pos: str = ""              # "" | high | low
    cap_mode: str = ""             # "" | word
    cap_size: float = 1.0          # 0.92 | 1.0 | 1.08
    palette: str = ""              # rangeen captions (styles.PALETTES); "" = style ka apna rang
    frame: str = ""                # "" = poori screen video | "title" = safed title card (upar title, beech video)

    def to_dict(self) -> dict:
        return asdict(self)

    def combo(self) -> tuple:
        """What makes two edits of the same moment look different."""
        return (self.caption_style, self.look, self.swap, self.bar, self.pace, self.zoom, self.hook,
                self.cap_pos, self.cap_mode, float(self.cap_size), self.frame)


# ---------------------------------------------------------------------
#  Do edits kitne milte hain (0..1): kitni cheezen bilkul same hain
# ---------------------------------------------------------------------
def similarity(a: tuple, b: tuple) -> float:
    n = max(len(a), len(b))
    if not n:
        return 1.0
    a = tuple(a) + ("",) * (n - len(a))
    b = tuple(b) + ("",) * (n - len(b))
    return sum(1 for x, y in zip(a, b) if x == y) / n


def _too_similar(c: tuple, seen: set) -> bool:
    return any(similarity(c, old) >= SIMILAR for old in seen)


def _gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return a


def _pick(seq: list[str], seed: str, avoid: str | None) -> str:
    """Stable pseudo-random pick that never repeats the previous value."""
    digest = int(hashlib.sha1(seed.encode()).hexdigest(), 16)
    options = [s for s in seq if s != avoid] or list(seq)
    return options[digest % len(options)]


FRAME_STYLES = ("clean_caps", "bold_two", "bold_two_bebas")   # title card ke captions (seekha hua andaaz)
FRAME_PALETTES = ("red", "yellow", "red", "yellow", "orange", "cyan")


def choose_edits(
    count: int,
    seed: str,
    default_style: str = "clean_pop",
    rotate_styles: bool = True,
    locked_style: str = "",
    looks_enabled: bool = True,
    groups: list[str] | None = None,
    taken: dict[str, set] | None = None,
    taken_palettes: dict[str, set] | None = None,
    frames: tuple[str, ...] = ("",),
    extra_styles: tuple[str, ...] = (),
    only_styles: tuple[str, ...] = (),
    auto_boxed: tuple[str, ...] = (),
    boxed_share: float = 0.2,
) -> list[EditChoice]:
    """
    Return one EditChoice per clip in order.
    `groups` names the moment (window) of each clip. Clips of the same
    moment (re-edits, also from earlier runs listed in `taken`) always
    get a combination that moment has never had, so no two clips are
    ever the same.
    """
    # Rotation mein sirf bina box wale styles; box style tabhi jab user khud lock kare
    styles = list(PLAIN_STYLES) + [k for k in extra_styles if k in STYLES and k not in PLAIN_STYLES]
    cap_modes = list(CAP_MODE)
    if only_styles and any(k in STYLES for k in only_styles):
        # campaign ka apna caption khandaan (jaise word highlight): sirf wohi, aur 1-2 lafz wala mode nahi
        styles = [k for k in only_styles if k in STYLES]
        cap_modes = [m for m in CAP_MODE if m != "word"]
    if locked_style and locked_style in STYLES and not only_styles:
        styles = [locked_style]
    elif not rotate_styles:
        styles = [default_style if default_style in STYLES else "clean_pop"]
    looks = list(LOOK_ORDER) if looks_enabled else [""]
    dims = [styles, looks, [False, True], list(BARS), list(PACES), list(ZOOMS), [True, False],
            list(CAP_POS), cap_modes, list(CAP_SIZE), list(frames or ("",))]
    total = 1
    for d in dims:
        total *= len(d)

    def combo_at(idx: int) -> tuple:
        out = []
        for d in dims:
            out.append(d[idx % len(d)])
            idx //= len(d)
        return tuple(out)

    def walk(seed_text: str):
        """Saare combos ek pakki (seed se) bikhri hui tarteeb mein, bina list banaye."""
        h = int(hashlib.sha1(seed_text.encode()).hexdigest(), 16)
        start, step = h % total, (h // total) % total or 1
        while _gcd(step, total) != 1:
            step += 1
        for k in range(total):
            yield combo_at((start + k * step) % total)

    used: dict[str, set] = {k: set(v) for k, v in (taken or {}).items()}
    pal_used: dict[str, set] = {k: set(v) for k, v in (taken_palettes or {}).items()}
    out: list[EditChoice] = []
    prev_style: str | None = None
    prev_look: str | None = None
    prev_palette: str | None = None
    for i in range(count):
        group = groups[i] if groups else f"clip{i}"
        seen = used.setdefault(group, set())
        first_time = not seen
        if first_time:
            # first edit of a moment: plain layout and pace, rotating style + look
            if i == 0 and default_style in styles:
                style = default_style            # first clip shows the default look (user ki apni pasand)
            else:
                style = _pick(styles, f"{seed}:style:{i}", prev_style)
            boxed = [k for k in auto_boxed if k in STYLES]
            if boxed and len(styles) > 1 and i > 0:
                # dabbe wale captions kabhi kabhi hi (lagbhag 5 mein se 1 clip), chehra na chhupe
                roll = int(hashlib.sha1(f"{seed}:boxed:{i}".encode()).hexdigest(), 16) % 1000
                if roll < boxed_share * 1000:
                    style = _pick(boxed, f"{seed}:boxstyle:{i}", prev_style)
            look = _pick(looks, f"{seed}:look:{i}", prev_look) if looks_enabled else ""
            zoom = ("punch", "push", "punch", "")[i % 4]      # first edits vary the motion too
            mode = ("", "reveal", "", "word", "reveal")[i % 5]   # har cut ke captions ka andaaz bhi alag
            if mode not in cap_modes:
                mode = ""
            frame = (frames or ("",))[i % len(frames or ("",))]     # naye cuts: title card aur poori screen baari baari
            choice = (style, look, False, "", "", zoom, True, "", mode, 1.0, frame)
            if choice in seen:
                first_time = False
        if not first_time:
            choice = None
            fallback = None
            tries = 0
            for c in walk(f"{seed}:{group}"):
                tries += 1
                if c in seen:
                    continue
                if fallback is None:
                    fallback = c
                if len(styles) > 1 and c[0] == prev_style:
                    continue
                if len(looks) > 1 and c[1] == prev_look:
                    continue
                if _too_similar(c, seen):                 # 85% se zyada milta hai: aur dhoondo
                    if tries > 20000:
                        break
                    continue
                choice = c
                break
            if choice is None:     # bohot edits ho chuke: jo bhi naya mile
                choice = fallback or combo_at(i % total)
        style, look, swap, bar, pace, zoom, hook, cap_pos, cap_mode, cap_size, frame = choice
        if frame == "title":
            # title card: un channels jaisa: CAPS bold, safed + ek tez rang (laal / peela), hook nahi (title hi hook)
            if style not in FRAME_STYLES:
                style = FRAME_STYLES[styles.index(style) % len(FRAME_STYLES)] if style in styles else FRAME_STYLES[0]
            hook, bar = False, ""
        st = STYLES[style]
        entrance = st.entrance if st.entrance == "fade" else _pick(list(ENTRANCES), f"{seed}:ent:{i}", None)
        # Hook ka andaaz aur rang, aur bolte lafz ka rang: har clip ke liye pakka (seed se)
        hook_box = False                 # hook ke peeche dabba nahi (chehra na chhupe), sirf kinare wala text
        hook_color = _pick(list(HOOK_COLORS), f"{seed}:hookcol:{i}", None)
        accent = "" if i == 0 else _pick(list(ACCENTS), f"{seed}:accent:{i}", None)
        # rangeen captions: lagataar do clips ki palette kabhi same nahi
        # re-edit: is moment ke pehle edits wala rang dobara nahi (jab tak naye rang bache hon)
        had = pal_used.setdefault(group, set())
        order = FRAME_PALETTES if frame == "title" else PALETTE_ORDER
        fresh_pal = [p for p in order if p not in had] or list(order)
        palette = _pick(fresh_pal, f"{seed}:palette:{group}:{len(seen)}", prev_palette)
        had.add(palette)
        out.append(EditChoice(caption_style=style, entrance=entrance, look=look, swap=swap, bar=bar, pace=pace,
                              zoom=zoom, hook=hook, hook_box=hook_box, hook_color=hook_color, accent=accent,
                              cap_pos=cap_pos, cap_mode=cap_mode, cap_size=cap_size, palette=palette,
                              frame=frame))
        seen.add(choice)
        prev_style, prev_look, prev_palette = style, look, palette
    return out
