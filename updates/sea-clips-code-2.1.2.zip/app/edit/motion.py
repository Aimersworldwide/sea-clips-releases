"""
=====================================================================
  EDIT / MOTION  (gentle zooms, Phase 3)
  Kaam: naram zoom (punch / push), sirf wajah ke saath.
  Two styles, both soft enough that faces stay natural:
    punch : a 5 % zoom-in at the start of a new sentence, eased in
            over 0.25 s, held while the line lands, eased out.
            At most one every 4 s, max 3 per clip, never across a
            camera cut (a zoom over a cut looks like a mistake).
    push  : a slow 3 % push-in over the whole clip (calm, cinematic).
  The zoom is a re-scale and centre crop of the finished frame, so it
  is identical on every laptop. Bicubic keeps it sharp at 5 %.
=====================================================================
"""
from __future__ import annotations

from app.transcribe.models import Word

ZOOMS = ("", "punch", "push")
PUNCH = 0.05
PUSH = 0.03
EASE_IN = 0.25
HOLD = 1.3
EASE_OUT = 0.35
GAP = 4.0
MAX_PUNCHES = 3
CUT_MARGIN = 0.6


def punch_times(words: list[Word], cuts: list[float], duration: float) -> list[float]:
    """Clip times where a punch zoom starts (new sentence, away from cuts and the ends)."""
    span = EASE_IN + HOLD + EASE_OUT
    out: list[float] = []
    for prev, w in zip(words, words[1:]):
        if not prev.ends_sentence:
            continue
        t = max(0.0, w.start - 0.05)
        if t < 1.0 or t + span > duration - 0.3:
            continue
        if out and t - out[-1] < GAP:
            continue
        if any(t - CUT_MARGIN < c < t + span + CUT_MARGIN for c in cuts):
            continue
        out.append(round(t, 3))
        if len(out) >= MAX_PUNCHES:
            break
    return out


def zoom_expr(kind: str, punches: list[float], duration: float) -> str:
    """ffmpeg expression of the zoom factor over time t (1 = no zoom)."""
    if kind == "push":
        return f"(1+{PUSH}*clip(t/{max(duration, 0.1):.3f},0,1))"
    if kind == "punch" and punches:
        bumps = [f"clip((t-{p:.3f})/{EASE_IN},0,1)*clip(({p + EASE_IN + HOLD + EASE_OUT:.3f}-t)/{EASE_OUT},0,1)"
                 for p in punches]
        return f"(1+{PUNCH}*({'+'.join(bumps)}))"
    return ""


def zoom_filter(kind: str, punches: list[float], duration: float, width: int, height: int,
                focus: tuple[float, float] = (0.5, 0.5)) -> str:
    """Zoom hamesha chehre par: focus (x, y, 0..1) wali jagah zoom mein apni jagah rehti hai, frame us ki
    taraf barhta hai (beech ki taraf nahi)."""
    expr = zoom_expr(kind, punches, duration)
    if not expr:
        return ""
    fx = min(1.0, max(0.0, focus[0]))
    fy = min(1.0, max(0.0, focus[1]))
    return (f"scale=w='trunc({width}*{expr}/2)*2':h='trunc({height}*{expr}/2)*2':eval=frame:flags=bicubic,"
            f"crop={width}:{height}:x='(iw-ow)*{fx:.3f}':y='(ih-oh)*{fy:.3f}'")
