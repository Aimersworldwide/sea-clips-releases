"""
=====================================================================
  EDIT / TITLE RULES   (har campaign ke apne title rules)
  Kaam: campaign ke rules ke mutabiq title aur hashtags banana / jaanchna.
  Rules campaign ki settings mein hain (requirements box khud bharta hai):
    * andaaz: viral (viral channels jaisa) | clean (seedha, sach, koi
      hype / clickbait / sawal wala chaara nahi)
    * siyasi lafz: aa sakte hain | bilkul nahi
    * emoji: auto (viral haan, clean nahi) | haan | nahi
    * har title mein zaroori naam / topic (jaise "Prop 42")
    * zyada se zyada kitne hashtags
  Har campaign mein HAMESHA (koi on/off nahi):
    * gaali, badtameezi, nafrat wale lafz, dhamki: kabhi nahi
    * title mein koi number / claim jo clip mein bola na gaya ho: nahi
=====================================================================
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

# ---------------------------------------------------------------------
#  Siyasi lafz (campaign kahe "no political / politically sensitive")
#  Party, siyasatdan, nazariye aur garam siyasi topics. Campaign ka apna
#  zaroori naam / topic (title_must) is se hamesha bacha rehta hai.
# ---------------------------------------------------------------------
POLITICAL = re.compile(
    r"\b(?:democrats?|democratic|republicans?|gop|maga|liberals?|leftists?|left[- ]wing|right[- ]wing|"
    r"conservatives?|progressives?|socialis[mt]s?|communis[mt]s?|marxis[mt]s?|fascis[mt]s?|nazis?|"
    r"woke|antifa|trump\w*|biden\w*|kamala|harris|obama|clinton|pelosi|desantis|vance|newsom|aoc|"
    r"impeach\w*|election\w*|elect(?:ed|ion)?|rigged|ballots?|senators?|congress\w*|politic\w*|"
    r"partisan|abortion|pro[- ]life|pro[- ]choice|immigra\w*|illegals?|deport\w*|border|"
    r"gun control|second amendment|2a|israel\w*|gaza|palestin\w*|hamas|zionis\w*|ukraine|russia|putin|"
    r"transgender|trans|racis[mt]s?|privilege|white supremac\w*|blm|feminis[mt]s?|"
    r"politics|government shutdown)\b", re.IGNORECASE)

# TOPICS (app.edit.titles) mein se jo siyasi hain
POLITICAL_TOPICS = {"Trump", "Biden", "Kamala Harris", "Impeachment", "the Election", "Abortion", "Gun Control",
                    "Immigration", "Socialism", "Capitalism", "Israel", "Ukraine", "Gender", "Racism", "the Media",
                    "Democrats", "Republicans", "Climate Change"}
GENERIC_TAGS = {"fyp", "foryou", "foryoupage", "viral", "trending", "shorts", "explore", "reels", "tiktok",
                "debate", "debates", "podcast", "news"}      # clean andaaz mein nahi (sirf campaign se mutalliq)
POLITICAL_TAGS = {"politics", "election", "trump", "biden", "kamalaharris", "impeachment", "abortion", "guncontrol",
                  "immigration", "socialism", "capitalism", "israel", "ukraine", "gender", "racism", "media",
                  "democrats", "republicans", "climate", "conservative", "liberal", "maga", "news"}

# ---------------------------------------------------------------------
#  Hype / clickbait (clean andaaz mein kabhi nahi)
# ---------------------------------------------------------------------
HYPE = re.compile(
    r"\b(?:destroy\w*|shuts? down|silenc\w*|owns?|owned|wreck\w*|slams?|obliterat\w*|demolish\w*|crush\w*|"
    r"perfect\w*|everything|insane\w*|crazy|unbelievable|epic|savage|exposed?|exposes|nobody|everyone|"
    r"wait for|not ready|didn'?t expect|did not expect|hits different|too funny|mic drop|must watch|"
    r"you need to|the truth|keeps? it real|can'?t argue|receipts|losing it|breaks? the internet|"
    r"shocking|jaw[- ]dropping|gone wrong|you won'?t believe|goat|legendary|brutal\w*|humiliat\w*|"
    r"melts? down|meltdown|triggered|speechless)\b", re.IGNORECASE)

# Number / claim: title mein sirf wahi jo clip mein bola gaya
NUMBER = re.compile(r"\$?\d[\d,.]*%?|\b(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|"
                    r"hundred|thousand|million|billion|trillion|percent|half|twice|double|triple)\b",
                    re.IGNORECASE)
WORD_NUM = {"one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6", "seven": "7",
            "eight": "8", "nine": "9", "ten": "10", "eleven": "11", "twelve": "12"}


# ---------------------------------------------------------------------
#  Gaali / badtameezi / nafrat / dhamki: har campaign mein hamesha band
# ---------------------------------------------------------------------
def is_clean(text: str) -> bool:
    """Title / hashtag mein koi gaali, badtameezi, nafrat ya dhamki wala lafz nahi (koi on/off nahi)."""
    from app.filters.guard import HOOK_BLOCKED
    from app.filters.profanity import INSULTS, MILD, MODERATE, SLURS, STRONG, THREATS
    low = (text or "").lower()
    for w in re.findall(r"[a-z0-9']+", low.replace("#", " ")):
        w = w.strip("'")
        if not w:
            continue
        if HOOK_BLOCKED.match(w):
            return False
        for pat in (STRONG, MODERATE, MILD, SLURS, INSULTS):
            if pat is not None and pat.match(w):
                return False
    joined = re.sub(r"[#_]", " ", low)
    return not any(p.search(joined) for p in THREATS)


def numbers_true(title: str, clip_text: str) -> bool:
    """Title ka har number / ginti clip mein bhi bola gaya ho (koi banaya hua claim nahi)."""
    clip = (clip_text or "").lower()
    clip_nums = {re.sub(r"[^\d.]", "", m) for m in re.findall(r"\$?\d[\d,.]*", clip)}
    for m in NUMBER.findall(title or ""):
        tok = m.lower()
        if tok[0].isdigit() or tok[0] == "$":
            if re.sub(r"[^\d.]", "", tok).rstrip(".") not in {n.rstrip(".") for n in clip_nums}:
                return False
        elif not re.search(rf"\b{re.escape(tok)}\b", clip) and WORD_NUM.get(tok, "#") not in clip_nums:
            return False
    return True


@dataclass
class TitleRules:
    style: str = "viral"          # viral | clean
    political: bool = True        # siyasi lafz aa sakte hain
    emoji: bool = True            # emoji lagana (auto ka faisla ho chuka)
    must: str = ""                # har title mein ye
    max_tags: int = 5             # zyada se zyada hashtags
    allow: tuple = ()             # campaign ke apne naam (topic): siyasi / hype jaanch mein nahi gine jaate

    @classmethod
    def from_profile(cls, p) -> "TitleRules":
        style = "clean" if getattr(p, "title_style", "viral") == "clean" else "viral"
        mode = getattr(p, "title_emoji", "auto")
        emoji = (style == "viral") if mode not in ("on", "off") else mode == "on"
        n = int(getattr(p, "max_hashtags", 0) or 0)
        terms = [t.strip() for t in re.split(r"[,;\n]", getattr(p, "topic_terms", "") or "") if t.strip()]
        return cls(style=style, political=bool(getattr(p, "political_words", True)), emoji=emoji,
                   must=(getattr(p, "title_must", "") or "").strip(), max_tags=n if n > 0 else 5,
                   allow=tuple(dict.fromkeys(terms)))

    @property
    def topic_name(self) -> str:
        """Title mein lagane ke liye campaign ka naam: zaroori naam, warna topic ka pehla naam ("Prop 42")."""
        return self.must or (self.allow[0] if self.allow else "")

    @property
    def clean(self) -> bool:
        return self.style == "clean"

    # ---- jaanch -------------------------------------------------------
    def _without_must(self, text: str) -> str:
        for term in sorted({t for t in (self.must, *self.allow) if t}, key=len, reverse=True):
            text = re.sub(re.escape(term), " ", text, flags=re.IGNORECASE)
        return text

    def political_ok(self, text: str) -> bool:
        return self.political or not POLITICAL.search(self._without_must(text))

    def hype_ok(self, text: str) -> bool:
        if not self.clean:
            return True
        rest = self._without_must(text)
        if HYPE.search(rest):
            return False
        # clean: bade huroof wale chillate lafz nahi (US / UK / FPPC jaise chhote naam theek)
        return not any(w.isupper() and len(w) > 4 for w in re.findall(r"[A-Za-z]+", rest))

    def ok(self, title: str, clip_text: str) -> bool:
        """Title is campaign ke rules pe poora utarta hai?"""
        if not title:
            return False
        return (is_clean(title) and self.political_ok(title) and self.hype_ok(title)
                and numbers_true(self._without_must(title), clip_text)
                and (not self.must or self.must.lower() in title.lower()))

    def with_must(self, title: str, limit: int = 90) -> str:
        """Zaroori naam / topic title mein na ho to saath jor do (jagah ho to)."""
        if not self.must or not title or self.must.lower() in title.lower():
            return title
        out = f"{title} | {self.must}"
        return out if len(out) <= limit else ""

    # ---- hashtags ---------------------------------------------------------
    def hashtags(self, tags: str, fixed: str = "") -> str:
        """Hashtags rules ke mutabiq: gaali / siyasi (agar mana) nikal do, ginti ki had."""
        keep_fixed = {"#" + t.lstrip("#").lower() for t in fixed.replace(",", " ").split() if t.strip("#")}
        out: list[str] = []
        for t in tags.split():
            word = t.lstrip("#").lower()
            if not word or not is_clean(word):
                continue
            if t.lower() not in keep_fixed and not self.political and (word in POLITICAL_TAGS or POLITICAL.search(word)):
                continue
            if t.lower() not in keep_fixed and self.clean and word in GENERIC_TAGS:
                continue
            if t not in out:
                out.append(t)
        return " ".join(out[:self.max_tags])


# ---------------------------------------------------------------------
#  Clean andaaz ka title: clip ki apni line ya seedhi baat, koi hype nahi
#    {M} zaroori naam / topic, {N} main person, {T} topic, {Q} clip ki line
# ---------------------------------------------------------------------
CLEAN_QUOTE = ['{M}: "{Q}"', '"{Q}" | {M}', '{N}: "{Q}"', '"{Q}" | {N}', '"{Q}"']
CLEAN_PLAIN = ["{N} on {T}", "{M}: {N} on {T}", "{N} Talks About {T}", "{T}: What {N} Said", "{M}: {T}",
               "{N} on {M}", "{M}: What {N} Said", "{N} Explains {M}", "{M} and {T}", "{T} | {M}",
               "{M}: What It Means for {T}", "{T}: The {M} Debate"]
# (31 Oct) aur sach, clip se jure andaaz: jab upar wale istemal ho chuke hon (ek hi khabar ki kai videos)
CLEAN_MORE = ["How {M} Affects {T}", "Why {M} Matters for {T}", "{M} Explained: {T}", "{T} and {M}: The Facts",
              "{M}: The {T} Question", "What {M} Means for Your {T}", "{T}: Where {M} Comes In", "{M} and Your {T}"]
# Topic na mile (ya topic campaign ke rules mein mana ho) to bhi sirf naam nahi: sach, saaf jumle
CLEAN_GENERIC = ["{N} Answers a Tough Question", "{N} Explains the Point", "{N} Gives a Clear Answer",
                 "{N}'s Answer to a Tough Question", "{N} Makes the Case", "{N} Responds to a Question",
                 "{N} Breaks It Down", "{N}'s Full Answer"]
SMALL = {"a", "an", "the", "of", "on", "in", "to", "for", "and", "or", "at", "by", "with", "is", "are", "vs"}


def _calm_case(text: str, keep: list[str]) -> str:
    """Title case, lekin chillate CAPS nahi (chhote naam jaise US, UK aur zaroori naam waise hi)."""
    keep_low = {k.lower() for k in keep if k}
    out = []
    for i, w in enumerate(text.split()):
        core = w.strip('"\'.,!?:|')
        if core.isupper() and len(core) > 4 and core.lower() not in keep_low:
            w = w.replace(core, core.capitalize())
        if i and w.lower() in SMALL:
            out.append(w.lower())
        else:
            k = next((n for n, ch in enumerate(w) if ch.isalpha()), 0)     # '"the' -> '"The'
            out.append(w[:k] + w[k:k + 1].upper() + w[k + 1:])
    return " ".join(out)


DANGLING = {"and", "but", "so", "or", "because", "the", "a", "an", "that", "is", "are", "was", "if", "when", "like",
            "my", "your", "his", "her", "their", "our", "saying", "says", "said", "say", "tell", "telling", "told",
            "think", "thinks", "than", "then", "which", "who", "where", "while", "it's", "we're", "they're", "i'm"}


# Line in lafzon se shuru ho to wo kisi jumle ka beech ka tukra hai (title nahi banta)
BAD_START = {"of", "to", "for", "with", "and", "or", "but", "that", "which", "than", "from", "by", "at", "in", "on",
             "because", "then", "into", "about", "as", "who", "whom", "whose", "where", "while", "if", "nor",
             "be", "been", "being", "might", "could", "would", "should", "can", "will", "not", "also", "too",
             "yeah", "um", "uh", "okay", "like", "is", "are", "was", "were", "it's", "its"}
# Line in par khatam ho to adhoori (sawal ya baat beech mein)
BAD_END = {"of", "to", "for", "with", "from", "by", "at", "in", "on", "into", "about", "as", "it", "does", "do",
           "did", "what", "how", "why", "not", "be", "been", "can", "could", "would", "should", "will", "just"}


def clean_quote(line: str, max_words: int = 14, whole: bool | None = None) -> str:
    """Clip ki line title ke laayak (poori line, sawal nahi, 3 se 14 lafz)."""
    from app.edit.titles import FILLER_START
    words = (line or "").split()
    while words and words[0].lower().strip(",") in FILLER_START:
        words = words[1:]
    text = " ".join(words).strip(" .,!;:-")
    if not (3 <= len(text.split()) <= max_words) or text.endswith("?") or (line or "").strip().endswith("?"):
        return ""
    last = text.split()[-1].lower().strip("\"'")
    if whole is None:                                          # poora jumla: aakhir mein "for" jaisa lafz theek hai
        whole = (line or "").strip().endswith((".", "!"))
    if last in DANGLING or (last in BAD_END and not whole):
        return ""                                        # adhoori line ("... coming in and saying") title nahi
    first = text.split()[0].lower().strip("\"',")
    if re.search(r"\byou know\b|\bi mean\b|\bkind of\b|\bsort of\b", text.lower()):
        return ""                                        # bol chaal ke bharti ke lafz: title mein bhadde
    if first in BAD_START:
        return ""                                        # beech se kata tukra ("of government, not ...") title nahi
    return text


def clean_title(rules: TitleRules, clip_text: str, name: str, quote: str, seed: str,
                avoid: set[str] | None = None, lines: list[str] | None = None, deep: bool = False) -> str:
    """Clean andaaz ka sach title; kuch theek na bane to "" (bina title behtar, ghalat title nahi).
    quote: clip ki sab se mazboot line; lines: clip ke baqi jumle (agar wo line kaam na aaye)."""
    from app.edit.titles import find_topic
    avoid = avoid or set()
    name = (name or "").strip()
    # siyasi topic mana ho to us ki jagah clip ka agla (ghair siyasi) topic, taake title phir bhi clip ka ho
    skip = [name, rules.must, *rules.allow] + ([] if rules.political else sorted(POLITICAL_TOPICS))
    topic, _ = find_topic(clip_text, skip)
    if topic and not rules.political and topic in POLITICAL_TOPICS:
        topic = ""
    pieces: list[tuple[str, bool]] = []
    for x in [quote, *(lines or [])]:
        pieces.append((x, True))
        # lamba jumla: us ke poore hisse (comma / "and" / "but" par) bhi title ban sakte hain (ye tukre hain)
        for part in re.split(r",\s+|;\s+|\s+(?:but|and so|because)\s+", x or ""):
            if part and part.strip() != (x or "").strip():
                pieces.append((part, False))
    quotes = [q for q in dict.fromkeys(clean_quote(x, whole=w) for x, w in pieces) if q]
    start = int(hashlib.sha1(seed.encode()).hexdigest(), 16)

    def turn(pool: list[str]) -> list[str]:            # har clip thora alag andaaz (seed se)
        k = start % len(pool)
        return pool[k:] + pool[:k]

    def build(tpl: str, q: str) -> str:
        if ("{M}" in tpl and not rules.topic_name) or ("{N}" in tpl and not name) or ("{T}" in tpl and not topic) \
                or ("{Q}" in tpl and not q):
            return ""
        if q and any(q.lower() in u for u in avoid):
            return ""                                    # ye line kisi aur clip ka title ban chuki: har clip alag
        if "{M}" in tpl and q and rules.topic_name and rules.topic_name.lower() in q.lower():
            return ""                                    # naam line mein pehle se hai: dobara nahi
        title = tpl.replace("{M}", rules.topic_name).replace("{N}", name).replace("{T}", topic).replace("{Q}", q)
        title = rules.with_must(_calm_case(title, [rules.topic_name, name]))
        if not title or len(title) > 90 or title.lower() in avoid or not rules.ok(title, clip_text):
            return ""
        return title
    for q in (quotes if deep else quotes[:6]):           # clip ki apni line pehle (sab se sach); deep = har line
        for tpl in turn(CLEAN_QUOTE):
            title = build(tpl, q)
            if title:
                return title
    for tpl in turn(CLEAN_PLAIN):
        title = build(tpl, "")
        if title:
            return title
    if deep:
        # clip ke baaqi topics aur mazeed andaaz: phir bhi clip ki asal baat, aam jumla nahi
        from app.edit.titles import find_topics
        for other in find_topics(clip_text, skip):
            if not rules.political and other in POLITICAL_TOPICS:
                continue
            topic = other
            for tpl in turn(CLEAN_PLAIN + CLEAN_MORE):
                title = build(tpl, "")
                if title:
                    return title
    return ""                                            # aage runner: video ke title se, phir aam jumle
