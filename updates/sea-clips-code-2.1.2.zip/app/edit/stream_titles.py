"""
=====================================================================
  EDIT / STREAM TITLES        (20 Nov 2026, GTA 6 stream clips)
  Kaam: streamer clips ke viral andaaz ke title: "{Naam} ... {game} 😭"
  (Kai Cenat / Jynxzi ki viral clips jaisa: naam pehle, kya hua, emoji).
  Clip ki baat mein jo hua (mar gaya, plane, police, gaadi, hansi ...)
  us ke hisaab se saancha; kuch na mile to aam saanche. Kabhi kabhi
  streamer ka apna chhota chillata jumla quote mein.
  Ek video ke titles aapas mein alag (used).
=====================================================================
"""
from __future__ import annotations

import re
import zlib

# (lafz jo clip mein hon, saanche). {n} = streamer, {g} = game
BUCKETS: list[tuple[tuple[str, ...], tuple[str, ...]]] = [
    (("wasted", "died", "dead", "killed me", "i'm dead", "respawn", "failed", "mission failed"),
     ("{n} Got WASTED In {g} 😭", "{n} Did NOT Survive This In {g} 💀", "{g} Humbled {n} Real Quick 😭",
      "{n} Failed The Mission In The Funniest Way 😭")),
    (("plane", "fly", "flying", "pilot", "land", "landing", "crash", "altitude"),
     ("{n} Should NOT Be Flying Planes In {g} 💀", "{n} Tried To Land A Plane In {g} 😭",
      "{n}'s Pilot Skills In {g} Are Crazy 💀", "{n} vs The Plane In {g} 😭")),
    (("cops", "police", "wanted", "stars", "sirens", "arrest", "busted"),
     ("{n} vs The Cops In {g} 🚨", "{n} Got Chased By The Police In {g} 😭", "The {g} Cops Did {n} Dirty 💀")),
    (("car", "drive", "driving", "steal", "stole", "crashed", "lambo", "bike", "boat"),
     ("{n}'s Driving In {g} Is Crazy 💀", "{n} Stole The Wrong Car In {g} 😭", "{n} Can't Drive In {g} 😭")),
    (("money", "rob", "robbery", "heist", "store", "cash", "bank"),
     ("{n} Tried To Rob A Store In {g} 😭", "{n}'s First Heist In {g} Went Wrong 💀")),
    (("gun", "shoot", "shot", "headshot", "fight", "punch"),
     ("{n} Started A Fight In {g} 💀", "{n} Went Crazy In {g} 😭")),
    (("chat", "bro", "yo", "what", "no way", "oh my god", "omg", "bruh"),
     ("{n} Was NOT Ready For This In {g} 😭", "{g} Had {n} Shook 💀", "{n}'s Reaction To {g} Is Priceless 😭",
      "{n} Couldn't Believe This In {g} 😭")),
]
GENERIC = ("{n}'s First Time Playing {g} 😭", "{n} Was NOT Ready For {g} 💀", "This {g} Moment Had {n} Shook 😭",
           "{n} Plays {g} And It Goes Wrong 😭", "{g} Is Too Real For {n} 💀")
QUOTE = ('"{q}" {n} In {g} 😭', '{n}: "{q}" 💀')
EMOJI_NAME = {"😭": "cry", "💀": "skull", "🚨": "shock", "😳": "shock", "🔥": "fire", "😂": "laugh"}
LAUGH = ("haha", "hahaha", "lmao", "lol", "laughing", "bro")
_NO = re.compile(r"\b(fuck|shit|bitch|nigg|fag|retard|damn|ass|dick|pussy|hell)\w*", re.I)


def _quote(text: str) -> str:
    """Streamer ka chhota chillata jumla (2-6 lafz, ! ya ? par khatam), gaaliyon ke baghair."""
    for part in re.split(r"(?<=[.!?])\s+", text):
        words = part.strip().split()
        if 2 <= len(words) <= 6 and part.strip()[-1:] in "!?" and not _NO.search(part):
            q = part.strip().strip("\"'")
            return q[:1].upper() + q[1:]
    return ""


def split_emoji(title: str) -> tuple[str, str]:
    """'X In GTA 6 😭' -> ('X In GTA 6', 'cry') (tool title aur emoji alag rakhta hai)."""
    name = ""
    for ch, nm in EMOJI_NAME.items():
        if ch in title:
            name = name or nm
            title = title.replace(ch, "")
    return re.sub(r"\s+", " ", title).strip(), name


def stream_title(clip_text: str, name: str, game: str, seed: str, used: set[str] | None = None,
                 ok=lambda t: True) -> str:
    """Clip ki baat se viral title (emoji ke saath); used mein pehle se ho to doosra saancha."""
    used = used or set()
    low = " " + re.sub(r"[^a-z' ]", " ", clip_text.lower()) + " "
    name, game = name.strip() or "He", game.strip() or "GTA 6"
    pools: list[tuple[str, ...]] = []
    for words, shapes in BUCKETS:
        hits = sum(low.count(f" {w} ") for w in words)
        if hits:
            pools.append(shapes)
    q = _quote(clip_text)
    h = zlib.crc32(seed.encode())
    order: list[str] = []
    if q and h % 3 == 0:
        order += [s.replace("{q}", q) for s in QUOTE]
    for shapes in pools:
        order += list(shapes)
    order += list(GENERIC)
    start = h % max(1, min(len(order), 4))
    order = order[start:] + order[:start]
    for shape in order:
        t = shape.format(n=name, g=game)
        if split_emoji(t)[0].lower() not in used and ok(split_emoji(t)[0]):
            return t
    return ""
