"""
=====================================================================
  EDIT / VIDEO TITLE      (clip ka title na bane to asal video ke title se)
  Kaam: har clip ka title pehle us ki apni baat se banta hai. Wo na bane
  to asal video (link / file) ke title se, har clip ke liye thora alag:
    "Charlie Kirk Debates College Students At The University of North
     Carolina" ->
      "Charlie Kirk Debates College Students at the University of North Carolina"
      "Charlie Kirk at the University of North Carolina"
      "Charlie Kirk Debates College Students"
      "Charlie Kirk vs College Students"
      ... aur aakhir mein "(Part 2)" jaise number (kabhi khaali nahi)
  Video ke title ka kachra (WATCH:, | channel, #tags, [Full], file ke
  _ aur id) pehle saaf hota hai.
=====================================================================
"""
from __future__ import annotations

import re

JUNK = re.compile(r"\[[^\]]*\]|\*[^*]*\*|\([^)]*(full|official|video|hd|4k|live|stream|clip|q&a)[^)]*\)|#\w+"
                  r"|\bfull\s+(video|episode|speech|interview|debate|q\s*&\s*a)\b.*$|\bq\s*&\s*a\s*$", re.I)
LEAD = re.compile(r"^(watch|breaking|new|exclusive|full video|full)\s*[:!|]\s*", re.I)
SMALL = {"a", "an", "the", "of", "on", "in", "to", "for", "and", "or", "at", "by", "with", "vs", "from"}


def clean_video_title(raw: str) -> str:
    """Video / file ke title se saaf, parhne laayak jumla ('' agar kuch na bache)."""
    t = (raw or "").replace("_", " ")
    t = re.sub(r"\s*[\[(]?[A-Za-z0-9_-]{11}[\])]?\s*$", "", t) if re.search(r"[\[(][A-Za-z0-9_-]{11}[\])]\s*$", t) else t
    t = JUNK.sub(" ", t)
    t = t.split(" | ")[0].split(" || ")[0]
    t = LEAD.sub("", t.strip())
    t = re.sub(r"\b(full v(ideo)?|full|official|uncut)\s*$", "", t, flags=re.I)
    t = re.sub(r"\b\d{6,}\b", " ", t)                       # upload ke lambe number
    t = re.sub(r"\b(?=\w*\d)(?=\w*[A-Za-z])\w{9,}\b", " ", t)   # 'KRON4Newsat4PM' jaise jure lafz
    t = re.sub(r"[^\w\s'’:,.&?!$%-]", " ", t)
    t = re.sub(r"\s+", " ", t).strip(" -:|,.")
    words = t.split()
    if len(words) < 2:
        return ""
    out = []
    for k, w in enumerate(words):
        low = w.lower()
        if low in SMALL and k:
            out.append(low)
        elif w.isupper() and len(w) <= 4:
            out.append(w)                                  # UNC, USA, NFL
        elif w.isupper():
            out.append(w.capitalize())                     # chillate CAPS nahi
        else:
            out.append(w[0].upper() + w[1:])
    return " ".join(out)


def _parts(title: str, name: str) -> list[str]:
    """Saaf title se chhote, sach hisse: naam + jagah, naam + kaam, 'naam vs ...'."""
    out = [title]
    low = title.lower()
    at = re.search(r"\b(at|in)\s+(the\s+)?([A-Z][\w'’.]*(?:\s+(?:of|the|[A-Z][\w'’.]*))*)", title)
    verb = re.match(rf"{re.escape(name)}\s+(\w+)\s+(.+?)(\s+(at|in|on)\s+.*)?$", title) if name else None
    if name and at:
        out.append(f"{name} at {'the ' if at.group(2) else ''}{at.group(3)}".strip())
    if verb:
        out.append(f"{name} {verb.group(1)} {verb.group(2)}".strip())
        if verb.group(1).lower() in ("debates", "debate", "vs", "takes", "faces", "confronts", "meets"):
            out.append(f"{name} vs {verb.group(2)}".strip())
    if name and not low.startswith(name.lower()):
        out.append(f"{name}: {title}")
    return [re.sub(r"\s+", " ", x).strip(" :,") for x in dict.fromkeys(out) if x]


def video_title_variants(raw: str, name: str = "", seed: int = 0) -> list[str]:
    """Asal video ke title se titles ki list (har clip ke liye seed se alag tarteeb), sab 90 harf tak."""
    base = clean_video_title(raw)
    if not base:
        return []
    parts = [p for p in _parts(base, name) if 2 <= len(p.split()) and len(p) <= 90]
    if not parts and len(base) > 90:
        parts = [base[:87].rsplit(" ", 1)[0]]
    if not parts:
        return []
    k = seed % len(parts)
    return parts[k:] + parts[:k]


def numbered(title: str, n: int) -> str:
    """Aakhri hal: '<title> (Part n)' (har clip alag, kabhi khaali nahi)."""
    return f"{title} (Part {max(1, n)})"
