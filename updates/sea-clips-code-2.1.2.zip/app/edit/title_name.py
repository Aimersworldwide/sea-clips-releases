"""
=====================================================================
  EDIT / TITLE NAME        (main speaker ka naam video ke title se)
  Kaam: "main speaker khud pehchano" wali campaign mein naam likha nahi
  hota. YouTube title aksar naam se shuru hota hai ("Charlie Kirk
  Debates College Students ..."). Wahi shuru wale 2-3 bare harf wale
  lafz naam maane jaate hain, taake clip ke title / hashtags mein naam
  aaye aur us ki spelling sahi rahe. Shak ho to koi naam nahi (ghalat
  naam se behtar hai naam na ho).
=====================================================================
"""
from __future__ import annotations

import re

SKIP_FIRST = {"the", "watch", "how", "why", "what", "when", "full", "video", "live", "breaking", "new",
              "exclusive", "must", "see", "wow", "omg", "watch:", "breaking:", "just", "in"}
NOT_NAME = {"debates", "debate", "destroys", "responds", "reacts", "vs", "versus", "students", "student",
            "college", "university", "of", "on", "at", "with", "and", "the", "a", "an", "to", "in", "for",
            "show", "podcast", "interview", "full", "episode", "live", "speech", "tour", "q", "qa", "explains",
            "says", "slams", "takes", "gets", "goes", "asks", "answers", "tried", "corner", "is", "was",
            "who", "why", "how", "what", "this", "that", "his", "her", "news", "america", "usa", "trump's",
            "rally", "speech", "conservatives", "conservative", "liberals", "liberal", "democrats", "republicans",
            "crowd", "town", "hall", "press", "conference", "fox", "cnn", "msnbc", "jubilee", "panel", "senate",
            "speaks", "talks", "discusses", "reveals", "calls", "shuts", "owns", "schools", "claps", "fires", "rips",
            "blasts", "torches", "exposes", "confronts", "warns", "admits", "breaks", "defends", "unloads",
            "dismantles", "humiliates", "silences", "obliterates", "crushes", "wrecks", "leaves", "makes",
            "tonight", "experience", "exchange", "heated", "between", "today", "daily", "weekly", "hour",
            "house", "congress", "hearing", "campus", "event", "highlights", "moments", "best", "funniest"}


def name_from_title(title: str) -> str:
    """'Charlie Kirk Debates College Students ...' -> 'Charlie Kirk'. Pakka na ho to ''."""
    tokens = (title or "").split()
    i = 0
    while i < len(tokens) and tokens[i].lower().strip(":!|-") in SKIP_FIRST:
        i += 1
    run: list[str] = []
    for tok in tokens[i:i + 4]:
        ends = tok.endswith((":", ",", "|", "!", "?"))
        clean = tok.strip(":,|!?\"()[]*").lstrip("'")
        if not re.fullmatch(r"[A-Z][A-Za-z'.]*", clean or "") or (clean.isupper() and len(clean) > 2) \
                or clean.lower().rstrip("'s") in NOT_NAME or clean.lower() in NOT_NAME:
            break
        possessive = clean.lower().endswith(("'s", "’s"))
        run.append(re.sub(r"['’]s$", "", clean).rstrip("'"))
        if ends or possessive:
            break
    # naam = pehla + aakhri naam; teesra lafz sirf tab jab beech wala initial ho ("Stephen A. Smith")
    if len(run) >= 3 and not re.fullmatch(r"[A-Z]\.?", run[1]):
        run = run[:2]
    if not 2 <= len(run) <= 3 or len(run[-1]) < 3:
        return ""
    return " ".join(run)
