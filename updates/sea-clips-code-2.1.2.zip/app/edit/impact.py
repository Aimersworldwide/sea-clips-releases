"""
Super (screen par shuru ka text) aur "asar" wale titles.

Kuch campaigns (jaise Diamonds: natural diamonds aur Botswana) kehti hain ke
har clip ke shuru mein screen par aisa jumla ho jo do cheezon ko jore
(cheez A ka mulk / log B par asar), aur clip ki apni baat se match kare.

Campaign mein "super_link" likha ho, jaise "Natural Diamonds | Botswana":
  * har clip ka Super clip ki baat ke topic se banta hai (education,
    wildlife, economy ...), aur us mein A aur B dono hamesha hote hain
  * title bhi isi topic se, Super se alag alfaaz mein
  * jis clip mein A ya B ka zikr hi nahi, wo clip campaign ki nahi
    (related() False): tool use nahi banata
Koi jhoota daawa nahi: topic sirf tab jab clip mein us ke lafz bole gaye.
"""
from __future__ import annotations

import re
import zlib

# topic: (clip ke lafz, Super ke jumle, title ke jumle)
#   {A} pehli cheez (Natural Diamonds), {B} doosri (Botswana)
THEMES: list[tuple[str, tuple[str, ...], tuple[str, ...], tuple[str, ...]]] = [
    ("scholarships",
     ("scholarship", "scholarships", "student allowance", "students allowance", "allowance", "sponsored"),
     ("{A} Help Fund Student Scholarships in {B}",
      "In {B}, {A} Help Pay for University",
      "{A} Support Students Across {B}"),
     ("How {A} Help Students in {B} Go to University",
      "{B} Students and the {A} That Fund Their Studies",
      "What {A} Mean for Students in {B}")),
    ("education",
     ("education", "school", "schools", "university", "universities", "student", "students", "teacher",
      "teachers", "learn", "learning", "classroom", "college"),
     ("{A} Help Fund Education in {B}",
      "How {A} Support Schools in {B}",
      "{A} Are Building Education in {B}"),
     ("How {A} Support Education in {B}",
      "Education in {B}: The Role of {A}",
      "What {A} Have Done for Schools in {B}")),
    ("wildlife",
     ("wildlife", "conservation", "conservancy", "animals", "elephants", "elephant", "nature", "park",
      "parks", "environment", "delta", "okavango", "lions", "rhino", "rhinos"),
     ("{A} and Wildlife Conservation in {B}",
      "{A}, Wildlife and the People of {B}",
      "{A} and the Wild Heart of {B}"),
     ("{A} and Wildlife in {B}",
      "Conservation in {B}: Where {A} Come In",
      "{B}'s Wildlife and Its {A}")),
    ("health",
     ("hospital", "hospitals", "clinic", "clinics", "health", "healthcare", "medical", "doctors"),
     ("{A} Help Fund Healthcare in {B}",
      "How {A} Support Health in {B}"),
     ("How {A} Support Healthcare in {B}",
      "Healthcare in {B} and the Role of {A}")),
    ("economy",
     ("economy", "economic", "money", "jobs", "job", "work", "income", "revenue", "development",
      "developed", "roads", "infrastructure", "growth", "grow", "wealth", "business", "businesses"),
     ("{A} Help Power the Economy of {B}",
      "How {A} Help {B} Grow",
      "{A} Help Build {B}"),
     ("How {A} Help {B} Grow",
      "{B}'s Economy and the Role of {A}",
      "What {A} Have Built in {B}")),
    ("tourism",
     ("tourism", "tourists", "tourist", "safari", "visitors", "lodge", "lodges"),
     ("{A}, Tourism and the Future of {B}",
      "{A} and Tourism Help Grow {B}"),
     ("{B}: {A}, Tourism and Wildlife",
      "How {A} and Tourism Shape {B}")),
    ("community",
     ("community", "communities", "people", "families", "village", "villages", "local", "locals", "country",
      "nation", "helped", "help", "helps"),
     ("{A} Help Communities in {B}",
      "How {A} Help the People of {B}",
      "{A} Make a Difference in {B}"),
     ("How {A} Help the People of {B}",
      "What {A} Mean to the People of {B}",
      "What {A} Have Done for {B}")),
]
# Clip mein A (diamonds) ka zikr hi nahi, sirf B (Botswana): koi daawa nahi, sirf sach jor ("B, home of A")
LINK_SUPER = {
    "scholarships": ("Student Life in {B}, Home of {A}", "Studying in {B}, the Land of {A}"),
    "education": ("Student Life in {B}, Home of {A}", "Inside a University in {B}, Home of {A}",
                  "Studying in {B}, the Land of {A}"),
    "wildlife": ("The Wild Side of {B}, Home of {A}", "Wildlife in {B}, the Land of {A}"),
    "tourism": ("Exploring {B}, Home of {A}", "A Trip Through {B}, the Land of {A}"),
}
LINK_GENERIC = ("Inside {B}, Home of {A}", "Life in {B}, the Land of {A}", "A Day in {B}, Home of {A}")
LINK_TITLE = {
    "scholarships": ("Student Life in {B}, the Home of {A}", "What It's Like to Study in {B}, Land of {A}"),
    "education": ("Student Life in {B}, the Home of {A}", "Touring a University in {B}, Land of {A}",
                  "What It's Like to Study in {B}, Land of {A}"),
    "wildlife": ("Wildlife in {B}, the Home of {A}", "Exploring the Wild Side of {B}, Land of {A}"),
    "tourism": ("Exploring {B}, the Home of {A}", "Travelling Through {B}, Land of {A}"),
}
LINK_TITLE_GENERIC = ("Life in {B}, the Home of {A}", "A Day in {B}, Land of {A}", "Inside {B}, the Home of {A}")
# (12 Nov) zyada re-edits: har topic ke saath ye aam (sach, bina khaas daawe) jumle bhi, taake Super aur
# title kam dohrayein. Topic wale pehle aate hain, phir ye.
MORE_SUPER = {
    "education": ("How {A} Are Shaping Education in {B}", "Students in {B} and the Power of {A}",
                  "Education First: {A} in {B}", "{A} Open Doors for Students in {B}"),
    "scholarships": ("How {A} Are Shaping Education in {B}", "Students in {B} and the Power of {A}"),
    "economy": ("How {A} Built Modern {B}", "{B}'s Growth Story Starts With {A}",
                "{A} Fuel {B}'s Development", "From the Ground Up: {A} in {B}"),
    "wildlife": ("{B}'s Wild Places and Its {A}", "Where {A} Meet Wildlife: {B}"),
    "community": ("{A} and Everyday Life in {B}", "The People of {B} and Their {A}"),
}
MORE_TITLE = {
    "education": ("Why Students in {B} Talk About {A}", "Inside {B}'s Education Story and {A}",
                  "How {A} Are Shaping Education in {B}", "Education in {B} and the Power of {A}"),
    "scholarships": ("Why Students in {B} Talk About {A}", "How {A} Are Shaping Education in {B}"),
    "economy": ("How {A} Built Modern {B}", "{B}'s Growth Story Starts With {A}",
                "The Money Behind {B}: {A}", "How {A} Fuel {B}'s Development"),
    "wildlife": ("{B}'s Wild Places and Its {A}", "Where {A} Meet Wildlife in {B}"),
    "community": ("What People in {B} Say About {A}", "{A} and Everyday Life in {B}"),
}
ANY_SUPER = ("Why {A} Matter to {B}", "{B}: A Nation Shaped by {A}", "The Real Impact of {A} in {B}",
             "Hear How {A} Shaped {B}", "From the Earth: {A} in {B}", "{A} and the Future of {B}")
ANY_TITLE = ("Why {A} Matter So Much in {B}", "The Real Impact of {A} on {B}", "How {A} Shaped Modern {B}",
             "{B} and Its {A}: The Real Story", "{A} and the Future of {B}", "Here's What {A} Did for {B}",
             "The {A} Story Behind {B}", "{B}'s {A} Explained", "Why {B} Is Proud of Its {A}")
LINK_ANY_SUPER = ("Discover {B}, the Land of {A}", "Welcome to {B}, Home of {A}", "This Is {B}, Land of {A}",
                  "Everyday Life in {B}, Home of {A}")
LINK_ANY_TITLE = ("Discover {B}, the Land of {A}", "Welcome to {B}, Home of {A}",
                  "Everyday Life in {B}, Home of {A}", "This Is {B}, Land of {A}",
                  "Meet the People of {B}, Land of {A}", "Inside {B}, a Nation of {A}")
GENERIC_SUPER = ("What {A} Mean for {B}", "{A} and the People of {B}", "The Story of {A} in {B}")
GENERIC_TITLE = ("What {A} Mean for {B}", "{A} and {B}: What It Means", "The Story of {A} in {B}")


def parse_link(text: str) -> tuple[str, str]:
    """"Natural Diamonds | Botswana" -> ("Natural Diamonds", "Botswana"); khaali = ("", "")."""
    parts = [x.strip() for x in re.split(r"[|,;/]", text or "") if x.strip()]
    if not parts:
        return "", ""
    return parts[0], (parts[1] if len(parts) > 1 else "")


def _core(term: str) -> str:
    """Pehchan ka asal lafz: "Natural Diamonds" -> "diamond", "Botswana" -> "botswana"."""
    words = [w for w in re.findall(r"[a-z]+", term.lower()) if w not in ("natural", "real", "the", "of")]
    word = words[-1] if words else term.lower()
    return word[:-1] if word.endswith("s") and len(word) > 4 else word


def related(clip_text: str, link: str) -> bool:
    """Clip mein A ya B ka zikr hai? (Na ho to clip is campaign ki nahi.)"""
    a, b = parse_link(link)
    low = clip_text.lower()
    return any(_core(t) in low for t in (a, b) if t)


def mentions_a(clip_text: str, a: str) -> bool:
    """Clip mein pehli cheez (diamonds) ka zikr hai? Na ho to Super / title koi daawa nahi karte."""
    return bool(a) and _core(a) in clip_text.lower()


def theme_of(clip_text: str) -> str:
    """Clip ki baat ka topic: jis topic ke sab se zyada lafz bole gaye (barabar ho to list mein pehla)."""
    low = " " + re.sub(r"[^a-z' ]", " ", clip_text.lower()) + " "
    best, hits = "", 0
    for name, keys, _s, _t in THEMES:
        n = sum(len(re.findall(rf"\b{re.escape(k)}\b", low)) for k in keys)
        if name == "community":
            n = n // 2                         # aam lafz: sirf jab koi aur topic na mile
        if n > hits:
            best, hits = name, n
    return best


def _fill(tpl: str, a: str, b: str) -> str:
    return re.sub(r"\s+", " ", tpl.replace("{A}", a).replace("{B}", b)).strip()


def _pick(pool: tuple[str, ...], a: str, b: str, seed: str, used: set[str] | None) -> str:
    start = zlib.crc32(seed.encode()) % len(pool)
    order = pool[start:] + pool[:start]
    for tpl in order:
        out = _fill(tpl, a, b)
        if not used or out.lower() not in used:
            return out
    return _fill(order[0], a, b)


def make_super(clip_text: str, link: str, seed: str = "", used: set[str] | None = None) -> str:
    """Shuru ka Super: A aur B dono, clip ke topic se."""
    a, b = parse_link(link)
    if not a:
        return ""
    if not b:
        return a
    t = theme_of(clip_text)
    if not mentions_a(clip_text, a):
        return _pick(LINK_SUPER.get(t, LINK_GENERIC) + LINK_ANY_SUPER, a, b, seed + ":super", used)
    pool = next((s for n, _k, s, _t in THEMES if n == t), GENERIC_SUPER)
    return _pick(pool + MORE_SUPER.get(t, ()) + ANY_SUPER, a, b, seed + ":super", used)


# (13 Nov) titles kabhi khatam na hon: upar wale saare use ho jayein to "Hook: jumla" wale naye title
# (har hook + har jumla = sau se zyada). Hook sirf aam alfaaz, koi naya daawa nahi.
TITLE_HOOKS = ("Inside Botswana", "Botswana Up Close", "Real Stories", "The Bigger Picture", "Beyond the Sparkle",
               "From the Earth", "Diamond Country", "Africa's Diamond Story", "A Closer Look", "Worth Knowing",
               "Behind the Sparkle", "Did You Know", "Straight From Botswana", "The Botswana Story",
               "Natural Diamond Facts", "Why It Matters", "On the Ground in Botswana", "Real Diamonds, Real Impact",
               "Botswana in Focus", "The Diamond Effect", "Heart of Africa", "Earth's Treasure", "Proud Botswana",
               "Story Time", "Life in Botswana", "Mined With Purpose", "Hidden Facts", "Southern Africa Stories",
               "Shine On Botswana", "Diamonds Explained", "Inside the Story", "Big Picture Botswana")


def _hooked(pool: tuple[str, ...], a: str, b: str, seed: str, used: set[str] | None) -> str:
    """Pool ke har jumle ke aage ek hook: pehla jo abhi tak use na hua ho."""
    import zlib as _z
    hs = TITLE_HOOKS[_z.crc32((seed + ":h").encode()) % len(TITLE_HOOKS):] + \
        TITLE_HOOKS[:_z.crc32((seed + ":h").encode()) % len(TITLE_HOOKS)]
    for h in hs:
        for tpl in pool:
            body = _fill(tpl, a, b)
            if ":" in body:                       # pehle se "X: Y" wala jumla: do colon nahi
                continue
            out = f"{h}: {body}"
            if not used or out.lower() not in used:
                return out
    return ""


def make_impact_title(clip_text: str, link: str, seed: str = "", used: set[str] | None = None,
                      avoid: str = "") -> str:
    """Title: Super jaisa topic, magar alag alfaaz (Super se mukhtalif)."""
    a, b = parse_link(link)
    if not a or not b:
        return ""
    t = theme_of(clip_text)
    if not mentions_a(clip_text, a):
        pool = LINK_TITLE.get(t, LINK_TITLE_GENERIC) + LINK_ANY_TITLE
    else:
        pool = next((tt for n, _k, _s, tt in THEMES if n == t), GENERIC_TITLE) + MORE_TITLE.get(t, ()) + ANY_TITLE
    head = " ".join(avoid.lower().split()[:3])
    pool = tuple(x for x in pool if not head or " ".join(_fill(x, a, b).lower().split()[:3]) != head) or pool
    out = _pick(pool, a, b, seed + ":title", used)
    if used and out.lower() in used:            # saare seedhe title use ho chuke: hook wala naya
        out = _hooked(pool, a, b, seed, used) or out
    return out


# ---------------------------------------------------------------------
#  (19 Nov, user) Classic ka upar wala CHHOTA title (Super wali campaign, jaise Diamonds):
#  viral reference jaisa 3 se 6 lafz. Pehle clip ki apni mashhoor line (jo bolne wale ne kahi,
#  topic wali, poori aur saaf); na mile to topic ka chhota, sach, bina clickbait jumla.
#  Super (A aur B dono) alag se neeche wali patti mein rehta hai, is liye title par koi pabandi nahi
#  ke dono naam hon.
# ---------------------------------------------------------------------
SHORT_TITLES: dict[str, tuple[str, ...]] = {
    "scholarships": ("Diamonds Fund Their Dreams", "Scholarships Made Possible", "Studying On Diamond Support",
                     "A Future Paid By Diamonds"),
    "education": ("Education Built On Diamonds", "Diamonds Built These Schools", "Free School In Botswana",
                  "Where Diamonds Meet Classrooms", "Learning In Diamond Country"),
    "wildlife": ("Botswana's Wild Side", "Where Diamonds Meet Wildlife", "Wild Botswana Up Close",
                 "Diamonds And Wildlife Together"),
    "health": ("Healthcare Built On Diamonds", "Diamonds Behind These Clinics", "Health Care In Botswana"),
    "economy": ("A Nation Built On Diamonds", "Diamonds Built This Country", "How Botswana Grew",
                "The Diamond Economy"),
    "tourism": ("Welcome To Diamond Country", "Botswana Is Different", "First Day In Botswana",
                "Diamond Country Up Close"),
    "community": ("Proud Of Botswana", "Real Botswana Stories", "What Diamonds Mean Here",
                  "The People Of Botswana"),
    "": ("The Botswana Diamond Story", "Diamond Country", "Natural Diamonds, Real Impact", "Inside Botswana"),
}
_LEAD_FILLER = {"and", "so", "but", "um", "uh", "like", "well", "because", "yeah", "okay", "oh", "you",
                "know", "i", "mean", "then", "also", "just", "actually", "basically", "really"}
_BAD_END = {"the", "a", "an", "to", "and", "of", "with", "for", "in", "our", "my", "is", "are", "was", "that",
            "this", "on", "at", "by", "from", "or", "but", "so", "their", "his", "her", "its", "we", "they", "it",
            "be", "have", "has", "had", "very", "more", "most", "some", "any", "as", "if", "when", "where"}
_STRONG = {"free", "proud", "never", "everything", "changed", "best", "love", "beautiful", "amazing", "real",
           "built", "dream", "dreams", "future", "first", "home", "thanks", "grateful", "possible", "incredible"}
_NO_GO = {"poor", "poverty", "corrupt", "corruption", "stole", "stolen", "war", "blood", "conflict", "fake",
          "lab", "synthetic", "exploit", "exploited", "exploitation", "hate", "kill", "died", "dead", "problem",
          "problems", "bad", "worst", "sad", "hard", "difficult", "don't", "not", "no", "can't", "won't"}


def _title_case(text: str) -> str:
    small = {"of", "the", "and", "a", "an", "in", "on", "to", "for", "at", "by"}
    out = []
    for i, w in enumerate(text.split()):
        low = w.lower()
        out.append(low if (i and low in small) else (w[:1].upper() + w[1:]))
    return " ".join(out)


def spoken_lines(clip_text: str) -> list[str]:
    """Clip ki chhoti, poori lines (3 se 6 lafz), shuru ke 'and / so / um' hata kar."""
    parts = re.split(r"(?<=[.!?])\s+|[,;:—]\s*|\s+-\s+", clip_text or "")
    out = []
    for raw in parts:
        words = re.findall(r"[A-Za-z][A-Za-z']*|\d+", raw)
        while words and words[0].lower() in _LEAD_FILLER:
            words = words[1:]
        if not 3 <= len(words) <= 6:
            continue
        if words[-1].lower() in _BAD_END:
            continue
        out.append(" ".join(words))
    return out


def classic_short_title(clip_text: str, link: str, seed: str = "", used: set[str] | None = None,
                        ok=None) -> str:
    """Classic ka chhota title: clip ki apni topic wali line, warna topic ka chhota jumla. `ok(text)` campaign
    ke rules (mana lafz, gaali) ka aakhri check."""
    a, b = parse_link(link)
    core_a = _core(a) if a else "diamond"
    core_b = (b or "botswana").lower()
    theme = theme_of(clip_text)
    keys = next((k for n, k, _s, _t in THEMES if n == theme), ())
    best, best_score = "", 0.0
    for line in spoken_lines(clip_text):
        low = line.lower()
        toks = set(re.findall(r"[a-z']+", low))
        if toks & _NO_GO:
            continue
        score = 0.0
        score += 3 if core_a in low else 0
        score += 3 if core_b in low else 0
        score += sum(1 for k in keys if re.search(rf"\b{re.escape(k)}\b", low))
        score += sum(0.8 for t in toks if t in _STRONG)
        score -= 0.4 * max(0, len(line.split()) - 5)          # chhota behtar
        cand = _title_case(line)
        if used and cand.lower() in used:
            continue
        if ok is not None and not ok(cand):
            continue
        if score > best_score:
            best, best_score = cand, score
    if best and best_score >= 3:
        return best
    pool = SHORT_TITLES.get(theme) or SHORT_TITLES[""]
    if not mentions_a(clip_text, a):
        pool = pool + SHORT_TITLES[""]
    import zlib as _z
    start = _z.crc32((seed + ":short").encode()) % len(pool)
    for i in range(len(pool)):
        cand = pool[(start + i) % len(pool)]
        if (not used or cand.lower() not in used) and (ok is None or ok(cand)):
            return cand
    return pool[start]
