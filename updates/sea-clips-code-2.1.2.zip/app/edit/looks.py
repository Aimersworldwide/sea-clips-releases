"""
=====================================================================
  EDIT / COLOUR LOOKS  (5 subtle looks)
  Kaam: halke colour looks (tasveer natural rehti hai).
  Limits from research: saturation within +-8 %, contrast up to
  +10 %, blacks never crushed, skin always natural, no heavy vignette.
  Each look is a short ffmpeg filter chain.
=====================================================================
"""
from __future__ import annotations

LOOKS: dict[str, str] = {
    # Balanced, just a touch of clarity.
    "neutral_clean": "eq=contrast=1.03:saturation=1.02",
    # Slightly warm mids, like TV news.
    "warm_broadcast": "colorbalance=rm=0.025:bm=-0.025,eq=contrast=1.04:saturation=1.03",
    # Soft film: lifted blacks, gentle S-curve, a little less colour.
    "soft_film": "curves=all='0/0.025 0.25/0.235 0.75/0.765 1/0.985',eq=saturation=0.96",
    # Cool shadows, neutral skin.
    "cool_newsroom": "colorbalance=rs=-0.025:bs=0.035,eq=contrast=1.04",
    # Richer contrast, slightly calmer colour.
    "rich_contrast": "curves=all='0/0 0.25/0.23 0.75/0.77 1/1',eq=contrast=1.05:saturation=0.97",
}

LOOK_ORDER = list(LOOKS)


def look_filter(name: str | None) -> str:
    return LOOKS.get(name or "", "")
