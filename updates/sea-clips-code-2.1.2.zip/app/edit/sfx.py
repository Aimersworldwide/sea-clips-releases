"""
=====================================================================
  EDIT / SOUND EFFECTS  (setting, off by default)
  Kaam: sound effects (setting se on / off, default off).
  Soft whoosh, pop and hit sounds under the edit: a pop or hit when
  the hook title appears, a whoosh into camera cuts and reaction
  shots, a hit or whoosh on punch zooms.
  Every sound is made here by the app itself from simple maths (noise
  and tones), so there is no download, no licence and no copyright
  risk, and the sound is identical on every laptop.
  Three sound families give re-edits a different feel:
    soft   : pop on the hook, swish on cuts, whoosh on zooms
    punchy : hit on the hook, whoosh on cuts, hit on zooms
    clean  : pop on the hook and zooms only, cuts stay silent
  Levels stay well under the voice (peaks -16 to -22 dBFS against a
  voice at -14 LUFS) and there is at least 1.5 s between two sounds.
=====================================================================
"""
from __future__ import annotations

import wave
from functools import lru_cache
from pathlib import Path

RATE = 48000
FAMILIES = ("soft", "punchy", "clean")
ROLES = {
    "soft": {"hook": "pop", "cut": "swish", "zoom": "whoosh"},
    "punchy": {"hook": "hit", "cut": "whoosh", "zoom": "hit"},
    "clean": {"hook": "pop", "cut": "", "zoom": "pop"},
}
PEAK_DB = {"whoosh": -20.0, "swish": -22.0, "pop": -18.0, "hit": -16.0}
# where the sound's strongest moment sits (seconds after it starts): it should hit ON the event
ACCENT = {"whoosh": 0.30, "swish": 0.16, "pop": 0.0, "hit": 0.0}
MIN_GAP = 1.5
MAX_SOUNDS = 6


def _bandpass_sweep(noise, f0: float, f1: float, q: float = 1.4):
    """Noise through a band pass filter whose centre glides from f0 to f1 (biquad, per sample)."""
    import math

    import numpy as np
    n = len(noise)
    out = np.zeros(n, np.float64)
    x1 = x2 = y1 = y2 = 0.0
    for i in range(n):
        if i % 32 == 0:                                  # update the filter every 32 samples
            f = f0 * (f1 / f0) ** (i / max(1, n - 1))
            w = 2 * math.pi * f / RATE
            alpha = math.sin(w) / (2 * q)
            a0 = 1 + alpha
            b0, b2 = alpha / a0, -alpha / a0
            a1, a2 = -2 * math.cos(w) / a0, (1 - alpha) / a0
        x = noise[i]
        y = b0 * x + b2 * x2 - a1 * y1 - a2 * y2
        x2, x1, y2, y1 = x1, x, y1, y
        out[i] = y
    return out


@lru_cache(maxsize=None)
def sound(name: str):
    """Stereo float array (n, 2) of one effect, peak at its PEAK_DB level."""
    import numpy as np
    rng = np.random.default_rng({"whoosh": 11, "swish": 12, "pop": 13, "hit": 14}[name])
    if name in ("whoosh", "swish"):
        dur = 0.45 if name == "whoosh" else 0.26
        n = int(dur * RATE)
        t = np.linspace(0, 1, n)
        lo, hi = (500, 3800) if name == "whoosh" else (1500, 6500)
        body = _bandpass_sweep(rng.standard_normal(n), lo, hi)
        acc = ACCENT[name] / dur
        env = np.where(t < acc, (t / acc) ** 2, ((1 - t) / (1 - acc)) ** 1.6)
        mono = body * env
        pan = np.linspace(0.25, 0.75, n)                 # glides from left to right
        stereo = np.stack([mono * np.sqrt(1 - pan), mono * np.sqrt(pan)], axis=1)
    elif name == "pop":
        n = int(0.09 * RATE)
        t = np.arange(n) / RATE
        freq = 300 + 700 * np.exp(-t / 0.012)
        mono = np.sin(2 * np.pi * np.cumsum(freq) / RATE) * np.exp(-t / 0.022)
        mono[:48] *= np.linspace(0, 1, 48)              # 1 ms fade in: no click
        stereo = np.stack([mono, mono], axis=1)
    elif name == "hit":
        n = int(0.38 * RATE)
        t = np.arange(n) / RATE
        freq = 45 + 70 * np.exp(-t / 0.05)
        tone = np.sin(2 * np.pi * np.cumsum(freq) / RATE) * np.exp(-t / 0.11)
        burst = np.convolve(rng.standard_normal(n), np.ones(24) / 24, mode="same") * np.exp(-t / 0.018) * 0.6
        mono = tone + burst
        mono[:96] *= np.linspace(0, 1, 96)
        stereo = np.stack([mono, mono], axis=1)
    else:
        raise ValueError(name)
    peak = float(np.abs(stereo).max()) or 1.0
    return (stereo / peak * 10 ** (PEAK_DB[name] / 20)).astype(np.float32)


def plan_sounds(family: str, hook_at: float | None, cuts: list[float], zooms: list[float],
                duration: float) -> list[tuple[float, str]]:
    """(event time, sound) list: hook first, then zooms, then cuts; spaced, capped, inside the clip."""
    roles = ROLES.get(family, ROLES["soft"])
    wanted: list[tuple[float, str]] = []
    if hook_at is not None and roles["hook"]:
        wanted.append((hook_at, roles["hook"]))
    wanted += [(t, roles["zoom"]) for t in zooms if roles["zoom"]]
    wanted += [(t, roles["cut"]) for t in cuts if roles["cut"]]
    chosen: list[tuple[float, str]] = []
    for t, name in wanted:                                # earlier entries have priority
        start = t - ACCENT[name]
        if start < 0 or t > duration - 0.3:
            continue
        if any(abs(t - c) < MIN_GAP for c, _ in chosen):
            continue
        chosen.append((round(t, 3), name))
        if len(chosen) >= MAX_SOUNDS:
            break
    return sorted(chosen)


def write_track(events: list[tuple[float, str]], duration: float, path: Path) -> Path:
    """One stereo 48 kHz WAV as long as the clip with every sound at its place."""
    import numpy as np
    n = int(duration * RATE) + RATE // 10
    track = np.zeros((n, 2), np.float32)
    for t, name in events:
        snd = sound(name)
        a = int((t - ACCENT[name]) * RATE)
        if a < 0 or a >= n:
            continue
        b = min(n, a + len(snd))
        track[a:b] += snd[: b - a]
    pcm = (np.clip(track, -1, 1) * 32767).astype("<i2")
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm.tobytes())
    return path
