"""
=====================================================================
  EDIT / TITLES + HASHTAGS
  Kaam: har clip ka viral andaaz ka title aur hashtags, clip ki apni
  baat (transcript) se. Andaaz un debate channels se seekha gaya jo
  lakhon views le rahe hain (Belmar Division, Debates Capital,
  Debates Raw, Oct 2026):
    * main speaker ka naam + ek taqatwar lafz CAPS mein + topic + emoji
      "Charlie Kirk SILENCES a Socialist Student with ONE Simple Question 🔥"
    * jawab ka intezar: "He Was NOT Ready for Charlie Kirk's Answer 😳"
    * har lafz bara harf se, 40 se 70 harf, aakhir mein ek emoji
    * hashtags: naam (#charliekirk), topic, aur 2 aam (#debate, #shorts...)
  Title kabhi wo baat nahi kehta jo clip mein nahi: topic aur quote
  clip ke apne alfaaz se aate hain. Bure / beep wale lafz kabhi nahi.
=====================================================================
"""
from __future__ import annotations

import hashlib
import re

# emoji naam -> assets/emoji/<naam>.png (video pe) aur asli emoji (Clips List / file mein)
EMOJI = {"shock": "😳", "fire": "🔥", "laugh": "😂", "cry": "😭", "mindblown": "🤯", "eyes": "👀",
         "think": "🤔", "skull": "💀", "heart": "❤️", "clap": "👏", "hundred": "💯", "wow": "😮"}

# topic: lafz jo clip mein aayein -> (title mein topic, hashtag)
TOPICS: list[tuple[tuple[str, ...], str, str]] = [
    (("trump",), "Trump", "trump"),
    (("biden",), "Biden", "biden"),
    (("kamala", "harris"), "Kamala Harris", "kamalaharris"),
    (("impeach",), "Impeachment", "impeachment"),
    (("election", "vote", "voting", "ballot"), "the Election", "election"),
    (("abortion", "pro-life", "pro life", "unborn"), "Abortion", "abortion"),
    (("gun", "second amendment", "firearm"), "Gun Control", "guncontrol"),
    (("immigra", "border", "illegal alien", "deport"), "Immigration", "immigration"),
    (("socialis", "communis", "marx"), "Socialism", "socialism"),
    (("capitalis", "free market"), "Capitalism", "capitalism"),
    (("tax",), "Taxes", "taxes"),
    (("god", "jesus", "bible", "christian", "church", "faith"), "Faith", "faith"),
    (("marriage", "husband", "wife"), "Marriage", "marriage"),
    (("israel", "gaza", "palestin", "hamas"), "Israel", "israel"),
    (("ukraine", "russia", "putin"), "Ukraine", "ukraine"),
    (("climate", "global warming"), "Climate Change", "climate"),
    (("transgender", "gender"), "Gender", "gender"),
    (("racism", "racist", "privilege"), "Racism", "racism"),
    (("college", "student", "university", "campus"), "College", "college"),
    (("media", "cnn", "fox news", "msnbc", "the view"), "the Media", "media"),
    (("democrat",), "Democrats", "democrats"),
    (("republican", "gop"), "Republicans", "republicans"),
    (("prison", "jail"), "Prison", "prison"),
    (("economy", "inflation", "prices"), "the Economy", "economy"),
    (("retirement", "retiree", "pension", "savings", "401k"), "Retirement Savings", "retirement"),
    (("senior", "elderly"), "Seniors", "seniors"),
    (("small business",), "Small Business", "smallbusiness"),
    (("veteran",), "Veterans", "veterans"),
    (("health care", "healthcare", "medicare", "insurance"), "Health Care", "healthcare"),
    (("school", "teacher", "education"), "Education", "education"),
    (("crime", "police"), "Crime", "crime"),
    (("science", "scientist", "study is", "studies", "the study"), "Science", "science"),
    (("constitution", "first amendment", "church and state"), "the Constitution", "constitution"),
    (("c-section", "cesarean", "medical", "doctor", "surgery"), "Medicine", "medicine"),
    (("free speech", "dialogue", "discussion"), "Free Speech", "freespeech"),
    (("family", "kids", "children", "parents"), "Family", "family"),
    (("history", "founders", "founding fathers", "hamilton"), "American History", "history"),
]

POPULAR_TAGS = ("debate", "debates", "politics", "shorts", "viral", "trending", "fyp", "foryou", "podcast", "news")

# (template, emoji, kis clip pe) - {N} naam, {T} topic, {Q} clip ki chhoti line
WITH_TOPIC = [
    ("{N} Breaks Down {T} Perfectly", "fire", ""),
    ("{N} Gets REAL About {T}", "shock", ""),
    ("{N}'s Take on {T} Is EVERYTHING", "fire", ""),
    ("{N} Explains {T} in Under a Minute", "fire", ""),
    ("Nobody Talks About This {t} Point", "eyes", ""),
    ("{N} on {T}: Must Watch", "eyes", ""),
    ("{N} Was NOT Holding Back on {T}", "shock", ""),
    ("{N} Just Said It About {T}", "eyes", ""),
]
QA = [
    ("{N} SHUTS DOWN the {t} Argument", "fire", "qa"),
    ("He Was NOT Ready for {N}'s Answer", "shock", "qa"),
    ("Wait for {N}'s Answer", "shock", "qa"),
    ("{N} Had the PERFECT Answer", "fire", "qa"),
    ("They Did NOT Expect {N}'s Response", "shock", "qa"),
]
WIT = [
    ("{N}'s Comeback Was Too Good", "laugh", "wit"),
    ("{N}'s Timing Was PERFECT", "laugh", "wit"),
    ("{N} Is Too Funny for This", "laugh", "wit"),
]
QUOTE = [
    ('"{Q}"', "shock", "quote"),
    ('{N}: "{Q}"', "fire", "quote"),
]
GENERIC = [
    ("{N} Said What Everyone Was Thinking", "shock", ""),
    ("{N} Didn't Hold Back Here", "fire", ""),
    ("This {N} Moment Hits Different", "shock", ""),
    ("{N} Said It Best", "clap", ""),
    ("{N} Made His Point in Seconds", "fire", ""),
    ("{N} Spoke the TRUTH Here", "hundred", ""),
    ("{N} Explains It PERFECTLY", "fire", ""),
    ("Listen to {N} on This One", "eyes", ""),
    ("{N} Brought the Receipts", "fire", ""),
    ("{N} Keeps It REAL", "hundred", ""),
    ("{N} With a Point Nobody Can Argue", "fire", ""),
    ("You Need to Hear {N} Say This", "eyes", ""),
]

SMALL = {"a", "an", "the", "of", "on", "in", "to", "for", "and", "or", "at", "by", "with"}


def title_case(text: str) -> str:
    """Har lafz bara harf se (CAPS wale waise hi), jaise un channels ke titles."""
    out = []
    for i, w in enumerate(text.split()):
        if w.isupper() and len(w) > 1:
            out.append(w)
        elif w.startswith('"') and len(w) > 1:
            out.append('"' + w[1:2].upper() + w[2:])
        elif i and w.lower() in SMALL:
            out.append(w.lower())
        else:
            out.append(w[:1].upper() + w[1:])
    return " ".join(out)


def find_topic(text: str, skip: list[str] | None = None) -> tuple[str, str]:
    """Clip ki baat ka sab se bara topic: (title ke liye, hashtag). Kuch na mile to ("", "")."""
    low = " " + text.lower() + " "
    skip_low = [s.lower() for s in (skip or []) if s]
    best, hits = ("", ""), 0
    for keys, label, tag in TOPICS:
        if any(label.lower() in s or s in label.lower() for s in skip_low):
            continue
        n = sum(low.count(k) for k in keys)
        if n > hits:
            best, hits = (label, tag), n
    return best


def find_topics(text: str, skip: list[str] | None = None) -> list[str]:
    """Clip ke saare topics (sab se zyada zikr wala pehle), sirf jin ka zikr ho."""
    low = " " + text.lower() + " "
    skip_low = [s.lower() for s in (skip or []) if s]
    found = []
    for keys, label, _tag in TOPICS:
        if any(label.lower() in s or s in label.lower() for s in skip_low):
            continue
        n = sum(low.count(k) for k in keys)
        if n:
            found.append((n, label))
    return [label for _n, label in sorted(found, key=lambda x: -x[0])]


FILLER_START = ("also,", "also", "so,", "so", "well,", "well", "and", "but", "now,", "like,", "um,", "uh,")


def _clean_quote(quote: str) -> str:
    """Line title ke laayak: shuru ke 'also / so / well' hatao, sawal ka nishan rehne do."""
    words = (quote or "").split()
    while words and words[0].lower() in FILLER_START:
        words = words[1:]
    if len(words) > 7:
        return ""                        # aadhi line title nahi banti
    text = " ".join(words).strip(" .,!;:")
    return text.rstrip("?") + "?" if text.endswith("?") or (quote or "").strip().endswith("?") and len(words) <= 7 \
        else text


def _pick(options: list, seed: str):
    return options[int(hashlib.sha1(seed.encode()).hexdigest(), 16) % len(options)]


def make_title(text: str, name: str, seed: str, quote: str = "", reasons: list[str] | None = None,
               avoid: set[str] | None = None) -> tuple[str, str]:
    """(title bina emoji, emoji naam). Title clip ki apni baat se, har clip ka alag."""
    reasons = [r.lower() for r in (reasons or [])]
    name = name.strip() or "He"
    topic, _ = find_topic(text, [name])
    quote = _clean_quote(quote)
    funny = any("wit" in r or "punchline" in r for r in reasons)
    pools: list[list] = []
    h = int(hashlib.sha1((seed + ":q").encode()).hexdigest(), 16)
    if quote and 3 <= len(quote.split()) <= 7 and h % 2 == 0:
        pools.append(QUOTE)              # clip ki apni zabardast line hi title (Debates Raw jaisa)
    if any("question" in r for r in reasons):
        pools.append(QA)
    if any("wit" in r or "punchline" in r for r in reasons):
        pools.append(WIT)
    if topic:
        pools.append(WITH_TOPIC)
    if quote and 2 <= len(quote.split()) <= 7:
        pools.append(QUOTE)
    pools.append(GENERIC)
    # pool bhi seed se ghoomta hai: har clip "Answer" wala title na le (andaaz bikhra rahe)
    hp = int(hashlib.sha1((seed + ":pool").encode()).hexdigest(), 16)
    if len(pools) > 1 and pools[0] is not QUOTE:
        k = hp % len(pools)
        pools = pools[k:] + pools[:k]
    first = pools[0]
    options = [t for pool in pools for t in pool]
    avoid = avoid or set()
    start = int(hashlib.sha1(seed.encode()).hexdigest(), 16) % len(first)   # pehli pasand: sab se mauzoon pool
    for k in range(len(options)):
        tpl, emoji, _ = options[(start + k) % len(options)]
        if ("{T}" in tpl or "{t}" in tpl) and not topic:
            continue
        if "{Q}" in tpl and not quote:
            continue
        short = topic[4:] if topic.startswith("the ") else topic
        title = tpl.replace("{N}", name).replace("{T}", topic).replace("{t}", short).replace("{Q}", quote)
        title = title_case(title)
        title = title.replace("'S ", "'s ")
        if "{Q}" in tpl and funny:
            emoji = "laugh"
        if len(title) > 70 or title.lower() in avoid:
            continue
        return title, emoji
    return title_case(f"{name} Said It Best"), "clap"


def make_hashtags(name: str, text: str, seed: str, fixed: str = "", count: int = 5,
                  viral: list[str] | None = None, generic: bool = True) -> str:
    """Campaign ke apne, naam, viral shorts wale (research), topic, phir aam hashtags (har clip thore alag)."""
    tags: list[str] = []
    for t in fixed.replace(",", " ").split():
        t = "#" + t.lstrip("#")                       # campaign ke likhe jaise (#NaturalDiamonds)
        if len(t) > 1 and t.lower() not in [x.lower() for x in tags]:
            tags.append(t)
    if name.strip():
        tags.append("#" + re.sub(r"[^a-z0-9]", "", name.lower()))
    for t in (viral or [])[:2]:                        # wahi jo milti hui viral shorts pe the
        if t not in tags and len(tags) < count - 1:
            tags.append(t)
    _, topic_tag = find_topic(text, [name])
    if topic_tag and "#" + topic_tag not in tags:
        tags.append("#" + topic_tag)
    pool = list(POPULAR_TAGS) if generic else []     # clean campaigns: sirf campaign se mutalliq tags
    k = int(hashlib.sha1(seed.encode()).hexdigest(), 16)
    while len(tags) < count and pool:
        t = "#" + pool.pop(k % len(pool))
        k //= 7
        if t not in tags:
            tags.append(t)
    seen: set[str] = set()
    out = []
    for t in tags:                                     # ek hi tag do dafa nahi (bare chhote haroof ka farq bhi nahi)
        if t.lower() not in seen:
            seen.add(t.lower())
            out.append(t)
    return " ".join(out)


def full_title(title: str, emoji: str) -> str:
    """Clips List / file ke liye: title + asli emoji."""
    return f"{title} {EMOJI.get(emoji, '')}".strip()
