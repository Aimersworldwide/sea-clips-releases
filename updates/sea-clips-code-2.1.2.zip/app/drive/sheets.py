"""
=====================================================================
  DRIVE / SHEETS
  Kaam: har campaign ki "Links" Google Sheet: do tab, Pending (abhi
  istemal nahi hue) aur Used (chal chuke). Wohi Google sign-in jo Drive
  upload ka hai (Drive ki ijazat Sheets par bhi chalti hai).
=====================================================================
"""
from __future__ import annotations

import urllib.parse

from app.drive.client import API, DriveClient

SHEETS = "https://sheets.googleapis.com/v4/spreadsheets"
PENDING, USED = "Pending", "Used"
PENDING_HEAD = ["Link", "Title", "Uploaded", "Minutes", "Channel", "Added", "Note", "In use"]
USED_HEAD = ["Link", "Title", "Uploaded", "Minutes", "Channel", "Used on", "Clips made", "Note"]


def _q(tab: str, rng: str = "") -> str:
    return urllib.parse.quote(f"'{tab}'" + (f"!{rng}" if rng else ""), safe="")


class SheetsClient:
    def __init__(self, drive: DriveClient):
        self.d = drive

    def create(self, title: str, folder_id: str = "") -> dict:
        """Nayi sheet (Pending + Used, sar-khat ke saath). {id, url, pending_gid, used_gid}"""
        body = {"properties": {"title": title},
                "sheets": [{"properties": {"title": PENDING, "gridProperties": {"frozenRowCount": 1}}},
                           {"properties": {"title": USED, "gridProperties": {"frozenRowCount": 1}}}]}
        r = self.d._call("POST", SHEETS, body=body)
        sid = r["spreadsheetId"]
        gids = {s["properties"]["title"]: s["properties"]["sheetId"] for s in r.get("sheets", [])}
        self.append(sid, PENDING, [PENDING_HEAD])
        self.append(sid, USED, [USED_HEAD])
        if folder_id:
            try:                                        # campaign ke Drive folder mein (Clip Pool ke saath)
                cur = self.d._call("GET", f"{API}/files/{sid}", {"fields": "parents", "supportsAllDrives": "true"})
                self.d._call("PATCH", f"{API}/files/{sid}",
                             {"addParents": folder_id, "removeParents": ",".join(cur.get("parents", [])),
                              "supportsAllDrives": "true"}, body={})
            except Exception:  # noqa: BLE001 - folder na mile to root mein hi theek
                pass
        return {"id": sid, "url": r.get("spreadsheetUrl", f"https://docs.google.com/spreadsheets/d/{sid}"),
                "pending_gid": gids.get(PENDING, 0), "used_gid": gids.get(USED, 1)}

    def exists(self, sid: str) -> bool:
        try:
            r = self.d._call("GET", f"{API}/files/{sid}", {"fields": "id,trashed", "supportsAllDrives": "true"})
            return not r.get("trashed")
        except Exception:  # noqa: BLE001
            return False

    def rows(self, sid: str, tab: str) -> list[list[str]]:
        r = self.d._call("GET", f"{SHEETS}/{sid}/values/{_q(tab, 'A:H')}")
        vals = r.get("values", [])
        return [list(map(str, v)) for v in vals[1:]]          # sar-khat ke baghair

    def append(self, sid: str, tab: str, rows: list[list]) -> None:
        if rows:
            self.d._call("POST", f"{SHEETS}/{sid}/values/{_q(tab, 'A1')}:append",
                         {"valueInputOption": "RAW", "insertDataOption": "INSERT_ROWS"}, body={"values": rows})

    def set_cell(self, sid: str, tab: str, cell: str, value: str) -> None:
        self.d._call("PUT", f"{SHEETS}/{sid}/values/{_q(tab, cell)}", {"valueInputOption": "RAW"},
                     body={"values": [[value]]})

    def delete_rows(self, sid: str, gid: int, indexes: list[int]) -> None:
        """Kai rows ek hi call mein (neeche se upar, taake baqi rows ki ginti na badle)."""
        reqs = [{"deleteDimension": {"range": {"sheetId": gid, "dimension": "ROWS", "startIndex": i,
                                               "endIndex": i + 1}}} for i in sorted(set(indexes), reverse=True)]
        if reqs:
            self.d._call("POST", f"{SHEETS}/{sid}:batchUpdate", body={"requests": reqs})

    def delete_row(self, sid: str, gid: int, index: int) -> None:
        """index = sheet ki asal row (0 = sar-khat)."""
        self.d._call("POST", f"{SHEETS}/{sid}:batchUpdate", body={"requests": [{"deleteDimension": {
            "range": {"sheetId": gid, "dimension": "ROWS", "startIndex": index, "endIndex": index + 1}}}]})
