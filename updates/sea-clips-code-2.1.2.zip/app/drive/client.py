"""
=====================================================================
  DRIVE / CLIENT
  Kaam: aapke Google Drive se baat (login, Clip Pool folder dhoondna,
  clip upload, upload ki tasdeeq). Sirf Python ki apni libraries.
  Sign-in is the Google "desktop app" flow: the browser opens Google's
  own page, the answer comes back to this laptop (127.0.0.1) only.
  The key file (drive_client.json) and the sign-in (drive_token.json)
  stay in the app data folder on this laptop.
=====================================================================
"""
from __future__ import annotations

import base64
import hashlib
import http.server
import json
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from app.core.logging_setup import get_logger
from app.core.paths import app_data_dir

log = get_logger("drive")

SCOPE = "https://www.googleapis.com/auth/drive"
AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
API = "https://www.googleapis.com/drive/v3"
UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"
FOLDER = "application/vnd.google-apps.folder"
CLIENT_FILE = "drive_client.json"
TOKEN_FILE = "drive_token.json"
POOL_NAME = "clip pool"


class DriveError(RuntimeError):
    pass


def norm(name: str) -> str:
    return "".join(ch for ch in (name or "").lower() if ch.isalnum())


def file_md5(path: Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------
#  Key file (Google Cloud "Desktop app" OAuth client)
# ---------------------------------------------------------------------
def read_client(path: Path) -> tuple[str, str]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise DriveError(f"This key file could not be read ({exc}).") from exc
    if "installed" not in data:
        if "web" in data:
            raise DriveError("This is a Web application key. In Google Cloud make a new OAuth client "
                             "of type 'Desktop app' and choose that file.")
        raise DriveError("This is not a Google OAuth key file.")
    d = data["installed"]
    if not d.get("client_id") or not d.get("client_secret"):
        raise DriveError("The key file has no client id / secret.")
    return d["client_id"], d["client_secret"]


def save_client(src: Path) -> None:
    read_client(src)                                    # check first
    (app_data_dir() / CLIENT_FILE).write_text(Path(src).read_text(encoding="utf-8"), encoding="utf-8")


def has_client() -> bool:
    try:
        read_client(app_data_dir() / CLIENT_FILE)
        return True
    except DriveError:
        return False


# ---------------------------------------------------------------------
#  Sign-in
# ---------------------------------------------------------------------
class DriveAuth:
    def __init__(self, folder: Path | None = None):
        self.folder = Path(folder or app_data_dir())
        self._access = ""
        self._expires = 0.0
        self._lock = threading.Lock()

    @property
    def token_path(self) -> Path:
        return self.folder / TOKEN_FILE

    def _client(self) -> tuple[str, str]:
        return read_client(self.folder / CLIENT_FILE)

    def token(self) -> dict:
        try:
            d = json.loads(self.token_path.read_text(encoding="utf-8"))
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    @property
    def connected(self) -> bool:
        return bool(self.token().get("refresh_token"))

    @property
    def email(self) -> str:
        return str(self.token().get("email") or "")

    def disconnect(self) -> None:
        try:
            self.token_path.unlink()
        except OSError:
            pass
        self._access, self._expires = "", 0.0

    def sign_in(self, open_browser, timeout: float = 300.0) -> str:
        """Browser mein Google login; jawab 127.0.0.1 par aata hai. Returns the account email."""
        cid, secret = self._client()
        verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
        state = secrets.token_urlsafe(16)
        got: dict = {}

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                if "code" in q or "error" in q:
                    got.update({k: v[0] for k, v in q.items()})
                ok = "code" in q and q.get("state", [""])[0] == state
                msg = ("Google Drive is connected. You can close this tab and go back to SEA CLIPS."
                       if ok else "Sign-in did not finish. Close this tab and try again in SEA CLIPS.")
                body = f"<html><body style='font-family:sans-serif;padding:40px'><h2>{msg}</h2></body></html>"
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(body.encode())

            def log_message(self, *a):
                pass

        srv = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        redirect = f"http://127.0.0.1:{srv.server_port}"
        url = AUTH_URL + "?" + urllib.parse.urlencode({
            "client_id": cid, "redirect_uri": redirect, "response_type": "code", "scope": SCOPE,
            "access_type": "offline", "prompt": "consent select_account", "state": state,
            "code_challenge": challenge, "code_challenge_method": "S256"})
        srv.timeout = 1.0
        open_browser(url)
        end = time.time() + timeout
        try:
            while not got and time.time() < end:
                srv.handle_request()
        finally:
            srv.server_close()
        if not got:
            raise DriveError("Sign-in timed out. Try again.")
        if got.get("state") != state or "code" not in got:
            raise DriveError(f"Sign-in was not completed ({got.get('error', 'no answer')}).")
        tok = _post_form(TOKEN_URL, {"code": got["code"], "client_id": cid, "client_secret": secret,
                                     "redirect_uri": redirect, "grant_type": "authorization_code",
                                     "code_verifier": verifier})
        if not tok.get("refresh_token"):
            raise DriveError("Google did not give a lasting sign-in. Remove SEA CLIPS from your Google "
                             "account's third-party access and connect again.")
        self._access, self._expires = tok["access_token"], time.time() + int(tok.get("expires_in", 3600)) - 120
        about = DriveClient(self).about()
        email = str(about.get("user", {}).get("emailAddress") or "")
        self.token_path.write_text(json.dumps({"refresh_token": tok["refresh_token"], "email": email}),
                                   encoding="utf-8")
        log.info("Drive connected: %s", email)
        return email

    def access_token(self, force: bool = False) -> str:
        with self._lock:
            if self._access and not force and time.time() < self._expires:
                return self._access
            rt = self.token().get("refresh_token")
            if not rt:
                raise DriveError("Google Drive is not connected.")
            cid, secret = self._client()
            try:
                tok = _post_form(TOKEN_URL, {"refresh_token": rt, "client_id": cid, "client_secret": secret,
                                             "grant_type": "refresh_token"})
            except DriveError as exc:
                if "invalid_grant" in str(exc):
                    raise DriveError("The Google Drive sign-in has expired. Connect Drive again in "
                                     "Settings.") from exc
                raise
            self._access = tok["access_token"]
            self._expires = time.time() + int(tok.get("expires_in", 3600)) - 120
            return self._access


def _post_form(url: str, form: dict) -> dict:
    req = urllib.request.Request(url, data=urllib.parse.urlencode(form).encode(), method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as exc:
        raise DriveError(f"Google sign-in error {exc.code}: {exc.read().decode(errors='replace')[:300]}") from exc
    except (urllib.error.URLError, OSError) as exc:
        raise DriveError(f"No internet connection to Google ({exc}).") from exc


# ---------------------------------------------------------------------
#  Drive calls
# ---------------------------------------------------------------------
class DriveClient:
    def __init__(self, auth: DriveAuth):
        self.auth = auth

    def _call(self, method: str, url: str, params: dict | None = None, body=None,
              headers: dict | None = None, raw: bool = False, tries: int = 4):
        if params:
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
        force = False
        for attempt in range(tries):
            h = {"Authorization": f"Bearer {self.auth.access_token(force)}", **(headers or {})}
            data = body
            if isinstance(body, (dict, list)):
                data = json.dumps(body).encode()
                h.setdefault("Content-Type", "application/json; charset=UTF-8")
            if hasattr(data, "seek"):
                data.seek(0)
            req = urllib.request.Request(url, data=data, method=method, headers=h)
            try:
                with urllib.request.urlopen(req, timeout=600) as r:
                    if raw:
                        return r
                    text = r.read().decode()
                    return json.loads(text) if text.strip() else {}
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode(errors="replace")[:300]
                if exc.code == 401 and attempt < tries - 1:
                    force = True
                    continue
                if exc.code in (429, 500, 502, 503, 504) and attempt < tries - 1:
                    time.sleep(2 ** attempt * 3)
                    continue
                raise DriveError(f"Drive error {exc.code}: {detail}") from exc
            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                if attempt < tries - 1:
                    time.sleep(2 ** attempt * 3)
                    continue
                raise DriveError(f"No internet connection to Google Drive ({exc}).") from exc
        raise DriveError("Drive did not answer.")

    def about(self) -> dict:
        return self._call("GET", f"{API}/about", {"fields": "user(emailAddress)"})

    def _list(self, q: str, fields: str) -> list[dict]:
        out, token = [], None
        while True:
            params = {"q": q, "fields": f"nextPageToken, files({fields})", "pageSize": 1000,
                      "supportsAllDrives": "true", "includeItemsFromAllDrives": "true"}
            if token:
                params["pageToken"] = token
            d = self._call("GET", f"{API}/files", params)
            out += d.get("files", [])
            token = d.get("nextPageToken")
            if not token:
                return out

    def clip_pools(self) -> list[dict]:
        """Har 'Clip Pool' folder aur us ka campaign folder: [{id, campaign, campaign_id}]."""
        pools = [f for f in self._list(f"mimeType='{FOLDER}' and trashed=false and name contains 'Pool'",
                                       "id, name, parents")
                 if norm(f.get("name")) == norm(POOL_NAME)]
        names: dict[str, str] = {}
        out = []
        for f in pools:
            parent = (f.get("parents") or [""])[0]
            if parent and parent not in names:
                try:
                    names[parent] = self._call("GET", f"{API}/files/{parent}",
                                               {"fields": "name", "supportsAllDrives": "true"}).get("name", "")
                except DriveError:
                    names[parent] = ""
            out.append({"id": f["id"], "campaign": names.get(parent, ""), "campaign_id": parent})
        return sorted(out, key=lambda x: x["campaign"].lower())

    def find_tagged(self, folder_id: str, key: str) -> list[dict]:
        q = (f"'{folder_id}' in parents and trashed=false and "
             f"appProperties has {{ key='aimers_clip' and value='{key}' }}")
        return self._list(q, "id, md5Checksum, size")

    def upload(self, path: Path, folder_id: str, name: str, key: str) -> dict:
        size = Path(path).stat().st_size
        meta = {"name": name, "parents": [folder_id], "appProperties": {"aimers_clip": key}}
        r = self._call("POST", UPLOAD, {"uploadType": "resumable", "supportsAllDrives": "true",
                                        "fields": "id,md5Checksum,size"}, body=meta,
                       headers={"X-Upload-Content-Type": "video/mp4", "X-Upload-Content-Length": str(size)},
                       raw=True)
        session = r.headers.get("Location")
        r.close()
        if not session:
            raise DriveError("Drive did not start the upload.")
        with open(path, "rb") as f:
            done = self._call("PUT", session, body=f,
                              headers={"Content-Type": "video/mp4", "Content-Length": str(size)}, tries=2)
        if done.get("id") and not done.get("md5Checksum"):
            # (18 Nov) upload ka jawab aksar sirf id deta hai: tasdeeq ke liye Drive se size / md5 alag se lo
            done = self._call("GET", f"{API}/files/{done['id']}",
                              {"fields": "id,md5Checksum,size", "supportsAllDrives": "true"})
        return done

    def trash(self, file_id: str) -> None:
        self._call("PATCH", f"{API}/files/{file_id}", {"supportsAllDrives": "true"}, body={"trashed": True})
