"""
=====================================================================
  DRIVE / SYNC
  Kaam: nayi clips ek saath (50 ka batch, ya video khatam hone par jitni
  bani hon) campaign ke Drive folder "<Campaign>/Clip Pool" mein; Drive
  par size aur md5 milne ke baad hi laptop se delete.
  Pure Python (no Qt) so it is tested without a screen; the app runs it
  on a background thread (app/ui/drive_sync.py).
=====================================================================
"""
from __future__ import annotations

import os
import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from app.core.logging_setup import get_logger
from app.drive.client import DriveError, file_md5, norm

log = get_logger("drive.sync")


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


@dataclass
class PendingClip:
    id: int
    label: str
    file_path: str
    campaign: str
    device: str


@dataclass
class BatchResult:
    uploaded: int = 0
    deleted: int = 0
    failed: list[str] = field(default_factory=list)
    no_folder: list[str] = field(default_factory=list)
    stopped: bool = False


def pending(db, since: str) -> list[PendingClip]:
    """Drive par na gayi, laptop par maujood, Drive jorne ke baad bani clips (sab ratings)."""
    if not since:
        return []
    with db._conn() as c:
        rows = c.execute("SELECT k.id, k.label, k.file_path, k.device_code, c.name FROM clips k "
                         "JOIN campaigns c ON c.id = k.campaign_id WHERE k.drive_id='' AND k.deleted_at='' "
                         "AND k.created_at >= ? ORDER BY k.id", (since,)).fetchall()
    return [PendingClip(r[0], r[1], r[2], r[4], r[3]) for r in rows]


def undeleted(db) -> list[tuple[int, str]]:
    """Drive par pohanch gayi magar laptop se abhi nahi hati (file khuli thi): dobara koshish."""
    with db._conn() as c:
        return [(r[0], r[1]) for r in
                c.execute("SELECT id, file_path FROM clips WHERE drive_id<>'' AND deleted_at=''").fetchall()]


def match_folder(campaign: str, pools: list[dict], chosen: dict[str, str]) -> str:
    """Campaign ka Clip Pool: pehle haath se chuna hua, warna naam se (bara chhota / space farq nahi)."""
    if chosen.get(campaign) == "none":
        return ""                               # haath se "Not set": laptop par hi rahein
    if chosen.get(campaign):
        return chosen[campaign]
    hits = [p["id"] for p in pools if norm(p["campaign"]) == norm(campaign)]
    return hits[0] if len(hits) == 1 else ""


def _remove(path: str) -> bool:
    try:
        os.remove(path)
        return True
    except FileNotFoundError:
        return True
    except OSError as exc:
        log.warning("Uploaded to Drive but could not delete %s yet: %s", path, exc)
        return False


def upload_batch(db, client, clips: list[PendingClip], chosen: dict[str, str],
                 stop: threading.Event | None = None, progress=None) -> BatchResult:
    """Clips ek ek Drive par (batch ek saath shuru hota hai), har ek ki tasdeeq, phir laptop se delete."""
    res = BatchResult()
    stop = stop or threading.Event()
    # pehle pichli dafa ki adhoori deletes
    for cid, path in undeleted(db):
        if _remove(path):
            db.mark_deleted([cid])
            res.deleted += 1
    if not clips:
        return res
    pools = client.clip_pools()
    fails_in_row = 0
    for n, clip in enumerate(clips, 1):
        if stop.is_set():
            res.stopped = True
            break
        if progress:
            progress(n - 1, len(clips), clip.label)
        folder = match_folder(clip.campaign, pools, chosen)
        if not folder:
            if clip.campaign not in res.no_folder:
                res.no_folder.append(clip.campaign)
            continue
        path = Path(clip.file_path)
        if not path.exists():
            continue                     # haath se hata di gayi: Library khud history mein daal deti hai
        key = f"{clip.device}-{clip.id}-{clip.label}"
        try:
            md5 = file_md5(path)
            size = path.stat().st_size
            done = next((f for f in client.find_tagged(folder, key)
                         if f.get("md5Checksum") == md5 and int(f.get("size") or 0) == size), None)
            if done is None:
                up = client.upload(path, folder, path.name, key)
                if up.get("md5Checksum") != md5 or int(up.get("size") or 0) != size:
                    try:
                        client.trash(up.get("id", ""))
                    except DriveError:
                        pass
                    raise DriveError("the copy on Drive did not match (size / checksum)")
                done = up
        except (DriveError, OSError) as exc:
            log.warning("Drive upload failed for %s: %s", clip.label, exc)
            res.failed.append(f"{clip.label}: {exc}")
            fails_in_row += 1
            if fails_in_row >= 3:
                break                     # lagatar 3 fail: kuch ghalat hai, agli baari dobara
            if "internet" in str(exc).lower() or "expired" in str(exc).lower() or "not connected" in str(exc).lower():
                break                     # baqi bhi fail hongi: agli baari
            continue
        with db._conn() as c:
            c.execute("UPDATE clips SET drive_id=?, drive_at=? WHERE id=?", (done["id"], _now(), clip.id))
        res.uploaded += 1
        fails_in_row = 0
        if _remove(str(path)):
            db.mark_deleted([clip.id])
            res.deleted += 1
    if progress:
        progress(len(clips), len(clips), "")
    log.info("Drive batch: %d uploaded, %d deleted, %d failed, no folder: %s",
             res.uploaded, res.deleted, len(res.failed), res.no_folder)
    return res
