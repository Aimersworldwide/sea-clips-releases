"""
=====================================================================
  TOOLS / FINAL CLEANUP      python -m app.tools.final_cleanup
  Kaam: raat ke kaam ke baad faltu cheezen hatana (sirf is laptop pe,
  installer mein nahi jata). Pehle poori list dikhata hai, phir YES
  likhne pe hi delete karta hai.
    D:\\AIMERS (tool folder):
      * purani test reports aur test files (campaign_report.txt ...)
      * test wali .bat files (Run Test, Run Multi Test ...) aur sample videos
      * frames_check, build (installer ka kaccha maal), __pycache__
    Clips folder (Settings wala, jaise D:\\Clips):
      * har folder / file, SIWAYE "Debate" folder ke
      * "Debate" folder poora rehta hai (final 20 clips, Clips List,
        Run Report)
  Kabhi nahi hatta: app ka code, assets, .venv, bin, installer
  (dist), backups, settings, history, speech model, downloads.
=====================================================================
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KEEP_CAMPAIGN = "Debate"

JUNK_FILES = (
    "campaign_report.txt", "feature_report.txt", "multi_clips.json", "multi_report.txt", "person_report.txt",
    "test_report.txt", "test_source.txt", "all_features_report.txt", "build_log.txt",
    "Run Big Test.bat", "Run Debate 100.bat", "Run Debate 100 Fresh.bat", "Run Feature Test.bat",
    "Run Multi Test.bat", "Run Multi Test 2.bat", "Run Person Test.bat", "Run Person Test 2.bat", "Run Test.bat",
    "Make Frames.bat", "Make Sample.bat", "Clean Old Clips.bat", "Run All Features Check.bat",
    "sample_debate.mp4", "sample_interview.mp4", "sample_interview2.mp4",
    "Test 1.3.0 (20 Clips).bat", "Test 1.4.0 (20 Clips).bat", "Online Photos Check.bat", "Photo Check Report.txt",
)
JUNK_DIRS = ("frames_check", "build", "sample_clips")


def _remove(x: Path, failed: list[str]) -> None:
    try:
        shutil.rmtree(x) if x.is_dir() else x.unlink()
    except OSError as exc:
        failed.append(f"{x} ({exc.strerror or exc})")


def plan() -> list[Path]:
    from app.core.config import AppSettings
    items: list[Path] = []
    items += [ROOT / n for n in JUNK_FILES if (ROOT / n).exists()]
    items += [ROOT / n for n in JUNK_DIRS if (ROOT / n).is_dir()]
    items += [p for p in ROOT.joinpath("app").rglob("__pycache__") if p.is_dir()]
    items += [p for p in ROOT.joinpath("tests").rglob("__pycache__") if p.is_dir()] if (ROOT / "tests").exists() else []
    s = AppSettings.validate(AppSettings.load())
    clips = Path(s.output_dir)
    if clips.exists() and clips.resolve() != ROOT.resolve():
        items += sorted(x for x in clips.iterdir() if x.name != KEEP_CAMPAIGN)
    return items


def main() -> int:
    items = plan()
    print("FINAL CLEANUP")
    print("These will be DELETED:")
    for x in items:
        print(f"   {'[folder]' if x.is_dir() else '[file]  '} {x}")
    if not items:
        print("   (nothing to clean)")
        return 0
    print()
    print(f"Kept: the '{KEEP_CAMPAIGN}' clips folder (final clips), the app, .venv, bin, dist (installer),")
    print("backups, settings, history, speech model and downloads.")
    if input("Type YES and press Enter to delete: ").strip() != "YES":
        print("Nothing deleted.")
        return 0
    failed: list[str] = []
    for x in items:
        _remove(x, failed)
    print(f"\nDone. Deleted {len(items) - len(failed)} items.")
    if failed:
        print("Could not delete (close it and run again): " + "; ".join(failed))
    return 0


if __name__ == "__main__":
    sys.exit(main())
