"""
=====================================================================
  TOOLS / CAMPAIGN RESET        (Campaigns > Reset this campaign)
  Kaam: sirf EK campaign ko naya bana dena, baaki campaigns ko haath
  lagaye baghair:
    * us campaign ki saari history: har clip ka record, numbering,
      deliveries (is ke baad wohi video dobara poori clip ho sakti hai)
    * (chuna ho to) us campaign ke folder ki saari clip videos
    * (chuna ho to) us campaign ki settings wapas default (naam aur
      folder wahi rehte hain)
  Kabhi nahi: doosri campaigns, app ka code, speech model, Clips folder
  khud, laptop ki koi aur file. Campaign ka folder Clips folder ke
  bahar ho to sirf tool ki banayi (record wali) clips jaati hain.
=====================================================================
"""
from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger("aimers.reset")


@dataclass
class CampaignResetResult:
    records: int = 0
    clips_deleted: int = 0
    settings_reset: bool = False
    failed: list[str] = field(default_factory=list)


def _inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return child.resolve() != parent.resolve()
    except (ValueError, OSError):
        return False


def _remove(x: Path, failed: list[str]) -> bool:
    try:
        shutil.rmtree(x) if x.is_dir() else x.unlink()
        return True
    except OSError as exc:
        failed.append(f"{x.name} ({exc.strerror or exc})")
        return False


def _shared(db, settings, campaign_id: int, root: Path) -> bool:
    """Kisi aur campaign ka folder isi folder mein (ya ye us ke andar / wahi) ho: poora folder kabhi saaf nahi."""
    from app.output.organizer import campaign_root
    try:
        with db._conn() as c:
            ids = [r[0] for r in c.execute("SELECT id FROM campaigns WHERE id<>?", (campaign_id,))]
    except Exception:  # noqa: BLE001 - pata na chale to ehtiyat
        return True
    for cid in ids:
        other = db.get_campaign(cid)
        if other is None:
            continue
        o = campaign_root(Path(settings.output_dir), other)
        try:
            if o.resolve() == root.resolve() or _inside(o, root) or _inside(root, o):
                return True
        except OSError:
            return True
    return False


def campaign_files(db, settings, campaign_id: int) -> tuple[Path | None, list[Path]]:
    """(campaign ka folder agar poora saaf ho sakta hai, warna None; tool ki banayi files)."""
    from app.output.organizer import campaign_root
    from app.tools.full_reset import ROOT, _safe_clips_folder
    profile = db.get_campaign(campaign_id)
    out = Path(settings.output_dir)
    root = campaign_root(out, profile) if profile else None
    whole = root if (root is not None and root.is_dir() and _safe_clips_folder(out, ROOT)
                     and _inside(root, out) and not _shared(db, settings, campaign_id, root)) else None
    files: list[Path] = []
    for rec in db.clips_for_campaign(campaign_id, state="present"):
        f = Path(rec.file_path)
        if f.is_file() and f.suffix.lower() == ".mp4":
            files.append(f)
    return whole, files


def count_campaign_videos(db, settings, campaign_id: int) -> int:
    whole, files = campaign_files(db, settings, campaign_id)
    if whole is not None:
        return sum(1 for _ in whole.rglob("*.mp4"))
    return len(files)


def _forget_preview(campaign_id: int) -> None:
    from app.pipeline.runner import _preview_state_file
    p = _preview_state_file()
    try:
        state = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    if state.pop(str(campaign_id), None) is not None:
        try:
            p.write_text(json.dumps(state), encoding="utf-8")
        except OSError:
            pass


def reset_campaign(db, settings, campaign_id: int, delete_clips: bool, reset_settings: bool) -> CampaignResetResult:
    """Ek campaign: history hamesha saaf; clips aur settings sirf chune hon to."""
    from app.core.config import CampaignProfile
    res = CampaignResetResult()
    profile = db.get_campaign(campaign_id)
    if profile is None:
        return res
    if delete_clips:
        whole, files = campaign_files(db, settings, campaign_id)
        if whole is not None:
            res.clips_deleted = sum(1 for _ in whole.rglob("*.mp4"))
            for x in sorted(whole.iterdir()):
                _remove(x, res.failed)
        else:
            for f in files:
                for sib in f.parent.glob(f.stem + ".*"):        # clip ke saath wali title / thumb file
                    if _remove(sib, res.failed) and sib.suffix.lower() == ".mp4":
                        res.clips_deleted += 1
    with db._conn() as c:
        res.records = c.execute("SELECT COUNT(*) FROM clips WHERE campaign_id=?", (campaign_id,)).fetchone()[0]
        for table in ("clips", "counters", "deliveries"):
            c.execute(f"DELETE FROM {table} WHERE campaign_id=?", (campaign_id,))
    _forget_preview(campaign_id)
    if reset_settings:
        fresh = CampaignProfile(name=profile.name, output_folder=profile.output_folder)
        db.update_campaign(campaign_id, fresh)
        res.settings_reset = True
    log.info("Campaign reset %s: %d records, %d clip videos removed, settings %s; %d failed",
             profile.name, res.records, res.clips_deleted, "default" if reset_settings else "kept", len(res.failed))
    return res
