"""
=====================================================================
  TOOLS / SET MAIN PERSON
  Kaam: developer tool: campaign ka main person set karna (installer mein nahi).
  python -m app.tools.set_main_person "<campaign>" "<name>" <photo folder>
  Puts the usable photos of a person into a campaign (copied into the
  app's own folder, exactly like "Add photos" on the Campaigns page),
  creates the campaign and its clips folder if needed. Photos that are
  not usable are listed with the reason and left out.
=====================================================================
"""
from __future__ import annotations

import hashlib
import shutil
import sys
from pathlib import Path


def main() -> int:
    from app.core.config import AppSettings
    from app.core.db import Database
    from app.core.paths import sub_dir
    from app.output.organizer import campaign_root
    from app.render.person import check_photos
    campaign, name, folder = sys.argv[1], sys.argv[2], Path(sys.argv[3])
    files = sorted(p for p in folder.iterdir() if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp", ".bmp"))
    store = sub_dir("people")
    copies = []
    for src in files:
        dst = store / f"{hashlib.sha1(src.read_bytes()).hexdigest()[:16]}{src.suffix.lower()}"
        if not dst.exists():
            shutil.copy2(src, dst)
        copies.append(str(dst))
    checks = check_photos(copies)
    good = [c.path for c in checks if c.ok]
    for src, c in zip(files, checks):
        print(f"  {src.name}: {'OK' if c.ok else 'NOT USED'} ({c.message})")
    db = Database()
    cid = db.ensure_campaign(campaign)
    p = db.get_campaign(cid)
    p.main_person_name = name
    p.main_person_photos = good
    p.main_person_min_screen = p.main_person_min_screen or 60
    p.main_person_min_speaking = p.main_person_min_speaking or 60
    db.update_campaign(cid, p)
    s = AppSettings.validate(AppSettings.load())
    root = campaign_root(Path(s.output_dir), p)
    root.mkdir(parents=True, exist_ok=True)
    print(f"Campaign '{campaign}': main person {name}, {len(good)} photos, "
          f"on screen {p.main_person_min_screen} %, talking {p.main_person_min_speaking} %")
    print(f"Clips folder: {root}")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
