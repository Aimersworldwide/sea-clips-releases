"""
=====================================================================
  TOOLS / CLEAN OLD CLIPS     python -m app.tools.clean_clips
  Kaam: developer tool: purane test clips saaf karna (installer mein nahi).
  Clears every old test clip so the next run starts fresh:
    * every folder and file inside the Clips folder (Settings) is
      deleted, EXCEPT the "Debate" folder itself
    * the "Debate" folder stays, but everything inside it is deleted
    * the app forgets every clip, number and delivery of every
      campaign (history reset; numbering starts again at 001)
    * every campaign except "Debate" is hidden from the campaign list;
      Debate keeps its settings and Ben Shapiro photos
  Asks for YES before deleting anything. Downloads, transcripts, the
  speech model and settings in the app data folder are kept.
=====================================================================
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

KEEP = "Debate"


def _remove(x: Path, failed: list[str]) -> None:
    try:
        shutil.rmtree(x) if x.is_dir() else x.unlink()
    except OSError as exc:
        failed.append(f"{x.name} ({exc.strerror or exc})")


def main() -> int:
    from app.core.config import AppSettings
    from app.core.db import Database
    s = AppSettings.validate(AppSettings.load())
    root = Path(s.output_dir)
    root.mkdir(parents=True, exist_ok=True)
    keep = root / KEEP
    items = sorted(x for x in root.iterdir() if x != keep)
    inside = sorted(keep.iterdir()) if keep.exists() else []
    print(f"Clips folder: {root}")
    print()
    print("These will be DELETED completely:")
    for x in items:
        print(f"   {'[folder]' if x.is_dir() else '[file]  '} {x.name}")
    if not items:
        print("   (nothing)")
    print()
    print(f"'{KEEP}' folder stays, but everything inside it is DELETED:")
    for x in inside:
        print(f"   {'[folder]' if x.is_dir() else '[file]  '} {KEEP}\\{x.name}")
    if not inside:
        print("   (empty)")
    print()
    print("The history of every campaign is reset (numbering starts again at 001).")
    print("Kept: Debate settings and its Ben Shapiro photos, downloads, transcripts, speech model, settings.")
    if input("Type YES and press Enter to delete: ").strip() != "YES":
        print("Nothing deleted.")
        return 0
    failed: list[str] = []
    for x in items + inside:
        _remove(x, failed)
    keep.mkdir(parents=True, exist_ok=True)
    db = Database()
    hidden = []
    for cid, name in db.list_campaigns():
        db.purge_campaign_clips(cid)
        if name != KEEP:
            db.delete_campaign(cid)
            hidden.append(name)
    print()
    print(f"Done. Deleted {len(items) + len(inside) - len(failed)} items. History reset for every campaign.")
    if hidden:
        print(f"Campaigns hidden: {', '.join(hidden)}")
    if failed:
        print("Could not delete (close any open clip, folder or Excel file and run again): " + "; ".join(failed))
    return 0


if __name__ == "__main__":
    sys.exit(main())
