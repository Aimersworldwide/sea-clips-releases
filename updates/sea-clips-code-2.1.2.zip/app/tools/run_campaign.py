"""
=====================================================================
  TOOLS / RUN CAMPAIGN     python -m app.tools.run_campaign "<campaign>" <link> <count> [--fresh] [--like=<campaign>] [--phase=1..5|-1] [--per-minute=N]
  Kaam: developer tool: ek campaign command se chalana (installer mein nahi).
  Makes clips for a real campaign exactly like the app's Create page
  (the campaign's own settings, main person, folder), and writes a live
  report: campaign_report.txt next to this tool and inside the
  campaign folder.
  --fresh: earlier test clips of this campaign are MOVED (never deleted)
  to <Clips>\\_to_delete\\<campaign> old run <time> and forgotten by the
  database, so the run starts again at clip 001 from every moment.
  --like=<campaign>: a test campaign gets all settings of that campaign
  (main person, photos, lengths, rules); the real campaign is untouched.
  --test: earlier clips of the video are ignored (so the best moments are
  made again for a fair comparison) and this run's clips are removed from
  history afterwards (files stay), so real campaigns are not affected.
=====================================================================
"""
from __future__ import annotations

import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def main() -> int:
    from app.core.config import AppSettings
    from app.core.db import Database
    from app.core.logging_setup import setup_logging
    from app.output.organizer import campaign_root
    from app.pipeline.runner import Events, JobRequest, Pipeline, PipelineError
    setup_logging()
    name, url, count = sys.argv[1], sys.argv[2], int(sys.argv[3])
    fresh = "--fresh" in sys.argv[4:]
    like = next((a.split("=", 1)[1] for a in sys.argv[4:] if a.startswith("--like=")), "")
    s = AppSettings.validate(AppSettings.load())
    per_min = next((a.split("=", 1)[1] for a in sys.argv[4:] if a.startswith("--per-minute=")), "")
    if per_min:
        s.clips_per_minute = max(1, int(per_min))   # sirf chhote phase test ke liye (asal settings nahi badalti)
    db = Database()
    cid = db.ensure_campaign(name)
    if like:
        # --like=<campaign>: usi campaign ki saari settings (main person, photos, rules) is test campaign mein
        src = next((c for c, n in db.list_campaigns() if n.lower() == like.lower()), None)
        if src is not None and src != cid:
            from dataclasses import replace
            prof = db.get_campaign(src)
            # apna alag folder (asal campaign ke clips kabhi nahi chhue jaate)
            db.update_campaign(cid, replace(prof, name=name, output_folder=""))
    camp = db.get_campaign(cid)
    root = campaign_root(Path(s.output_dir), camp)
    moved_to = None
    if fresh:
        import shutil
        old = [x for x in root.iterdir()] if root.exists() else []
        if old:
            moved_to = Path(s.output_dir) / "_to_delete" / f"{name} old run {time.strftime('%Y-%m-%d %H%M')}"
            moved_to.mkdir(parents=True, exist_ok=True)
            for x in old:
                shutil.move(str(x), str(moved_to / x.name))
        db.purge_campaign_clips(cid)
    lines: list[str] = []

    def out(text: str = "") -> None:
        print(text, flush=True)
        lines.append(text)
        body = "\n".join(lines) + "\n"
        (ROOT / "campaign_report.txt").write_text(body, encoding="utf-8")
        try:
            root.mkdir(parents=True, exist_ok=True)
            (root / "Run Report.txt").write_text(body, encoding="utf-8")
        except OSError:
            pass

    t0 = time.time()
    lo, hi = camp.length_range(s)
    out(f"AIMERS campaign run | {time.strftime('%Y-%m-%d %H:%M')} | campaign '{name}' | {count} clips | {lo}-{hi}s")
    if camp.main_person_photos:
        out(f"Main person: {camp.main_person_name} ({len(camp.main_person_photos)} photos, on screen "
            f"{camp.main_person_min_screen}%, talking {camp.main_person_min_speaking}%)")
    out(f"Link: {url}")
    if moved_to:
        out(f"Old clips moved to: {moved_to} (delete that folder yourself when you want)")
    out(f"Folder: {root}")
    stats = {"n": 0, "vis": 0.0, "talk": 0.0}

    def clip(done: int, n: int, info: dict) -> None:
        pr = info.get("person") or {}
        length = info.get("duration") or ((info.get("end", 0) or 0) - (info.get("start", 0) or 0))
        extra = (f" | {camp.main_person_name or 'person'} on screen {pr.get('visible', 0):.0%}, "
                 f"talking {pr.get('speaking', 0):.0%}" if pr else "")
        out(f"  {done}/{n} {info.get('label')} | {info.get('rating')} {info.get('score')} | {length:.0f}s | "
            f"re-edit {info.get('remix')}{extra}")
        if pr:
            stats["n"] += 1
            stats["vis"] += pr.get("visible", 0)
            stats["talk"] += pr.get("speaking", 0)

    ev = Events(stage=lambda st: out(f"  [{time.time() - t0:6.0f}s] {st}"), clip_done=clip,
                warning=lambda k, d: out(f"  note: {k} {d}"), log=lambda m: out(f"  log: {m}"))
    test = "--test" in sys.argv[4:]
    if test:
        # --test: pehle bane clips ki history na dekho (taake best moments dobara bane, muqabla ho sake)
        db.used_windows = lambda source_hash: []
        db.made_edits = lambda source_hash: []
        out("Test run: history ignored, and this campaign's clips are taken out of history afterwards")
    try:
        phase = next((int(a.split("=", 1)[1]) for a in sys.argv[4:] if a.startswith("--phase=")), 0)
        r = Pipeline(s, db, JobRequest(url, cid, clip_count=count, phase=phase), ev).run()
        out("")
        out(f"RESULT: made {r.made}/{r.requested} | {r.counts} | failed {len(r.failed)} | "
            f"{(time.time() - t0) / 60:.0f} min")
        if stats["n"]:
            out(f"Average: on screen {stats['vis'] / stats['n']:.0%}, talking {stats['talk'] / stats['n']:.0%}")
        out(f"Dropped moments: {r.dropped}")
    except PipelineError as exc:
        out(f"RESULT: FAIL {exc.key} {exc.detail}")
    except Exception:  # noqa: BLE001
        out("RESULT: FAIL unexpected")
        out(traceback.format_exc())
    if test:
        Database().purge_campaign_clips(cid)      # test clips history ko asal campaigns ke liye ganda na karein
    return 0


if __name__ == "__main__":
    sys.exit(main())
