"""
=====================================================================
  TOOLS / MORNING CHECK      python -m app.tools.morning_check
  Kaam: developer check, sirf is laptop pe (installer mein nahi jata).
  Wo cheezen check karta hai jo cloud mein test nahi ho sakti thin:
    1. GPU          : NVIDIA GPU, NVENC encoder, CUDA decode
    2. Speech model : faster-whisper GPU pe chalta hai? (5 s ka test)
    3. GPU encode   : ek chhota clip GPU se + CPU se, dono theek?
    4. Online       : YouTube link ki maloomat (download nahi), GitHub
                      update check, Wikipedia (naamon ki research)
    5. App check    : setup_check (ffmpeg, fonts, models)
    6. Online photos: campaign ke main person (Debate: Ben Shapiro) ki
                      mazeed photos YouTube se (sirf test folder mein)
  Nateeja: "Morning Check Report.txt" is folder mein. Koi file delete
  nahi hoti, koi setting nahi badalti.
=====================================================================
"""
from __future__ import annotations

import subprocess
import sys
import tempfile
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "Morning Check Report.txt"
TEST_LINK = "https://youtu.be/B0jjW27W2L4"

lines: list[str] = []
results: list[tuple[str, bool]] = []


def out(text: str = "") -> None:
    print(text, flush=True)
    lines.append(text)
    report = ROOT / "Photo Check Report.txt" if sys.argv[1:] == ["photos"] else REPORT
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")


def step(name: str, fn) -> None:
    out(f"\n--- {name} ---")
    t0 = time.time()
    try:
        ok, detail = fn()
    except Exception as exc:  # noqa: BLE001
        ok, detail = False, f"{exc}\n{traceback.format_exc()[-600:]}"
    results.append((name, ok))
    out(f"{'PASS' if ok else 'FAIL'}  ({time.time() - t0:.1f}s)  {detail}")


# ---------------------------------------------------------------------
#  1. GPU
# ---------------------------------------------------------------------
def gpu() -> tuple[bool, str]:
    from app.core.gpu import cuda_decode_available, nvenc_available
    smi = ""
    try:
        smi = subprocess.run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"],
                             capture_output=True, text=True, timeout=20).stdout.strip()
    except Exception:  # noqa: BLE001
        smi = "nvidia-smi not found"
    nv, cu = nvenc_available(), cuda_decode_available()
    return nv and cu, f"GPU: {smi or 'none'} | NVENC: {nv} | CUDA decode: {cu}"


# ---------------------------------------------------------------------
#  2. Speech model on the GPU
# ---------------------------------------------------------------------
def whisper() -> tuple[bool, str]:
    from app.core.config import AppSettings
    from app.core.paths import models_dir
    from app.media.ffmpeg_tools import ffmpeg_bin
    from app.transcribe import asr
    device = asr.pick_device()
    s = AppSettings.validate(AppSettings.load())
    wav = Path(tempfile.gettempdir()) / "aimers_morning.wav"
    subprocess.run([ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi", "-i",
                    "sine=frequency=440:duration=5", "-ar", "16000", "-ac", "1", str(wav)], check=True)
    t0 = time.time()
    tr = asr.transcribe(wav, 5.0, models_dir(s.models_dir), names=["Ben Shapiro"])
    took = time.time() - t0
    return True, f"device: {device} | model ran in {took:.1f}s | engine: {tr.engine or 'whisper'}"


# ---------------------------------------------------------------------
#  3. GPU encode vs CPU encode (one short real render each)
# ---------------------------------------------------------------------
def encode() -> tuple[bool, str]:
    from app.core.gpu import nvenc_available
    from app.media.ffmpeg_tools import ffmpeg_bin
    from app.render.renderer import video_codec_args
    tmp = Path(tempfile.gettempdir())
    src = tmp / "aimers_morning_src.mp4"
    subprocess.run([ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi", "-i",
                    "testsrc2=s=1920x1080:r=30:d=4", "-c:v", "libx264", "-preset", "ultrafast", str(src)], check=True)
    notes = []
    ok = True
    for gpu_on in (False, True):
        if gpu_on and not nvenc_available():
            notes.append("GPU encode: no NVENC (skipped)")
            continue
        dst = tmp / f"aimers_morning_{'gpu' if gpu_on else 'cpu'}.mp4"
        args = [ffmpeg_bin(), "-hide_banner", "-loglevel", "error", "-y"]
        if gpu_on:
            args += ["-hwaccel", "cuda"]
        args += ["-i", str(src), "-vf", "scale=1080:1920", *video_codec_args("high", gpu_on, 30.0, 1920), str(dst)]
        t0 = time.time()
        r = subprocess.run(args, capture_output=True, text=True)
        good = r.returncode == 0 and dst.exists() and dst.stat().st_size > 10_000
        ok = ok and good
        notes.append(f"{'GPU' if gpu_on else 'CPU'} encode: {'OK' if good else 'FAILED ' + r.stderr[-200:]} "
                     f"({time.time() - t0:.1f}s, {dst.stat().st_size / 1e6 if dst.exists() else 0:.1f} MB)")
    return ok, " | ".join(notes)


# ---------------------------------------------------------------------
#  4. Online features
# ---------------------------------------------------------------------
def online() -> tuple[bool, str]:
    notes, ok = [], True
    try:
        import yt_dlp  # type: ignore
        with yt_dlp.YoutubeDL({"quiet": True, "skip_download": True, "no_warnings": True}) as ydl:
            info = ydl.extract_info(TEST_LINK, download=False) or {}
        notes.append(f"YouTube: OK ({str(info.get('title', ''))[:50]})")
    except Exception as exc:  # noqa: BLE001
        ok = False
        notes.append(f"YouTube: FAILED {str(exc)[:120]}")
    try:
        from app.core.notify import latest_release
        from app.version import UPDATE_REPO
        rel = latest_release(UPDATE_REPO)
        notes.append(f"GitHub updates: reachable (latest: {rel['version'] if rel else 'no release yet'})")
    except Exception as exc:  # noqa: BLE001
        notes.append(f"GitHub updates: {str(exc)[:100]} (fine if no release was published yet)")
    try:
        from app.campaign.research import via_wikipedia
        names, src = via_wikipedia("United States senators")
        notes.append(f"Wikipedia research: {len(names)} names")
    except Exception as exc:  # noqa: BLE001
        notes.append(f"Wikipedia research: {str(exc)[:100]}")
    return ok, " | ".join(notes)


# ---------------------------------------------------------------------
#  5. App self check
# ---------------------------------------------------------------------
def setup() -> tuple[bool, str]:
    r = subprocess.run([sys.executable, "-m", "app.tools.setup_check"], cwd=str(ROOT), capture_output=True,
                       text=True, timeout=600)
    tail = (r.stdout + r.stderr).strip().splitlines()[-6:]
    return r.returncode == 0, " / ".join(tail)


# ---------------------------------------------------------------------
#  6. Online photos (main person ki mazeed photos), campaign badla nahi jata
# ---------------------------------------------------------------------
def photos() -> tuple[bool, str]:
    from app.core.db import Database
    from app.render.photo_finder import find_online
    db = Database()
    person = None
    for cid, _name in db.list_campaigns():
        camp = db.get_campaign(cid)
        if camp.main_person_name.strip() and len(camp.main_person_photos) >= 2:
            person = (camp.main_person_name, camp.main_person_photos)
            if camp.name.lower() == "debate":
                break
    if person is None:
        return True, "skipped (no campaign with a main person and photos)"
    folder = Path(tempfile.gettempdir()) / "aimers_photo_check"
    got = find_online(person[0], person[1], folder, max_videos=2, on_log=out)
    poses = sorted({p.stem.rsplit("_", 1)[-1] for p in got})
    return bool(got), f"{len(got)} photos of {person[0]} ({', '.join(poses) or 'none'}) in {folder}"


def main() -> int:
    from app.version import VERSION
    out(f"AIMERS Morning Check | version {VERSION} | {time.strftime('%Y-%m-%d %H:%M')}")
    if sys.argv[1:] == ["photos"]:                  # sirf online photos wala check
        step("6. Online photos of the main person", photos)
        return 0 if all(ok for _, ok in results) else 1
    step("1. GPU (NVENC + CUDA)", gpu)
    step("2. Speech model on GPU", whisper)
    step("3. GPU / CPU encoding", encode)
    step("4. Online features", online)
    step("5. App self check", setup)
    step("6. Online photos of the main person", photos)
    out("\nSUMMARY")
    for name, ok in results:
        out(f"  {'PASS' if ok else 'FAIL'}  {name}")
    return 0 if all(ok for _, ok in results) else 1


if __name__ == "__main__":
    sys.exit(main())
