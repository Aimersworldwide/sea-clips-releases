"""
=====================================================================
  TOOLS / FULL RESET        python -m app.tools.full_reset
  Kaam: tool ko bilkul naya bana dena (sirf is laptop pe, installer
  mein nahi jata). Sirf AIMERS tool ki apni cheezen, laptop ki koi aur
  file kabhi nahi. Pehle poori list dikhata hai, phir YES likhne pe
  hi delete karta hai. App khuli ho to kuch nahi karta.
    Delete:
      * Clips folder ke andar SAB (saare clips, har campaign ka folder)
      * tool folder (D:\\AIMERS) mein jo cheez KEEP list mein nahi:
        test .bat files, reports, sample videos, frames_check,
        channel_samples, build, tests, developer test tools ...
      * dist mein sirf naya installer rehta hai
      * backups mein purani copies (source backup "... source.zip" rehti hai)
      * tool ki history poori: saari campaigns (Debate bhi), clips ka
        record, numbering, deliveries, photos, research, cache, temp,
        logs, purane fonts, speech model ki adhoori download
    Kabhi nahi: app ka code, .venv, bin, assets, naya installer,
    source backup, settings, poora speech model, Clips folder khud.
=====================================================================
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

# Tool folder mein sirf ye rehte hain (baaki sab test / faltu)
KEEP_ROOT = {
    ".gitignore", ".venv", "app", "assets", "bin", "dist", "installer", "scripts", "backups",
    "README.md", "requirements.txt", "requirements-gpu.txt", "requirements-ocr.txt",
    "Install.bat", "Check Setup.bat", "Start AIMERS.bat", "Build Installer.bat", "Full Reset.bat",
}
# developer / test tools (installer mein bhi nahi jaate); source backup mein sab mehfooz hai
DEV_TOOLS = ("all_features.py", "clean_clips.py", "feature_test.py", "multi_test.py", "person_test.py",
             "real_test.py", "set_main_person.py", "run_campaign.py", "morning_check.py", "final_cleanup.py",
             "channel_study.py", "speed_check.py")
# tool ke data folder (AppData) mein sirf ye rehte hain: settings aur speech model
KEEP_DATA = {"settings.json", "models"}
MODEL_FILES = ("model.bin", "config.json", "tokenizer.json", "vocabulary.json", "preprocessor_config.json")
INSTALLER_NAME = "AIMERS_Auto_Clipping_Tool_Setup"     # naya installer: .exe + .bin hissay
SOURCE_BACKUP = "source.zip"                            # "AIMERS 1.6.0 source.zip" jaisi backup hamesha rehti hai


def _remove(x: Path, failed: list[str]) -> None:
    try:
        shutil.rmtree(x) if x.is_dir() else x.unlink()
    except OSError as exc:
        failed.append(f"{x} ({exc.strerror or exc})")


# ---------------------------------------------------------------------
#  Kya kya jayega (files / folders)
# ---------------------------------------------------------------------
def plan_files(root: Path = ROOT) -> list[Path]:
    from app.core.config import AppSettings
    from app.core.paths import app_data_dir
    items: list[Path] = []
    # tool folder: KEEP list ke ilawa sab
    items += sorted(x for x in root.iterdir() if x.name not in KEEP_ROOT)
    # dist: sirf naya installer
    dist = root / "dist"
    if dist.is_dir():
        items += sorted(x for x in dist.iterdir() if x.name != "installer")
        inst = dist / "installer"
        if inst.is_dir():
            items += sorted(x for x in inst.iterdir() if not x.name.startswith(INSTALLER_NAME))
    # backups: purani copies jaati hain, source backup rehti hai
    backups = root / "backups"
    if backups.is_dir():
        items += sorted(x for x in backups.iterdir() if not x.name.endswith(SOURCE_BACKUP))
    items += [root / "app" / "tools" / n for n in DEV_TOOLS if (root / "app" / "tools" / n).exists()]
    for sub in ("app", "scripts"):
        if (root / sub).is_dir():
            items += [p for p in (root / sub).rglob("__pycache__") if p.is_dir()]
    # Clips folder ke andar sab (folder khud rehta hai)
    s = AppSettings.validate(AppSettings.load())
    clips = Path(s.output_dir)
    if _safe_clips_folder(clips, root):
        items += sorted(clips.iterdir())
    # tool ka data: settings aur speech model ke ilawa sab (history, campaigns, photos, research, cache ...)
    data = app_data_dir()
    if data.is_dir():
        items += sorted(x for x in data.iterdir() if x.name not in KEEP_DATA)
        items += _model_leftovers(data / "models")
    return list(dict.fromkeys(items))


def _safe_clips_folder(clips: Path, root: Path) -> bool:
    """Sirf tool ka apna clips folder (jaise D:\\Clips): kabhi poori drive, home, Desktop, Documents waghera nahi."""
    if not clips.is_dir():
        return False
    c = clips.resolve()
    home = Path.home().resolve()
    blocked = {root.resolve(), home, *(home / n for n in ("Desktop", "Documents", "Downloads", "Videos", "Pictures",
                                                          "Music", "OneDrive"))}
    return c != Path(c.anchor) and c not in blocked and len(c.parts) >= 2


def _complete(folder: Path) -> bool:
    return all((folder / f).is_file() for f in MODEL_FILES) and (folder / "model.bin").stat().st_size > 100_000_000


def _model_leftovers(models: Path) -> list[Path]:
    """Speech model folder: poore models rehte hain; adhoori download / download ka cache tab hi jaata
    hai jab poora model maujood ho (tool kabhi bina model ke na reh jaye)."""
    if not models.is_dir():
        return []
    complete = [x for x in models.iterdir() if x.is_dir() and _complete(x)]
    if not complete:
        return []
    return sorted(x for x in models.iterdir() if x not in complete)


def app_is_open() -> bool:
    """AIMERS app khuli hai? (wahi lock jo app khud lagati hai)"""
    from PySide6.QtCore import QLockFile

    from app.core.paths import app_data_dir
    path = app_data_dir() / "app.lock"
    if not path.exists():
        return False
    lock = QLockFile(str(path))
    if lock.tryLock(100):
        lock.unlock()
        return False
    return True


def _size(x: Path) -> int:
    try:
        if x.is_dir():
            return sum(f.stat().st_size for f in x.rglob("*") if f.is_file())
        return x.stat().st_size
    except OSError:
        return 0


def main() -> int:
    if app_is_open():
        print("The AIMERS app is open. Close it first, then run Full Reset again. Nothing changed.")
        return 1
    items = plan_files()
    total = 0
    print("FULL RESET (only AIMERS tool things, nothing else on this laptop)")
    print("These files and folders will be DELETED:")
    for x in items:
        size = _size(x)
        total += size
        print(f"   {'[folder]' if x.is_dir() else '[file]  '} {x}  ({size / 1e6:,.0f} MB)")
    print(f"\nSpace freed: about {total / 1e9:,.1f} GB")
    print("History: ALL campaigns (Debate too), every clip record, numbering, deliveries, photos and research"
          " are cleared. The tool starts completely fresh.")
    print("\nKept: the app code, .venv, bin, assets, the new installer (dist\\installer), the source backup"
          " (backups\\... source.zip), your settings, the speech model, and the Clips folder itself (empty).")
    if input("\nType YES and press Enter to reset: ").strip() != "YES":
        print("Nothing changed.")
        return 0
    failed: list[str] = []
    for x in items:
        _remove(x, failed)
    print(f"\nDone. Deleted {len(items) - len(failed)} files / folders. The tool is fresh: no campaigns,"
          f" numbering starts at 001.")
    if failed:
        print("Could not delete (close the app / video and run again): " + "; ".join(failed))
    return 0


if __name__ == "__main__":
    sys.exit(main())
