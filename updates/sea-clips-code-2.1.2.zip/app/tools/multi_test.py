"""
=====================================================================
  TOOLS / MULTI TEST      python -m app.tools.multi_test [clips] [kinds...]
  Kaam: developer test: alag qism ki videos (installer mein nahi).
  Real test on THIS laptop with different kinds of video, so framing,
  speaker following, hooks, zooms and captions are checked on more
  than one style of footage:
      talk      one speaker on a stage (TED style)
      podcast   two or more people at a table
      interview sit-down interview with camera cuts
      panel     debate / news panel, many people
      vlog      one person talking to camera
      crowd     discussion in a big group
  Videos are found with a YouTube search (8 to 30 minutes long) and
  used only on this laptop for testing. Your own links can be put in
  multi_sources.txt (one per line: name | link) instead.
  Each kind gets its own campaign "Multi <kind>" (old test clips of
  that campaign are cleared first). Writes multi_report.txt live and
  multi_clips.json (every clip file) for checking.
=====================================================================
"""
from __future__ import annotations

import json
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "multi_report.txt"
CLIPS = ROOT / "multi_clips.json"
SOURCES = ROOT / "multi_sources.txt"

KINDS = [
    ("talk", "TED talk", 8, 20),
    ("podcast", "podcast clip two people talking", 8, 30),
    ("interview", "sit down interview full", 10, 30),
    ("panel", "news debate panel discussion", 8, 30),
    ("vlog", "talking head vlog storytime", 8, 25),
    ("crowd", "Jubilee Middle Ground", 15, 45),
]


def find_video(query: str, lo_min: int, hi_min: int, cookies: str) -> tuple[str, str, float]:
    import yt_dlp
    from app.media.download import _bin
    opts = {"quiet": True, "no_warnings": True, "extract_flat": True, "skip_download": True}
    if cookies and Path(cookies).is_file():
        opts["cookiefile"] = cookies
    deno = _bin("deno")
    if deno:
        opts["js_runtimes"] = {"deno": {"path": str(deno)}}
    with yt_dlp.YoutubeDL(opts) as ydl:
        found = ydl.extract_info(f"ytsearch15:{query}", download=False)
    for e in found.get("entries") or []:
        dur = float(e.get("duration") or 0)
        if lo_min * 60 <= dur <= hi_min * 60 and not e.get("live_status") in ("is_live", "is_upcoming"):
            url = e.get("url") or f"https://www.youtube.com/watch?v={e.get('id')}"
            return url, e.get("title", ""), dur
    raise RuntimeError(f"no {lo_min}-{hi_min} min video found for '{query}'")


def main() -> int:
    from app.core.logging_setup import setup_logging
    setup_logging()
    lines: list[str] = []
    all_clips: list[dict] = []

    def out(text: str = "") -> None:
        print(text, flush=True)
        lines.append(text)
        REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")

    count = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    only = set(sys.argv[2:])                     # e.g. "interview podcast": only these kinds
    from app.core.config import AppSettings
    from app.core.db import Database
    from app.output.organizer import campaign_root
    from app.pipeline.runner import Events, JobRequest, Pipeline, PipelineError
    import shutil

    s = AppSettings.validate(AppSettings.load())
    db = Database()
    jobs: list[tuple[str, str, str, float]] = []
    if SOURCES.exists():
        for raw in SOURCES.read_text(encoding="utf-8").splitlines():
            if "|" in raw and raw.strip() and not raw.strip().startswith("#"):
                name, link = (x.strip() for x in raw.split("|", 1))
                jobs.append((name, link, "", 0.0))
    out(f"AIMERS multi test | {count} clips per video | {time.strftime('%Y-%m-%d %H:%M')}")
    if not jobs:
        for name, query, lo, hi in KINDS:
            if only and name not in only:
                continue
            try:
                url, title, dur = find_video(query, lo, hi, s.youtube_cookies)
                jobs.append((name, url, title, dur))
                out(f"found {name}: {title} ({dur / 60:.1f} min) {url}")
            except Exception as exc:  # noqa: BLE001
                out(f"SKIP {name}: search failed ({exc})")

    started_all = time.time()
    for name, url, title, dur in jobs:
        out("")
        out(f"=== {name.upper()} === {title} {url}")
        t0 = time.time()
        try:
            cid = db.ensure_campaign(f"Multi {name}")
            old = campaign_root(Path(s.output_dir), db.get_campaign(cid))
            if old.exists():
                shutil.rmtree(old, ignore_errors=True)
            db.purge_campaign_clips(cid)
            holder: dict = {}

            def clip(done: int, total: int, info: dict, name=name) -> None:
                e = info.get("edit") or {}
                layouts = list((getattr(holder.get("pipe"), "_layouts", {}) or {}).values())
                lay = ", ".join(f"{p.mode}{'' if p.mode != 'crop' else f'@{p.x_center:.2f}'} "
                                f"{p.start:.1f}-{p.end:.1f}" for p in (layouts[-1] if layouts else []))
                out(f"  clip {done}/{total}: {info.get('label')} | {info.get('rating')} {info.get('score')} | "
                    f"{info.get('style')} | zoom {e.get('zoom') or '-'} | hook {e.get('hook')} | "
                    f"re-edit {info.get('remix')}")
                out(f"      layout: {lay or 'centre'}")
                if info.get("file"):
                    all_clips.append({"kind": name, "file": info["file"], "label": info.get("label"),
                                      "rating": info.get("rating"), "layout": lay})
                    CLIPS.write_text(json.dumps(all_clips, indent=1), encoding="utf-8")

            ev = Events(stage=lambda st: out(f"  [{time.time() - t0:6.0f}s] {st}"), clip_done=clip,
                        warning=lambda k, d: out(f"  WARNING {k} {d}"), log=lambda m: out(f"  log: {m}"))
            pipe = Pipeline(s, db, JobRequest(url, cid, clip_count=count), ev)
            holder["pipe"] = pipe
            r = pipe.run()
            out(f"  RESULT {name}: made {r.made}/{r.requested} | {r.counts} | failed {len(r.failed)} | "
                f"repaired {r.repaired} | {time.time() - t0:.0f}s")
        except PipelineError as exc:
            out(f"  RESULT {name}: FAIL {exc.key} {exc.detail}")
        except Exception:  # noqa: BLE001
            out(f"  RESULT {name}: FAIL unexpected")
            out(traceback.format_exc())
    out("")
    out(f"ALL DONE in {(time.time() - started_all) / 60:.0f} min | clips {len(all_clips)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
