"""
=====================================================================
  TOOLS / MAIN PERSON TEST      python -m app.tools.person_test
  Kaam: developer test: main person feature (installer mein nahi).
  Real test of the "Main person" option with Ben Shapiro (BS):
    1. finds a solo Ben Shapiro video on YouTube and takes 4 clear
       face photos of him from it (the person seen most, big and
       sharp), saved in   <Clips>\\Main Person Test\\BS photos\\
    2. a campaign "Main Person Test" with those photos, name
       "Ben Shapiro", on screen 60 %, talking 60 %
    3. clips from Ben Shapiro videos WITH other people (debate,
       interview), so the check really has to tell him apart
  Report: <Clips>\\Main Person Test\\Main Person Report.txt and
  person_report.txt next to this tool. Settings on disk are never
  changed.
=====================================================================
"""
from __future__ import annotations

import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

PHOTO_QUERY = ("Ben Shapiro show monologue", 8, 40)
VIDEOS = [
    ("debate", "Ben Shapiro debates college student", 10, 45, 6),
    ("interview", "Ben Shapiro interview with guest podcast", 15, 90, 6),
]
NAME = "Ben Shapiro"


def take_photos(video: Path, out_dir: Path, log) -> list[str]:
    """4 face photos of the person seen most (big, sharp, frontal) in a solo video."""
    import cv2
    import numpy as np

    from app.media.ffmpeg_tools import ffmpeg_bin
    from app.media.probe import probe
    from app.render.person import DETECT_MODEL, RECOG_MODEL
    info = probe(video)
    recog = cv2.FaceRecognizerSF.create(str(RECOG_MODEL), "")
    found = []                                  # (time, embedding, crop, size)
    n = 80
    for k in range(n):
        t = info.duration * (k + 0.5) / n
        raw = subprocess.run([ffmpeg_bin(), "-loglevel", "error", "-ss", f"{t:.2f}", "-i", str(video),
                              "-frames:v", "1", "-vf", "scale=1280:-2", "-f", "image2pipe", "-vcodec", "png", "-"],
                             capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
        img = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR) if raw else None
        if img is None:
            continue
        h, w = img.shape[:2]
        det = cv2.FaceDetectorYN.create(str(DETECT_MODEL), "", (w, h), 0.6, 0.3, 50)
        _, faces = det.detect(img)
        if faces is None or len(faces) != 1:
            continue
        f = faces[0]
        if f[2] < 140 or f[-1] < 0.9:
            continue
        emb = recog.feature(recog.alignCrop(img, f.reshape(1, -1))).reshape(-1)
        emb = emb / (np.linalg.norm(emb) + 1e-9)
        x, y, fw, fh = (int(v) for v in f[:4])
        pad = int(fw * 0.7)
        crop = img[max(0, y - pad):y + fh + pad, max(0, x - pad):x + fw + pad]
        found.append((t, emb, crop, fw))
    if not found:
        return []
    # the person seen most: the face most others agree with
    agree = [sum(float(np.dot(a[1], b[1])) > 0.5 for b in found) for a in found]
    best = max(range(len(found)), key=lambda i: agree[i])
    same = [x for x in found if float(np.dot(x[1], found[best][1])) > 0.5]
    log(f"  person seen most: in {len(same)} of {len(found)} clear single-face frames")
    same.sort(key=lambda x: x[0])
    picks = [same[int(i * (len(same) - 1) / 3)] for i in range(4)] if len(same) >= 4 else same
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for i, (t, _, crop, _) in enumerate(picks, 1):
        p = out_dir / f"BS photo {i} ({int(t)}s).jpg"
        ok, buf = cv2.imencode(".jpg", crop, [cv2.IMWRITE_JPEG_QUALITY, 95])
        if ok:
            p.write_bytes(buf.tobytes())
            paths.append(str(p))
    return paths


def main() -> int:
    from app.core.config import AppSettings
    from app.core.db import Database
    from app.core.logging_setup import setup_logging
    from app.core.paths import cache_dir
    from app.media.download import download
    from app.output.organizer import campaign_root
    from app.pipeline.runner import Events, JobRequest, Pipeline, PipelineError
    from app.render.person import check_photos
    from app.tools.multi_test import find_video
    setup_logging()

    s = AppSettings.validate(AppSettings.load())
    base = Path(s.output_dir) / (sys.argv[1] if len(sys.argv) > 1 else "Main Person Test")
    photos_dir = Path(s.output_dir) / "Main Person Test" / "BS photos"
    lines: list[str] = []

    def out(text: str = "") -> None:
        print(text, flush=True)
        lines.append(text)
        base.mkdir(parents=True, exist_ok=True)
        (base / "Main Person Report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        (ROOT / "person_report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

    started = time.time()
    out(f"AIMERS main person test | {time.strftime('%Y-%m-%d %H:%M')}")
    out(f"Folder: {base}")
    try:
        # ---- 1. photos of him: the user's own (BS photos folder), else from a solo video
        photos = sorted(str(x) for x in photos_dir.glob("*") if x.suffix.lower() in (".jpg", ".jpeg", ".png")) \
            if photos_dir.exists() else []
        if photos:
            out(f"Using the {len(photos)} photos in {photos_dir}")
        else:
            q, lo, hi = PHOTO_QUERY
            url, title, dur = find_video(q, lo, hi, s.youtube_cookies)
            out(f"Photo video: {title} ({dur / 60:.0f} min) {url}")
            src = download(url, cache_dir() / "downloads", cookies_file=s.youtube_cookies)
            photos = take_photos(src, photos_dir, out)
        checks = check_photos(photos)
        for c in checks:
            out(f"  photo {Path(c.path).name}: {'OK' if c.ok else 'NOT USED'} ({c.message})")
        photos = [c.path for c in checks if c.ok]
        if not photos:
            out("RESULT: FAIL no clear photos found")
            return 1

        # ---- 2. campaign ---------------------------------------------------
        db = Database()
        cid = db.ensure_campaign("Main Person Test")
        camp = db.get_campaign(cid)
        camp.main_person_name = NAME
        camp.main_person_photos = photos
        camp.main_person_min_screen = 60
        camp.main_person_min_speaking = 60
        db.update_campaign(cid, camp)
        db.purge_campaign_clips(cid)
        shutil.rmtree(campaign_root(base, camp), ignore_errors=True)
        run = AppSettings.validate(AppSettings.load())
        run.output_dir = str(base)
        run.min_length, run.max_length = 30, 60
        run.reaction_shots, run.better_moments, run.sound_effects = True, True, False

        # ---- 3. videos with other people -----------------------------------
        total = 0
        for kind, query, vlo, vhi, count in VIDEOS:
            out("")
            try:
                vurl, vtitle, vdur = find_video(query, vlo, vhi, s.youtube_cookies)
            except Exception as exc:  # noqa: BLE001
                out(f"=== {kind.upper()} === search failed: {exc}")
                continue
            out(f"=== {kind.upper()} === {vtitle} ({vdur / 60:.0f} min) {vurl}")
            t0 = time.time()

            def clip(done: int, n: int, info: dict) -> None:
                nonlocal total
                pr = info.get("person") or {}
                length = (info.get("end", 0) or 0) - (info.get("start", 0) or 0)
                out(f"  {info.get('label')} | {info.get('rating')} {info.get('score')} | {length:.0f}s | "
                    f"{NAME} on screen {pr.get('visible', 0):.0%}, talking {pr.get('speaking', 0):.0%}, "
                    f"first 3 s {pr.get('hook', 0):.0%}")
                out(f"      file: {info.get('file')}")
                total += 1

            ev = Events(stage=lambda st: out(f"  [{time.time() - t0:5.0f}s] {st}"), clip_done=clip,
                        warning=lambda k, d: out(f"  note: {k} {d}"), log=lambda m: out(f"  log: {m}"))
            try:
                r = Pipeline(run, db, JobRequest(vurl, cid, clip_count=count), ev).run()
                out(f"  RESULT: made {r.made}/{r.requested} | {r.counts} | dropped {r.dropped} | "
                    f"{time.time() - t0:.0f}s")
            except PipelineError as exc:
                out(f"  RESULT: FAIL {exc.key} {exc.detail}")
        out("")
        out(f"ALL DONE in {(time.time() - started) / 60:.0f} min | clips {total}")
    except Exception:  # noqa: BLE001
        out("RESULT: FAIL unexpected")
        out(traceback.format_exc())
    return 0


if __name__ == "__main__":
    sys.exit(main())
