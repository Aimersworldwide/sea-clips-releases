"""
=====================================================================
  TOOLS / SETUP CHECK     python -m app.tools.setup_check [--fetch-models]
  Kaam: install ki jaanch (ffmpeg, model, fonts).
  Run by the installer (and any time for support). Proves on THIS
  laptop that everything works, ending with a real 3-second test
  render with captions + QC. Prints a clear PASS / FAIL list.
  --fetch-models  downloads the English speech model now, so the
                  first real run does not wait for it.
=====================================================================
"""
from __future__ import annotations

import argparse
import importlib
import subprocess
import sys
import tempfile
import time
from pathlib import Path

RESULTS: list[tuple[str, bool, str, bool]] = []     # name, ok, detail, critical


def check(name: str, critical: bool = True):
    def wrap(fn):
        try:
            detail = fn() or ""
            RESULTS.append((name, True, str(detail), critical))
        except Exception as exc:  # noqa: BLE001 - report everything
            RESULTS.append((name, False, f"{type(exc).__name__}: {exc}", critical))
        return fn
    return wrap


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fetch-models", action="store_true")
    ap.add_argument("--installed", action="store_true", help="check a self-contained installation folder")
    args = ap.parse_args()

    from app.core.logging_setup import setup_logging
    setup_logging()

    @check("Python 3.10+ (64-bit)")
    def _py():
        assert sys.version_info >= (3, 10) and sys.maxsize > 2**32, sys.version
        return sys.version.split()[0]

    @check("Python packages")
    def _pkgs():
        versions = []
        for mod in ("PySide6", "faster_whisper", "ctranslate2", "openpyxl", "yt_dlp", "fontTools"):
            m = importlib.import_module(mod)
            versions.append(f"{mod} {getattr(m, '__version__', getattr(getattr(m, 'version', None), '__version__', '?'))}")
        return ", ".join(versions)

    @check("FFmpeg with captions (libass), x264, zimg")
    def _ffmpeg():
        from app.media.ffmpeg_tools import ffmpeg_bin, ffprobe_bin
        ff = ffmpeg_bin()
        ffprobe_bin()
        filters = subprocess.run([ff, "-hide_banner", "-filters"], capture_output=True, text=True).stdout
        encoders = subprocess.run([ff, "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
        missing = [n for n, ok in (("subtitles", " subtitles " in filters), ("zscale", " zscale " in filters),
                                   ("libx264", "libx264" in encoders)) if not ok]
        assert not missing, "missing: " + ", ".join(missing)
        return ff

    @check("Caption fonts")
    def _fonts():
        from app.captions.fonts import FONT_DIR, FONT_FILES
        missing = [f for f in FONT_FILES.values() if not (FONT_DIR / f).exists()]
        assert not missing, missing
        return f"{len(FONT_FILES)} fonts"

    @check("YouTube helper (deno)", critical=False)
    def _deno():
        from app.media.download import _bin
        deno = _bin("deno")
        assert deno, "bin/deno.exe missing (YouTube links may fail)"
        return subprocess.run([str(deno), "--version"], capture_output=True, text=True).stdout.splitlines()[0]

    @check("NVIDIA GPU for speech", critical=False)
    def _gpu():
        from app.media.ffmpeg_tools import has_nvidia_gpu
        from app.transcribe.asr import pick_device
        if not has_nvidia_gpu():
            return "no NVIDIA GPU: CPU mode (same quality, slower)"
        device, compute = pick_device()
        assert device == "cuda", "GPU found but CUDA libraries not usable; CPU will be used"
        return f"{device} {compute}"

    @check("Test render (captions, beep, loudness, QC)")
    def _render():
        from app.media.probe import probe
        from app.qc.check import check_clip
        from app.render.renderer import RenderJob, render_clip
        from app.render.timeline import Segment
        from app.transcribe.models import Word
        tmp = Path(tempfile.mkdtemp(prefix="aimers_check_"))
        src = tmp / "src.mp4"
        from app.media.ffmpeg_tools import ffmpeg_bin
        subprocess.run([ffmpeg_bin(), "-loglevel", "error", "-y", "-f", "lavfi", "-i",
                        "testsrc2=size=1920x1080:rate=30:duration=6", "-f", "lavfi", "-i",
                        "sine=frequency=300:duration=6", "-c:v", "libx264", "-preset", "ultrafast",
                        "-c:a", "aac", "-shortest", str(src)], check=True)
        words = [Word(w, 0.2 + i * 0.5, 0.6 + i * 0.5) for i, w in enumerate("this is a quick test".split())]
        t0 = time.time()
        out = render_clip(RenderJob(source=probe(src), segments=[Segment(1.0, 4.0)], words=words, masked={2},
                                    censor=[(1.2, 1.5)], out_path=tmp / "out.mp4", look="warm_broadcast",
                                    temp_dir=tmp))
        qc = check_clip(out, (1080, 1920), 3.0)
        assert qc.ok, qc.summary
        return f"OK in {time.time() - t0:.1f}s ({tmp})"

    @check("Face finder (OpenCV + YuNet model)")
    def _faces():
        import cv2
        from app.render.layout import MODEL
        assert MODEL.exists(), f"missing {MODEL}"
        cv2.FaceDetectorYN.create(str(MODEL), "", (320, 320))
        return f"opencv {cv2.__version__}"

    @check("Main person recogniser (SFace model)")
    def _person():
        import hashlib

        import cv2
        from app.render.person import RECOG_MODEL, RECOG_SHA256
        assert RECOG_MODEL.exists(), f"missing {RECOG_MODEL}"
        digest = hashlib.sha256(RECOG_MODEL.read_bytes()).hexdigest()
        assert digest == RECOG_SHA256, "face recognition model file is damaged"
        cv2.FaceRecognizerSF.create(str(RECOG_MODEL), "")
        return "ok"

    if args.installed:
        @check("Self-contained installation")
        def _installed():
            from app.core.paths import resource, resource_root
            from app.transcribe.asr import ENGLISH_MODEL, local_model_dir
            root = resource_root().resolve()
            exe = Path(sys.executable).resolve()
            assert root in exe.parents, f"Python {exe} is not inside {root}"
            folder = local_model_dir(ENGLISH_MODEL, root / "no-user-models")
            assert folder is not None and root in folder.resolve().parents, "speech model not inside the installation"
            for name in ("ffmpeg.exe", "ffprobe.exe", "deno.exe"):
                assert resource("bin", name).exists(), f"missing bin/{name}"
            import yt_dlp
            importlib.import_module("pip")      # the downloader updates itself with pip
            return f"{root} | model {folder.name} | yt-dlp {yt_dlp.version.__version__}"

    if args.fetch_models:
        @check("Speech model download (English)")
        def _models():
            from app.core.config import AppSettings
            from app.core.paths import models_dir
            from app.transcribe.asr import ENGLISH_MODEL, fetch_model, model_ready
            folder = models_dir(AppSettings.load().models_dir)
            if model_ready(ENGLISH_MODEL, folder):
                return "already downloaded"
            fetch_model(ENGLISH_MODEL, folder)
            return f"saved in {folder}"

    print()
    print("=" * 64)
    print("  AIMERS Auto Clipping Tool - setup check")
    print("=" * 64)
    bad_critical = False
    for name, ok, detail, critical in RESULTS:
        mark = "PASS" if ok else ("FAIL" if critical else "WARN")
        print(f"  [{mark}] {name}")
        if detail:
            print(f"         {detail[:300]}")
        bad_critical |= (not ok and critical)
    print("=" * 64)
    print("  RESULT:", "PROBLEM - send the log folder for help" if bad_critical else "READY")
    print()
    return 1 if bad_critical else 0


if __name__ == "__main__":
    sys.exit(main())
