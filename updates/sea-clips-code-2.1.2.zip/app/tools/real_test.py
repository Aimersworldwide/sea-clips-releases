"""
=====================================================================
  TOOLS / REAL TEST      python -m app.tools.real_test
  Kaam: developer test (installer mein nahi).
  End-to-end test on THIS laptop with the real speech model:
  source (link or file) -> transcript -> clips, exactly like the app.
  Source comes from the first line of test_source.txt (next to
  "Run Test.bat"). Writes test_report.txt with timings, transcript
  sample, every clip's score and file, and the full error if any.
  Uses its own campaign "Test Run" so real campaigns are untouched.
=====================================================================
"""
from __future__ import annotations

import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "test_report.txt"
SOURCE_FILE = ROOT / "test_source.txt"


def main() -> int:
    from app.core.logging_setup import setup_logging
    from app.pipeline.runner import PipelineError
    setup_logging()
    lines: list[str] = []

    def out(text: str = "") -> None:
        print(text, flush=True)
        lines.append(text)
        REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")   # live, so it can be read mid-run

    started = time.time()
    try:
        source = (SOURCE_FILE.read_text(encoding="utf-8").strip().splitlines() or [""])[0].strip().strip('"')
        count = int(sys.argv[1]) if len(sys.argv) > 1 else 5
        out("AIMERS real test")
        out(f"source: {source}")
        out(f"clips requested: {count}")
        if not source:
            out("RESULT: FAIL - test_source.txt is empty")
            return 1

        from app.core.config import AppSettings
        from app.core.db import Database
        from app.core.paths import models_dir
        from app.media.ffmpeg_tools import has_nvidia_gpu
        from app.pipeline.runner import Events, JobRequest, Pipeline
        from app.transcribe.asr import ENGLISH_MODEL, model_ready, pick_device

        s = AppSettings.validate(AppSettings.load())
        out(f"gpu found: {has_nvidia_gpu()} | speech device: {pick_device()}")
        out(f"model ready: {model_ready(ENGLISH_MODEL, models_dir(s.models_dir))}")
        out(f"clips folder: {s.output_dir}")
        db = Database()
        cid = db.ensure_campaign("Test Run")
        # Fresh start every time: old test clips and their numbers are
        # removed, so the same link is clipped again with the newest code.
        import shutil
        from app.output.organizer import campaign_root
        old = campaign_root(Path(s.output_dir), db.get_campaign(cid))
        if old.exists():
            shutil.rmtree(old, ignore_errors=True)
        db.purge_campaign_clips(cid)
        out(f"old test clips cleared: {old}")
        try:
            import cv2  # noqa: F401
            from app.render.layout import MODEL
            out(f"face finder ready: {MODEL.exists()} (opencv {cv2.__version__})")
        except Exception as exc:  # noqa: BLE001
            out(f"face finder NOT ready: {exc}")

        stage_t = {"t": time.time(), "name": "start"}
        last = {"p": -1}

        def stage(name: str) -> None:
            out(f"  [{time.time() - started:7.1f}s] stage {stage_t['name']} took {time.time() - stage_t['t']:.1f}s")
            stage_t.update(t=time.time(), name=name)
            out(f"  [{time.time() - started:7.1f}s] >> {name}")

        def progress(v: float, text: str) -> None:
            p = int(v * 20)
            if p != last["p"]:
                last["p"] = p
                out(f"  [{time.time() - started:7.1f}s] {v * 100:5.1f}% {text}")

        def clip(done: int, total: int, info: dict) -> None:
            layout_log = list((getattr(pipe, "_layouts", {}) or {}).values())
            if layout_log:
                out("      layout: " + ", ".join(f"{p.mode} {p.start:.1f}-{p.end:.1f}" for p in layout_log[-1]))
            out(f"  clip {done}/{total}: {info.get('label')} | {info.get('rating')} | score {info.get('score')} | "
                f"style {info.get('style')} | re-edit {info.get('remix')} | repaired {info.get('repaired')}")
            e = info.get("edit") or {}
            out(f"      edit: look {e.get('look')} | swap {e.get('swap')} | bar {e.get('bar') or '-'} | pace {e.get('pace') or 'normal'}")
            if info.get("file"):
                out(f"      {info['file']}")

        ev = Events(stage=stage, progress=progress, clip_done=clip,
                    warning=lambda k, d: out(f"  WARNING {k} {d}"), log=lambda m: out(f"  log: {m}"))
        pipe = Pipeline(s, db, JobRequest(source, cid, clip_count=count), ev)
        summary = pipe.run()
        stage("finished")

        # transcript sample
        from app.core.paths import cache_dir
        newest = sorted(cache_dir().glob("*/transcript.json"), key=lambda p: p.stat().st_mtime)
        if newest:
            from app.transcribe.models import Transcript
            tr = Transcript.load(newest[-1])
            out("")
            out(f"transcript: {len(tr.words)} words | language {tr.language} | translated {tr.translated} | "
                f"engine {tr.engine}")
            out("first words: " + " ".join(w.text for w in tr.words[:80]))

        out("")
        out(f"made {summary.made} of {summary.requested} | counts {summary.counts} | repaired {summary.repaired} | "
            f"failed {len(summary.failed)} | moments {summary.moments} | max good {summary.max_good}")
        out(f"dropped: {summary.dropped}")
        out(f"folder: {summary.folder}")
        out(f"total time: {time.time() - started:.0f}s")
        out("RESULT: PASS" if summary.made > 0 else "RESULT: FAIL - no clips made")
        return 0 if summary.made > 0 else 1
    except PipelineError as exc:
        out(f"RESULT: FAIL - {exc.key} {exc.detail}")
        return 1
    except Exception:  # noqa: BLE001
        out("RESULT: FAIL - unexpected error")
        out(traceback.format_exc())
        return 1


if __name__ == "__main__":
    sys.exit(main())
