"""
=====================================================================
  TOOLS / FEATURE TEST      python -m app.tools.feature_test
  Kaam: developer test (installer mein nahi).
  Real test of the three new options on THIS laptop. Everything goes
  into one new folder next to the normal clips:
      <Clips>\\Feature Test\\
          1 Reaction Shots\\        reaction shots ON
          2 Better Moments - Old\\  better moments OFF (how it was)
          2 Better Moments - New\\  better moments ON  (same video)
          3 Sound Effects\\         sound effects ON
          4 Long Clips (60-120s)\\  all three ON, long clips
          Feature Test Report.txt  what each clip got
  Clips are 30 to 60 seconds (except folder 4). Settings on disk are
  never changed: every option is switched only inside this test.
  Old feature test clips are cleared first.
=====================================================================
"""
from __future__ import annotations

import shutil
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

INTERVIEW = "https://www.youtube.com/watch?v=SPGxj0mhTBU"        # sit down interview (cached)
DEBATE = "https://www.youtube.com/watch?v=VrB7e6wNEMM"           # four women at a table (cached)

#        folder,                    link,      clips, (min, max), reactions, better, sfx
# Old runs first and its clips are then forgotten by the database, so New can
# choose freely from the same video (a fair before / after comparison).
JOBS = [
    ("2 Better Moments - Old", INTERVIEW, 6, (30, 60), True, False, False),
    ("2 Better Moments - New", INTERVIEW, 6, (30, 60), True, True, False),
    ("1 Reaction Shots", DEBATE, 6, (30, 60), True, True, False),
    ("1 Reaction Shots", INTERVIEW, 4, (30, 60), True, True, False),
    ("3 Sound Effects", INTERVIEW, 6, (30, 60), True, True, True),
    ("4 Long Clips (60-120s)", DEBATE, 3, (60, 120), True, True, True),
]


def main() -> int:
    from app.core.config import AppSettings
    from app.core.db import Database
    from app.core.logging_setup import setup_logging
    from app.output.organizer import campaign_root
    from app.pipeline.runner import Events, JobRequest, Pipeline, PipelineError
    setup_logging()

    s = AppSettings.validate(AppSettings.load())
    base = Path(s.output_dir) / "Feature Test"
    report = base / "Feature Test Report.txt"
    lines: list[str] = []

    def out(text: str = "") -> None:
        print(text, flush=True)
        lines.append(text)
        base.mkdir(parents=True, exist_ok=True)
        report.write_text("\n".join(lines) + "\n", encoding="utf-8")
        (ROOT / "feature_report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

    db = Database()
    if base.exists():
        for child in base.iterdir():
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
    out(f"AIMERS feature test | {time.strftime('%Y-%m-%d %H:%M')}")
    out(f"Folder: {base}")
    out("Reaction shots: a short look at a listener while someone else talks.")
    out("Better moments: stricter choice of where a clip starts and ends"
        + (" + AI judge (Gemini key found)" if s.gemini_api_key else " (rules only, no Gemini key in Settings)") + ".")
    out("Sound effects: soft whoosh / pop / hit made by the app itself (no copyright).")
    started_all, cleared = time.time(), set()
    total = 0
    for folder, url, count, (lo, hi), reactions, better, sfx in JOBS:
        out("")
        out(f"=== {folder} === {url} | {count} clips {lo}-{hi}s | reactions {'ON' if reactions else 'OFF'}, "
            f"better moments {'ON' if better else 'OFF'}, sound effects {'ON' if sfx else 'OFF'}")
        t0 = time.time()
        run = AppSettings.validate(AppSettings.load())
        run.output_dir = str(base)
        run.min_length, run.max_length = lo, hi
        run.reaction_shots, run.better_moments, run.sound_effects = reactions, better, sfx
        try:
            cid = db.ensure_campaign(folder)
            camp = db.get_campaign(cid)
            if folder not in cleared:
                db.purge_campaign_clips(cid)
                shutil.rmtree(campaign_root(base, camp), ignore_errors=True)
                cleared.add(folder)
            holder: dict = {}

            def clip(done: int, n: int, info: dict) -> None:
                nonlocal total
                pipe = holder.get("pipe")
                key = (round(info.get("start", -1), 2), round(info.get("end", -1), 2), bool(run.reaction_shots))
                pieces = (getattr(pipe, "_layouts", {}) or {}).get(key) or []
                reacts = [p for p in pieces if getattr(p, "reaction", False)]
                e = info.get("edit") or {}
                length = (info.get("end", 0) or 0) - (info.get("start", 0) or 0)
                out(f"  {info.get('label')} | {info.get('rating')} {info.get('score')} | {length:.0f}s | "
                    f"{info.get('style')} | zoom {e.get('zoom') or '-'} | "
                    f"reaction shots {len(reacts)}" + (" at " + ", ".join(f"{p.start - info['start']:.1f}s"
                                                                       for p in reacts) if reacts else ""))
                out(f"      why: {', '.join(info.get('reasons') or []) or '-'}")
                out(f"      file: {info.get('file')}")
                total += 1

            ev = Events(stage=lambda st: out(f"  [{time.time() - t0:5.0f}s] {st}"), clip_done=clip,
                        warning=lambda k, d: out(f"  note: {k} {d}"), log=lambda m: out(f"  log: {m}"))
            pipe = Pipeline(run, db, JobRequest(url, cid, clip_count=count), ev)
            holder["pipe"] = pipe
            r = pipe.run()
            out(f"  RESULT: made {r.made}/{r.requested} | {r.counts} | failed {len(r.failed)} | {time.time() - t0:.0f}s")
            if folder.endswith("- Old"):
                db.purge_campaign_clips(cid)          # files stay; only the "already made" memory goes
        except PipelineError as exc:
            out(f"  RESULT: FAIL {exc.key} {exc.detail}")
        except Exception:  # noqa: BLE001
            out("  RESULT: FAIL unexpected")
            out(traceback.format_exc())
    out("")
    out(f"ALL DONE in {(time.time() - started_all) / 60:.0f} min | clips {total}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
