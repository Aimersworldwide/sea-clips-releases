"""
=====================================================================
  TOOLS / SPEED CHECK      python -m app.tools.speed_check <link> [count]
  Kaam: developer tool (installer mein nahi). Ek hi video ke wahi clips
  do dafa banata hai: (A) purane hisaab se jitne clips ek sath, (B) naye
  hisaab se (cores + RAM). Phir dikhata hai: kitna waqt laga, aur kya
  har clip bit-by-bit wahi bana (quality 100% same). Test campaigns
  "Speed Test" (files Full Reset.bat se hatti hain, tool kuch delete nahi karta).
=====================================================================
"""
from __future__ import annotations

import hashlib
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _md5(path: Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    from app.core.config import AppSettings
    from app.core.db import Database
    from app.core.logging_setup import setup_logging
    from app.pipeline.runner import Events, JobRequest, Pipeline, free_ram_gb, render_workers
    setup_logging()
    url = sys.argv[1]
    count = int(sys.argv[2]) if len(sys.argv) > 2 else 6
    cores = os.cpu_count() or 2
    old = 1 if cores < 6 else 2 if cores < 12 else 3
    new, threads = render_workers(0)
    lines = [f"CPU threads {cores}, free RAM {free_ram_gb():.1f} GB, encoder threads per clip {threads or 'auto'}",
             f"A (old): {old} clips at a time    B (new): {new} clips at a time", ""]
    report = ROOT / "Speed Check.txt"
    results = {}
    for tag, workers in (("A", old), ("B", new)):
        s = AppSettings.validate(AppSettings.load())
        s.render_workers = workers
        s.preview_pack = False
        db = Database()
        like = next((c for c, n in db.list_campaigns() if n.lower() == "debate"), None)
        name = "Speed Test"                                # dono run ek hi campaign: edits bhi bilkul same
        cid = db.ensure_campaign(name)
        if like is not None:
            from dataclasses import replace
            db.update_campaign(cid, replace(db.get_campaign(like), name=name, output_folder=""))
        db.purge_campaign_clips(cid)
        db.used_windows = lambda source_hash: []          # dono run bilkul same clips banayein
        db.made_edits = lambda source_hash: []
        t0 = time.time()
        r = Pipeline(s, db, JobRequest(url, cid, clip_count=count), Events()).run()
        took = time.time() - t0
        files = {}
        for c in Database().clips_for_campaign(cid):
            if Path(c.file_path).exists():
                files[c.extra.get("tag", c.label)] = _md5(Path(c.file_path))
        results[tag] = (took, files)
        lines.append(f"{tag}: {r.made} clips in {took / 60:.1f} min ({took / max(r.made, 1):.0f} s per clip)")
        Database().purge_campaign_clips(cid)              # files rehti hain (Full Reset.bat hatata hai)
        report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    (ta, fa), (tb, fb) = results["A"], results["B"]
    same = [k for k in fa if fb.get(k) == fa[k]]
    lines += ["", f"Same clips bit by bit: {len(same)} of {len(fa)}",
              f"Faster by: {(1 - tb / max(ta, 1)) * 100:.0f}%"]
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())
