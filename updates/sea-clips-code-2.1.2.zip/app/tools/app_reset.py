"""
=====================================================================
  TOOLS / APP RESET        (Settings > Reset tool: ek button, sab naya)
  Kaam: app ke andar se tool ko bilkul naya bana dena:
    * saari history: har clip ka record, numbering, deliveries
    * saari campaigns (un ki settings, photos, research)
    * cache aur purani temp files
    * app ki settings wapas default (sirf Clips folder ki jagah, speech
      model ki jagah aur cookies file ka rasta rehta hai)
    * (chuna ho to) Clips folder ke andar ki saari clip videos
  Kabhi nahi: app ka code, speech model, Clips folder khud, laptop ki
  koi aur file. Run chal raha ho to kuch nahi hota.
=====================================================================
"""
from __future__ import annotations

import logging
import shutil
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger("aimers.reset")

KEEP_DATA = {"settings.json", "models", "aimers.db", "aimers.db-wal", "aimers.db-shm", "app.lock", "logs"}
KEEP_SETTINGS = ("output_dir", "models_dir", "youtube_cookies", "language", "device_code")


@dataclass
class ResetResult:
    clips_deleted: int = 0
    campaigns: int = 0
    records: int = 0
    failed: list[str] = field(default_factory=list)


def _remove(x: Path, failed: list[str]) -> bool:
    try:
        shutil.rmtree(x) if x.is_dir() else x.unlink()
        return True
    except OSError as exc:
        failed.append(f"{x.name} ({exc.strerror or exc})")
        return False


def clip_files(output_dir: Path) -> list[Path]:
    """Clips folder ke andar ki har cheez (folder khud nahi). Khatarnaak jagah (drive, home) ho to kuch nahi."""
    from app.tools.full_reset import ROOT, _safe_clips_folder
    if not _safe_clips_folder(output_dir, ROOT):
        return []
    return sorted(output_dir.iterdir())


def count_videos(output_dir: Path) -> int:
    n = 0
    for x in clip_files(output_dir):
        if x.is_dir():
            n += sum(1 for f in x.rglob("*.mp4"))
        elif x.suffix.lower() == ".mp4":
            n += 1
    return n


def reset_everything(db, settings, delete_clips: bool) -> ResetResult:
    """Sab history, campaigns, cache aur settings naye; delete_clips ho to Clips folder bhi khaali."""
    from app.core.config import AppSettings
    from app.core.paths import app_data_dir
    res = ResetResult()
    out = Path(settings.output_dir)
    if delete_clips:
        res.clips_deleted = count_videos(out)
        for x in clip_files(out):
            _remove(x, res.failed)
    # history aur campaigns (database khula rehta hai: andar se khaali)
    with db._conn() as c:
        res.campaigns = c.execute("SELECT COUNT(*) FROM campaigns").fetchone()[0]
        res.records = c.execute("SELECT COUNT(*) FROM clips").fetchone()[0]
        for table in ("deliveries", "clips", "counters", "campaigns"):
            c.execute(f"DELETE FROM {table}")
        try:
            c.execute("DELETE FROM sqlite_sequence")       # numbering phir 001 se
        except Exception:  # noqa: BLE001 - table na ho to koi baat nahi
            pass
    # cache, photos, research, temp ... (settings, speech model, database aur logs rehte hain)
    data = app_data_dir()
    if data.is_dir():
        for x in sorted(data.iterdir()):
            if x.name not in KEEP_DATA:
                _remove(x, res.failed)
    # settings default (zaroori raste rehte hain)
    fresh = AppSettings()
    for name in KEEP_SETTINGS:
        if hasattr(settings, name):
            setattr(fresh, name, getattr(settings, name))
    AppSettings.validate(fresh).save()
    log.info("Tool reset: %d campaigns, %d clip records, %d clip videos removed; %d failed",
             res.campaigns, res.records, res.clips_deleted, len(res.failed))
    return res
