"""
=====================================================================
  TOOLS / CHANNEL STUDY      python -m app.tools.channel_study <channel link> [<channel link> ...]
  Kaam: developer tool (installer mein nahi): doosre clipping channels
  ka public data nikalna, taake hamari editing un ke kaamyaab pattern
  ke qareeb ho. Har channel ki Shorts aur Videos list (title, views,
  lambai), phir sab se zyada chalne wali aur sab se nayi videos ki
  poori details (description, hashtags, tags), aur har channel ki 3
  sab se zyada chalne wali shorts ka sample (720p) dekhne ke liye.
  Output:  channel_data.json  aur  channel_samples\\  (tool folder mein)
=====================================================================
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TOP_DETAILS = 25        # sab se zyada views wali (poori details)
RECENT_DETAILS = 15     # sab se nayi (poori details)
SAMPLES = 3             # dekhne ke liye download (har channel)


def _ydl(extra: dict | None = None):
    import yt_dlp  # type: ignore
    from app.media.download import _deno_options
    opts = {"quiet": True, "no_warnings": True, "ignoreerrors": True, "skip_download": True}
    opts.update(_deno_options())
    opts.update(extra or {})
    return yt_dlp.YoutubeDL(opts)


def _base(link: str) -> str:
    link = link.split("?")[0].rstrip("/")
    for tail in ("/shorts", "/videos", "/featured", "/streams"):
        if link.endswith(tail):
            link = link[: -len(tail)]
    return link


def _list(url: str) -> list[dict]:
    with _ydl({"extract_flat": "in_playlist"}) as y:
        info = y.extract_info(url, download=False) or {}
    out = []
    for e in info.get("entries") or []:
        if not e:
            continue
        out.append({"id": e.get("id"), "title": e.get("title"), "views": e.get("view_count"),
                    "duration": e.get("duration"), "url": e.get("url")})
    return out


def _details(vid: str) -> dict:
    with _ydl() as y:
        i = y.extract_info(f"https://www.youtube.com/watch?v={vid}", download=False) or {}
    return {k: i.get(k) for k in ("id", "title", "description", "tags", "categories", "view_count", "like_count",
                                  "comment_count", "duration", "upload_date", "width", "height", "channel",
                                  "channel_follower_count")}


def main() -> int:
    links = [a for a in sys.argv[1:] if a.startswith("http")]
    report = ROOT / "channel_data.json"
    samples = ROOT / "channel_samples"
    data: dict = {"made": time.strftime("%Y-%m-%d %H:%M"), "channels": []}
    for link in links:
        base = _base(link)
        print(f"Channel: {base}", flush=True)
        ch: dict = {"link": base, "shorts": [], "videos": [], "details": []}
        for kind in ("shorts", "videos"):
            try:
                ch[kind] = _list(f"{base}/{kind}")
            except Exception as exc:  # noqa: BLE001
                print(f"   {kind}: {exc}", flush=True)
            print(f"   {kind}: {len(ch[kind])}", flush=True)
        allv = ch["shorts"] + ch["videos"]
        top = sorted([v for v in allv if v.get("views")], key=lambda v: -v["views"])[:TOP_DETAILS]
        recent = ch["shorts"][:RECENT_DETAILS] + ch["videos"][:5]
        want = list(dict.fromkeys(v["id"] for v in top + recent if v.get("id")))
        for n, vid in enumerate(want, 1):
            try:
                ch["details"].append(_details(vid))
            except Exception as exc:  # noqa: BLE001
                print(f"   details {vid}: {exc}", flush=True)
            print(f"   details {n}/{len(want)}", flush=True)
        data["channels"].append(ch)
        report.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
        # dekhne ke liye sab se zyada chalne wali shorts
        best = sorted([v for v in ch["shorts"] if v.get("views")], key=lambda v: -v["views"])[:SAMPLES]
        folder = samples / base.rsplit("/", 1)[-1].lstrip("@")
        folder.mkdir(parents=True, exist_ok=True)
        for v in best:
            try:
                with _ydl({"skip_download": False, "format": "bv*[height<=720][ext=mp4]+ba[ext=m4a]/b[height<=720]",
                           "merge_output_format": "mp4", "outtmpl": str(folder / "%(id)s.%(ext)s")}) as y:
                    y.download([f"https://www.youtube.com/shorts/{v['id']}"])
            except Exception as exc:  # noqa: BLE001
                print(f"   sample {v['id']}: {exc}", flush=True)
        print(f"   samples: {len(list(folder.glob('*.mp4')))}", flush=True)
    print(f"Done: {report}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
