"""
=====================================================================
  TOOLS / ALL FEATURES CHECK     python -m app.tools.all_features [first] [last]
  Kaam: developer test: har feature 2 videos pe (installer mein nahi jata).
  Tests every feature on its own, in small phases: each phase makes
  2 clips from each of 2 videos (4 clips), with ONLY that feature
  changed from the normal settings. Everything goes into
      <Clips>\\Feature Check\\NN Feature name\\
      <Clips>\\Feature Check\\Feature Check Report.txt
  and the same report as feature_check_report.txt next to this tool.
  Settings on disk are never changed. Old Feature Check clips are
  cleared first. Optional numbers run only some phases, for example
  "all_features 5 7" runs phases 5 to 7.
  Videos are the ones already downloaded, so most phases skip the
  download and the speech step and go straight to clips.
=====================================================================
"""
from __future__ import annotations

import shutil
import sys
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

BEN_SHOW = "https://youtu.be/B0jjW27W2L4"                         # Ben Shapiro show: picture boxes + full screen
INTERVIEW = "https://www.youtube.com/watch?v=SPGxj0mhTBU"        # two people at a desk
TABLE = "https://www.youtube.com/watch?v=VrB7e6wNEMM"            # four women at a table (debate)
BEN_DEBATE = "https://www.youtube.com/watch?v=-1NFirxhXWE"       # Ben Shapiro with other people


@dataclass
class Phase:
    name: str
    shows: str                                   # what to look at in the clips
    settings: dict = field(default_factory=dict)  # app settings changed for this phase only
    campaign: dict = field(default_factory=dict)  # campaign settings changed for this phase only
    videos: tuple = (BEN_SHOW, INTERVIEW)
    clips: int = 2
    length: tuple = (20, 30)
    ratio: str | None = None
    main_person: bool = False
    deliver: bool = False


PHASES = [
    Phase("Normal settings", "The base look every other phase is compared with. Captions, hook title, zoom, "
          "colour look, reaction shots and better moments ON; sound effects OFF."),
    Phase("Layout (stack, boxes, face)", "Two people stacked top and bottom; Ben show graphics with the speaker "
          "box on top and the tweet or video below (no blue background); single speaker face crop.",
          videos=(BEN_SHOW, TABLE)),
    Phase("Captions OFF", "No captions at all.", campaign={"captions_enabled": False}),
    Phase("Caption styles rotate", "Each clip gets a different caption style (style name in the report).",
          clips=3),
    Phase("Hook title OFF", "No hook title at the start.", settings={"hook_titles": False}),
    Phase("Zoom effects OFF", "No punch or push zooms; the picture stays still.",
          settings={"zoom_effects": False, "emphasis_zoom": False}),
    Phase("Reaction shots OFF", "No short looks at a listener (compare with phase 1).",
          settings={"reaction_shots": False}),
    Phase("Better moments OFF", "Older, looser choice of start and end (compare scores with phase 1).",
          settings={"better_moments": False}),
    Phase("Sound effects ON", "Soft whoosh / pop / hit at zooms, hooks and cuts.", settings={"sound_effects": True}),
    Phase("Colour look and sharpen OFF", "Original colours, no sharpening.",
          settings={"color_looks_enabled": False, "sharpen": False}),
    Phase("Silence remover strong", "Pauses cut more tightly (clip still ends on a full sentence).",
          settings={"silence_level": "strong"}),
    Phase("Loudness OFF", "Original volume instead of -14 LUFS.", settings={"loudness_normalize": False}),
    Phase("16-9 output", "Landscape 1920x1080 clips.", ratio="16:9"),
    Phase("Long clips 60-120 s", "One long clip per video, still ending on a full sentence.", clips=1,
          length=(60, 120)),
    Phase("Bad words MUTE strict", "Strict word filter; bad words muted instead of beeped, shown as s*** in captions.",
          settings={"beep_mode": "mute", "profanity_level": "strict"}),
    Phase("Main person Ben Shapiro", "Ben on screen and talking at least 60% of every clip, on screen in the first "
          "seconds; on screen and talking shares in the report.", videos=(BEN_SHOW, BEN_DEBATE), main_person=True),
    Phase("Logo overlay", "AIMERS R logo in the top right corner of every clip.",
          campaign={"logo": {"enabled": True, "path": "assets/brand/r_mark.png", "position": "top_right",
                             "size_pct": 11.0, "opacity": 0.65, "timing": "full"}}),
    Phase("Delivery tracker", "2 clips given to 'Test Receiver': moved to Delivered\\Test Receiver <date> and "
          "never given twice.", deliver=True),
]


def _layout_text(pipe, info: dict, reactions: bool) -> str:
    key = (round(info.get("start", -1), 2), round(info.get("end", -1), 2), bool(reactions))
    pieces = (getattr(pipe, "_layouts", {}) or {}).get(key) or []
    if not pieces:
        return "centre"
    seen: list[str] = []
    for p in pieces:
        name = {"stack": "stacked", "panels": "boxes", "crop": "face", "fit_blur": "full picture"}.get(p.mode, p.mode)
        if getattr(p, "reaction", False):
            name = "reaction"
        if not seen or seen[-1] != name:
            seen.append(name)
    return " > ".join(seen)


def main() -> int:
    from app.core.config import AppSettings, OverlaySpec
    from app.core.db import Database
    from app.core.logging_setup import setup_logging
    from app.output.delivery import deliver_next
    from app.output.organizer import campaign_root
    from app.pipeline.runner import Events, JobRequest, Pipeline, PipelineError
    setup_logging()

    first = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    last = int(sys.argv[2]) if len(sys.argv) > 2 else len(PHASES)
    s = AppSettings.validate(AppSettings.load())
    base = Path(s.output_dir) / "Feature Check"
    lines: list[str] = []

    def out(text: str = "") -> None:
        print(text, flush=True)
        lines.append(text)
        base.mkdir(parents=True, exist_ok=True)
        body = "\n".join(lines) + "\n"
        (base / "Feature Check Report.txt").write_text(body, encoding="utf-8")
        (ROOT / "feature_check_report.txt").write_text(body, encoding="utf-8")

    db = Database()
    debate = db.get_campaign(db.ensure_campaign("Debate"))
    if first == 1 and base.exists():
        shutil.rmtree(base, ignore_errors=True)
    out(f"AIMERS all features check | {time.strftime('%Y-%m-%d %H:%M')} | phases {first} to {last}")
    out(f"Folder: {base}")
    out("Each phase: 2 videos x its clip count, only that feature changed from normal settings.")
    started, summary = time.time(), []
    for n, ph in enumerate(PHASES, 1):
        if not first <= n <= last:
            continue
        folder = f"{n:02d} {ph.name}"
        out("")
        out(f"=== {folder} ===")
        out(f"Look for: {ph.shows}")
        run = AppSettings.validate(AppSettings.load())
        run.output_dir = str(base)
        run.min_length, run.max_length = ph.length
        for k, v in ph.settings.items():
            setattr(run, k, v)
        run = AppSettings.validate(run)
        cid = db.ensure_campaign(folder)
        camp = db.get_campaign(cid)
        for k, v in ph.campaign.items():
            if k == "logo":
                spec = OverlaySpec(**v)
                spec.path = str(ROOT / spec.path)
                camp.logo = spec
            else:
                setattr(camp, k, v)
        if ph.main_person:
            camp.main_person_name = debate.main_person_name or "Ben Shapiro"
            camp.main_person_photos = list(debate.main_person_photos)
            camp.main_person_min_screen = debate.main_person_min_screen or 60
            camp.main_person_min_speaking = debate.main_person_min_speaking or 60
            if not camp.main_person_photos:
                out("  SKIPPED: the Debate campaign has no Ben Shapiro photos")
                summary.append((folder, "SKIPPED", 0, 0))
                continue
        db.update_campaign(cid, camp)
        db.purge_campaign_clips(cid)
        shutil.rmtree(campaign_root(base, camp), ignore_errors=True)
        made = wanted = 0
        ok = True
        for url in ph.videos:
            t0 = time.time()
            holder: dict = {}

            def clip(done: int, total: int, info: dict) -> None:
                e = info.get("edit") or {}
                pr = info.get("person") or {}
                length = (info.get("end", 0) or 0) - (info.get("start", 0) or 0)
                extra = (f" | Ben on screen {pr.get('visible', 0):.0%}, talking {pr.get('speaking', 0):.0%}, "
                         f"first seconds {pr.get('hook', 0):.0%}" if pr else "")
                out(f"  {info.get('label')} | {info.get('rating')} {info.get('score')} | {length:.0f}s | "
                    f"style {info.get('style') or 'none'} | zoom {e.get('zoom') or '-'} | "
                    f"layout {_layout_text(holder.get('pipe'), info, run.reaction_shots)}{extra}")
                out(f"      file: {info.get('file')}")

            ev = Events(stage=lambda st: None, clip_done=clip,
                        warning=lambda k, d: out(f"  note: {k} {d}"), log=lambda m: out(f"  log: {m}"))
            out(f"  video: {url}")
            try:
                pipe = Pipeline(run, db, JobRequest(url, cid, clip_count=ph.clips, ratio=ph.ratio), ev)
                holder["pipe"] = pipe
                r = pipe.run()
                made, wanted = made + r.made, wanted + r.requested
                ok = ok and r.made == r.requested and not r.failed
                out(f"  result: made {r.made}/{r.requested} | {r.counts} | failed {len(r.failed)} | "
                    f"{time.time() - t0:.0f}s")
            except PipelineError as exc:
                ok = False
                wanted += ph.clips
                out(f"  result: FAIL {exc.key} {exc.detail}")
            except Exception:  # noqa: BLE001
                ok = False
                wanted += ph.clips
                out("  result: FAIL unexpected")
                out(traceback.format_exc())
        if ph.deliver and made:
            try:
                d = deliver_next(db, cid, campaign_root(base, camp), "Test Receiver", 2)
                again = len([c for c in db.clips_for_campaign(cid, undelivered_only=True)])
                out(f"  delivery: gave {d.count} clips to Test Receiver, {again} still free to give")
                ok = ok and d.count == min(2, made)
            except Exception as exc:  # noqa: BLE001
                ok = False
                out(f"  delivery: FAIL {exc}")
        summary.append((folder, "PASS" if ok else "CHECK", made, wanted))
    out("")
    out("SUMMARY (PASS = all clips made; still watch the clips to judge the look)")
    for folder, verdict, made, wanted in summary:
        out(f"  {verdict:7} {folder} | {made}/{wanted} clips")
    out(f"ALL DONE in {(time.time() - started) / 60:.0f} min")
    return 0


if __name__ == "__main__":
    sys.exit(main())
