"""
=====================================================================
  CAMPAIGN / PERSON CHECK            (21 Nov 2026)
  Kaam: sheet ka link download karne SE PEHLE dekhna ke campaign ka
  main person (jaise Debate: Ben Shapiro) video mein hai ya nahi.
  Internet se hi video ke alag alag hisson ki ~30 chhoti tasveerein,
  har ek mein chehra pehchana jata hai (campaign ki photos se).
  Kitne hisson mein wo mila = share. Share kam ho to video download hi
  nahi hoti (ghanta bachta hai). Kuch bhi masla ho to None: video
  allow (koi link zaya na ho). Clips ka 60% wala rule alag se wohi.
=====================================================================
"""
from __future__ import annotations

import subprocess
from concurrent.futures import ThreadPoolExecutor

from app.core.logging_setup import get_logger

log = get_logger("person_check")

SAMPLES = 30          # kitni tasveerein
MIN_FRAMES = 12       # is se kam tasveerein mili to faisla nahi (video allow)
WORKERS = 4
FRAME_TIMEOUT = 40


def stream(link: str) -> tuple[str, float]:
    """Chhoti quality ki video ka seedha pata + lambai (download kuch nahi hota)."""
    import yt_dlp  # type: ignore
    from app.media.download import _deno_options
    opts = {"quiet": True, "no_warnings": True, "noplaylist": True, "skip_download": True,
            "format": "best[height<=480][vcodec!=none]/worst[vcodec!=none]/best"}
    opts.update(_deno_options())
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(link, download=False)
    url = info.get("url") or ""
    if not url and info.get("requested_formats"):
        url = info["requested_formats"][0].get("url", "")
    if not url:
        raise RuntimeError("no stream address")
    return url, float(info.get("duration") or 0)


def grab_frame(url: str, t: float):
    """Ek waqt ki ek tasveer (BGR numpy) ya None."""
    import cv2
    import numpy as np
    from app.media.ffmpeg_tools import ffmpeg_bin
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostdin", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", url,
           "-frames:v", "1", "-vf", "scale=960:-2", "-f", "image2pipe", "-vcodec", "png", "-"]
    try:
        out = subprocess.run(cmd, capture_output=True, timeout=FRAME_TIMEOUT,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
    except (subprocess.TimeoutExpired, OSError):
        return None
    if not out:
        return None
    img = cv2.imdecode(np.frombuffer(out, np.uint8), cv2.IMREAD_COLOR)
    return img


def frame_has(frame, matcher) -> bool:
    """Is tasveer mein main person hai?"""
    import cv2
    from app.render.person import DETECT_MODEL, is_match
    h, w = frame.shape[:2]
    det = cv2.FaceDetectorYN.create(str(DETECT_MODEL), "", (w, h), 0.6, 0.3, 50)
    _, faces = det.detect(frame)
    if faces is None:
        return False
    return any(is_match(matcher.similarity(frame, f)) for f in faces)


def share_in(url: str, duration: float, matcher, samples: int = SAMPLES, grab=grab_frame) -> float | None:
    """Kitne hisson mein main person mila (0..1); tasveerein kam milein to None."""
    if duration <= 0:
        return None
    times = [duration * (0.04 + 0.92 * k / max(1, samples - 1)) for k in range(samples)]
    with ThreadPoolExecutor(WORKERS) as pool:
        frames = list(pool.map(lambda t: grab(url, t), times))
    frames = [f for f in frames if f is not None]
    if len(frames) < MIN_FRAMES:
        return None
    hits = sum(1 for f in frames if frame_has(f, matcher))
    return hits / len(frames)


def check(link: str, photos: list[str], stream_fn=stream, grab=grab_frame) -> float | None:
    """Link mein main person ka share; None = pata nahi chala (allow)."""
    try:
        from app.render.person import PersonMatcher, available
        if not photos or not available():
            return None
        matcher = PersonMatcher(photos)
        if not matcher.usable:
            return None
        url, duration = stream_fn(link)
        share = share_in(url, duration, matcher, grab=grab)
        log.info("Person check %s: %s", link, "unknown" if share is None else f"{share:.0%} on screen")
        return share
    except Exception as exc:  # noqa: BLE001 - check na ho sake to video allow
        log.info("Person check skipped for %s: %s", link, str(exc)[:200])
        return None
