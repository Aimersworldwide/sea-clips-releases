"""
=====================================================================
  PIPELINE / RUNNER   (link or file  ->  finished, sorted clips)
  Kaam: poora kaam: link -> download -> sunna -> moments -> render -> folders.
  Stages and their share of the progress bar:
      download 10 | prepare 6 | transcribe 26 | plan 2 | render 56
  (stages that are not needed are skipped and the rest stretch)

  Safety:
    * Resume: download, normalised video, audio and transcript are
      cached per source. Re-running the same source skips straight to
      clips, and the duplicate check skips clips already made.
    * Pause / Cancel are checked between clips; a cancelled clip
      leaves no half file behind.
    * Windows is kept awake while working.
    * Disk space checked before and during rendering.
    * Each clip is checked (QC). Failed -> rendered once more with safe
      settings -> still failed -> goes to "Below 50" with the reason.
  The runner never touches the UI; it reports through `Events`.
=====================================================================
"""
from __future__ import annotations

import dataclasses
import json
import re
import shutil
import threading
import time
import zlib
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Callable

from app.core.config import AppSettings, CampaignProfile
from app.core.db import Database
from app.core.logging_setup import get_logger
from app.core.paths import cache_dir, models_dir, move_with_retry, safe_filename, temp_dir, title_filename
from app.core.system import keep_awake
from app.edit.variety import EditChoice, choose_edits
from app.filters.profanity import DEFAULT_VIPS
from app.media.download import download, is_url
from app.media.ffmpeg_tools import Cancelled, FFmpegError, free_space_gb
from app.media.prepare import extract_speech_audio, needs_normalizing, normalize
from app.media.probe import SourceInfo, check_source, probe, source_hash
from app.output.organizer import (campaign_root, clip_filename, clip_label, clip_title, hook_from_text,
                                  rating_folder, unique_path)
from app.qc.check import check_clip
from app.render.framing import FramePlan, choose_mode, fit_zoom_for
from app.render.layout import analyse as analyse_layout, stacked_share
from app.render.renderer import RenderJob, final_size, render_clip
from app.render.timeline import Segment, build_segments, remap_words, total_duration
from app.select.planner import ClipPlan, plan_clips, window_key
from app.transcribe.asr import ENGLISH_MODEL, model_ready, transcribe
from app.transcribe.names import NameFixer, campaign_names, fix_transcript, hotwords
from app.transcribe.models import Transcript

log = get_logger("pipeline")

HOOK_PERSON_SECONDS = 3.0   # main person campaigns: he must be on screen in the first seconds...
HOOK_PERSON_SHARE = 0.66    # ...at least this share of them
PERSON_RARE_SHARE = 0.08    # main person video ke itne se kam hisse mein mile to photo ki warning
SUBS_COVER_SHARE = 0.30    # source ke subtitles clip ke itne hisse mein dikhen to captions ke peeche cover box

def reedit_frame(base_zoom: float, base_bg: str, seed: str) -> tuple[str, float]:
    """Poori tasveer wali campaign ke re-edit ka frame: zoom base se thora upar/neeche, background blur ya black."""
    import zlib
    h = zlib.crc32(seed.encode())
    zooms = (round(base_zoom - 0.25, 2), base_zoom, round(base_zoom + 0.2, 2))
    zoom = max(1.25, zooms[h % 3])
    if base_bg == "mix":
        bg = BG_MIX[(h // 3) % len(BG_MIX)]
    elif base_bg in ("blur", "black"):
        bg = ("blur", "black", "blur")[(h // 3) % 3]
    else:
        bg = "black"                                  # (19 Nov) safed background mana: purani white bhi kaala
    return bg, zoom


# Campaign line (Super) ka andaaz har clip mein alag: aadha dabbe ke saath, aadha bina dabbe (sirf kinara)
SUPER_LOOKS = ((True, "#111111"), (False, "#FFFFFF"), (True, "#FFFFFF"), (False, "#FFE11A"),
               (True, "#F2C85B"), (False, "#FFFFFF"))


def super_look(seed: str) -> tuple[bool, str]:
    import zlib
    return SUPER_LOOKS[zlib.crc32(seed.encode()) % len(SUPER_LOOKS)]


# (19 Nov, user) campaigns mein safed background mana: kahin bhi white nahi, sirf kaala / blur
BG_MIX = ("blur", "black", "black", "blur")   # Mix: har clip mein alag


def clip_background(base_bg: str, seed: str) -> str:
    """Campaign ka background; Mix ho to har clip ka apna (pakka, seed se)."""
    if base_bg != "mix":
        return base_bg if base_bg in ("blur", "black") else "black"   # purani "white" setting bhi kaala
    import zlib
    return BG_MIX[zlib.crc32(seed.encode()) % len(BG_MIX)]


SUPER_SECONDS = 4.5          # Super (campaign ka zaroori jumla): poori clip mein, kam az kam itne second


TIGHT_SHARE = 0.40   # (17 Nov) clip ka itna hissa bahut qareeb wala shot ho to clip nahi
SPLIT_MIN = 0.85     # (18 Nov) split clip ka itna hissa asal do log, warna Classic


MUSIC_EXT = (".mp3", ".m4a", ".aac", ".wav", ".ogg", ".flac")
MUSIC_RETIRED = {"aimers test bed 01.m4a"}   # (18 Nov) purana test gaana, ab Ambient 01 se 04


def music_tracks(folder: str) -> list[Path]:
    """(17 Nov) Campaign ke music folder ke gaane; khaali / na mile to tool ka apna test gaana."""
    out: list[Path] = []
    if folder and Path(folder).is_dir():
        out = sorted(f for f in Path(folder).iterdir() if f.is_file() and f.suffix.lower() in MUSIC_EXT)
    if not out:
        from app.core.paths import resource
        own = Path(resource("assets", "music"))
        if own.is_dir():
            out = sorted(f for f in own.iterdir() if f.is_file() and f.suffix.lower() in MUSIC_EXT
                         and f.name.lower() not in MUSIC_RETIRED)
    return out


def pick_music(folder: str, seed: str) -> tuple[str, float]:
    """Har clip ka gaana aur gaane mein shuru ki jagah (pakka, seed se)."""
    tracks = music_tracks(folder)
    if not tracks:
        return "", 0.0
    h = zlib.crc32(seed.encode())
    return str(tracks[h % len(tracks)]), float((h >> 8) % 40)


def pick_hook(words, names: list[str] | None = None, skip: str = "", avoid: set[int] | None = None,
              clean=None) -> str:
    """
    Hook title: a teaser from LATER in the clip (the first line is already
    on screen as a caption). Questions and exclamations first, then the
    longest line. Short and clean (6 words). Lines with blocked words
    (death, kill, swears, attacks on the main people) are never used.
    """
    from app.filters.guard import hook_is_clean
    sentences, current, bad = [], [], False
    for k, w in enumerate(words):
        current.append(w.text)
        bad = bad or (avoid is not None and k in avoid)      # beep / kata hua lafz: ye line hook nahi
        if w.ends_sentence:
            sentences.append(None if bad else " ".join(current))
            current, bad = [], False
    # sirf POORI line (8 lafz tak) ya jumle ka poora hissa (comma tak): "..." wala adhoora hook nahi
    import re as _re
    from app.output.organizer import HOOK_WORDS
    from app.select.scoring import WIT_PHRASES
    def norm(t: str) -> str:
        return " ".join(_re.sub(r"[^a-z0-9' ]+", " ", t.lower()).split())

    skip_n = norm(skip)
    pool = []
    for x in sentences[1:]:
        if x is None:
            continue
        if skip_n and (norm(x) in skip_n or skip_n in norm(x)):
            continue                                   # cold open wali line (ya us ka hissa) dobara hook nahi
        pool.append(x)
        parts = [p.strip() for p in _re.split(r"(?<=[,;:])\s+", x) if p.strip()]
        if len(parts) > 1:
            pool += [p.rstrip(",;:") + ("?" if x.rstrip().endswith("?") and p is parts[-1] else "") for p in parts]
    later = []
    for x in pool:
        if skip_n and norm(x) and norm(x) in skip_n:
            continue
        text = hook_from_text(x, HOOK_WORDS + 2)
        n = len(x.split())
        if 3 <= n <= HOOK_WORDS + 2 and not text.endswith("...") and hook_is_clean(text, names) \
                and (clean is None or clean(text)):
            later.append((x, text))
    if not later:
        return ""
    best = max(later, key=lambda xt: (xt[0].rstrip().endswith(("?", "!")),
                                       any(ph in xt[0].lower() for ph in WIT_PHRASES), min(len(xt[0].split()), 8)))
    return best[1]


QA_TALK_MAX = 0.8          # main person is se kam bole tabhi clip sawal-jawab (koi aur bhi bol raha)
CARD_HOOK_MAX = 12         # title card (Auto): sirf jab pehli line aam ho (hook 0..25 mein 12 ya kam)
RAM_PER_CLIP_GB = 3.5      # ek clip ke render ki RAM: naapi hui sab se zyada 3.1 GB (kai shots wala clip), gunjaish ke sath
RAM_RESERVE_GB = 2.5       # Windows, app aur speech model ke liye hamesha khali


def free_ram_gb() -> float:
    """Abhi kitni RAM khali hai (GB). Pata na chale to 0 (phir purana hisaab)."""
    import sys
    try:
        if sys.platform == "win32":
            import ctypes

            class _Mem(ctypes.Structure):
                _fields_ = [("len", ctypes.c_ulong), ("load", ctypes.c_ulong), ("total", ctypes.c_ulonglong),
                            ("avail", ctypes.c_ulonglong), ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong),
                            ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong), ("ext", ctypes.c_ulonglong)]
            m = _Mem()
            m.len = ctypes.sizeof(_Mem)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
                return m.avail / 1024 ** 3
            return 0.0
        with open("/proc/meminfo", encoding="ascii") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) / 1024 ** 2
    except Exception:  # noqa: BLE001 - kabhi run na roke
        return 0.0
    return 0.0


# ---------------------------------------------------------------------
#  Sawal jawab clips mein editor jaisi variety (har clip / edit alag)
#    qa      : upar sawal karne wala / audience, neeche main speaker
#    qa_top  : ulta: main speaker upar, audience / sawal karne wala neeche
#    mix     : upar neeche, magar main speaker ke CHHOTE shots (MIX_MAX tak) poori screen par (punch in)
#  Poori screen sirf us shot mein jahan camera wala shakhs khud bol raha ho (honth); warna upar neeche.
#  Is campaign ki pehchaan upar neeche hai, is liye "solo" (poori clip akela) ab nahi.
#  Seed clip ke tag + style se: aik moment ke alag edits alag layout lete hain.
# ---------------------------------------------------------------------
QA_VARIANTS = (("qa", 50), ("qa_top", 35), ("mix", 15))
MIX_MAX = 3.5


def qa_variant(pieces, seed: str, name: str | None = None):
    if name is None:
        h = zlib.crc32(seed.encode()) % sum(w for _, w in QA_VARIANTS)
        for name, w in QA_VARIANTS:
            if h < w:
                break
            h -= w
    out = []
    for pc in pieces:
        if pc.mode != "qa":
            out.append(pc)
        elif name == "qa_top" and not getattr(pc, "same_person", False):
            # ulta: (akele shakhs ke do zoom mein close up hamesha neeche, door wala upar: user ki pasand)
            out.append(dataclasses.replace(pc, live_top=not pc.live_top))
        elif (name == "mix" and getattr(pc, "main_live", False) and getattr(pc, "live_talks", False)
              and pc.end - pc.start <= MIX_MAX):
            # chhota punch in: poori screen usi ko jo camera par hai AUR bol raha hai
            out.append(dataclasses.replace(pc, mode="crop", comp=(), comps=()))
        else:
            out.append(pc)
    return out


def post_title_of(title: str, suffix: str) -> str:
    """Post ka title: clip ka apna title + campaign ka aakhri hissa (jaise "Vote Yes on 42"), ek dafa."""
    title, suffix = (title or "").strip(), (suffix or "").strip()
    if not title or not suffix or suffix.lower() in title.lower():
        return title
    return f"{title.rstrip(' .')} \u2022 {suffix}"


def card_edit(edit, tag: str):
    """Title card wala clip: seekha hua andaaz (CAPS bold captions, laal / peela ek rang), hook nahi."""
    from app.edit.variety import FRAME_PALETTES, FRAME_STYLES
    h = zlib.crc32(tag.encode())
    from app.captions.styles import CHIP_STYLES
    keep = edit.caption_style in FRAME_STYLES or edit.caption_style in CHIP_STYLES    # chip campaign ka apna andaaz
    style = edit.caption_style if keep else FRAME_STYLES[h % len(FRAME_STYLES)]
    palette = edit.palette if edit.palette in FRAME_PALETTES else FRAME_PALETTES[(h // 7) % len(FRAME_PALETTES)]
    return dataclasses.replace(edit, caption_style=style, palette=palette, hook=False, bar="", frame="title")


def render_workers(setting: int = 0) -> tuple[int, int]:
    """
    (clips at the same time, encoder threads per clip).
    Har clip ka encoder bilkul pehle jitne threads pe chalta hai (purana
    hisaab: 6 se kam CPU threads 1 clip, 12 se kam 2, warna 3), is liye
    har clip bit-by-bit wahi banta hai. Sirf ek sath zyada clips banate
    hain jab laptop ke cores aur khali RAM ijazat dein (0 = khud);
    purane se kam kabhi nahi.
    """
    import os
    cores = os.cpu_count() or 2
    old = 1 if cores < 6 else 2 if cores < 12 else 3
    threads = max(2, cores // old) if old > 1 else 0          # encoder threads: hamesha purane jaise
    if setting > 0:
        return max(1, min(6, setting)), threads
    by_cpu = max(old, cores // 4)                             # 8 threads 2, 16 threads 4 ...
    ram = free_ram_gb()
    by_ram = max(1, int((ram - RAM_RESERVE_GB) / RAM_PER_CLIP_GB)) if ram > 0 else old
    return max(old, min(6, by_cpu, by_ram)), threads          # kabhi purane se kam nahi (laptop pe purana hamesha chala)


STREAM_HEAD_COLOR = "#FFFFFF"   # (20 Nov) stream headline ka dabba (kaale huroof)
STREAM_MIN_GAMEPLAY = 0.6   # (20 Nov) stream clip ka kam az kam itna hissa gameplay (cutscene nahi)
STREAM_MAX_BEEPS = 6        # (20 Nov) stream clip mein itne beep tak moment chalega
STREAM_CAPTION_Y = {"round": 0.585, "stack": 0.53}     # (20 Nov) stream clips: captions game par (gol chehre / beech ki lakeer se door)
STAGE_WEIGHTS = {"download": 10, "prepare": 6, "transcribe": 26, "plan": 2, "render": 56}
MIN_FREE_GB = 2.0
MB_PER_CLIP = 40          # worst case estimate for a 30 s 1080p clip
RENDER_QUALITY = "high"   # same on every laptop; tests switch to "draft" for speed
PREVIEW_N = 10            # preview pack: itne best clips pehle
PREVIEW_WAIT = 20 * 60    # itne second jawab na aaye to khud aage chalo


# ---------------------------------------------------------------------
#  Preview pack ka jawab (UI se): OK = chalo, Cancel = ruko
# ---------------------------------------------------------------------
# online photo search: har shakhs ki ek session mein sirf ek koshish
_PHOTO_TRIED: set = set()

class PreviewGate:
    def __init__(self):
        self.event = threading.Event()
        self.answer = ""

    def reply(self, answer: str) -> None:
        self.answer = answer
        self.event.set()


def preview_wait(profile) -> float:
    """Campaign ka preview timer (second). 1 se 120 minute; ghalat ho to 20."""
    try:
        m = int(getattr(profile, "preview_minutes", 20) or 20)
    except (TypeError, ValueError):
        m = 20
    return float(max(1, min(120, m)) * 60)


def settings_fingerprint(profile, settings) -> str:
    """Campaign + clip settings ka chhota sa nishan: badle to preview dobara."""
    import hashlib
    keep = {k: v for k, v in profile.to_dict().items()
            if k not in ("raw_rules", "start_date", "end_date", "delivery_note", "output_folder", "preview_minutes")}
    app = {k: getattr(settings, k, None) for k in (
        "min_length", "max_length", "ratio", "captions_enabled", "default_caption_style", "rotate_caption_styles",
        "color_looks_enabled", "silence_level", "beep_mode", "profanity_level", "hook_titles", "zoom_effects",
        "reaction_shots", "sound_effects", "youtube_hq", "gpu_encode", "cold_open", "name_card")}
    return hashlib.sha1(json.dumps([keep, app], sort_keys=True, default=str).encode()).hexdigest()[:16]


def _preview_state_file() -> Path:
    from app.core.paths import app_data_dir
    return app_data_dir() / "preview_state.json"


def preview_needed(campaign_id: int, fingerprint: str) -> bool:
    try:
        state = json.loads(_preview_state_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        state = {}
    return state.get(str(campaign_id)) != fingerprint


def remember_preview(campaign_id: int, fingerprint: str) -> None:
    path = _preview_state_file()
    try:
        state = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except (OSError, ValueError):
        state = {}
    state[str(campaign_id)] = fingerprint
    try:
        path.write_text(json.dumps(state, indent=1), encoding="utf-8")
    except OSError:
        pass


# ---------------------------------------------------------------------
#  Public data
# ---------------------------------------------------------------------
@dataclass
class JobRequest:
    source: str                      # file path or link
    campaign_id: int
    clip_count: int | None = None    # None -> app default
    min_len: int | None = None
    max_len: int | None = None
    ratio: str | None = None
    phase: int = 0                   # 0 = apni ginti; -1 = agla phase khud; 1..5 = ye phase (100 clips / minute)
    profile: dict | None = None      # (queue) campaign settings ki copy jab video line mein lagi; None = abhi ki
    preview: bool | None = None      # (queue) is video ka preview; None = app setting
    prefetch_only: bool = False      # (20 Nov) sirf download + audio + transcript, clips nahi (agli video pehle se tayyar)
    prefetch_download_only: bool = False   # (21 Nov) CPU wala laptop: peeche sirf download (clips dheeme na hon)


MAX_PHASES = 5


@dataclass
class Events:
    """Callbacks (all optional). The UI wraps these in Qt signals."""
    stage: Callable[[str], None] = lambda name: None
    progress: Callable[[float, str], None] = lambda overall, text: None
    clip_done: Callable[[int, int, dict], None] = lambda done, total, info: None
    warning: Callable[[str, dict], None] = lambda key, data: None
    log: Callable[[str], None] = lambda msg: None
    preview: Callable[[list], None] | None = None     # pehle 10 clips tayyar: UI OK / Cancel poochta hai


@dataclass
class RunSummary:
    requested: int = 0
    made: int = 0
    counts: dict[str, int] = field(default_factory=lambda: {"recommended": 0, "medium": 0, "below": 0, "check": 0})
    repaired: int = 0
    failed: list[str] = field(default_factory=list)
    max_good: int = 0
    moments: int = 0
    dropped: dict[str, int] = field(default_factory=dict)
    folder: str = ""
    seconds: float = 0.0
    cancelled: bool = False


class PipelineError(RuntimeError):
    """A problem the user must fix (message key for i18n + details)."""

    def __init__(self, key: str, detail: str = ""):
        super().__init__(detail or key)
        self.key, self.detail = key, detail


# ---------------------------------------------------------------------
#  Runner
# ---------------------------------------------------------------------
class Pipeline:
    def __init__(self, settings: AppSettings, db: Database, request: JobRequest,
                 events: Events | None = None,
                 cancel_event: threading.Event | None = None,
                 pause_event: threading.Event | None = None,
                 transcriber: Callable[..., Transcript] | None = None,
                 preview_gate: PreviewGate | None = None):
        self.s = settings
        self.db = db
        self.req = request
        self.ev = events or Events()
        self.cancel = cancel_event or threading.Event()
        self.pause = pause_event or threading.Event()    # set = paused
        self._transcribe = transcriber or transcribe     # tests inject a fake
        self.preview_gate = preview_gate
        profile = (CampaignProfile.from_dict(request.profile) if request.profile
                   else db.get_campaign(request.campaign_id))
        if profile is None:
            raise PipelineError("msg.no_campaign")
        self.profile: CampaignProfile = profile
        self._weights: dict[str, float] = {}
        self._done_weight = 0.0
        self._shown = 0.0                      # progress shown so far (never goes back)
        user_progress = self.ev.progress

        def forward_only(value: float, text: str) -> None:
            self._shown = max(self._shown, min(1.0, value))
            user_progress(self._shown, text)
        self.ev = Events(stage=self.ev.stage, progress=forward_only, clip_done=self.ev.clip_done,
                         warning=self.ev.warning, log=self.ev.log, preview=self.ev.preview)

    # --- progress helpers -------------------------------------------
    def _setup_weights(self, downloading: bool, normalizing: bool) -> None:
        active = dict(STAGE_WEIGHTS)
        if not downloading:
            active.pop("download")
        if not normalizing:
            active["prepare"] = 2      # audio extraction only
        total = sum(active.values())
        self._weights = {k: v / total for k, v in active.items()}

    def _stage_cb(self, stage: str, text: str) -> Callable[[float], None]:
        base = self._done_weight
        weight = self._weights.get(stage, 0.0)

        def cb(frac: float) -> None:
            self.ev.progress(min(1.0, base + weight * max(0.0, min(1.0, frac))), text)
        return cb

    def _finish_stage(self, stage: str) -> None:
        self._done_weight += self._weights.get(stage, 0.0)

    def _check_cancel(self) -> None:
        while self.pause.is_set() and not self.cancel.is_set():
            time.sleep(0.25)
        if self.cancel.is_set():
            raise Cancelled()

    # --- main --------------------------------------------------------
    def run(self) -> RunSummary:
        started = time.time()
        summary = RunSummary()
        with keep_awake():
            try:
                self._run(summary)
            except Cancelled:
                summary.cancelled = True
                self.ev.log("Cancelled by user.")
            finally:
                summary.seconds = time.time() - started
                self._write_outputs(summary)
        return summary

    def _run(self, summary: RunSummary) -> None:
        s, p = self.s, self.profile
        src_text = self.req.source.strip().strip('"')
        downloading = is_url(src_text)
        self._require_person_photos(p)

        # ---- 1. source -------------------------------------------------
        if downloading:
            self._setup_weights(True, False)
            self.ev.stage("download")
            src_path = download(src_text, cache_dir() / "downloads",
                                on_progress=self._stage_cb("download", "Downloading"), cancel_event=self.cancel,
                                cookies_file=s.youtube_cookies)
            self._finish_stage("download")
            if self.req.prefetch_only and self.req.prefetch_download_only:
                return                   # (21 Nov) GPU nahi: baqi tayyari baari aane par (CPU clips ke liye khali)
        else:
            src_path = Path(src_text)
            if not src_path.exists():
                raise PipelineError("msg.file_missing", str(src_path))

        info = probe(src_path)
        check = check_source(info)
        if not check.ok:
            raise PipelineError(f"msg.{check.message_key}" if not check.message_key.startswith("msg.")
                                else check.message_key)
        if check.low_quality:
            self.ev.warning("msg.source_low", {"height": check.height})
        self._setup_weights(downloading, needs_normalizing(info))
        self._done_weight = self._weights.get("download", 0.0) if downloading else 0.0

        # ---- 2. prepare (cached per source) ----------------------------
        self._check_cancel()
        self.ev.stage("prepare")
        shash = source_hash(src_path)
        work = cache_dir() / shash
        self._work = work
        work.mkdir(parents=True, exist_ok=True)
        if needs_normalizing(info):
            # The clean master is big (about 10 GB per hour at 1080p) and lives
            # on the app-data drive (usually C:). Check that drive first.
            w, h = info.display_size
            need_gb = 2.0 + info.duration * 3.5 * max(1.0, (w * h) / (1920 * 1080)) / 1024
            if not (work / "master.mp4").exists() and free_space_gb(work) < need_gb:
                raise PipelineError("msg.disk_low", f"{free_space_gb(work):.1f} GB free on the app drive, "
                                                    f"need about {need_gb:.0f} GB")
            master = normalize(info, work / "master.mp4",
                               on_progress=self._stage_cb("prepare", "Preparing video"), cancel_event=self.cancel)
            info = probe(master)
        wav = extract_speech_audio(info.path, work / "speech.wav", info.duration, cancel_event=self.cancel)
        self._finish_stage("prepare")

        # ---- 3. transcript (cached) ------------------------------------
        self._check_cancel()
        self.ev.stage("transcribe")
        tpath = work / "transcript.json"
        # naamon ki list: campaign ke log + campaign ke naam + Settings + built-in
        names = campaign_names(p, s)
        self._fixer = NameFixer(names, s.names_dictionary)
        if tpath.exists():
            transcript = Transcript.load(tpath)
            self.ev.log("Using saved transcript.")
        else:
            models = models_dir(s.models_dir)
            if self._transcribe is transcribe and not model_ready(ENGLISH_MODEL, models):
                self.ev.warning("msg.model_download", {})
            transcript = self._transcribe(wav, info.duration, models, names=hotwords(names),
                                          on_progress=self._stage_cb("transcribe", "Listening to the video"),
                                          cancel_event=self.cancel)
            transcript.save(tpath)
        fixed = fix_transcript(transcript, self._fixer)          # ghalat spellings theek (har dafa, cache pe bhi)
        if fixed:
            self.ev.log(f"Name spelling: {fixed} words corrected.")
        if transcript.translated:
            self.ev.warning("msg.translated", {"language": transcript.language})
        self._finish_stage("transcribe")
        if self.req.prefetch_only:
            # (20 Nov) agli video ka main person scan bhi pehle se: wohi code, wohi cache file, is liye
            # asal run ko bilkul wohi nateeja milta hai, bas 10-20 minute pehle tayyar
            self._prefetch_people(info, work, p)
            return                       # agli video tayyar: cache mein download, audio, transcript, scan

        # ---- 4. plan -----------------------------------------------------
        self._check_cancel()
        self.ev.stage("plan")
        lo, hi = p.length_range(s)
        if self.req.min_len:
            lo = self.req.min_len
        if self.req.max_len:
            hi = max(self.req.max_len, lo + 1)
        count = self.req.clip_count or s.clip_count
        self._phase = 0
        if self.req.phase:
            # ---- phases: video ke har minute ke 100 clips = ek phase; phase 1 sab se behtareen ----
            per_phase = max(1, round(info.duration / 60 * s.clips_per_minute))
            made = self.db.count_from_source(self.req.campaign_id, shash)
            phase = self.req.phase if self.req.phase > 0 else made // per_phase + 1
            if phase > MAX_PHASES:
                raise PipelineError("msg.phases_done", f"{made} clips")
            if made < (phase - 1) * per_phase:
                self.ev.log(f"Phase {phase}: earlier phases are not complete ({made} clips made); "
                            f"the next best clips are made.")
            self._phase = phase
            count = per_phase
            self.ev.log(f"Phase {phase} of {MAX_PHASES}: {per_phase} clips "
                        f"({info.duration / 60:.1f} minute video x {s.clips_per_minute} per minute).")
        ratio = self.req.ratio or p.ratio or s.ratio
        self._min_len = lo
        self._max_len = hi
        banned = list(dict.fromkeys(s.general_banned_words + p.banned_words))
        # the campaign's main person is always protected: insults aimed at him are beeped
        vips = list(dict.fromkeys(DEFAULT_VIPS + s.vip_names + p.main_names()))
        fresh = (getattr(p, "fresh_since", "") or "").strip()
        if fresh:
            # (19 Nov, user) campaign ko naye andaaz se dobara: is tareekh se pehle bane clips ke moments
            # phir se use ho sakte hain (naya edit, naya title); is ke baad bane clips dobara nahi bante
            used = [(a, b) for a, b, _ in self.db.used_windows(shash, since=fresh)]
            self.ev.log(f"Fresh start since {fresh}: older clips of this video do not block moments.")
        else:
            used = [(a, b) for a, b, _ in self.db.used_windows(shash)]
        self._taken = list(used)                 # naye cuts ki aakhri jagah (ek jaise clip na banen)
        self._taken_lock = threading.Lock()
        energy = None
        try:                                    # voice energy for scoring (never blocks a run)
            from app.select.scoring import liveliness, speech_envelope
            from app.transcribe.asr import load_wav
            env = speech_envelope(load_wav(wav))
            energy = (lambda a, b: liveliness(env, 20, a, b)) if env is not None else None
            from app.select.scoring import quiet_spans
            self._quiet = quiet_spans(env) if env is not None else []      # awaaz wali khamoshi
        except Exception as exc:  # noqa: BLE001
            log.warning("Voice energy not used: %s", exc)
        window_filter = self._main_person_filter(info, work, p)
        if getattr(p, "stream_layout", "") and ratio == "9:16" and not info.is_vertical:
            # (20 Nov, GTA 6) sirf gameplay ke moments: cutscene (kahani ki film) wale nahi. Rockstar akele
            # cutscene wali videos hata deta hai, aur un mein NPC bolte hain, streamer nahi.
            from app.render.facecam import detect as detect_facecam
            from app.render.hud import gameplay_seconds, gameplay_share
            cam = detect_facecam(info, work / "facecam.json")
            play = gameplay_seconds(info, cam.box() if cam else None, work / "hud.json")
            if play:
                self.ev.log(f"Game HUD found: gameplay in {sum(play)} of {len(play)} seconds; cutscenes skipped.")
                base_filter = window_filter

                def window_filter(start, end, seg_words, _base=base_filter, _play=play):
                    return gameplay_share(_play, start, end) >= STREAM_MIN_GAMEPLAY and (
                        _base is None or _base(start, end, seg_words))
        self._listen = []
        self._listen_book = None
        if (getattr(p, "fill_screen", False) and getattr(p, "stack_layout", True)
                and getattr(self, "_person_timeline", None)):
            # upar neeche ke doosre hisse ke liye: poori video mein sunne wali audience (aawaz main speaker ki)
            from app.render.listeners import find_listening_shots
            self._listen = find_listening_shots(wav, self._person_timeline, transcript.words,
                                                work / "listeners.json")
            self.ev.log(f"Listening audience shots found: {len(self._listen)}")
            if self._listen:
                # (5 Nov) har sunne wale chehre ko poore batch mein barabar baanto, lagataar dobara nahi
                from app.render.layout import ListenerBook
                self._listen_book = ListenerBook(work / "listen_use.json")
        if getattr(p, "auto_main_speaker", False) and not p.main_names() and getattr(self, "_person_timeline", None):
            # main speaker ka naam video ke title se (sirf is run ke liye, campaign mein save nahi)
            from app.media.download import source_meta
            from app.edit.title_name import name_from_title
            title = str(source_meta(src_path).get("title") or src_path.stem.replace("_", " "))
            found = name_from_title(title)
            if found:
                self._fp_profile = p                   # preview ki pehchan campaign ki settings se, naam se nahi
                p = dataclasses.replace(p, main_person_name=found, names=list(dict.fromkeys([*p.names, found])))
                self.profile = p
                vips = list(dict.fromkeys([*vips, found]))
                self.ev.log(f"Main speaker's name from the video title: {found}")
        try:
            # asal video ka title (clip ka apna title na bane to is se, har clip thora alag)
            from app.media.download import source_meta
            self._video_title = str(source_meta(src_path).get("title") or src_path.stem.replace("_", " "))
        except Exception:  # noqa: BLE001
            self._video_title = ""
        if self._video_title:
            self.ev.warning("info.video_title", {"title": self._video_title[:140]})     # line mein naam dikhe
        guard, guard_judge = self._make_guard(p, src_path, lo)
        judge = None
        if s.better_moments:
            from app.select.ai_rank import make_judge
            judge = make_judge(s.gemini_api_key, s.gemini_model)
        # main person campaign: kuch extra (spare) clips plan karo; agar kisi moment ka clip
        # "main person kam bolta hai" pe fail ho, us moment ke baaki clips ki jagah spare bante hain
        spares = (count // 4 + 3) if window_filter is not None else (count // 10 + 3)   # fail ho to jagah lene wale
        self._target = count
        # (20 Nov) streamer zyada gaaliyan dete hain: beep kar ke moment rakho (warna aadhe achhe moments chhoot jate)
        frame_is_stream = bool(getattr(p, "stream_layout", "")) and ratio == "9:16" and not info.is_vertical
        plan = plan_clips(transcript, lo, hi, count + spares, versions_per_moment=p.versions_per_moment, energy=energy,
                          per_moment_cap=int(getattr(p, "max_per_moment", 0) or 0),
                          avoid_topics=p.banned_topics, better=s.better_moments, rerank=judge,
                          window_filter=window_filter, guard=guard, guard_judge=guard_judge,
                          block_size=s.block_size, used_windows=used,
                          profanity_level=p.effective_profanity(s), banned_words=banned,
                          vip_names=vips, max_beeps=(max(s.max_beeps_per_clip, STREAM_MAX_BEEPS) if frame_is_stream
                                                           else s.max_beeps_per_clip), dynamic_cuts=True,
                          smart_cuts=True, cold_open=self._cold_open_on(p), teaser_clean=self._teaser_clean(p),
                          teaser_speaker=self._teaser_speaker() if window_filter is not None else None,
                          silence_level=s.silence_level, quiet=getattr(self, "_quiet", None),
                          beep_mode=s.beep_mode, viral=self._viral_research(p, src_path),
                          keep_ads=p.own_ads, avoid_spans=self._topic_spans(p, transcript),
                          complete_point=bool(getattr(p, "complete_point", False)))
        summary.requested, summary.max_good = count, plan.max_good
        summary.moments, summary.dropped = plan.moments, plan.dropped
        if not plan.clips:
            raise PipelineError("msg.no_clips", json.dumps(plan.dropped))
        main = plan.clips[:count]
        if len(plan.clips) < count:
            self.ev.warning("msg.fewer_clips", {"possible": len(plan.clips), "requested": count})
        elif any(cp.remix for cp in main):
            unique = len({cp.window_key for cp in main})
            self.ev.warning("msg.remixed", {"unique": unique, "remixed": sum(1 for cp in main if cp.remix)})
        self._finish_stage("plan")

        # ---- 5. render ---------------------------------------------------
        root = campaign_root(Path(s.output_dir), p)
        summary.folder = str(root)
        need_gb = MIN_FREE_GB + len(plan.clips) * MB_PER_CLIP / 1024
        root.mkdir(parents=True, exist_ok=True)
        if free_space_gb(root) < need_gb:
            raise PipelineError("msg.disk_low", f"{free_space_gb(root):.1f} GB free, need {need_gb:.1f} GB")

        from app.captions.styles import ALL_PICKABLE, AUTO_BOXED, CHIP_STYLES
        locked = p.caption_style if p.caption_style in ALL_PICKABLE else ""
        # (online font pack hata diya: rotation sirf user ke pasand kiye 9 styles se, 24 Oct)
        # Edits already used per moment (earlier runs too), so a re-edit
        # never repeats a look that moment already had.
        taken: dict[str, set] = {}
        taken_pal: dict[str, set] = {}
        from app.select.planner import SIMILAR_SHARE, _same_share
        spans = {cp.window_key: (cp.window.start, cp.window.end) for cp in plan.clips}
        for a, b, style_json in self.db.made_edits(shash):
            try:
                d = json.loads(style_json) if style_json else {}
                known = {f.name for f in dataclasses.fields(EditChoice)}
                combo = EditChoice(**{k: v for k, v in d.items() if k in known}).combo()
            except (ValueError, TypeError, AttributeError):
                continue
            # pichla clip kisi plan window jaisa ho (trim ki wajah se thora farq) to us ka look bhi "liya hua"
            for key, span in spans.items():
                if key == window_key(a, b) or _same_share((a, b), span) >= SIMILAR_SHARE:
                    taken.setdefault(key, set()).add(combo)
                    if d.get("palette"):
                        taken_pal.setdefault(key, set()).add(d["palette"])
        edits = choose_edits(len(plan.clips), seed=f"{shash}:{self.req.campaign_id}",
                             default_style=s.default_caption_style, rotate_styles=s.rotate_caption_styles,
                             locked_style=locked,
                             looks_enabled=s.color_looks_enabled and not getattr(p, "light_edit", False),
                             groups=[cp.window_key for cp in plan.clips], taken=taken, taken_palettes=taken_pal,
                             frames=("",),     # title card ka faisla har clip pe alag (runner, _card_for)
                             only_styles=tuple(CHIP_STYLES) if getattr(p, "word_chip", False) else (),
                             extra_styles=tuple(CHIP_STYLES) if getattr(p, "mix_styles", False) else (),
                             auto_boxed=(tuple(AUTO_BOXED) if not locked and not getattr(p, "word_chip", False)
                                         else ()))
        # is video ke pehle bane clips ke titles (naya title un se alag ho)
        self._titles_used = set()
        self._titles_lock = threading.Lock()
        # (31 Oct) aur is campaign ki baaqi videos ke titles bhi: ek hi khabar ki kai videos (Kron1, Kron3)
        # se bhi har post ka title alag (TikTok par ek jaise title nahi)
        styles = [st for _a, _b, st in self.db.made_edits(shash)]
        try:
            styles += [c.style for c in self.db.clips_for_campaign(self.req.campaign_id, state="all")]
        except Exception as exc:  # noqa: BLE001
            log.warning("Campaign titles not read: %s", exc)
        for style_json in styles:
            try:
                old = json.loads(style_json or "{}").get("title_plain", "")
            except ValueError:
                old = ""
            if old:
                self._titles_used.add(old.lower())
        frame = FramePlan(mode=choose_mode(info, ratio))
        self._stream_cam = None
        if getattr(p, "stream_layout", "") and ratio == "9:16" and not info.is_vertical:
            # (20 Nov, GTA 6) streamer ki video: camera ka dabba dhoondo; chehra gol / upar, game alag
            from app.render.facecam import detect as detect_facecam
            cam = detect_facecam(info, work / "facecam.json")
            if cam is not None:
                self._stream_cam = cam
                frame = FramePlan(mode="stream", cam=cam.box(), face=cam.face(),
                                  layout="stack" if p.stream_layout == "stack" else "round")
                self.ev.log(f"Streamer camera found ({cam.w:.0%} x {cam.h:.0%} of the picture): {p.stream_layout} layout.")
            else:
                self.ev.log("No streamer camera found: normal framing.")
        if getattr(p, "whole_picture", False) and ratio == "9:16" and not info.is_vertical:
            frame = FramePlan(mode="fit_blur")          # campaign: poori tasveer, kuch nahi katta, upar neeche blur
        self._vcap_y = None
        if ratio == "9:16" and info.is_vertical and getattr(p, "fit_bars", "full") == "half":
            # (31 Oct) campaign ki khari ad (dabbe mein video): andar wali video thori bari, captions us ke neeche
            band = self._inner_video(info, work)
            if band is not None:
                from app.render.framing import vertical_zoom
                z, top, bottom = vertical_zoom(band)
                frame = dataclasses.replace(frame, vzoom=z, vtop=top)
                self._vcap_y = round(bottom + 0.045, 3)
                self.ev.log(f"Ad video inside the frame found ({band[0]:.2f}-{band[1]:.2f}): zoomed {z:.2f}x.")
        # Channel logo in the source (only looked for when the campaign wants it hidden).
        self._logo_box = None
        if p.source_logo in ("blur", "replace"):
            from app.render.logo import detect as detect_logo
            self._logo_box = detect_logo(info, work / "logo.json")
            if self._logo_box is None:
                self.ev.log("No channel logo found in this video; nothing to hide.")
        tmp = temp_dir() / f"render_{shash[:10]}"
        tmp.mkdir(parents=True, exist_ok=True)
        self.ev.stage("render")

        try:
            self._render_all(plan, edits, transcript, info, shash, src_path, ratio, frame, root, tmp, summary)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        # Run complete: the big master copy is no longer needed (the
        # transcript and audio stay, so a re-run is still quick).
        (work / "master.mp4").unlink(missing_ok=True)
        if downloading and s.auto_delete_source:
            # Only links we downloaded are deleted, never the user's own files.
            src_path.unlink(missing_ok=True)
        self.ev.progress(1.0, "Done")

    def _render_all(self, plan, edits, transcript, info, shash, src_path, ratio, frame, root, tmp,
                    summary: RunSummary) -> None:
        """
        Clips are rendered `workers` at a time (more on laptops with many
        CPU cores). Every clip still uses exactly the same quality
        settings; this only uses idle cores, so the run finishes sooner.
        """
        from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

        # ---- GPU: sirf tab jab laptop pe ho (GPU Fast encoding user ka option) ----
        from app.core.gpu import cuda_decode_available, nvenc_available
        self._gpu_encode = bool(self.s.gpu_encode) and nvenc_available()
        self._gpu_decode = cuda_decode_available()
        if self.s.gpu_encode and not self._gpu_encode:
            self.ev.log("GPU Fast encoding is on, but no GPU was found; using normal encoding.")
        render_cb_base = self._done_weight
        render_w = self._weights.get("render", 0.0)
        total = min(len(plan.clips), getattr(self, "_target", len(plan.clips)))   # spares ginti mein nahi
        self._bad_moments: set[str] = set()
        workers, threads = render_workers(self.s.render_workers)
        self._encoder_threads = threads
        lock = threading.Lock()
        fractions: dict[int, float] = {}
        done = {"n": 0}

        def clip_cb(frac: float, n: int) -> None:
            with lock:
                fractions[n] = max(fractions.get(n, 0.0), min(1.0, frac))
                value = min(1.0, sum(fractions.values()) / total)
                current = min(done["n"] - len(summary.failed) + 1, total)
            self.ev.progress(render_cb_base + render_w * value, f"Clip {current} of {total}")

        def one(n: int, cp: ClipPlan, edit: EditChoice):
            self._check_cancel()
            try:
                out = self._make_clip(cp, edit, transcript, info, shash, src_path, ratio, frame, root, tmp,
                                      lambda f, n=n: clip_cb(f, n), slot=n)
                if out is None:
                    self._release_role(cp)              # clip nahi bana: us ka variant (black / white) agle ko mile
                return out
            except (Cancelled, PipelineError):
                self._release_role(cp)
                raise
            except Exception as exc:  # noqa: BLE001 - ek clip ka masla (file lock, ghalti) poora run na roke
                self._release_role(cp)
                log.exception("Clip %s %s failed: %s", cp.moment_id, cp.tag, exc)
                self.ev.log(f"Clip {cp.tag} could not be made ({type(exc).__name__}); a spare clip takes its place.")
                return None

        jobs = list(enumerate(zip(plan.clips, edits)))
        pending: dict = {}
        error: BaseException | None = None
        # ---- preview pack: pehli link / settings badli -> pehle 10 best clips, phir OK / Cancel ----
        fingerprint = settings_fingerprint(getattr(self, "_fp_profile", None) or self.profile, self.s)
        if self.req.preview is None:
            want_preview = self.s.preview_pack and preview_needed(self.req.campaign_id, fingerprint)
        else:                                   # queue item: user ne is video ke liye khud chuna
            want_preview = bool(self.req.preview)
        gate_open = not (want_preview and self.ev.preview is not None and self.preview_gate is not None
                         and total > PREVIEW_N)
        preview_infos: list[dict] = []
        submitted = 0
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="render") as pool:
            while (jobs or pending) and error is None:
                if not gate_open and submitted >= PREVIEW_N and not pending:
                    try:
                        self._ask_preview(preview_infos)
                        remember_preview(self.req.campaign_id, fingerprint)
                    except BaseException as exc:   # noqa: BLE001 - Cancelled
                        error = exc
                        break
                    gate_open = True
                while (jobs and len(pending) < workers and not self.cancel.is_set()
                       and done["n"] - len(summary.failed) + len(pending) < total
                       and (gate_open or submitted < PREVIEW_N)):
                    n, (cp, edit) = jobs.pop(0)
                    if cp.moment_id in self._bad_moments:
                        continue                 # is moment mein main person nahi bolta: spare clip le lo
                    if n and n % 10 == 0 and free_space_gb(root) < MIN_FREE_GB:
                        error = PipelineError("msg.disk_low", f"{free_space_gb(root):.1f} GB free")
                        break
                    pending[pool.submit(one, n, cp, edit)] = (n, cp)
                    submitted += 1
                if not pending:
                    break
                finished, _ = wait(list(pending), return_when=FIRST_COMPLETED)
                for fut in finished:
                    n, cp = pending.pop(fut)
                    try:
                        result = fut.result()
                    except BaseException as exc:   # noqa: BLE001 - Cancelled / PipelineError: stop the run
                        error = error or exc
                        continue
                    with lock:
                        done["n"] += 1
                        if result is None:
                            fractions.pop(n, None)        # fail: is ki jagah spare clip aata hai
                        else:
                            fractions[n] = 1.0
                        count = done["n"] - len(summary.failed) - (1 if result is None else 0)
                    if result is None:
                        summary.failed.append(cp.moment_id)
                    else:
                        summary.made += 1
                        summary.counts[result["rating"]] += 1
                        summary.repaired += int(result["repaired"])
                    self.ev.clip_done(count, total, result or {})
                    if result is not None and not gate_open:
                        preview_infos.append(result)
            if error is not None:
                self.cancel.set() if isinstance(error, Cancelled) else None
                for fut in pending:          # let running clips stop / finish cleanly
                    try:
                        fut.result()
                    except BaseException:    # noqa: BLE001
                        pass
        if self.cancel.is_set() and error is None:
            raise Cancelled()
        if error is not None:
            raise error

    # (17 Nov, user) Classic campaign: har moment ke 4 variant = Classic kaali patti, Classic safed patti,
    # 2 split. Jo clip pehle shuru ho woh pehla khaali variant leta hai; na bane to variant wapas.
    CLASSIC_ROLES = ("black", "split", "split2")      # (19 Nov) safed Classic band: sirf kaala

    def _claim_role(self, cp) -> str:
        split = bool(getattr(getattr(self, "profile", None), "classic_split", True))
        roles = self.CLASSIC_ROLES if split else ("black",)
        with self.__dict__.setdefault("_role_lock", threading.Lock()):
            taken = self.__dict__.setdefault("_moment_roles", {}).setdefault(cp.moment_id, {})
            if cp.tag in taken:
                return taken[cp.tag]
            # (19 Nov) bina split wali campaign: kaala + safed ke baad baqi versions apne asal andaaz mein ("")
            role = next((r for r in roles if r not in taken.values()), "split" if split else "plain")
            taken[cp.tag] = role
            return role

    def _release_role(self, cp) -> None:
        with self.__dict__.setdefault("_role_lock", threading.Lock()):
            self.__dict__.setdefault("_moment_roles", {}).get(cp.moment_id, {}).pop(cp.tag, None)

    def _too_similar(self, start: float, end: float) -> bool:
        """Naya cut kisi pehle bane (ya isi run ke) naye cut jaisa hai? Nahi to us ki jagah rakh lo."""
        from app.select.planner import SIMILAR_SHARE, _same_share
        lock = getattr(self, "_taken_lock", None)
        if lock is None:
            return False
        with lock:
            if any(_same_share((start, end), t) >= SIMILAR_SHARE for t in self._taken):
                return True
            self._taken.append((start, end))
            return False

    # --- preview pack ---------------------------------------------------
    # Kaam: UI ko pehle 10 clips dikhao aur jawab ka intezaar karo.
    # OK = aage, Cancel = run band, 20 minute tak jawab nahi = aage.
    def _ask_preview(self, infos: list[dict]) -> None:
        gate = self.preview_gate
        gate.event.clear()
        gate.answer = ""
        wait_s = preview_wait(self.profile)
        mins = int(round(wait_s / 60))
        self.ev.log(f"Preview: the {len(infos)} best clips are ready. Waiting for OK (continues by itself in {mins} minutes).")
        self.ev.preview(sorted(infos, key=lambda x: -x.get("score", 0)))
        waited = 0.0
        while not gate.event.is_set() and waited < wait_s:
            if self.cancel.is_set():
                raise Cancelled()
            gate.event.wait(0.5)
            waited += 0.5
        if gate.answer == "cancel":
            self.ev.log("Preview: cancelled by the user.")
            self.cancel.set()
            raise Cancelled()
        self.ev.log("Preview: OK, making the rest." if gate.answer == "ok" else
                    f"Preview: no answer in {mins} minutes, making the rest with the same settings.")

    # --- main person ---------------------------------------------------
    # Kaam: campaign ke main people (ek ya kai) ko poori video mein dhoondo
    # (1 frame har second, cache), phir sirf wahi clips jahan wo screen pe
    # aur bol rahe hon. "any" = koi bhi ek kaafi, "all" = sab nazar aayein.
    # --- viral se seekhna: research (YouTube public shorts) + matching model --------
    def _viral_research(self, p, src_path: Path):
        """Title engine tayar karo aur moments ke liye viral scorer ka factory do (None = kuch nahi)."""
        from app.research.embed import embedder
        from app.research.match import TitleEngine, ViralScorer
        from app.research.viral import research
        name = (p.main_person_name or "").strip()
        names = [n for n in p.main_names() if n]
        subject = list(dict.fromkeys([name, *names] + ([name.split()[-1]] if len(name.split()) > 1 else [])))
        subject = [x for x in subject if x]
        # main person ho to us ki shorts, warna video ke topic (asal title ke pehle lafz)
        query = name or " ".join(re.sub(r"[_\[\]()]+", " ", src_path.stem).split()[:6])
        if (getattr(p, "super_link", "") or "").strip():
            # Super wali campaign: titles campaign ke topic se bante hain; har video pe 120 shorts parhna
            # (10+ minute) bekaar. Sirf built-in library.
            self.ev.log("Research skipped: this campaign writes its own titles and Super.")
            self._title_engine = None
            return None
        try:
            items = research(query, subject, online=bool(getattr(self.s, "research_online", True)),
                             on_log=self.ev.log, cancel=self.cancel)
        except Exception as exc:  # noqa: BLE001 - research kabhi run na roke
            log.warning("Research failed: %s", exc)
            items = []
        emb = embedder()
        try:
            self._title_engine = TitleEngine(items, name, emb) if items else None
        except Exception as exc:  # noqa: BLE001
            log.warning("Title engine not used: %s", exc)
            self._title_engine = None
        own = sum(1 for it in items if not it.builtin)
        if own:
            self.ev.log(f"Learning from {own} viral shorts of '{query}' (+ built-in library).")
        if emb is None or not own:
            return None
        return lambda sentences: ViralScorer(items, sentences, emb)

    # --- (14 Nov) main person ka naam hai to photos zaroori: warna run shuru hi na ho ---
    # Kaam: photos ke baghair tool chehra nahi pehchanta aur 60% rule laagu nahi hota,
    # is liye har bolne wale ka clip ban jata. Aisa run download se pehle hi rok do.
    @staticmethod
    def _require_person_photos(p) -> None:
        if getattr(p, "auto_main_speaker", False):
            return
        for name, photos in p.people_for_matching():
            if name and not photos:
                raise PipelineError("msg.main_person_no_photos", name)

    # (17 Nov, user) auto main speaker mein "jo zyada dikhe" kabhi doosra shakhs nikalta (OSU: Candace).
    # Campaign ka pasandeeda shakhs (Political: Charlie Kirk) video mein ho to wohi main person, warna purana tareeqa.
    PREFER_MIN_SHARE = 0.10        # video ke kam az kam itne seconds mein screen par ho

    def _preferred_person(self, p, found, info: SourceInfo, work: Path):
        import json

        import numpy as np

        from app.core.paths import resource
        name = str(getattr(p, "preferred_person", "") or "").strip()
        if not name:
            # campaign ki setting khaali: assets/people/campaigns.json mein campaign ka pasandeeda shakhs
            try:
                table = json.loads(Path(resource("assets", "people", "campaigns.json")).read_text(encoding="utf-8"))
                name = str(table.get(getattr(p, "name", ""), "") or "").strip()
            except (OSError, ValueError, AttributeError):
                name = ""
        if not name:
            return None
        from app.render.person import MATCH, FeatureMatcher, scan
        try:
            data = json.loads(Path(resource("assets", "people", f"{name}.json")).read_text(encoding="utf-8"))
            refs = [np.asarray(r, np.float32) for r in data.get("refs", [])]
            refs = [r / (np.linalg.norm(r) + 1e-9) for r in refs]
            pm = FeatureMatcher(refs) if refs else None
        except (OSError, ValueError, TypeError, RuntimeError) as exc:
            log.warning("Preferred person %s not loaded: %s", name, exc)
            return None
        if pm is None:
            return None
        if found is not None and getattr(found, "refs", None):
            got = np.mean([max(float(np.dot(f / (np.linalg.norm(f) + 1e-9), r)) for r in refs) for f in found.refs])
            if got >= MATCH:
                self.ev.log(f"Main speaker is {name}.")
                return None                       # wohi hai: kuch nahi badalna
        self.ev.log(f"Checking whether {name} is in this video...")
        tl = scan(info.path, info.duration, info.display_size, pm, work / "person.json", self.cancel)
        share = sum(1 for _, v in tl if v > 0) / len(tl) if tl else 0.0
        if share >= self.PREFER_MIN_SHARE:
            self.ev.log(f"{name} is on screen in {share:.0%} of the video: {name} is the main person.")
            self._pref_name = name
            return pm
        self.ev.log(f"{name} is not in this video ({share:.0%}); the person shown most is the main person.")
        return None

    def _prefetch_people(self, info: SourceInfo, work: Path, p) -> None:
        """Pehle se tayyari: main person ki scan cache mein. Koi bhi masla ho to chhor do (asal run khud karega)."""
        self._no_photo_fetch = True          # campaign ki settings yahan se kabhi save na hon
        try:
            self._main_person_filter(info, work, p)
        except Cancelled:
            raise
        except Exception as exc:  # noqa: BLE001 - sirf behtari
            log.info("Prefetch: main person scan left to the real run: %s", str(exc)[:200])

    def _main_person_filter(self, info: SourceInfo, work: Path, p):
        self._matcher = None
        self._person_timeline = None
        self._ensure_auto_photos(p)
        people = [(n, ph) for n, ph in p.people_for_matching() if ph]
        auto = not people and bool(getattr(p, "auto_main_speaker", False))
        if not people and not auto:
            return None
        from app.render.person import (GroupMatcher, PersonMatcher, available, find_main_speaker, scan,
                                       screen_share, share_at)
        names = ", ".join(n or "main person" for n, _ in people) or "the main speaker"
        if not available():
            if not auto:                            # (14 Nov) naam wale campaign: bina check ke clips nahi
                raise PipelineError("msg.main_person_model", names)
            self.ev.log(f"Main person: face recognition model missing, {names} not checked.")
            return None
        if auto:
            # naam / photo nahi: video ka main speaker (sab se zyada bara chehra) khud dhoondo
            self.ev.log("Finding the main speaker in the video (the person shown most)...")
            found = find_main_speaker(info.path, info.duration, info.display_size, work / "main_speaker.json",
                                      self.cancel)
            pref = self._preferred_person(p, found, info, work)
            if pref is not None:
                found = pref
            if found is None:
                self.ev.log("Main speaker: no single clear main person in this video; clips are made without it.")
                return None
            people = [(p.main_names()[0] if p.main_names() else
                       (getattr(self, "_pref_name", "") if pref is not None else ""), found)]
        matchers, timelines = [], []
        for k, (name, photos) in enumerate(people):
            name = name or ("the main speaker" if auto else "the main person")
            m = photos if auto else PersonMatcher(photos)
            for c in m.checks:
                if not c.ok:
                    self.ev.log(f"Main person photo not used ({Path(c.path).name}): {c.message}")
            if not m.usable:
                if not auto:                        # (14 Nov) photos bekaar: run roko, galat clips nahi
                    raise PipelineError("msg.main_person_photos_bad", name)
                self.ev.warning("msg.main_person_photos", {"name": name})
                continue
            self.ev.log(f"Looking for {name} in the video ({len(m.refs)} {'faces' if auto else 'photos'})...")
            cache = work / ("person.json" if k == 0 else f"person_{k}.json")
            tl = scan(info.path, info.duration, info.display_size, m, cache, self.cancel)
            self.ev.log(f"{name} is on screen in {sum(1 for _, v in tl if v > 0)} of {len(tl)} seconds.")
            seen = sum(1 for _, v in tl if v > 0) / max(1, len(tl))
            if tl and seen < PERSON_RARE_SHARE and not auto:
                # (15 Nov) photo shayad purani / alag hai: foran batao, poori raat zaya na ho
                self.ev.warning("msg.person_rare", {"name": name, "pct": round(seen * 100)})
            matchers.append(m)
            timelines.append(tl)
        if not matchers:
            return None
        # sab logon ki timeline mila kar: har second jo sab se zyada nazar aaye
        timeline = [(timelines[0][i][0], max(t[i][1] for t in timelines if i < len(t)))
                    for i in range(len(timelines[0]))]
        self._matcher = matchers[0] if len(matchers) == 1 else GroupMatcher(matchers)
        self._person_timeline = timeline
        every = p.people_mode == "all" and len(timelines) > 1
        min_screen, min_talk = p.main_person_min_screen / 100, p.main_person_min_speaking / 100

        def keep(start: float, end: float, seg_words) -> bool:
            if screen_share(timeline, start, end) < min_screen or not seg_words:
                return False
            if every and any(screen_share(t, start, end) < min_screen / 2 for t in timelines):
                return False                       # "all": har shakhs kuch na kuch nazar aaye
            # hook unhi ka: shuru ke seconds mein screen pe hon
            if screen_share(timeline, start, start + HOOK_PERSON_SECONDS) < HOOK_PERSON_SHARE:
                return False
            on = sum(1 for w in seg_words if share_at(timeline, (w.start + w.end) / 2) > 0)
            return on / len(seg_words) >= min_talk
        return keep

    def _his_at(self):
        """Poori video ki scan se: is second main person sab se bara chehra hai? (1 / 0.5 / 0) ya None."""
        tl = getattr(self, "_person_timeline", None)
        if not tl:
            return None
        from app.render.person import share_at
        return lambda t: share_at(tl, t)

    # --- cold open line main person ki ho (wohi screen pe), opponent ki nahi --
    def _teaser_speaker(self):
        timeline = getattr(self, "_person_timeline", None)
        if not timeline:
            return None
        from app.render.person import screen_share
        return lambda a, b: screen_share(timeline, a, b) >= HOOK_PERSON_SHARE

    # --- naam patti ka text (Settings: name_card) --------------------------
    def _name_card(self, src_path: Path) -> str:
        if not self.s.name_card:
            return ""
        names = self.profile.main_names()
        if not names:
            return ""
        from app.media.download import source_meta
        date = str(source_meta(src_path).get("upload_date") or "")
        months = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()
        if len(date) == 8 and date.isdigit() and 1 <= int(date[4:6]) <= 12:
            return f"{names[0]}  |  {months[int(date[4:6]) - 1]} {date[:4]}"
        return names[0]

    # --- cold open line saaf hai? (koi gaali, khatarnaak lafz, main person pe hamla nahi)
    @staticmethod
    def _teaser_clean(p):
        from app.filters.guard import hook_is_clean
        from app.filters.profanity import analyze
        from app.transcribe.models import Word
        names = p.main_names()

        def ok(text: str) -> bool:
            if not hook_is_clean(text, names):
                return False
            ws = [Word(t, 0.0, 0.1) for t in text.split()]
            return not analyze(ws, "strict").beep_indexes
        return ok

    # --- mazeed photos khud (YouTube), har shakhs ke liye ek hi dafa ------
    # Kaam: user ki photos se milte chehre YouTube ki videos se; campaign mein
    # save hote hain taake agli dafa dobara na dhoondne parein.
    def _ensure_auto_photos(self, p) -> None:
        import os
        if (getattr(self, "_no_photo_fetch", False)
                or not getattr(self.s, "research_online", True) or not getattr(self.s, "auto_person_photos", True)
                or os.environ.get("AIMERS_NO_BACKGROUND")):          # tests: koi network nahi
            return
        from app.core.paths import sub_dir
        from app.render.person import available
        from app.render.photo_finder import find_online
        if not available():
            return
        changed = False
        targets = []
        if p.main_person_name.strip() and p.main_person_photos and not p.main_person_auto_photos:
            targets.append((p.main_person_name, p.main_person_photos, None))
        for item in p.more_people or []:
            if isinstance(item, dict) and item.get("name") and item.get("photos") and not item.get("auto_photos"):
                targets.append((item["name"], item["photos"], item))
        for name, photos, item in targets:
            self._check_cancel()
            key = (name.strip().lower(), tuple(photos))
            if key in _PHOTO_TRIED:                 # is session mein ek dafa koshish ho chuki
                continue
            _PHOTO_TRIED.add(key)
            self.ev.log(f"Looking online for more photos of {name} (once)...")
            import hashlib
            folder = sub_dir("people") / ("auto_" + hashlib.sha1(name.lower().encode()).hexdigest()[:10])
            try:
                got = [str(x) for x in find_online(name, photos, folder, max_videos=2, cancel_event=self.cancel,
                                                   on_log=self.ev.log)]
            except Exception as exc:  # noqa: BLE001 - photos bonus hain, run kabhi na ruke
                log.warning("online photos failed: %s", exc)
                got = []
            if not got:
                self.ev.log(f"No extra photos found for {name}; using your photos only.")
                continue
            self.ev.log(f"{len(got)} extra photos of {name} added (your own photos stay the main reference).")
            if item is None:
                p.main_person_auto_photos = got
            else:
                item["auto_photos"] = got
            changed = True
        if changed:
            self.db.update_campaign(self.req.campaign_id, p)

    # --- protection guard ------------------------------------------------
    # Kaam: main people ke khilaaf baatein (filters/guard.py). Campaign
    # setting se on/off. Naam hon to chalta hai; photos hon to "kaun bol
    # raha hai" aur "clip un pe khatam" bhi check hota hai.
    def _make_guard(self, p, src_path: Path, lo: float):
        names = p.main_names()
        tl = getattr(self, "_person_timeline", None)
        auto = bool(getattr(p, "auto_main_speaker", False)) and bool(tl)
        self._guard_auto = auto and p.protect_main_person
        if not p.protect_main_person or not (names or auto):
            return None, None
        from app.filters.guard import Guard, hostile_title
        from app.render.person import share_at
        his_at = (lambda t: share_at(tl, t)) if tl else None
        strict = hostile_title(src_path.stem.replace("_", " "), names)
        if strict:
            self.ev.log("Source title is negative about the main person: protection is stricter for this video.")
        judge = None
        if self.s.gemini_api_key:
            from app.select.ai_rank import make_guard_judge
            judge = make_guard_judge(names, self.s.gemini_api_key, self.s.gemini_model)
        return Guard(names, his_at=his_at, strict=strict, min_len=lo, auto=auto), judge   # naam ho tab bhi he / him

    # --- one clip ------------------------------------------------------
    def _make_clip(self, cp: ClipPlan, edit: EditChoice, transcript: Transcript, info: SourceInfo,
                   shash: str, src_path: Path, ratio: str, frame: FramePlan, root: Path, tmp: Path,
                   progress: Callable[[float], None], slot: int = 0) -> dict | None:
        s, p, win = self.s, self.profile, cp.window
        words = transcript.words[win.w_first: win.w_last + 1]
        beep_rel = {i - win.w_first for i in win.beep_words}
        guard_cut = {i - win.w_first for i in getattr(win, "cut_words", [])}   # protection guard: kaate gaye jumle
        beep_rel -= guard_cut
        mode = s.beep_mode
        if getattr(p, "strict_edits", False):
            # (15 Nov) campaign: koi edit baat ka matlab na badle. Beech se jumla kaatna mana: aisa lamha nahi
            # banta, aur gaali sirf beep hoti hai (kaati nahi jati).
            if guard_cut:
                self.ev.log(f"{cp.tag}: protection would cut words inside the clip; skipped (no meaning changing edits).")
                return None
            mode = "beep"
        # Silence removal must never push a clip below the minimum length
        # the user set (videos with long quiet parts). Step down to a
        # lighter level, and to none if needed.
        levels = ["strong", "medium", "light", "off"]
        user = s.silence_level if s.silence_level in levels else "light"
        wanted = edit.pace or user                      # re-edit: apni pace
        smart = getattr(win, "pace", "")
        if smart in levels and user != "off" and levels.index(smart) < levels.index(wanted):
            wanted = smart                              # smart cut: tez, magar "off" ki izzat aur "strong" se kam nahi
        start_at = levels.index(wanted) if wanted in levels else 3
        floor = float(getattr(self, "_min_len", 0))      # campaign ki minimum length kabhi kam nahi
        ceil = float(getattr(self, "_max_len", 1e9)) + 0.3  # aur maximum se zyada bhi nahi
        tried: list[tuple[str, list]] = []
        segments = None
        lead_rel = {i - win.w_first for i in getattr(win, "lead_cut", [])}
        for level in levels[start_at:]:
            # pehle saare kat (shuru ki tamheed bhi); chhota pade to tamheed wapas, khamoshi phir bhi kat ti hai
            for cuts in ((beep_rel if mode == "cut" else set()) | guard_cut,
                         ((beep_rel if mode == "cut" else set()) | guard_cut) - lead_rel):
                segs = build_segments(words, win.start, win.end, level, cut_word_indexes=cuts or None,
                                      quiet=getattr(self, "_quiet", None))
                tried.append((level, segs))
                if floor <= total_duration(segs) <= ceil:
                    segments = segs
                    break
                if not lead_rel:
                    break
            if segments is not None:
                break
            log.info("%s v%d: silence level %s gives %.1fs (campaign %.0f-%.0fs)",
                     cp.moment_id, cp.version, level, total_duration(segs), floor, ceil - 0.3)
        if segments is None:
            # koi level poora nahi baitha: max se kam wala sab se lamba (khamoshi phir bhi kat ti hai)
            inside = [sg for _, sg in tried if total_duration(sg) <= ceil]
            segments = max(inside, key=total_duration) if inside else min((sg for _, sg in tried), key=total_duration)
        # Cold open: sab se pakadne wali line shuru mein ek dafa (Settings: cold_open)
        teaser_text = ""
        teaser = getattr(win, "teaser", ())
        if teaser and self._cold_open_on(p):
            a, b = teaser[0] - win.w_first, teaser[1] - win.w_first
            nxt = words[b + 1].start if b + 1 < len(words) else win.end
            seg = Segment(max(win.start, words[a].start - 0.06), min(nxt, words[b].end + 0.15))
            if total_duration(segments) + seg.duration <= getattr(self, "_max_len", 1e9) + 0.3:
                segments = [seg] + segments
                teaser_text = " ".join(w.text for w in words[a:b + 1])
        mapped = remap_words(words, segments)
        clip_words = [w for _, w in mapped]
        num_check = self._check_numbers(info, win, clip_words, cp)      # captions ke numbers screen se milao
        masked = {k for k, (orig, _) in enumerate(mapped) if orig in beep_rel}
        censor = []
        if mode != "cut":
            for k in sorted(masked):
                # speech model ke waqt 0.1 s tak hil sakte hain: beep thora chaura, magar saath wale lafz tak nahi
                lo = clip_words[k - 1].end if k > 0 else 0.0
                hi = clip_words[k + 1].start if k + 1 < len(clip_words) else clip_words[k].end + 0.06
                a, b = clip_words[k].start, clip_words[k].end
                censor.append((min(a, max(lo, a - 0.06)), max(b, min(hi, b + 0.06))))
        duration = total_duration(segments)
        if floor and duration < floor - 0.3:
            # campaign ki minimum lambai se chhota clip kaam ka nahi: spare clip jagah lega
            self.ev.log(f"{cp.tag}: {duration:.1f}s is shorter than the campaign minimum; a spare clip is used.")
            return None
        if not cp.remix and self._too_similar(win.start, win.end):
            # aakhri cut kisi pehle bane clip jaisa nikla (pichla phase ya isi run mein): spare clip jagah lega
            self.ev.log(f"{cp.tag}: too close to a clip already made; a spare clip is used.")
            return None

        link = (getattr(p, "super_link", "") or "").strip()
        if link:
            from app.edit.impact import related
            said = " ".join(w.text for k, w in enumerate(clip_words) if k not in masked)
            if not related(said, link):
                # Super wali campaign: clip mein A / B ka zikr hi nahi (jaise doosre mulk ki video): kabhi nahi
                self.ev.log(f"{cp.tag}: no mention of {link.replace('|', 'or')}; skipped (campaign needs that link).")
                return None

        rating = win.score.rating
        out_tmp = tmp / f"clip_{slot:05d}_{cp.moment_id}_{cp.version}.mp4"
        captions = p.captions_enabled and s.captions_enabled

        # Who is where, shot by shot (stack top/bottom, follow the face).
        # Shared by all versions of the same moment.
        key = (round(win.start, 2), round(win.end, 2), bool(s.reaction_shots))
        cache = self.__dict__.setdefault("_layouts", {})
        # har window ka apna taala: alag windows saath saath naapi ja sakti hain
        with self.__dict__.setdefault("_layout_lock", threading.Lock()):
            win_lock = self.__dict__.setdefault("_layout_locks", {}).setdefault(key, threading.Lock())
        with win_lock:
            if key not in cache and frame.mode == "crop":
                spoken = [(w.start, w.end) for w in words]
                stats: dict = {}
                cache[key] = analyse_layout(info, win.start, win.end, ratio, self.cancel, words=spoken,
                                            reactions=s.reaction_shots, matcher=getattr(self, "_matcher", None),
                                            stats=stats, quiet=list(getattr(win, "attacks", [])),
                                            fill=bool(getattr(p, "fill_screen", False)),
                                            his_at=self._his_at(), listen=getattr(self, "_listen", None),
                                            stack=bool(getattr(p, "stack_layout", True)),
                                            book=getattr(self, "_listen_book", None),
                                            fill_zoom_level=float(getattr(p, "fit_zoom", 0) or 0),
                                            no_split=bool(getattr(p, "fill_screen", False)
                                                          and not getattr(p, "stack_layout", True)))
                self.__dict__.setdefault("_person_stats", {})[key] = stats
        pieces = cache.get(key) or None
        person = self.__dict__.get("_person_stats", {}).get(key) or {}
        if person.get("mid_subs", 0.0) >= SUBS_COVER_SHARE:
            # (14 Nov) source ke apne captions beech mein (hamare captions ki jagah): do caption ek doosre
            # pe charhte. Ye clip nahi banta, spare clip jagah lega.
            self.ev.log(f"{cp.tag}: the video shows its own captions where ours go; skipped.")
            return None
        if pieces and edit.swap:                       # re-edit: right side on top (never moves the main person down)
            pieces = [pc if getattr(pc, "locked", False) else replace(pc, swap=True) for pc in pieces]
        if pieces and any(pc.mode == "qa" for pc in pieces):
            pieces = qa_variant(pieces, f"{shash}:{cp.tag}:{edit.caption_style}")
            book = getattr(self, "_listen_book", None)
            if book is not None:
                pieces = book.assign(pieces)        # is clip ke apne sunne wale (barabar, lagataar nahi)
        caption_y = 0.5 if pieces and stacked_share(pieces) >= 0.5 else None   # captions on the divider
        # (17 Nov, Ami) bahut qareeb ka shot: crop mein chehra screen se bara, zyada der tak = ye clip na bane
        mfw = float(getattr(p, "max_face_width", 0) or 0)
        if mfw > 0 and pieces and ratio == "9:16" and not info.is_vertical:
            sw_, sh_ = info.display_size
            crop_frac = (sh_ * 9 / 16) / max(1, sw_)
            total = sum(q.end - q.start for q in pieces) or 1.0
            tight = sum(q.end - q.start for q in pieces
                        if q.mode == "crop" and q.face_w and q.face_w / crop_frac > mfw)
            if tight / total > TIGHT_SHARE:
                self.ev.log(f"{cp.tag}: face too close for a full screen crop in {tight / total:.0%} of the clip; skipped.")
                return None
        # (17 Nov) Classic: har moment ka pehla version (aur phir har doosra) square video + upar title,
        # sirf jab main person kaafi der screen par ho; warna wohi purana (split) andaaz
        classic_bg, classic_pieces, classic_person = "", None, {}
        role = self._claim_role(cp) if getattr(p, "classic_style", False) else ""
        # (18 Nov, user) split sirf tab jab clip ka kam az kam SPLIT_MIN hissa sach mein do alag log dikhaye
        # (bodyguard / saath khara / audience / sawal karne wala; ruki tasveer ya wohi shakhs dobara nahi).
        # Na ho to: split variant nahi banta (us moment ke Classic kaala / safed bante hain), aur Classic
        # wala variant split ke bajaye Classic hi banta hai.
        from app.render.layout import two_people_share
        split_ok = bool(pieces) and two_people_share(pieces) >= SPLIT_MIN
        if role in ("split", "split2") and not split_ok and frame.mode == "crop":
            self.ev.log(f"{cp.tag}: no clean second person for a split ({two_people_share(pieces or []):.0%}); "
                        "this moment keeps its Classic versions.")
            return None
        if (role in ("black", "white") and ratio == "9:16" and captions and frame.mode in ("crop", "fit_blur")
                and not info.is_vertical):
            ckey = key + ("classic",)
            with self.__dict__.setdefault("_layout_lock", threading.Lock()):
                c_lock = self.__dict__.setdefault("_layout_locks", {}).setdefault(ckey, threading.Lock())
            with c_lock:
                if ckey not in cache:
                    cstats: dict = {}
                    cache[ckey] = analyse_layout(info, win.start, win.end, ratio, self.cancel,
                                                 words=[(w.start, w.end) for w in words], reactions=False,
                                                 matcher=getattr(self, "_matcher", None), stats=cstats,
                                                 quiet=list(getattr(win, "attacks", [])), fill=True,
                                                 his_at=self._his_at(), listen=None, stack=False, book=None,
                                                 fill_zoom_level=float(getattr(p, "fit_zoom", 0) or 0),
                                                 no_split=True)
                    self.__dict__.setdefault("_person_stats", {})[ckey] = cstats
            classic_pieces = cache.get(ckey) or None
            if classic_pieces:
                # (17 Nov) poore clip ka ek hamwar camera (jhatke nahi): aahista shuru, aahista ruke
                from app.render.framing import CLASSIC_EDGE, classic_camera
                sw_, sh_ = info.display_size
                classic_pieces = classic_camera(classic_pieces, half=min(0.5, sh_ * (1 - CLASSIC_EDGE) / sw_ / 2))
            classic_person = self.__dict__.get("_person_stats", {}).get(ckey) or {}
            need = int(getattr(p, "classic_min_screen", 60) or 60)
            seen = classic_person.get("visible", 1.0 if not p.main_names() and "visible" not in classic_person else 0.0)
            if classic_pieces and seen * 100 >= need:
                classic_bg = role
            elif classic_pieces and not split_ok:
                classic_bg = role                      # split saaf nahi banta: Classic behtar (user, 18 Nov)
                self.ev.log(f"{cp.tag}: main person on screen {seen:.0%}, but no clean split; Classic used.")
            else:
                self.ev.log(f"{cp.tag}: main person on screen {seen:.0%} (Classic needs {need}%); split style used.")
        if caption_y is None and not pieces and getattr(self, "_vcap_y", None):
            caption_y = self._vcap_y                       # khari ad: zoom ke baad video ke foran neeche
        if frame.mode == "stream":
            # (20 Nov) mix: har moment ka apna layout (round / stack baari baari), versions mein bhi badle
            if getattr(p, "stream_layout", "") == "mix":
                pick = zlib.crc32(f"{shash}:{cp.moment_id}:{cp.version}".encode()) % 2
                frame = replace(frame, layout=("round", "stack")[pick])
            caption_y = STREAM_CAPTION_Y[frame.layout]

        hook_text = pick_hook(words, p.main_names(), skip=teaser_text, avoid=beep_rel | guard_cut,
                              clean=self._teaser_clean(p))
        if hook_text and getattr(self, "_fixer", None) is not None:
            hook_text = self._fixer.fix_text(hook_text)        # aakhri spelling check
        super_text = ""
        if link:
            from app.edit.impact import make_super
            with getattr(self, "_titles_lock", threading.Lock()):
                used_sup = self.__dict__.setdefault("_supers_used", set())
                super_text = make_super(" ".join(w.text for k, w in enumerate(clip_words) if k not in masked), link,
                                        f"{shash}:{cp.tag}:{win.start:.2f}", used_sup)
                used_sup.add(super_text.lower())
        # viral andaaz ka title + hashtags (clip ki apni baat se), title card pe bhi yahi title
        from app.edit.title_rules import clean_title
        from app.edit.titles import make_hashtags, make_title
        from app.filters.guard import hook_is_clean
        from app.edit.title_rules import is_clean
        main_name = (p.main_person_name or "").strip()
        if not main_name and frame.mode == "stream":
            main_name = (getattr(p, "title_must", "") or "").strip()      # (20 Nov) stream: title ka subject streamer
        clip_text = " ".join(w.text for k, w in enumerate(clip_words) if k not in masked)
        reasons = list(win.score.reasons)
        # "jawab / sawal" wale titles sirf asal baat-cheet pe: main person akela bole (khud sawal, khud jawab)
        # to ye daawa jhoota hoga
        # asal baat-cheet tab jab koi aur bhi kaafi bole (QA_TALK_MAX); warna main person khud sawal kar raha
        # hai ya kisi video pe react kar raha hai (jaise ad pe tabsra): "jawab" wala daawa jhoota
        talk = person.get("speaking") if "speaking" in person else None
        conversation = talk is None or talk < QA_TALK_MAX
        if not conversation:
            reasons = [r for r in reasons if "question" not in r]
        qa = conversation and any("question and answer" in r for r in reasons) and "?" in clip_text
        engine = getattr(self, "_title_engine", None)
        seed = zlib.crc32(f"{shash}:{cp.tag}:{win.start:.2f}".encode())
        rules = p.title_rules()                              # is campaign ke title rules (andaaz, siyasi, emoji ...)
        with getattr(self, "_titles_lock", threading.Lock()):
            used = getattr(self, "_titles_used", set())
            blocked = [b.lower() for b in (list(s.general_banned_words) + list(p.banned_words)
                                           + list(p.banned_topics)
                                           + list(getattr(p, "title_banned_words", []) or [])) if b and b.strip()]

            def allowed(text: str) -> bool:
                """Campaign ke mana kiye lafz / topic title mein kabhi nahi."""
                low = text.lower()
                return not any(re.search(rf"\b{re.escape(b)}\b", low) for b in blocked)

            def fits(text: str) -> bool:
                """Title campaign ke har rule pe poora: mana lafz nahi, gaali nahi, siyasi (agar mana), sach."""
                return bool(text) and hook_is_clean(text, p.main_names()) and allowed(text) and rules.ok(text, clip_text)
            title_plain, title_emoji = "", ""
            title_unsure = False
            if link:
                # Super wali campaign: title bhi clip ke topic se (A aur B dono), Super se alag alfaaz
                from app.edit.impact import make_impact_title
                cand = make_impact_title(clip_text, link, f"{shash}:{cp.tag}:{win.start:.2f}", used, avoid=super_text)
                if cand and hook_is_clean(cand, p.main_names()) and allowed(cand) and is_clean(cand):
                    title_plain = cand
            if not title_plain and getattr(p, "strict_edits", False) and rules.must:
                # (15 Nov) sakht campaign (jaise Ami Horowitz): kisi aur ki baat naam ke saath quote nahi
                # (jhoota intisaab), sirf naam wale ka apna sawal ya seedha, izzat wala title
                title_plain = self._asks_title(rules, clip_text, fits, used, getattr(self, "_video_title", ""), seed)
            if not title_plain and frame.mode == "stream" and not rules.clean:
                # (20 Nov) stream clip: "{streamer} ... {game} 😭" (viral stream clips ka andaaz)
                from app.edit.stream_titles import split_emoji, stream_title
                game = next((t for t in rules.allow if t.lower() != main_name.lower()), "") or "GTA 6"
                cand = stream_title(clip_text, main_name, game, f"{shash}:{cp.tag}:{win.start:.2f}", used, ok=fits)
                if cand:
                    title_plain, title_emoji = split_emoji(cand)
            if title_plain:
                pass
            elif rules.clean:
                # seedha, sach title: clip ki apni line ya campaign ka topic, koi hype / emoji nahi
                lines = [x for x in re.split(r"(?<=[.!?])\s+", clip_text) if x.strip()]
                cand = clean_title(rules, clip_text, main_name, hook_text or "", f"{shash}:{cp.tag}:{win.start:.2f}",
                                   used, lines)
                if fits(cand):
                    title_plain = cand
            else:
                tried: set[str] = set(used)
                if engine is not None and seed % 5 != 0:         # 4 mein se 3+ viral saanchon se, baaki apne andaaz
                    for _ in range(4):
                        try:
                            viral = engine.best(clip_text, tried, seed=seed, qa=qa)
                        except Exception as exc:  # noqa: BLE001
                            log.warning("Viral title skipped: %s", exc)
                            viral = None
                        if not viral:
                            break
                        cand = rules.with_must(viral[0])
                        if fits(cand):
                            title_plain = cand
                            title_emoji = viral[1] or ("laugh" if any("wit" in r for r in reasons) else "shock")
                            break
                        tried.add(viral[0].lower())
                for k in range(8):
                    if title_plain:
                        break
                    base, emo = make_title(clip_text if k < 6 else "", main_name, f"{shash}:{cp.tag}:{win.start:.2f}:{k}",
                                           quote=hook_text if k < 6 else "", reasons=reasons, avoid=tried)
                    cand = rules.with_must(base)
                    if fits(cand):
                        title_plain, title_emoji = cand, emo
                    tried.add(base.lower())
            if not title_plain:
                # (28 Oct) kabhi bina title nahi: naye sab istemal ho chuke hon to purana saaf title dobara,
                # aur woh bhi na bane to campaign ka naam + clip ka topic (YouTube khaali title par file ka naam lagata)
                title_plain = self._fallback_title(rules, clip_text, main_name, hook_text, shash, cp, win, fits,
                                                   used, getattr(self, "_video_title", ""))
                if not title_plain:
                    # koi naya, rules wala title nahi bana: saada title (shayad pehle bhi aaya ho), clip "Check" mein
                    from app.edit.title_rules import _calm_case
                    from app.edit.video_title import clean_video_title
                    base = next((b for b in (clean_video_title(getattr(self, "_video_title", "")),
                                             rules.topic_name, main_name) if b), "")
                    title_plain = rules.with_must(_calm_case(base, [rules.topic_name, main_name])) if base else ""
                    title_unsure = True
            if not rules.emoji:
                title_emoji = ""                                 # campaign: emoji nahi
            if title_plain:
                used.add(title_plain.lower())
        viral_tags = []
        if engine is not None and s.hashtags_enabled and not rules.clean:
            try:
                viral_tags = engine.hashtags(clip_text, [])
            except Exception:  # noqa: BLE001
                viral_tags = []
        fixed_tags = p.hashtags
        if rules.must:
            fixed_tags = f"{fixed_tags} #{re.sub(r'[^a-z0-9]', '', rules.must.lower())}".strip()
        hashtags = make_hashtags(main_name, clip_text, f"{shash}:{cp.tag}", fixed=fixed_tags, viral=viral_tags,
                                 count=rules.max_tags, generic=not rules.clean) if s.hashtags_enabled else ""
        if hashtags and blocked:
            hashtags = " ".join(t for t in hashtags.split() if not any(b.replace(" ", "") in t for b in blocked))
        if hashtags:
            hashtags = rules.hashtags(hashtags, fixed=p.hashtags)   # gaali kabhi nahi, siyasi (agar mana), ginti ki had
        classic_title = title_plain if (classic_bg and not title_unsure) else ""
        if classic_title:
            # screen ke title mein quote ke nishaan nahi (pehla rangeen lafz saaf), "$150 ,000" jaisi likhai jori
            classic_title = re.sub(r"[\"\u201c\u201d]", "", classic_title)
            classic_title = re.sub(r"(\d) ,(\d)", r"\1,\2", classic_title).strip(" '\u2018\u2019")
            classic_title = " ".join(w[:1].upper() + w[1:] for w in classic_title.split())   # har lafz bara (reference)
        if classic_bg and link and classic_title:
            # (19 Nov, user) Super wali campaign (Diamonds): upar chhota viral title (clip ki apni line ya topic
            # ka chhota jumla), lamba Super neeche wali patti mein
            from app.edit.impact import classic_short_title
            with getattr(self, "_titles_lock", threading.Lock()):
                short_used = self.__dict__.setdefault("_short_titles_used", set())
                short = classic_short_title(clip_text, link, f"{shash}:{cp.tag}:{win.start:.2f}", short_used,
                                            ok=lambda t: allowed(t) and hook_is_clean(t, p.main_names()) and is_clean(t))
                if short:
                    short_used.add(short.lower())
                    classic_title = short
        if classic_bg and not classic_title:
            classic_bg = ""                            # Classic ka title pakka nahi bana: split andaaz
            self.ev.log(f"{cp.tag}: no sure title for the Classic look; split style used.")
        if classic_bg:
            pieces, person, caption_y = classic_pieces, classic_person, None   # variant ka apna rang (black / white)
        if not s.titles_enabled or not getattr(p, "titles", True):
            title_plain, title_emoji = "", ""          # titles band (app ya campaign): na title card, na naam mein title
        super_whole = bool(super_text)                 # Diamonds jaisa Super: poori clip
        if not super_text and getattr(p, "name_super", False) and captions:
            # (15 Nov) har clip mein campaign ka naam screen par (jaise "Ami Horowitz"): shuru ke ~4.5 s title,
            # jis mein title_must ka naam hamesha hota hai; title na ho to sirf naam
            must = rules.must or main_name
            super_text = title_plain if (title_plain and must and must.lower() in title_plain.lower()
                                         and len(title_plain.split()) <= 7) else must   # (15 Nov) lamba jumla nahi, chhoti line
            super_text = re.sub(r"\s*\|\s*", " | ", super_text).strip(" |")
        if not getattr(p, "line_on", True):
            super_text, super_whole = "", False        # (15 Nov) campaign line band: screen par koi line nahi
        wp_bg, wp_zoom = clip_background(getattr(p, "background", "black"), f"{shash}:{cp.tag}:bg"), 0.0
        if getattr(p, "whole_picture", False) and ratio == "9:16" and (cp.remix or cp.version):
            # re-edit / doosra cut: frame bhi badlo (zoom thora kam/zyada, background blur/black), taake har
            # version alag dikhe; pehla edit campaign ki apni setting par
            wp_bg, wp_zoom = reedit_frame(float(getattr(p, "fit_zoom", 0) or 0) or 1.7,
                                          getattr(p, "background", "black"),
                                          f"{shash}:{cp.tag}:{win.start:.2f}")
        classic_super = ""
        if classic_bg:
            # Classic: upar title; Super zaroori ho (Diamonds) to neeche wali patti mein, warna koi aur line nahi
            classic_super = super_text if (super_whole and link) else ""
            super_text, super_whole = "", False
        card_off = (self._card_for(win, teaser_text, title_plain, ratio, pieces, info)
                    if captions and not super_text and not classic_bg and frame.mode != "stream" else None)        # Super ho to title card nahi (Super upar)
        card = card_off is not None
        plain_edit = edit
        if card:
            edit = card_edit(edit, cp.tag)
        sfx_family = ""
        if s.sound_effects and not getattr(p, "light_edit", False) and not classic_bg:
            from app.edit.sfx import FAMILIES
            sfx_family = FAMILIES[zlib.crc32(f"{cp.moment_id}/{cp.version}".encode()) % len(FAMILIES)]

        disc_state = {"top": False, "cover": 0.0}      # purana disclosure dekh kar patti kahan / kitni unchi
        disc_region = self._free_region(info, win, ratio, pieces) if self._disclosure() else None

        music_file, music_off = ("", 0.0)
        if classic_bg and getattr(p, "music_allowed", False):
            music_file, music_off = pick_music(getattr(p, "music_folder", "") or "", f"{shash}:{cp.tag}:music")

        # (18 Nov, user) Classic v2: title ka ahem lafz rangeen; captions baari baari (reference ke chhote / hamare),
        # har moment ke kaale aur safed mein alag; Political ki aawaz reference jaisi oonchi
        classic_key, classic_caption = "", "classic_caps"
        if classic_bg and classic_title:
            from app.captions.builder import key_word
            classic_key = str(key_word(classic_title, clip_text, tuple(p.main_names())))
            m_no = int(re.sub(r"\D", "", cp.moment_id) or 0)
            classic_caption = "classic_ref" if (m_no % 2 == 0) == (classic_bg == "black") else "classic_caps"
        loud = bool(getattr(p, "loud_master", False))

        # (20 Nov) stream clips: viral stream clips jaisa bada safed headline (clip ka title) poori clip mein
        stream_head = ""
        if frame.mode == "stream" and captions and title_plain:
            stream_head = title_plain                       # naam saath (viral clips: "Kai Cenat ... 😭")

        def job(safe: bool) -> RenderJob:
            if classic_bg:
                return replace(plain_job(safe), classic=classic_bg, classic_title=classic_title, zoom="", hook="",
                               hook_force=False, bar="", look="", title_card="", card_offset=-1, sfx="",
                               name_card="", caption_y=None, cover_subs=False,
                               music=music_file, music_offset=music_off,
                               music_volume=float(getattr(p, "music_volume", 0.2) or 0.2),
                               classic_key=classic_key, classic_caption=classic_caption, loud=loud,
                               classic_super=classic_super)
            return replace(plain_job(safe), loud=loud)

        def plain_job(safe: bool) -> RenderJob:
            return RenderJob(source=info, segments=segments, words=clip_words, masked=masked, censor=censor,
                             out_path=out_tmp, ratio=ratio, frame=frame, captions=captions,
                             pieces=None if safe else pieces, caption_y=None if safe else caption_y,
                             platform=getattr(p, "platform", ""),
                             bar="" if (safe or self._disclosure()) else edit.bar, threads=getattr(self, "_encoder_threads", 0),
                             logo_box=getattr(self, "_logo_box", None), logo_mode=p.source_logo,
                             # campaign ki bani hui 9:16 ad (logo, news, disclosure apni jagah): zoom nahi, warna
                             # kinare (un ka disclosure, logo) katte hain
                             zoom="" if (safe or not s.zoom_effects or disc_region is not None
                                         or getattr(p, "light_edit", False) or frame.mode == "stream") else edit.zoom,
                             hook=super_text or stream_head or (hook_text if (edit.hook and self._hook_on(p) and captions) else ""),
                             hook_seconds=(max(SUPER_SECONDS, duration + 1.0) if super_whole else SUPER_SECONDS)
                             if super_text else (duration + 1.0 if stream_head else 0.0),
                             hook_force=bool(super_text or stream_head),
                             sfx="" if safe else sfx_family,
                             brand=p.logo if p.logo.enabled else None,
                             caption_style=edit.caption_style, entrance=edit.entrance,
                             accent=getattr(edit, "accent", ""), palette=getattr(edit, "palette", ""), hook_box=(super_look(f"{shash}:{cp.tag}:super")[0] if super_text
                                       else True if stream_head else getattr(edit, "hook_box", True)),
                             hook_color=(super_look(f"{shash}:{cp.tag}:super")[1] if super_text
                                         else STREAM_HEAD_COLOR if stream_head else getattr(edit, "hook_color", "")),
                             cover_subs=(not safe) and person.get("subs", 0.0) >= SUBS_COVER_SHARE,
                             name_card=self._name_card(src_path) if captions else "",
                             caption_pos="" if safe else getattr(edit, "cap_pos", ""),
                             caption_mode="" if safe else getattr(edit, "cap_mode", ""),
                             caption_size=1.0 if safe else getattr(edit, "cap_size", 1.0),
                             look="" if safe else edit.look, sharpen=s.sharpen and not safe,
                             loudness=s.loudness_normalize, censor_mode=mode if mode != "cut" else "",
                             quality=RENDER_QUALITY, temp_dir=tmp,
                             hq=s.youtube_hq, gpu_encode=getattr(self, "_gpu_encode", False),
                             gpu_decode=getattr(self, "_gpu_decode", False),
                             disclosure=self._disclosure(),
                             disclosure_top=disc_state["top"], disclosure_cover=disc_state["cover"],
                             disclosure_place=("top" if frame.mode == "stream" else p.disclosure_place),
                             disclosure_region=(None if frame.mode == "stream" else disc_region),
                             background=wp_bg,
                             blur_bands=tuple(self._ticker_bands(info)) if p.hide_ticker else (),
                             level_voices=bool(getattr(p, "level_voices", False)),
                             fit_zoom=wp_zoom if wp_zoom else ((float(getattr(p, "fit_zoom", 0) or 0)
                                       if float(getattr(p, "fit_zoom", 0) or 0) > 1.0
                                       else fit_zoom_for(info, getattr(p, "fit_bars", "full"))) if ratio == "9:16" else 1.0),
                             title_card=title_plain if (card and not safe) else "", card_offset=card_off if card else -1,
                             title_emoji=title_emoji,
                             channel_name=s.channel_name if (s.show_channel_name and s.channel_name) else "")

        def render_attempts() -> tuple[bool, str]:
            repaired_, problem_ = False, ""
            for attempt in (False, True):
                try:
                    render_clip(job(attempt), on_progress=progress, cancel_event=self.cancel)
                    qc = check_clip(out_tmp, final_size(ratio, s.youtube_hq), duration,
                                    (info.path, win.start, win.end))
                    if qc.ok:
                        return attempt, ""
                    problem_ = qc.summary
                except Cancelled:
                    out_tmp.unlink(missing_ok=True)
                    raise
                except FFmpegError as exc:
                    problem_ = f"{exc} {exc.tail[-300:]}"
                log.warning("%s v%d attempt %d failed: %s", cp.moment_id, cp.version, 1 + int(attempt), problem_)
            return repaired_, problem_

        repaired, problem = render_attempts()
        if card and not problem:
            # aakhri jaanch: kisi ke baal safed hisse ko chhu rahe hon to title card hatao, poori screen pe dobara
            from app.qc.check import card_head_clear
            from app.render.renderer import CARD_TOP
            top = CARD_TOP[1 if (s.show_channel_name and s.channel_name) else 0]
            try:
                clear = card_head_clear(out_tmp, top)
            except Exception as exc:  # noqa: BLE001 - jaanch na ho sake to ehtiyat: title card nahi
                log.warning("Title card head check failed: %s", exc)
                clear = False
            if not clear:
                log.info("%s: title card would touch a head; made full screen instead", cp.tag)
                card, edit = False, plain_edit
                repaired, problem = render_attempts()
        disc_check = ""
        if self._disclosure() and not problem and not p.keep_old_disclosure:
            # video ka apna purana disclosure: neeche ho to patti dhakti hai, upar ho to patti upar
            disc_check, retry = self._old_disclosure(out_tmp, job, ratio, disc_state, cp)
            if retry:
                repaired, problem = render_attempts()
                if not problem:
                    disc_check = self._old_disclosure_gone(out_tmp, job, ratio, disc_state)
        if problem:
            if not out_tmp.exists():
                self.ev.log(f"{cp.moment_id} v{cp.version}: could not be made ({problem[:120]})")
                return None
            rating = "below"           # playable but imperfect -> never mixed with good clips
        if "visible" in person and (person.get("visible", 0) * 100 < p.main_person_min_screen
                                    or person.get("speaking", 0) * 100 < p.main_person_min_speaking
                                    or person.get("hook", 1.0) < HOOK_PERSON_SHARE):
            rating = "below"           # main person not on screen / talking enough: never Recommended
            if person.get("speaking", 1.0) * 100 < p.main_person_min_speaking:
                getattr(self, "_bad_moments", set()).add(cp.moment_id)   # is moment ke baaki cuts nahi
            problem = (f"{', '.join(p.main_names()) or 'main person'} on screen {person.get('visible', 0):.0%}, "
                       f"speaking {person.get('speaking', 0):.0%}, in the first seconds {person.get('hook', 1.0):.0%}")

        if num_check is not None and num_check.unsure and rating != "below":
            rating = "check"           # captions mein pakka na hone wala number / lafz: "Check" folder
            problem = problem or num_check.problem
        if disc_check and rating != "below":
            rating = "check"           # disclosure pakka saaf nahi: "Check" folder, kabhi deliver nahi
            problem = problem or disc_check
        if title_unsure and rating != "below" and s.titles_enabled and getattr(p, "titles", True):
            rating = "check"           # (15 Nov) koi achha alag title nahi bana: post se pehle title dekh lo
            problem = problem or "no fitting new title: please write one before posting"
        if getattr(win, "check", False) and rating != "below":
            rating = "check"           # protection guard not sure: "Check" folder, never delivered
            problem = problem or "protection guard: please check before posting"
        with self.__dict__.setdefault("_save_lock", threading.Lock()):
            rules = self._rules_report(win, duration, masked, guard_cut, person, problem)
            info_out = self._save_clip(cp, edit, win, words, out_tmp, root, rating, problem, repaired,
                                       duration, masked, src_path, shash, rules,
                                       titles=(title_plain, title_emoji, hashtags))
            if info_out is not None and "visible" in person:
                info_out["person"] = person
            return info_out

    # --- title card ka faisla (sirf jahan faida, sirf jab sar na kate) ------
    def _disclosure(self) -> str:
        """Campaign ka on-screen disclosure (lafz ba lafz), na ho to ""."""
        p = getattr(self, "profile", None)
        if p is None or not p.disclosure_enabled:
            return ""
        return (p.disclosure_text or "").strip()

    def _check_numbers(self, info, win, clip_words, cp):
        """Clip ke captions: numbers screen par likhe numbers se milao, shak wale lafz batao (Check ki wajah)."""
        from app.qc.numbers import NumberCheck, canon, check_words
        if not any(canon(w.text) or w.doubt for w in clip_words):
            return None
        screen: set[str] = set()
        if any(canon(w.text) for w in clip_words):
            from app.qc.numbers import screen_numbers
            try:
                screen = screen_numbers(info.path, win.start, win.end)
            except Exception as exc:  # noqa: BLE001 - screen na parh sake to sirf suna hua
                log.warning("Screen number check failed: %s", exc)
        try:
            result = check_words(clip_words, screen, self.profile.main_names() + list(self.profile.names))
        except Exception as exc:  # noqa: BLE001
            log.warning("Caption number check failed: %s", exc)
            return NumberCheck()
        for old, new in result.fixed:
            self.ev.log(f"{cp.tag}: caption number {old} corrected to {new} (as written on screen).")
        return result

    def _cold_open_on(self, p) -> bool:
        """Cold open (sab se mazboot line shuru mein): campaign On / Off, ya auto: clean titles mein band."""
        mode = getattr(p, "cold_open_mode", "auto")
        if mode in ("on", "off"):
            return mode == "on"
        return bool(self.s.cold_open) and not p.title_rules().clean

    def _hook_on(self, p) -> bool:
        """Shuru mein screen par jumla (hook): campaign On / Off, ya auto: clean titles mein band."""
        mode = getattr(p, "hook_mode", "auto")
        if mode in ("on", "off"):
            return mode == "on"
        return bool(self.s.hook_titles) and not p.title_rules().clean

    def _topic_spans(self, p, transcript) -> list[tuple[float, float]]:
        """Campaign ke topic ke khilaf jumle (Topic protection guard On ho to)."""
        if not getattr(p, "topic_guard", False):
            return []
        from app.filters.topic_guard import TopicGuard
        terms = (p.topic_terms or p.title_must or "").strip()
        spans = TopicGuard(terms, p.topic_bad_words).spans(transcript.words)
        if spans:
            self.ev.log(f"Topic protection: {len(spans)} sentence(s) against the campaign topic are never clipped.")
        return spans

    def _inner_video(self, info, work):
        """Khari ad ke andar chalti video (upar, neeche), work folder mein yaad; None = aam khari video."""
        path = work / "inner_video.json"
        try:
            if path.exists():
                got = json.loads(path.read_text(encoding="utf-8"))
                return tuple(got) if got else None
        except (OSError, ValueError):
            pass
        try:
            from app.render.screen_scan import find_inner_video
            band = find_inner_video(info.path, info.duration)
        except Exception as exc:  # noqa: BLE001 - na mile to zoom nahi
            log.warning("Inner video check skipped: %s", exc)
            band = None
        try:
            path.write_text(json.dumps(list(band) if band else []), encoding="utf-8")
        except OSError:
            pass
        return band

    def _ticker_bands(self, info) -> list[tuple[float, float]]:
        """News ki chalti patti(yan) is video mein (ek dafa naapi, cache mein)."""
        cache = self.__dict__.setdefault("_tickers", {})
        key = str(info.path)
        with self.__dict__.setdefault("_ticker_lock", threading.Lock()):
            if key not in cache:
                path = getattr(self, "_work", None)
                path = path / "ticker.json" if path is not None else None
                bands = None
                if path is not None and path.is_file():
                    try:
                        bands = [tuple(b) for b in json.loads(path.read_text())]
                    except (OSError, ValueError):
                        bands = None
                if bands is None:
                    from app.render.screen_scan import find_ticker_bands
                    try:
                        bands = find_ticker_bands(info.path, 0.0, info.duration, samples=8)
                    except Exception as exc:  # noqa: BLE001 - naap na sake to blur nahi (clip phir bhi bane)
                        log.warning("Ticker check failed: %s", exc)
                        bands = []
                    if path is not None:
                        try:
                            path.write_text(json.dumps(bands))
                        except OSError:
                            pass
                    if bands:
                        self.ev.log("News ticker found: it is blurred on every clip.")
                cache[key] = bands
            return cache[key]

    def _free_region(self, info, win, ratio: str, pieces) -> tuple[float, float] | None:
        """Disclosure 'video ke neeche': video khud 9:16 ho (campaign ki bani hui ad) to us mein khaali jagah."""
        p = self.profile
        if p.disclosure_place != "below_video" or ratio != "9:16":
            return None
        sw, sh = info.display_size
        if not (sh > sw and abs(sw / sh - 9 / 16) < 0.02):
            return None                                   # sirf jab poora frame waisa hi dikhe (koi crop / zoom nahi)
        if pieces and any(getattr(pc, "band", 1.0) < 0.999 or pc.mode != "crop" for pc in pieces):
            return None
        from app.render.renderer import UI_SAFE
        from app.render.screen_scan import find_free_region
        try:
            return find_free_region(info.path, win.start, win.end, 0.05, 0.40, UI_SAFE)
        except Exception as exc:  # noqa: BLE001
            log.warning("Free space check failed: %s", exc)
            return None

    def _strip(self, job, ratio: str, state: dict) -> tuple[float, float, float]:
        """(patti y0, y1, unchai) frame ke hisse mein, jaisi abhi render hui."""
        from app.render.renderer import disclosure_span
        y0, y1 = disclosure_span(job(False)) or (1.0, 1.0)
        return y0, y1, y1 - y0

    def _old_disclosure(self, path: Path, job, ratio: str, state: dict, cp) -> tuple[str, bool]:
        """Pehli clip parh kar: (Check ki wajah ya "", dobara banana hai?)."""
        from app.qc import old_disclosure as od
        if not od.available():
            log.warning("Text reader (OCR) not installed: old on-screen disclosure not checked")
            return "", False
        try:
            from app.captions.builder import disclosure_band
            from app.render.renderer import OUTPUTS
            out_w, out_h = OUTPUTS[ratio]
            y0, y1, band = self._strip(job, ratio, state)
            pl = od.plan(od.scan(path, self._disclosure(), (y0, y1)), band,
                         lambda c: disclosure_band(self._disclosure(), out_w, out_h, c)[2] / out_h)
        except Exception as exc:  # noqa: BLE001 - jaanch na ho sake to ehtiyat: Check
            log.warning("Old disclosure check failed: %s", exc)
            return f"old disclosure check failed ({exc})"[:160], False
        if pl.action == "check":
            return pl.reason, False
        if pl.action in ("top", "bottom"):
            log.info("%s: %s", cp.tag, pl.reason)
            state.update(top=pl.action == "top", cover=pl.cover)
            return "", True
        return "", False

    def _old_disclosure_gone(self, path: Path, job, ratio: str, state: dict) -> str:
        """Patti badalne ke baad aakhri jaanch: purana disclosure ab bhi dikhe to Check ki wajah."""
        from app.qc import old_disclosure as od
        try:
            y0, y1, _band = self._strip(job, ratio, state)
            again = od.scan(path, self._disclosure(), (y0, y1))
        except Exception as exc:  # noqa: BLE001
            return f"old disclosure check failed ({exc})"[:160]
        if again.clean:
            return ""
        words = "; ".join(sorted({b.text for b in again.boxes}))[:100]
        return f"old disclosure still visible after moving the strip ({words})"

    def _card_for(self, win, teaser_text: str, title: str, ratio: str, pieces, info) -> int | None:
        """Title card lagana hai to 9:16 frame se kaatne ki jagah (px), warna None."""
        mode = self.s.title_cards
        if mode == "off" or not title or ratio != "9:16" or not pieces or self._disclosure():
            return None                                  # disclosure ki patti: saaf look, title card nahi
        if mode == "auto":
            if teaser_text:
                return None                    # cold open pehle hi pakadta hai
            if "strong opening line" in (win.score.reasons or []) or getattr(win.score, "hook", 0) > CARD_HOOK_MAX:
                return None                    # pehli line hi pakadti hai (sawal / zordar): seedha video behtar
        from app.render.framing import card_crop_offset
        return card_crop_offset(info, pieces)

    # ---------------------------------------------------------------------
    #  Aakhri hal ka title (29 Oct): kabhi bina title nahi, aur har clip alag
    #  Tarteeb: 1) clip ki apni baat (line / topic)  2) asal video ke title
    #  se (har clip thora alag)  3) saaf aam jumle (naam ke saath)  4) campaign
    #  ka naam  5) video title / naam + "(Part n)" (hamesha bane)
    # ---------------------------------------------------------------------
    # --- (15 Nov) sakht campaign ka title: naam wale ka sawal / seedha topic, kisi ka quote nahi ---
    # Kaam: "Ami Horowitz: <kisi protester ki baat>" jaisa title jhoota intisaab aur manfi lagta hai.
    # Pehle: clip ka sawal (street interview mein sawal naam wala poochta hai) "<Naam> Asks: "...?"".
    # Phir: video ka apna title / clip ka topic naam ke saath. Phir: izzat wale aam title (Part n tak).
    ASKS_GENERIC = ["{N} Asks the Tough Questions", "{N} Talks to the Crowd", "{N} Hits the Street",
                    "{N} Gets Real Answers", "{N} Asks What People Really Think", "{N} Wants to Know",
                    "{N} Starts the Conversation", "{N} Street Interview", "{N} Asks the Crowd",
                    "{N} Goes Straight to the Source"]
    # clip ke topic se (topic clip ki apni baat se nikalta hai)
    ASKS_TOPIC = ["{N} Asks About {T}", "{T}: {N} Asks the Crowd", "{N} on the Street: {T}",
                  "What People Really Think About {T}", "{N} Gets Answers on {T}", "{T}, Asked on the Street",
                  "{N} Asks People About {T}", "Real Answers on {T}", "{T}: Street Interview with {N}",
                  "{N} Puts {T} to the Crowd"]

    @classmethod
    def _asks_title(cls, rules, clip_text: str, fits, used: set, video_title: str, seed: int) -> str:
        from app.edit.title_rules import POLITICAL_TOPICS, _calm_case
        from app.edit.titles import find_topics
        from app.edit.video_title import video_title_variants
        name = rules.must

        def ok(c: str) -> bool:
            return bool(c) and c.lower() not in used and fits(c)
        for q in (x.strip() for x in re.split(r"(?<=[.!?])\s+", clip_text) if x.strip().endswith("?")):
            q = re.sub(r"^(so|and|but|okay|ok|well|um|uh)[, ]+", "", q, flags=re.I).strip()
            if 4 <= len(q.split()) <= 14:
                cand = f"{name} Asks: \u201c{_calm_case(q.rstrip('?').strip(), [name])}?\u201d"
                if ok(cand):
                    return cand
        topics = find_topics(clip_text, [name, *rules.allow]
                             + ([] if rules.political else sorted(POLITICAL_TOPICS)))[:3]
        cands = []
        for k, topic in enumerate(topics):
            shift = (seed + k) % len(cls.ASKS_TOPIC)
            cands += [g.replace("{N}", name).replace("{T}", topic)
                      for g in cls.ASKS_TOPIC[shift:] + cls.ASKS_TOPIC[:shift]]
        cands += [rules.with_must(_calm_case(v, [name])) for v in video_title_variants(video_title, name, seed)]
        k = seed % len(cls.ASKS_GENERIC)
        cands += [g.replace("{N}", name) for g in cls.ASKS_GENERIC[k:] + cls.ASKS_GENERIC[:k]]
        for cand in cands:
            cand = _calm_case(cand, [name]) if cand else ""
            if ok(cand):
                return cand
        return ""      # (15 Nov) "(Part 10)" jaise title nahi: koi achha na bane to clip "Check" mein

    @staticmethod
    def _fallback_title(rules, clip_text: str, name: str, hook_text: str, shash: str, cp, win, fits,
                        used: set | None = None, video_title: str = "") -> str:
        from app.edit.title_rules import CLEAN_GENERIC, _calm_case, clean_title
        from app.edit.titles import find_topic
        from app.edit.video_title import video_title_variants
        used = used if used is not None else set()

        def ok(c: str) -> bool:
            return bool(c) and c.lower() not in used and fits(c)
        lines = [x for x in re.split(r"(?<=[.!?])\s+", clip_text) if x.strip()]
        cand = clean_title(rules, clip_text, name, hook_text or "", f"{shash}:{cp.tag}:{win.start:.2f}:again",
                           used, lines, deep=True)   # (31 Oct) clip ki har line aazmao, aam title se pehle
        if ok(cand):
            return cand
        from app.edit.title_rules import POLITICAL_TOPICS
        topic, _ = find_topic(clip_text, [name, rules.must, *rules.allow]
                              + ([] if rules.political else sorted(POLITICAL_TOPICS)))
        seed = zlib.crc32(f"{shash}:{cp.tag}".encode())
        k = seed % len(CLEAN_GENERIC)
        generic = [g.replace("{N}", name) for g in CLEAN_GENERIC[k:] + CLEAN_GENERIC[:k]] if name else []
        video = video_title_variants(video_title, name, seed)
        for cand in (f"{rules.topic_name}: {topic}" if rules.topic_name and topic else "",
                     f"{name} on {topic}" if name and topic else "",
                     f"{topic}: What {name} Said" if name and topic else "",
                     *video, *generic, rules.topic_name, name):
            cand = rules.with_must(_calm_case(cand, [rules.topic_name, name])) if cand else ""
            if ok(cand):
                return cand
        return ""      # (15 Nov) numbered "(Part n)" title nahi; runner clip ko "Check" mein bhejta hai

    # --- har clip ki rules report (Clips List mein "Rules" column) ---------
    def _rules_report(self, win, duration: float, masked, guard_cut, person: dict, problem: str) -> str:
        p = self.profile
        lo = getattr(self, "_min_len", 0)
        parts = [f"length {duration:.1f}s (min {lo}s) {'OK' if duration >= lo - 0.05 else 'SHORT'}"]
        if "visible" in person:
            parts.append(f"main person on screen {person.get('visible', 0):.0%}, talking {person.get('speaking', 0):.0%}")
        if p.protect_main_person and (p.main_names() or getattr(self, "_guard_auto", False)):
            g = len(getattr(win, "attacks", []) or [])
            parts.append("protection: " + (f"{g} attack(s) handled, {len(guard_cut)} words cut" if g else "clean")
                         + (", CHECK" if getattr(win, "check", False) else ""))
        parts.append(f"swearing: {len(masked)} beeped" if masked else "swearing: clean")
        parts.append(f"QC: {problem[:80]}" if problem else "QC OK")
        return "; ".join(parts)

    def _save_clip(self, cp, edit, win, words, out_tmp, root, rating, problem, repaired, duration, masked,
                   src_path, shash, rules: str = "", titles: tuple[str, str, str] = ("", "", "")) -> dict | None:
        """Steps after a clip is rendered; one clip at a time (numbers, names, database)."""
        from app.edit.titles import full_title
        s, p = self.s, self.profile
        title_plain, title_emoji, hashtags = titles
        # 1) Put the file safely into its folder under a temporary name.
        #    Failing here costs no clip number.
        batch = self.db.current_batch(self.req.campaign_id, s.device_code)
        if getattr(self, "_phase", 0):
            batch = f"{batch} Phase {self._phase}".strip()        # har phase ka apna folder
        folder = rating_folder(root, rating, batch)
        staged = folder / f"_saving_{cp.moment_id}_{cp.version}.mp4"
        try:
            move_with_retry(out_tmp, staged)
        except OSError as exc:
            log.error("Clip %s v%d could not be saved to %s: %s", cp.moment_id, cp.version, folder, exc)
            self.ev.log(f"{cp.moment_id} v{cp.version}: could not be saved ({exc})")
            return None

        # 2) Only now take the next number, so numbering never has gaps.
        numbers, batch = self.db.reserve_numbers(self.req.campaign_id, s.device_code, 1)
        label = clip_label(p.name, s.device_code, numbers[0])
        first_sentence = []
        for w in words:
            first_sentence.append(w.text)
            if w.ends_sentence:
                break
        from app.filters.guard import hook_is_clean
        title_hook = hook_from_text(" ".join(first_sentence))
        if not hook_is_clean(title_hook, p.main_names()):
            title_hook = ""                    # file title mein kabhi bure / khatarnaak lafz nahi
        title = clip_title(p.title, title_hook, numbers[0]) or title_plain     # campaign ka apna title pehle
        post_title = post_title_of(title_plain, getattr(p, "title_suffix", ""))
        if getattr(p, "file_name", "label") == "title" and post_title:
            # (30 Oct) TikTok post ke liye: file ka naam hi post ka title (Drive se copy kar ke caption mein)
            final = unique_path(folder, title_filename(post_title) + ".mp4")
        elif s.upload_names and title_plain:
            # upload ke liye tayar naam: sirf "Title 😳 #hashtags" (label History mein rehta hai)
            name = safe_filename(f"{full_title(title_plain, title_emoji)} {hashtags}".strip(), 180)
            final = unique_path(folder, name + ".mp4")
        else:
            final = unique_path(folder, clip_filename(f"{label} {cp.tag}", title, p.hashtags))
        try:
            move_with_retry(staged, final)          # rename inside the same folder
        except OSError as exc:
            # The number is taken, so keep the clip (under the staged name)
            # rather than leave a gap; the Library shows where it is.
            log.error("%s could not be renamed (%s); kept as %s", label, exc, staged.name)
            final = staged
        reasons = ", ".join(win.score.reasons)
        if problem:
            reasons = f"QC: {problem[:120]}; {reasons}"
        self.db.add_clip(
            campaign_id=self.req.campaign_id, label=label, number=numbers[0], device_code=s.device_code,
            batch_label=batch, source_path=str(src_path), source_hash=shash, moment_id=cp.moment_id,
            version=cp.version, block=cp.block, start_sec=win.start, end_sec=win.end, duration=round(duration, 2),
            score=win.score.total, score_reasons=reasons, rating=rating, file_path=str(final),
            style=json.dumps({**edit.to_dict(), "tag": cp.tag, "rules": rules,
                              "title": full_title(post_title or title_plain, title_emoji),
                              "title_plain": title_plain, "hashtags": hashtags}), fingerprint=f"{win.start:.2f}-{win.end:.2f}",
            beeps=len(masked), repaired=int(repaired),
        )
        return {"label": label, "rating": rating, "score": win.score.total, "file": str(final),
                "repaired": repaired, "style": edit.caption_style, "remix": cp.remix, "edit": edit.to_dict(),
                "start": win.start, "end": win.end, "duration": round(duration, 2),
                "reasons": list(win.score.reasons), "title": full_title(post_title or title_plain, title_emoji),
                "hashtags": hashtags}

    # --- after the run ---------------------------------------------------
    def _write_outputs(self, summary: RunSummary) -> None:
        """PC pe koi Excel / note / report file nahi (user ka faisla, 25 Oct 2026).
        Saara data tool ke andar (database) rehta hai aur History page pe dikhta hai."""
        return
