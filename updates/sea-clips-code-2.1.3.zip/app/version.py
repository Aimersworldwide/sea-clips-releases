"""
=====================================================================
  SEA CLIPS Auto Clipper (by AIMERS Worldwide)
  Kaam: app ka version (ek hi jagah).
  Version information (single source of truth)
=====================================================================
"""

APP_NAME = "SEA CLIPS Auto Clipper"
COMPANY = "AIMERS Worldwide"
POWERED_BY = "Powered by Rayyan"
VERSION = "2.1.3"
UPDATE_REPO = "Aimersworldwide/sea-clips-releases"   # sirf releases (installer + code pack), code private
